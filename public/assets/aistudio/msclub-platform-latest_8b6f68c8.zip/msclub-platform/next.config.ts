import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /**
   * This platform is data-driven and authenticated: every dashboard, admin and
   * member page reads the database at request time. The Cache Components model
   * is intentionally not adopted here — `cacheComponents` stays off so routes
   * render dynamically with the conventional Server Component semantics.
   */
  cacheComponents: false,
  partialPrefetching: false,

  reactStrictMode: true,

  turbopack: {
    root: process.cwd(),
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },

  images: {
    remotePatterns: [
      { protocol: "https", hostname: "res.cloudinary.com" },
      { protocol: "https", hostname: "i.ytimg.com" },
      { protocol: "https", hostname: "img.youtube.com" },
      { protocol: "https", hostname: "images.unsplash.com" },
    ],
  },

  serverExternalPackages: ["cloudinary", "resend", "pdfkit"],

  // Fonts are read from disk at request time; make sure they ship with the PDF route.
  outputFileTracingIncludes: { "/api/certificates/[code]/pdf": ["./src/fonts/pdf/**"] },

  poweredByHeader: false,

  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "X-Frame-Options", value: "DENY" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
          { key: "Strict-Transport-Security", value: "max-age=63072000; includeSubDomains; preload" },
          // Camera is needed by the staff QR scanner (same origin only).
          { key: "Permissions-Policy", value: "camera=(self), microphone=(), geolocation=(), payment=()" },
          { key: "Cross-Origin-Opener-Policy", value: "same-origin" },
        ],
      },
    ];
  },
};

export default nextConfig;
