# Microsoft Student Clubs Platform — Innovation University

Bilingual (Arabic RTL / English) platform for a student club: public site, member portal, admin console, events with QR attendance, gamification (XP, levels, badges, leaderboards), learning hub, certificates.

**Status:** see [`docs/PROGRESS.md`](docs/PROGRESS.md) — it lists exactly what is built, tested and still missing.

## Stack
Next.js 16 (App Router, `proxy.ts`) · React 19 · Prisma 7 (client generated to `src/generated`) · PostgreSQL · Auth.js v5 · Zod 4 · Tailwind + shadcn/ui · Recharts · pdfkit · Vitest.

## Architecture in one minute
- **Authorization is server-side everywhere.** `src/proxy.ts` is only an optimistic redirect + CSP nonce. Every page / action / route handler re-checks via `src/lib/auth/dal.ts` (`requireAuth`, `requirePermission`, `requireTeamAccess`, `assertPermission`). Permissions are read from the database on each request.
- **Mutations** go through `src/lib/actions/admin.ts` (`runAction`: auth → permission → rate limit → Zod) and return codes, never English prose.
- **XP is a ledger** (`xp_transactions`): append-only, idempotency-keyed, row-locked; reversals add compensating rows (`src/lib/xp.ts`).
- **Event passes** are HMAC-signed (`src/lib/qr.ts`), nothing secret stored; capacity/waitlist/attendance are transactional (`registration.ts`, `attendance.ts`).
- i18n: `src/lib/i18n/{en,ar,admin-en,admin-ar}.ts` (Arabic is type-checked against English).

## Local setup
```bash
npm install                      # also runs prisma generate + copies the QR decoder WASM
cp .env.example .env             # fill in placeholders (never commit .env)
# PostgreSQL: local server, or `npx prisma dev`
npx prisma migrate deploy        # apply migrations (uses DIRECT_URL, falls back to DATABASE_URL)
SEED_ADMIN_EMAIL=you@example.com SEED_ADMIN_PASSWORD='a-long-password' npm run seed
npm run dev
```
Seed creates roles + permissions, levels, points rules, badges, tracks, certificate templates, a super admin, and clearly-marked **demo** events/courses.

## Tests
```bash
createdb msclub_test             # the database name MUST contain "test" (tests refuse otherwise)
npm run test:db                  # applies migrations to the test DB (TEST_DATABASE_URL optional)
npm test                         # Vitest against real PostgreSQL
```
Other checks: `npm run typecheck`, `npm run lint`, `npm run build`.

## Environment variables (see `.env.example`)
`DATABASE_URL` (pooled) · `DIRECT_URL` (migrations) · `AUTH_SECRET` · `NEXT_PUBLIC_APP_URL` · `RESEND_API_KEY`/`EMAIL_FROM` (without it e-mails print to the console) · `CLOUDINARY_*` (uploads; otherwise local `public/uploads`, dev only) · `QR_SECRET` (optional, defaults to `AUTH_SECRET`) · `CRON_SECRET` (protects `/api/cron/event-reminders`).

## Deploying (Vercel + Neon)
1. Create a Neon project; use the **pooled** string as `DATABASE_URL` and the **direct** string as `DIRECT_URL`.
2. Set all env vars in Vercel; run `npx prisma migrate deploy` (CI or locally against the direct URL) and the seed once.
3. Configure Cloudinary (the serverless filesystem is read-only).
4. Add a cron (Vercel Cron or any scheduler) calling `GET /api/cron/event-reminders` with `Authorization: Bearer $CRON_SECRET` every ~15 minutes.

## YouTube note
Lessons use YouTube video IDs (validated server-side, rendered via `youtube-nocookie`). **Unlisted videos are not private**: anyone with the URL can watch them on YouTube. The platform can only protect its own pages.

## Scripts
`seed`, `db:seed`, `test`, `test:unit`, `test:watch`, `test:db`, `typecheck`, `lint`, `build`.
