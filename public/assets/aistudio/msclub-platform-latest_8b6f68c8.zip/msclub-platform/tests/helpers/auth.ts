import type { AuthContext } from "@/lib/auth/dal";
import type { PermissionKey } from "@/lib/rbac/permissions";

/** Mutable holder read by the mocked `getAuthContext` (see `mockAuth`). */
export const session: { current: unknown } = { current: null };

export function ctxFor(user: { id: string; name: string; email: string }, permissions: PermissionKey[] = [], opts: { superAdmin?: boolean } = {}): AuthContext {
  return {
    userId: user.id, id: user.id, name: user.name, email: user.email, image: null, status: "ACTIVE", locale: "EN",
    isActive: true, isSuperAdmin: opts.superAdmin ?? false, roles: [], permissions: new Set(permissions),
    teamPermissions: new Map(), teams: [],
  };
}

export function signInAs(ctx: AuthContext | null) {
  session.current = ctx;
}

export function fd(values: Record<string, string | string[]>): FormData {
  const f = new FormData();
  for (const [k, v] of Object.entries(values)) for (const item of Array.isArray(v) ? v : [v]) f.append(k, item);
  return f;
}
