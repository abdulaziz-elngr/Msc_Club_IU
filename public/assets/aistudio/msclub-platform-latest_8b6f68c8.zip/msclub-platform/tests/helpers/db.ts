import { db } from "@/lib/db";

/** Truncates EVERY application table (new tables are covered automatically). */
export async function resetDb() {
  const rows = await db.$queryRaw<{ tablename: string }[]>`
    SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename <> '_prisma_migrations'`;
  if (rows.length === 0) return;
  await db.$executeRawUnsafe(`TRUNCATE ${rows.map((r) => `"${r.tablename}"`).join(", ")} RESTART IDENTITY CASCADE`);
}

let counter = 0;
export async function makeUser(overrides: Record<string, unknown> = {}) {
  counter += 1;
  return db.user.create({
    data: {
      name: `Test User ${counter}`,
      email: `user${counter}-${Date.now()}@example.test`,
      status: "ACTIVE",
      emailVerified: new Date(),
      ...overrides,
    },
  });
}

export async function makeEvent(overrides: Record<string, unknown> = {}) {
  counter += 1;
  const startsAt = new Date(Date.now() + 2 * 3600_000);
  return db.event.create({
    data: {
      slug: `event-${counter}-${Date.now()}`,
      title: `Test Event ${counter}`,
      status: "REGISTRATION_OPEN",
      startsAt,
      endsAt: new Date(startsAt.getTime() + 2 * 3600_000),
      capacity: 10,
      waitlistEnabled: true,
      attendancePoints: 20,
      ...overrides,
    },
  });
}

export async function seedRules() {
  await db.pointsRule.createMany({
    data: [{ key: "event.attendance", activityType: "attendance", label: "Event attendance", points: 10, referenceType: "ATTENDANCE" }],
    skipDuplicates: true,
  });
}

export async function seedLevels() {
  await db.level.createMany({
    data: [
      { key: "l1", name: "Beginner", order: 1, minXp: 0 },
      { key: "l2", name: "Explorer", order: 2, minXp: 50 },
      { key: "l3", name: "Builder", order: 3, minXp: 150 },
    ],
    skipDuplicates: true,
  });
}

/** Creates roles with the given permission keys (permissions are created on demand). */
export async function makeRole(key: string, permissionKeys: string[] = []) {
  const role = await db.role.upsert({ where: { key: key as never }, update: {}, create: { key: key as never, name: key } });
  for (const pk of permissionKeys) {
    const perm = await db.permission.upsert({ where: { key: pk }, update: {}, create: { key: pk, group: pk.split(".")[0], label: pk } });
    await db.rolePermission.createMany({ data: [{ roleId: role.id, permissionId: perm.id }], skipDuplicates: true });
  }
  return role;
}

export async function makeApplication(userStatus = "APPLICANT", status = "SUBMITTED") {
  const user = await makeUser({ status: userStatus });
  const application = await db.memberApplication.create({ data: { userId: user.id, status: status as never } });
  return { user, application };
}
