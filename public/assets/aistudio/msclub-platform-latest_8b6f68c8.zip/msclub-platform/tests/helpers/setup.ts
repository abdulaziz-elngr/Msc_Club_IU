import { vi } from "vitest";

/**
 * Test environment.
 * The suite talks to a REAL PostgreSQL database and truncates it between tests,
 * so it refuses to run unless the database name contains "test".
 */
const url =
  process.env.TEST_DATABASE_URL ?? "postgresql://msclub:msclub@localhost:5432/msclub_test";

const dbName = new URL(url).pathname.replace(/^\//, "");
if (!/test/i.test(dbName)) {
  throw new Error(`Refusing to run tests against "${dbName}": the database name must contain "test".`);
}

process.env.DATABASE_URL = url;
process.env.AUTH_SECRET = "test-secret-test-secret-test-secret-1234";
process.env.NEXT_PUBLIC_APP_URL = "http://localhost:3000";
(process.env as Record<string, string>).NODE_ENV = "test";
delete process.env.RESEND_API_KEY;
process.env.CRON_SECRET = "test-cron-secret-0123456789";

// Server actions / audit helpers read request headers; there is no request in tests.
vi.mock("next/headers", () => ({
  headers: async () => new Headers({ "x-forwarded-for": "203.0.113.7", "user-agent": "vitest" }),
  cookies: async () => ({ get: () => undefined, set: () => undefined }),
}));

// The real Auth.js instance is irrelevant to unit/integration tests; sessions are injected via tests/helpers/auth.ts.
vi.mock("@/auth", () => ({ auth: async () => null, signIn: async () => undefined, signOut: async () => undefined, handlers: {} }));

// Server actions call revalidatePath; there is no Next request context in tests.
vi.mock("next/cache", () => ({ revalidatePath: () => undefined, revalidateTag: () => undefined, unstable_cache: (fn: unknown) => fn }));

// Silence the console e-mail transport and expected error logs.
vi.spyOn(console, "info").mockImplementation(() => undefined);
vi.spyOn(console, "log").mockImplementation(() => undefined);
