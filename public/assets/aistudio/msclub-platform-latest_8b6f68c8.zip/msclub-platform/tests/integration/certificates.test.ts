import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import { renderCertificatePdf } from "@/lib/certificate-pdf";
import { CODE_PATTERN, issueCertificate, maskName, newCertificateCode, revokeCertificate, verifyCertificate } from "@/lib/certificates";
import { makeUser, resetDb } from "../helpers/db";

beforeEach(resetDb);
const base = (userId: string, ref = "c1") => ({ type: "COURSE" as const, title: "Azure", userId, referenceType: "COURSE", referenceId: ref });

describe("certificates", () => {
  it("codes are well-formed and unique-looking", () => {
    const codes = new Set(Array.from({ length: 500 }, newCertificateCode));
    expect(codes.size).toBe(500);
    for (const c of codes) expect(c).toMatch(CODE_PATTERN);
  });

  it("issuing is idempotent per member + reference, even concurrently", async () => {
    const u = await makeUser();
    const all = await Promise.all(Array.from({ length: 6 }, () => issueCertificate(base(u.id))));
    expect(new Set(all.map((c) => c.id)).size).toBe(1);
    expect(await db.certificate.count()).toBe(1);
    expect(await db.notification.count({ where: { userId: u.id } })).toBe(1);
    await issueCertificate(base(u.id, "c2"));
    expect(await db.certificate.count()).toBe(2);
  });

  it("public verification exposes no private data and masks the holder's name", async () => {
    const u = await makeUser({ name: "Sara Ahmed Hassan", email: "sara@private.test", studentId: "20260001", phone: "+201000000000" });
    const cert = await issueCertificate(base(u.id));
    const result = await verifyCertificate(cert.code.toLowerCase());
    expect(result).toMatchObject({ status: "valid", holder: "Sara H.", title: "Azure" });
    const json = JSON.stringify(result);
    for (const secret of ["private.test", "20260001", "+2010", "Ahmed", u.id, cert.id]) expect(json).not.toContain(secret);
    expect(await verifyCertificate("MSC-AAAA-BBBB-CCCC")).toEqual({ status: "not_found" });
    expect(await verifyCertificate("../../etc/passwd")).toEqual({ status: "not_found" });
    expect(maskName("Madonna")).toBe("Madonna");
  });

  it("revocation needs a reason, shows as revoked, and a revoked cert can be reissued", async () => {
    const [u, admin] = [await makeUser(), await makeUser()];
    const cert = await issueCertificate(base(u.id));
    expect(await revokeCertificate({ certificateId: cert.id, reason: " ", actorId: admin.id })).toMatchObject({ ok: false });
    expect(await revokeCertificate({ certificateId: cert.id, reason: "Issued in error", actorId: admin.id })).toEqual({ ok: true });
    expect(await verifyCertificate(cert.code)).toMatchObject({ status: "revoked" });
    expect(await revokeCertificate({ certificateId: cert.id, reason: "again", actorId: admin.id })).toMatchObject({ ok: false });
    expect((await issueCertificate(base(u.id))).id).not.toBe(cert.id);
  });

  it("renders valid English and Arabic PDFs", async () => {
    const u = await makeUser({ name: "سارة أحمد حسن" });
    const cert = await issueCertificate({ ...base(u.id), titleAr: "أساسيات أزور" });
    for (const locale of ["en", "ar"] as const) {
      const pdf = await renderCertificatePdf(cert.id, locale);
      expect(pdf.subarray(0, 5).toString()).toBe("%PDF-");
      expect(pdf.length).toBeGreaterThan(8_000);
    }
  });
});
