import { beforeEach, describe, expect, it } from "vitest";
import { ForbiddenError } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { addTeamMember, authorizeTeam, removeTeamMember, setLeadership } from "@/lib/teams-admin";
import { ctxFor } from "../helpers/auth";
import { makeUser, resetDb } from "../helpers/db";

beforeEach(resetDb);
const makeTeam = (slug: string) => db.team.create({ data: { slug, name: slug } });

describe("team membership & leadership", () => {
  it("adds only ACTIVE members, by e-mail, case-insensitively; re-adding never auto-promotes", async () => {
    const team = await makeTeam("web"); const admin = await makeUser();
    const m = await makeUser({ email: "Sara@Example.test" }); const applicant = await makeUser({ status: "APPLICANT" });
    expect(await addTeamMember({ teamId: team.id, email: "sara@example.TEST", actorId: admin.id })).toEqual({ ok: true });
    expect(await addTeamMember({ teamId: team.id, email: applicant.email, actorId: admin.id })).toMatchObject({ ok: false, code: "NOT_ACTIVE" });
    expect(await addTeamMember({ teamId: team.id, email: "ghost@example.test", actorId: admin.id })).toMatchObject({ ok: false });
    await setLeadership({ teamId: team.id, leadEmail: m.email, actorId: admin.id });
    await removeTeamMember({ teamId: team.id, userId: m.id, actorId: admin.id });
    await addTeamMember({ teamId: team.id, email: m.email, actorId: admin.id });
    expect((await db.teamMembership.findFirstOrThrow({ where: { userId: m.id } })).role).toBe("MEMBER");
  });

  it("changing the lead demotes the previous lead but keeps them in the team", async () => {
    const team = await makeTeam("ai"); const admin = await makeUser();
    const [a, b] = [await makeUser(), await makeUser()];
    await setLeadership({ teamId: team.id, leadEmail: a.email, actorId: admin.id });
    await setLeadership({ teamId: team.id, leadEmail: b.email, actorId: admin.id });
    expect((await db.team.findUniqueOrThrow({ where: { id: team.id } })).leadId).toBe(b.id);
    expect((await db.teamMembership.findFirstOrThrow({ where: { userId: a.id } }))).toMatchObject({ role: "MEMBER", status: "ACTIVE" });
    expect((await db.teamMembership.findFirstOrThrow({ where: { userId: b.id } })).role).toBe("LEAD");
    expect(await db.auditLog.count({ where: { action: "team.leadership" } })).toBe(2);
  });

  it("rejects the same person as lead and co-lead, and unknown users", async () => {
    const team = await makeTeam("sec"); const admin = await makeUser(); const a = await makeUser();
    expect(await setLeadership({ teamId: team.id, leadEmail: a.email, coLeadEmail: a.email, actorId: admin.id })).toMatchObject({ ok: false, code: "SAME_PERSON" });
    expect(await setLeadership({ teamId: team.id, leadEmail: "nobody@example.test", actorId: admin.id })).toMatchObject({ ok: false, code: "NOT_ACTIVE" });
    expect((await db.team.findUniqueOrThrow({ where: { id: team.id } })).leadId).toBeNull();
  });

  it("removing a lead clears the leadership pointer", async () => {
    const team = await makeTeam("data"); const admin = await makeUser(); const a = await makeUser();
    await setLeadership({ teamId: team.id, leadEmail: a.email, actorId: admin.id });
    expect(await removeTeamMember({ teamId: team.id, userId: a.id, actorId: admin.id })).toEqual({ ok: true });
    expect((await db.team.findUniqueOrThrow({ where: { id: team.id } })).leadId).toBeNull();
    expect(await removeTeamMember({ teamId: team.id, userId: a.id, actorId: admin.id })).toMatchObject({ ok: false });
  });
});

describe("authorizeTeam (cross-team isolation)", () => {
  it("a team lead can manage their own team but NOT another team", async () => {
    const [mine, other] = [await makeTeam("mine"), await makeTeam("other")];
    const u = await makeUser();
    const ctx = ctxFor(u, []);
    ctx.teams = [{ teamId: mine.id, teamSlug: "mine", teamName: "mine", role: "LEAD", permissions: [] }];
    expect(() => authorizeTeam(ctx, mine.id, "manage_members")).not.toThrow();
    expect(() => authorizeTeam(ctx, other.id, "manage_members")).toThrow(ForbiddenError);
    expect(() => authorizeTeam(ctx, other.id, "view")).toThrow(ForbiddenError);
  });
  it("plain members cannot manage; global permission holders can manage any team", async () => {
    const t = await makeTeam("t"); const u = await makeUser();
    const member = ctxFor(u, []);
    member.teams = [{ teamId: t.id, teamSlug: "t", teamName: "t", role: "MEMBER", permissions: [] }];
    expect(() => authorizeTeam(member, t.id, "manage_members")).toThrow(ForbiddenError);
    expect(() => authorizeTeam(member, t.id, "view")).not.toThrow();
    expect(() => authorizeTeam(ctxFor(u, ["teams.manage_members"]), t.id, "manage_members")).not.toThrow();
  });
});
