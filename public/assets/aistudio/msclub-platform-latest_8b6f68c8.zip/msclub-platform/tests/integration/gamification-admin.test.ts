import { beforeEach, describe, expect, it, vi } from "vitest";
import { ctxFor, fd, session, signInAs } from "../helpers/auth";
import { makeUser, resetDb } from "../helpers/db";

vi.mock("@/lib/auth/dal", async (importOriginal) => {
  const real = await importOriginal<typeof import("@/lib/auth/dal")>();
  return { ...real, getAuthContext: async () => session.current };
});

import {
  adjustPointsAction, awardPointsAction, deleteLevelAction, grantBadgeAction, recalculateLevelsAction, reversePointsAction,
  revokeBadgeAction, saveBadgeAction, saveLevelAction, savePointsRuleAction,
} from "@/app/actions/admin-gamification";
import { db } from "@/lib/db";

beforeEach(async () => {
  await resetDb();
  signInAs(null);
});

const as = async (perms: string[]) => {
  const u = await makeUser();
  signInAs(ctxFor(u, perms as never));
  return u;
};
const rule = (over: Record<string, unknown> = {}) =>
  db.pointsRule.create({ data: { key: "community.help", activityType: "community", label: "Helped a member", points: 15, referenceType: "COMMUNITY", ...over } });
const nonce = () => `n${Math.random().toString(36).slice(2, 14)}x`;

describe("points rules & manual awards", () => {
  it("rule management needs points.adjust; reserved keys are refused", async () => {
    await as(["points.award"]);
    const form = fd({ key: "demo.rule", label: "Demo", activityType: "demo", points: "5", referenceType: "COMMUNITY", enabled: "on" });
    expect(await savePointsRuleAction(null, undefined, form)).toMatchObject({ code: "FORBIDDEN" });
    await as(["points.adjust"]);
    expect(await savePointsRuleAction(null, undefined, form)).toMatchObject({ ok: true });
    expect(await savePointsRuleAction(null, undefined, fd({ key: "admin.adjustment", label: "x", activityType: "x", points: "1", referenceType: "COMMUNITY" }))).toMatchObject({ ok: false });
    expect(await savePointsRuleAction(null, undefined, form)).toMatchObject({ ok: false, fieldErrors: { key: "duplicate" } });
  });

  it("awards a rule once even if the same form is submitted repeatedly (idempotent)", async () => {
    await rule();
    const target = await makeUser();
    await as(["points.award"]);
    const n = nonce();
    const submit = () => awardPointsAction(undefined, fd({ email: target.email.toUpperCase(), ruleKey: "community.help", nonce: n }));
    const results = await Promise.all([submit(), submit(), submit()]);
    expect(results.every((r) => r.ok)).toBe(true);
    expect(await db.xPTransaction.count({ where: { userId: target.id } })).toBe(1);
    expect((await db.user.findUniqueOrThrow({ where: { id: target.id } })).totalXp).toBe(15);
    expect(await db.auditLog.count({ where: { action: "points.award" } })).toBe(1);
  });

  it("approval-required rules need the senior permission; unknown members and rules are rejected", async () => {
    await rule({ key: "bonus.big", points: 500, requiresApproval: true });
    const target = await makeUser();
    await as(["points.award"]);
    expect(await awardPointsAction(undefined, fd({ email: target.email, ruleKey: "bonus.big", nonce: nonce() }))).toMatchObject({ code: "FORBIDDEN" });
    await as(["points.award", "points.adjust"]);
    expect(await awardPointsAction(undefined, fd({ email: target.email, ruleKey: "bonus.big", nonce: nonce() }))).toMatchObject({ ok: true });
    expect(await awardPointsAction(undefined, fd({ email: "ghost@example.test", ruleKey: "bonus.big", nonce: nonce() }))).toMatchObject({ fieldErrors: { email: "invalid" } });
    expect(await awardPointsAction(undefined, fd({ email: target.email, ruleKey: "nope.nope", nonce: nonce() }))).toMatchObject({ fieldErrors: { ruleKey: "invalid" } });
  });

  it("a rule's cap is enforced for manual awards", async () => {
    await rule({ maxAwardsPerUser: 1 });
    const target = await makeUser();
    await as(["points.award"]);
    expect(await awardPointsAction(undefined, fd({ email: target.email, ruleKey: "community.help", nonce: nonce() }))).toMatchObject({ ok: true });
    expect(await awardPointsAction(undefined, fd({ email: target.email, ruleKey: "community.help", nonce: nonce() }))).toMatchObject({ ok: false, code: "CAPPED" });
  });
});

describe("adjustments & reversal", () => {
  it("deducting needs points.adjust and a reason; adding needs points.award", async () => {
    const target = await makeUser();
    await as(["points.award"]);
    const deduct = fd({ email: target.email, amount: "-20", reason: "Spam", nonce: nonce() });
    expect(await adjustPointsAction(undefined, deduct)).toMatchObject({ code: "FORBIDDEN" });
    expect(await adjustPointsAction(undefined, fd({ email: target.email, amount: "20", reason: "Bonus", nonce: nonce() }))).toMatchObject({ ok: true });

    await as(["points.adjust"]);
    expect(await adjustPointsAction(undefined, fd({ email: target.email, amount: "-5", nonce: nonce() }))).toMatchObject({ ok: false, fieldErrors: { reason: "required" } });
    expect(await adjustPointsAction(undefined, fd({ email: target.email, amount: "0", reason: "x", nonce: nonce() }))).toMatchObject({ ok: false });
    expect(await adjustPointsAction(undefined, fd({ email: target.email, amount: "-5", reason: "Spam", nonce: nonce() }))).toMatchObject({ ok: true });
    expect((await db.user.findUniqueOrThrow({ where: { id: target.id } })).totalXp).toBe(15);
    expect(await db.auditLog.count({ where: { action: "points.deduct" } })).toBe(1);
  });

  it("reversal needs points.reverse + reason, adds a linked compensating row and is audited", async () => {
    await rule();
    const target = await makeUser();
    await as(["points.award"]);
    await awardPointsAction(undefined, fd({ email: target.email, ruleKey: "community.help", nonce: nonce() }));
    const tx = await db.xPTransaction.findFirstOrThrow({ where: { userId: target.id } });

    expect(await reversePointsAction(tx.id, undefined, fd({ reason: "Mistake" }))).toMatchObject({ code: "FORBIDDEN" });
    await as(["points.reverse"]);
    expect(await reversePointsAction(tx.id, undefined, fd({}))).toMatchObject({ ok: false, fieldErrors: { reason: "required" } });
    expect(await reversePointsAction(tx.id, undefined, fd({ reason: "Mistake" }))).toMatchObject({ ok: true });
    expect(await reversePointsAction(tx.id, undefined, fd({ reason: "Mistake" }))).toMatchObject({ ok: true }); // replay is harmless
    const rows = await db.xPTransaction.findMany({ where: { userId: target.id }, orderBy: { createdAt: "asc" } });
    expect(rows.map((r) => r.amount)).toEqual([15, -15]);
    expect(rows[1].reversesId).toBe(tx.id);
    expect((await db.user.findUniqueOrThrow({ where: { id: target.id } })).totalXp).toBe(0);
  });
});

describe("levels", () => {
  const level = (over: Record<string, string> = {}) => fd({ key: "bronze", name: "Bronze", minXp: "0", icon: "star", color: "#1B6AC4", enabled: "on", ...over });

  it("needs levels.manage; thresholds are unique; colours and icons are whitelisted", async () => {
    await as([]);
    expect(await saveLevelAction(null, undefined, level())).toMatchObject({ code: "FORBIDDEN" });
    await as(["levels.manage"]);
    expect(await saveLevelAction(null, undefined, level())).toMatchObject({ ok: true });
    expect(await saveLevelAction(null, undefined, level({ key: "other", name: "Other" }))).toMatchObject({ fieldErrors: { minXp: "duplicate" } });
    expect(await saveLevelAction(null, undefined, level({ key: "x1", minXp: "50", color: "red" }))).toMatchObject({ ok: false, code: "INVALID" });
    expect(await saveLevelAction(null, undefined, level({ key: "x2", minXp: "60", icon: "<script>" }))).toMatchObject({ ok: false, code: "INVALID" });
  });

  it("saving re-derives every member's level and renumbers order by threshold; levels in use cannot be deleted", async () => {
    await as(["levels.manage"]);
    await saveLevelAction(null, undefined, level({ key: "gold", name: "Gold", minXp: "100" }));
    await saveLevelAction(null, undefined, level({ key: "bronze", name: "Bronze", minXp: "0" }));
    const m = await makeUser({ totalXp: 150 });
    await recalculateLevelsAction();
    const gold = await db.level.findUniqueOrThrow({ where: { key: "gold" } });
    const bronze = await db.level.findUniqueOrThrow({ where: { key: "bronze" } });
    expect(bronze.order).toBe(1); expect(gold.order).toBe(2);
    expect((await db.user.findUniqueOrThrow({ where: { id: m.id } })).levelId).toBe(gold.id);
    expect(await deleteLevelAction(gold.id)).toMatchObject({ ok: false, code: "IN_USE" });
    // raising the threshold moves the member back down automatically
    await saveLevelAction(gold.id, undefined, level({ key: "gold", name: "Gold", minXp: "500" }));
    expect((await db.user.findUniqueOrThrow({ where: { id: m.id } })).levelId).toBe(bronze.id);
    expect(await deleteLevelAction(gold.id)).toMatchObject({ ok: true });
  });
});

describe("badges", () => {
  const badge = (over: Record<string, string> = {}) => fd({ key: "first-steps", name: "First steps", icon: "award", color: "#1B6AC4", tier: "bronze", criteriaType: "events_attended", threshold: "1", autoAward: "on", enabled: "on", ...over });

  it("stores declarative criteria (auto) or empty criteria (manual only)", async () => {
    await as(["badges.manage"]);
    await saveBadgeAction(null, undefined, badge());
    expect((await db.badge.findUniqueOrThrow({ where: { key: "first-steps" } })).criteria).toEqual({ type: "events_attended", threshold: 1 });
    await saveBadgeAction(null, undefined, badge({ key: "mentor", criteriaType: "manual", threshold: "" }));
    expect(await db.badge.findUniqueOrThrow({ where: { key: "mentor" } })).toMatchObject({ criteria: {}, autoAward: false });
    expect(await saveBadgeAction(null, undefined, badge({ key: "bad", threshold: "" }))).toMatchObject({ fieldErrors: { threshold: "required" } });
    expect(await saveBadgeAction(null, undefined, badge({ key: "bad2", criteriaType: "drop_table" }))).toMatchObject({ ok: false, code: "INVALID" });
  });

  it("grant is once-only, revoke only when held, both need badges.manage and notify/audit", async () => {
    const target = await makeUser();
    await as([]);
    await expect(grantBadgeAction(undefined, fd({ email: target.email, badgeId: "x".repeat(10) }))).resolves.toMatchObject({ code: "FORBIDDEN" });
    await as(["badges.manage"]);
    await saveBadgeAction(null, undefined, badge({ criteriaType: "manual", threshold: "" }));
    const b = await db.badge.findUniqueOrThrow({ where: { key: "first-steps" } });
    expect(await grantBadgeAction(undefined, fd({ email: target.email, badgeId: b.id }))).toMatchObject({ ok: true });
    expect(await grantBadgeAction(undefined, fd({ email: target.email, badgeId: b.id }))).toMatchObject({ ok: false, code: "ALREADY_HELD" });
    expect(await db.userBadge.count({ where: { userId: target.id } })).toBe(1);
    expect(await db.notification.count({ where: { userId: target.id, type: "BADGE_EARNED" } })).toBe(1);
    expect(await revokeBadgeAction(undefined, fd({ email: target.email, badgeId: b.id }))).toMatchObject({ ok: true });
    expect(await revokeBadgeAction(undefined, fd({ email: target.email, badgeId: b.id }))).toMatchObject({ ok: false, code: "NOT_HELD" });
  });
});
