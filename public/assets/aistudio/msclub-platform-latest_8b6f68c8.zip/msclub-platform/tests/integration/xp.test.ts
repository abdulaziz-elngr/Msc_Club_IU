import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import { adjustXp, awardXp, reconcileUserXp, reverseXp } from "@/lib/xp";
import { makeUser, resetDb, seedLevels } from "../helpers/db";

async function rule(key: string, points: number, extra: Record<string, unknown> = {}) {
  return db.pointsRule.create({ data: { key, activityType: key, label: key, points, referenceType: "COMMUNITY", ...extra } });
}
const base = (userId: string, key: string, ref: string) => ({
  userId, activityKey: key, referenceType: "COMMUNITY" as const, referenceId: ref, description: key,
});

beforeEach(resetDb);

describe("XP ledger", () => {
  it("awards from the rule catalogue and keeps totalXp in sync", async () => {
    const u = await makeUser();
    await rule("a", 30);
    const r = await awardXp(base(u.id, "a", "1"));
    expect(r).toMatchObject({ awarded: true, amount: 30, totalXp: 30 });
    expect((await db.user.findUniqueOrThrow({ where: { id: u.id } })).totalXp).toBe(30);
  });

  it("is idempotent: the same reference never double-awards", async () => {
    const u = await makeUser();
    await rule("a", 30);
    await awardXp(base(u.id, "a", "1"));
    const again = await awardXp(base(u.id, "a", "1"));
    expect(again).toMatchObject({ awarded: false, duplicate: true });
    expect(await db.xPTransaction.count({ where: { userId: u.id } })).toBe(1);
  });

  it("survives 15 concurrent identical requests (one row, correct total)", async () => {
    const u = await makeUser();
    await rule("a", 30);
    const results = await Promise.all(Array.from({ length: 15 }, () => awardXp(base(u.id, "a", "same"))));
    expect(results.filter((r) => r.awarded)).toHaveLength(1);
    expect(await db.xPTransaction.count({ where: { userId: u.id } })).toBe(1);
    expect((await db.user.findUniqueOrThrow({ where: { id: u.id } })).totalXp).toBe(30);
  });

  it("keeps totalXp exact under 20 concurrent DIFFERENT awards (no lost updates)", async () => {
    const u = await makeUser();
    await rule("a", 5);
    await Promise.all(Array.from({ length: 20 }, (_, i) => awardXp(base(u.id, "a", `ref-${i}`))));
    const user = await db.user.findUniqueOrThrow({ where: { id: u.id } });
    const sum = await db.xPTransaction.aggregate({ where: { userId: u.id }, _sum: { amount: true } });
    expect(user.totalXp).toBe(100);
    expect(sum._sum.amount).toBe(100);
  });

  it("ignores unknown and disabled activities", async () => {
    const u = await makeUser();
    await rule("off", 10, { enabled: false });
    expect((await awardXp(base(u.id, "missing", "1"))).awarded).toBe(false);
    expect((await awardXp(base(u.id, "off", "1"))).awarded).toBe(false);
  });

  it("enforces maxAwardsPerUser under concurrency", async () => {
    const u = await makeUser();
    await rule("cap", 10, { maxAwardsPerUser: 2 });
    await Promise.all(Array.from({ length: 8 }, (_, i) => awardXp(base(u.id, "cap", `r${i}`))));
    expect(await db.xPTransaction.count({ where: { userId: u.id, amount: { gt: 0 } } })).toBe(2);
  });

  it("detects level-ups, notifies once, and does not on same-level awards", async () => {
    const u = await makeUser();
    await seedLevels();
    await rule("a", 60);
    const first = await awardXp(base(u.id, "a", "1")); // 60 -> Explorer
    expect(first).toMatchObject({ leveledUp: true, levelKey: "l2" });
    const second = await awardXp(base(u.id, "a", "2")); // 120 -> still Explorer
    expect(second).toMatchObject({ leveledUp: false, levelKey: "l2" });
    expect(await db.notification.count({ where: { userId: u.id, type: "LEVEL_UNLOCKED" } })).toBe(1);
  });
});

describe("reversal & adjustment", () => {
  it("reverses with a NEW linked negative row and never mutates history (FK regression)", async () => {
    const u = await makeUser();
    const admin = await makeUser();
    await seedLevels();
    await rule("a", 60);
    const award = await awardXp(base(u.id, "a", "1"));
    const original = await db.xPTransaction.findUniqueOrThrow({ where: { id: award.transactionId! } });

    const rev = await reverseXp({ transactionId: original.id, reason: "mistake", actorId: admin.id });
    expect(rev).toMatchObject({ awarded: true, amount: -60, totalXp: 0, levelKey: "l1" });

    const after = await db.xPTransaction.findUniqueOrThrow({ where: { id: original.id } });
    expect(after.amount).toBe(60);
    expect(after.createdAt).toEqual(original.createdAt);
    const reversal = await db.xPTransaction.findUniqueOrThrow({ where: { id: rev.transactionId! } });
    expect(reversal.reversesId).toBe(original.id);
  });

  it("reverses only once, even concurrently", async () => {
    const u = await makeUser();
    const admin = await makeUser();
    await rule("a", 40);
    const award = await awardXp(base(u.id, "a", "1"));
    await Promise.all(
      Array.from({ length: 6 }, () => reverseXp({ transactionId: award.transactionId!, reason: "x", actorId: admin.id })),
    );
    expect(await db.xPTransaction.count({ where: { userId: u.id } })).toBe(2);
    expect((await db.user.findUniqueOrThrow({ where: { id: u.id } })).totalXp).toBe(0);
  });

  it("requires a reason", async () => {
    const u = await makeUser();
    const admin = await makeUser();
    await rule("a", 40);
    const award = await awardXp(base(u.id, "a", "1"));
    expect((await reverseXp({ transactionId: award.transactionId!, reason: "  ", actorId: admin.id })).awarded).toBe(false);
    expect((await adjustXp({ userId: u.id, amount: 5, reason: "", actorId: admin.id, key: "k" })).awarded).toBe(false);
  });

  it("supports positive and negative manual adjustments without a catalogue rule", async () => {
    const u = await makeUser();
    const admin = await makeUser();
    expect(await adjustXp({ userId: u.id, amount: 25, reason: "bonus", actorId: admin.id, key: "k1" })).toMatchObject({ awarded: true, totalXp: 25 });
    expect(await adjustXp({ userId: u.id, amount: -10, reason: "penalty", actorId: admin.id, key: "k2" })).toMatchObject({ awarded: true, totalXp: 15 });
    // double submit of the same form
    expect((await adjustXp({ userId: u.id, amount: 25, reason: "bonus", actorId: admin.id, key: "k1" })).duplicate).toBe(true);
    expect((await db.user.findUniqueOrThrow({ where: { id: u.id } })).totalXp).toBe(15);
  });

  it("reconcile repairs a drifted cache from the ledger", async () => {
    const u = await makeUser();
    await rule("a", 30);
    await awardXp(base(u.id, "a", "1"));
    await db.user.update({ where: { id: u.id }, data: { totalXp: 9999 } });
    expect(await reconcileUserXp(u.id)).toBe(30);
    expect((await db.user.findUniqueOrThrow({ where: { id: u.id } })).totalXp).toBe(30);
  });
});
