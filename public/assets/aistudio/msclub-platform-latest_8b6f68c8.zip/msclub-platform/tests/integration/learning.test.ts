import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import {
  completeLesson, courseProgress, enrollInCourse, getLessonAccess, heartbeatCredit, recordHeartbeat, requiredWatchSeconds,
} from "@/lib/learning";
import { makeUser, resetDb } from "../helpers/db";

beforeEach(async () => {
  await resetDb();
  await db.pointsRule.createMany({ data: [
    { key: "course.enroll", activityType: "COURSE", label: "Enroll", points: 15, referenceType: "COURSE" },
    { key: "lesson.complete", activityType: "LESSON", label: "Lesson", points: 10, referenceType: "LESSON" },
    { key: "course.complete", activityType: "COURSE", label: "Course", points: 250, referenceType: "COURSE" },
  ] });
});

async function makeCourse(over: Record<string, unknown> = {}, lessons = 2, duration = 100) {
  const course = await db.course.create({ data: { slug: `c-${Math.random().toString(36).slice(2, 8)}`, title: "Azure", published: true, ...over } });
  const mod = await db.courseModule.create({ data: { courseId: course.id, title: "M1", order: 1 } });
  const ls = [];
  for (let i = 0; i < lessons; i += 1) ls.push(await db.lesson.create({ data: { courseId: course.id, moduleId: mod.id, title: `L${i + 1}`, order: i + 1, durationSeconds: duration } }));
  return { course, lessons: ls };
}
/** Credits `seconds` of watch time by moving the clock between heartbeats (30s each). */
async function watch(userId: string, lessonId: string, seconds: number, start = new Date("2026-11-09T10:00:00Z")) {
  let t = start.getTime();
  await recordHeartbeat({ userId, lessonId, now: new Date(t) });
  for (let done = 0; done < seconds; done += 30) { t += 30_000; await recordHeartbeat({ userId, lessonId, now: new Date(t) }); }
}

describe("pure rules", () => {
  it("heartbeat credit is capped by real elapsed time and ignores too-fast calls", () => {
    expect(heartbeatCredit(2_000)).toBe(0);
    expect(heartbeatCredit(15_000)).toBe(15);
    expect(heartbeatCredit(10 * 60_000)).toBe(40);
    expect(heartbeatCredit(Number.NaN)).toBe(0);
  });
  it("required watch time and completion rules", () => {
    expect(requiredWatchSeconds(100)).toBe(70);
    expect(requiredWatchSeconds(0)).toBe(10);
    expect(courseProgress(2, 4, "ALL_LESSONS", 100)).toEqual({ pct: 50, done: false });
    expect(courseProgress(3, 4, "PERCENT", 75)).toEqual({ pct: 75, done: true });
    expect(courseProgress(0, 0, "ALL_LESSONS", 100).done).toBe(false);
  });
});

describe("enrolment", () => {
  it("is idempotent, awards enrol XP once, and only for active members of published courses", async () => {
    const { course } = await makeCourse();
    const u = await makeUser();
    expect(await enrollInCourse({ userId: u.id, courseId: course.id })).toMatchObject({ ok: true, already: false });
    expect(await enrollInCourse({ userId: u.id, courseId: course.id })).toMatchObject({ ok: true, already: true });
    await Promise.all([enrollInCourse({ userId: u.id, courseId: course.id }), enrollInCourse({ userId: u.id, courseId: course.id })]);
    expect(await db.courseEnrollment.count()).toBe(1);
    expect(await db.xPTransaction.count({ where: { userId: u.id } })).toBe(1);

    const draft = await makeCourse({ published: false });
    expect(await enrollInCourse({ userId: u.id, courseId: draft.course.id })).toMatchObject({ ok: false, code: "NOT_FOUND" });
    const applicant = await makeUser({ status: "APPLICANT" });
    expect(await enrollInCourse({ userId: applicant.id, courseId: course.id })).toMatchObject({ ok: false, code: "NOT_ELIGIBLE" });
  });

  it("enforces prerequisite courses", async () => {
    const base = await makeCourse({}, 1); const advanced = await makeCourse({}, 1);
    await db.coursePrerequisite.create({ data: { courseId: advanced.course.id, requiresId: base.course.id } });
    const u = await makeUser();
    expect(await enrollInCourse({ userId: u.id, courseId: advanced.course.id })).toMatchObject({ ok: false, code: "PREREQUISITES" });
    await enrollInCourse({ userId: u.id, courseId: base.course.id });
    await watch(u.id, base.lessons[0].id, 90);
    expect(await completeLesson({ userId: u.id, lessonId: base.lessons[0].id })).toMatchObject({ ok: true, courseCompleted: true });
    expect(await enrollInCourse({ userId: u.id, courseId: advanced.course.id })).toMatchObject({ ok: true });
  });
});

describe("lessons: access, watch time and completion", () => {
  it("requires enrolment; cannot be completed without server-credited time", async () => {
    const { course, lessons } = await makeCourse();
    const u = await makeUser();
    expect(await getLessonAccess({ userId: u.id, lessonId: lessons[0].id })).toMatchObject({ ok: false, code: "NOT_ENROLLED" });
    expect(await completeLesson({ userId: u.id, lessonId: lessons[0].id })).toMatchObject({ ok: false, code: "NOT_ENROLLED" });
    await enrollInCourse({ userId: u.id, courseId: course.id });
    expect(await completeLesson({ userId: u.id, lessonId: lessons[0].id })).toMatchObject({ ok: false, code: "NOT_ENOUGH_TIME", remainingSeconds: 70 });
    expect(await db.xPTransaction.count({ where: { activityKey: "lesson.complete" } })).toBe(0);
  });

  it("a client hammering heartbeats cannot mint watch time: credit never exceeds real elapsed time", async () => {
    const { course, lessons } = await makeCourse();
    const u = await makeUser();
    await enrollInCourse({ userId: u.id, courseId: course.id });
    const t0 = new Date("2026-11-09T10:00:00Z").getTime();
    const seconds = async () => (await db.lessonProgress.findFirstOrThrow({ where: { userId: u.id } })).secondsWatched;

    await recordHeartbeat({ userId: u.id, lessonId: lessons[0].id, now: new Date(t0) });
    // 200 calls squeezed into 4.9 s are all rejected as too fast…
    for (let i = 1; i <= 200; i += 1) await recordHeartbeat({ userId: u.id, lessonId: lessons[0].id, now: new Date(t0 + i * 24) });
    expect(await seconds()).toBe(0);
    // …and the rejected calls did not move the clock, so real credit is not starved either.
    await recordHeartbeat({ userId: u.id, lessonId: lessons[0].id, now: new Date(t0 + 20_000) });
    expect(await seconds()).toBe(20);

    // Even with a flood spread across a minute, the total can never exceed the wall-clock time.
    for (let i = 1; i <= 600; i += 1) await recordHeartbeat({ userId: u.id, lessonId: lessons[0].id, now: new Date(t0 + 20_000 + i * 100) });
    expect(await seconds()).toBeLessThanOrEqual(80);
    // A forged long gap is capped (a stalled tab cannot claim minutes at once).
    const before = await seconds();
    await recordHeartbeat({ userId: u.id, lessonId: lessons[0].id, now: new Date(t0 + 20_000 + 60_000 + 3_600_000) });
    expect((await seconds()) - before).toBeLessThanOrEqual(40);
  });

  it("completing awards lesson XP once, updates progress, resumes, and finishing the course issues rewards once", async () => {
    const { course, lessons } = await makeCourse({ certificateEnabled: true });
    await db.certificateTemplate.create({ data: { key: "course", name: "Course", type: "COURSE" } });
    const u = await makeUser();
    await enrollInCourse({ userId: u.id, courseId: course.id });
    await watch(u.id, lessons[0].id, 90);
    const first = await completeLesson({ userId: u.id, lessonId: lessons[0].id });
    expect(first).toMatchObject({ ok: true, already: false, courseCompleted: false, progressPct: 50, lessonXp: 10 });
    expect(await completeLesson({ userId: u.id, lessonId: lessons[0].id })).toMatchObject({ ok: true, already: true, lessonXp: 0 });

    await watch(u.id, lessons[1].id, 90);
    const results = await Promise.all([completeLesson({ userId: u.id, lessonId: lessons[1].id }), completeLesson({ userId: u.id, lessonId: lessons[1].id })]);
    expect(results.filter((r) => r.ok && !r.already)).toHaveLength(1);

    const e = await db.courseEnrollment.findFirstOrThrow({ where: { userId: u.id } });
    expect(e).toMatchObject({ progressPct: 100, completedLessons: 2 });
    expect(e.completedAt).not.toBeNull();
    expect(await db.xPTransaction.count({ where: { userId: u.id, activityKey: "course.complete" } })).toBe(1);
    expect(await db.xPTransaction.count({ where: { userId: u.id, activityKey: "lesson.complete" } })).toBe(2);
    expect(await db.certificate.count({ where: { userId: u.id } })).toBe(1);
    expect(await db.notification.count({ where: { userId: u.id, type: "COURSE_COMPLETED" } })).toBe(1);
    expect((await db.user.findUniqueOrThrow({ where: { id: u.id } })).totalXp).toBe(15 + 10 + 10 + 250);
  });

  it("sequential courses lock later lessons until the previous one is complete", async () => {
    const { course, lessons } = await makeCourse({ sequential: true });
    const u = await makeUser();
    await enrollInCourse({ userId: u.id, courseId: course.id });
    expect(await getLessonAccess({ userId: u.id, lessonId: lessons[1].id })).toMatchObject({ ok: false, code: "LOCKED" });
    await watch(u.id, lessons[0].id, 90);
    await completeLesson({ userId: u.id, lessonId: lessons[0].id });
    expect(await getLessonAccess({ userId: u.id, lessonId: lessons[1].id })).toMatchObject({ ok: true });
  });

  it("suspended members and unpublished courses are locked out", async () => {
    const { course, lessons } = await makeCourse();
    const u = await makeUser();
    await enrollInCourse({ userId: u.id, courseId: course.id });
    await db.user.update({ where: { id: u.id }, data: { status: "SUSPENDED" } });
    expect(await getLessonAccess({ userId: u.id, lessonId: lessons[0].id })).toMatchObject({ ok: false, code: "NOT_ELIGIBLE" });
    await db.user.update({ where: { id: u.id }, data: { status: "ACTIVE" } });
    await db.course.update({ where: { id: course.id }, data: { published: false } });
    expect(await getLessonAccess({ userId: u.id, lessonId: lessons[0].id })).toMatchObject({ ok: false, code: "NOT_FOUND" });
  });
});
