import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import { setUserRole } from "@/lib/roles-admin";
import { ctxFor } from "../helpers/auth";
import { makeRole, makeUser, resetDb } from "../helpers/db";

beforeEach(resetDb);

describe("role assignment guards", () => {
  it("only a super admin can grant or revoke SUPER_ADMIN", async () => {
    await makeRole("SUPER_ADMIN", ["events.read"]);
    const hr = await makeUser(); const target = await makeUser();
    const actor = ctxFor(hr, ["members.update"] as never);
    expect(await setUserRole({ actor, userId: target.id, role: "SUPER_ADMIN", grant: true })).toMatchObject({ ok: false, code: "FORBIDDEN" });
    expect(await db.userRole.count()).toBe(0);
  });

  it("prevents privilege escalation: you can't grant a role holding permissions you lack", async () => {
    await makeRole("EVENTS_LEAD", ["events.read", "events.publish"]);
    await makeRole("MEMBER", ["events.read"]);
    const lead = await makeUser(); const target = await makeUser();
    const actor = ctxFor(lead, ["events.read"] as never);
    expect(await setUserRole({ actor, userId: target.id, role: "EVENTS_LEAD", grant: true })).toMatchObject({ ok: false, code: "FORBIDDEN" });
    expect(await setUserRole({ actor, userId: target.id, role: "MEMBER", grant: true })).toMatchObject({ ok: true });
    expect(await db.auditLog.count({ where: { action: "role.grant" } })).toBe(1);
  });

  it("super admins can grant anything", async () => {
    await makeRole("CLUB_PRESIDENT", ["admin.settings.manage"]);
    const boss = await makeUser(); const target = await makeUser();
    expect(await setUserRole({ actor: ctxFor(boss, [], { superAdmin: true }), userId: target.id, role: "CLUB_PRESIDENT", grant: true })).toMatchObject({ ok: true });
  });

  it("the last SUPER_ADMIN cannot be removed, even by concurrent revocations", async () => {
    const sa = await makeRole("SUPER_ADMIN");
    const [a, b] = [await makeUser(), await makeUser()];
    await db.userRole.createMany({ data: [{ userId: a.id, roleId: sa.id }, { userId: b.id, roleId: sa.id }] });
    const actor = ctxFor(a, [], { superAdmin: true });
    const results = await Promise.all([
      setUserRole({ actor, userId: a.id, role: "SUPER_ADMIN", grant: false }),
      setUserRole({ actor, userId: b.id, role: "SUPER_ADMIN", grant: false }),
    ]);
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.find((r) => !r.ok)).toMatchObject({ code: "LAST_SUPER_ADMIN" });
    expect(await db.userRole.count({ where: { roleId: sa.id } })).toBe(1);
  });
});
