import { beforeEach, describe, expect, it } from "vitest";
import { transitionApplication } from "@/lib/applications";
import { db } from "@/lib/db";
import { makeApplication, makeRole, makeUser, resetDb } from "../helpers/db";

beforeEach(resetDb);

describe("application workflow", () => {
  it("SUBMITTED → UNDER_REVIEW → ACCEPTED activates the member, swaps roles, keeps history, notifies", async () => {
    const reviewer = await makeUser();
    await makeRole("MEMBER"); const applicantRole = await makeRole("APPLICANT");
    const { user, application } = await makeApplication();
    await db.userRole.create({ data: { userId: user.id, roleId: applicantRole.id } });

    expect(await transitionApplication({ applicationId: application.id, to: "UNDER_REVIEW", actorId: reviewer.id })).toMatchObject({ ok: true });
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).status).toBe("UNDER_REVIEW");
    expect(await transitionApplication({ applicationId: application.id, to: "ACCEPTED", actorId: reviewer.id, note: "Welcome" })).toMatchObject({ ok: true });

    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).status).toBe("ACTIVE");
    const roles = (await db.userRole.findMany({ where: { userId: user.id }, include: { role: true } })).map((r) => r.role.key);
    expect(roles).toEqual(["MEMBER"]);
    const history = await db.applicationEvent.findMany({ where: { applicationId: application.id }, orderBy: { createdAt: "asc" } });
    expect(history.map((h) => [h.fromStatus, h.toStatus])).toEqual([["SUBMITTED", "UNDER_REVIEW"], ["UNDER_REVIEW", "ACCEPTED"]]);
    expect(await db.notification.count({ where: { userId: user.id, type: "APPLICATION_STATUS" } })).toBe(2);
    expect(await db.auditLog.count({ where: { action: "application.accepted" } })).toBe(1);
  });

  it("rejection requires a note; accepted applications are final; rejected ones can be reopened", async () => {
    const reviewer = await makeUser();
    const a = await makeApplication();
    expect(await transitionApplication({ applicationId: a.application.id, to: "REJECTED", actorId: reviewer.id })).toMatchObject({ ok: false, code: "NOTE_REQUIRED" });
    expect(await transitionApplication({ applicationId: a.application.id, to: "REJECTED", actorId: reviewer.id, note: "Incomplete" })).toMatchObject({ ok: true });
    expect((await db.user.findUniqueOrThrow({ where: { id: a.user.id } })).status).toBe("REJECTED");
    expect(await transitionApplication({ applicationId: a.application.id, to: "UNDER_REVIEW", actorId: reviewer.id })).toMatchObject({ ok: true });

    const b = await makeApplication();
    await transitionApplication({ applicationId: b.application.id, to: "ACCEPTED", actorId: reviewer.id });
    expect(await transitionApplication({ applicationId: b.application.id, to: "REJECTED", actorId: reviewer.id, note: "x" })).toMatchObject({ ok: false, code: "INVALID_TRANSITION" });
    expect(await transitionApplication({ applicationId: "nope-nope-nope", to: "ACCEPTED", actorId: reviewer.id })).toMatchObject({ ok: false, code: "NOT_FOUND" });
  });

  it("only one of two concurrent decisions wins", async () => {
    const reviewer = await makeUser();
    const { application } = await makeApplication();
    const results = await Promise.all([
      transitionApplication({ applicationId: application.id, to: "ACCEPTED", actorId: reviewer.id }),
      transitionApplication({ applicationId: application.id, to: "REJECTED", actorId: reviewer.id, note: "no" }),
      transitionApplication({ applicationId: application.id, to: "ACCEPTED", actorId: reviewer.id }),
    ]);
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(await db.applicationEvent.count({ where: { applicationId: application.id } })).toBe(1);
  });

  it("never reactivates a suspended account", async () => {
    const reviewer = await makeUser();
    const { user, application } = await makeApplication("SUSPENDED");
    await transitionApplication({ applicationId: application.id, to: "ACCEPTED", actorId: reviewer.id });
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).status).toBe("SUSPENDED");
  });
});
