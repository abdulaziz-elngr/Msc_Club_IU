import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import { cancelRegistration, fillFromWaitlist, registerForEvent, waitlistRank } from "@/lib/registration";
import { makeEvent, makeUser, resetDb } from "../helpers/db";

beforeEach(resetDb);
const reg = (eventId: string, userId: string, answers = {}) => registerForEvent({ eventId, userId, answers });

describe("registration", () => {
  it("confirms a member and records the registration", async () => {
    const [e, u] = [await makeEvent(), await makeUser()];
    expect(await reg(e.id, u.id)).toMatchObject({ ok: true, status: "CONFIRMED" });
    expect(await db.notification.count({ where: { userId: u.id, type: "EVENT_REGISTERED" } })).toBe(1);
  });

  it("rejects duplicate registration (sequential and 8 concurrent)", async () => {
    const [e, u] = [await makeEvent(), await makeUser()];
    await reg(e.id, u.id);
    expect(await reg(e.id, u.id)).toMatchObject({ ok: false, code: "ALREADY_REGISTERED" });

    const u2 = await makeUser();
    const results = await Promise.all(Array.from({ length: 8 }, () => reg(e.id, u2.id)));
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(await db.eventRegistration.count({ where: { eventId: e.id, userId: u2.id } })).toBe(1);
  });

  it("never overbooks: 25 concurrent members, capacity 10, waitlist for the rest", async () => {
    const e = await makeEvent({ capacity: 10 });
    const users = await Promise.all(Array.from({ length: 25 }, () => makeUser()));
    const results = await Promise.all(users.map((u) => reg(e.id, u.id)));
    expect(results.every((r) => r.ok)).toBe(true);
    expect(await db.eventRegistration.count({ where: { eventId: e.id, status: "CONFIRMED" } })).toBe(10);
    expect(await db.eventRegistration.count({ where: { eventId: e.id, status: "WAITLISTED" } })).toBe(15);
    const positions = (await db.eventRegistration.findMany({ where: { status: "WAITLISTED" }, select: { waitlistPos: true } })).map((r) => r.waitlistPos);
    expect(new Set(positions).size).toBe(15); // unique positions
  });

  it("returns FULL when the waitlist is disabled", async () => {
    const e = await makeEvent({ capacity: 1, waitlistEnabled: false });
    await reg(e.id, (await makeUser()).id);
    expect(await reg(e.id, (await makeUser()).id)).toMatchObject({ ok: false, code: "FULL" });
  });

  it("blocks closed, draft, ended, non-active and out-of-window registrations", async () => {
    const u = await makeUser();
    expect(await reg((await makeEvent({ status: "REGISTRATION_CLOSED" })).id, u.id)).toMatchObject({ code: "REGISTRATION_CLOSED" });
    expect(await reg((await makeEvent({ status: "DRAFT" })).id, u.id)).toMatchObject({ code: "EVENT_NOT_FOUND" });
    expect(await reg((await makeEvent({ registrationClosesAt: new Date(Date.now() - 1000) })).id, u.id)).toMatchObject({ code: "REGISTRATION_CLOSED" });
    expect(await reg((await makeEvent({ registrationOpensAt: new Date(Date.now() + 3600_000) })).id, u.id)).toMatchObject({ code: "REGISTRATION_CLOSED" });
    const applicant = await makeUser({ status: "APPLICANT" });
    expect(await reg((await makeEvent()).id, applicant.id)).toMatchObject({ code: "NOT_ELIGIBLE" });
  });

  it("validates custom fields server-side and stores only declared keys", async () => {
    const e = await makeEvent();
    await db.eventFormField.createMany({
      data: [
        { eventId: e.id, key: "laptop", label: "Laptop", type: "select", options: ["yes", "no"], required: true },
        { eventId: e.id, key: "note", label: "Note", type: "text", required: false },
      ],
    });
    const u = await makeUser();
    expect(await reg(e.id, u.id, { laptop: "maybe" })).toMatchObject({ ok: false, code: "INVALID_ANSWERS", fieldErrors: { laptop: "notAnOption" } });
    expect(await reg(e.id, u.id, { laptop: "yes", note: "hi", role: "ADMIN" })).toMatchObject({ ok: true });
    const stored = await db.eventRegistration.findFirstOrThrow({ where: { eventId: e.id, userId: u.id } });
    expect(stored.answers).toEqual({ laptop: "yes", note: "hi" });
  });
});

describe("cancellation & waitlist promotion", () => {
  it("promotes the oldest waitlisted member automatically, exactly one seat per cancellation", async () => {
    const e = await makeEvent({ capacity: 2 });
    const [a, b, c, d] = await Promise.all([makeUser(), makeUser(), makeUser(), makeUser()]);
    await reg(e.id, a.id); await reg(e.id, b.id);
    await reg(e.id, c.id); await reg(e.id, d.id);
    expect(await waitlistRank(e.id, c.id)).toBe(1);
    expect(await waitlistRank(e.id, d.id)).toBe(2);

    expect(await cancelRegistration({ eventId: e.id, userId: a.id })).toMatchObject({ ok: true, promotedUserId: c.id });
    expect((await db.eventRegistration.findFirstOrThrow({ where: { userId: c.id } })).status).toBe("CONFIRMED");
    expect((await db.eventRegistration.findFirstOrThrow({ where: { userId: d.id } })).status).toBe("WAITLISTED");
    expect(await db.eventRegistration.count({ where: { eventId: e.id, status: "CONFIRMED" } })).toBe(2);
    expect(await db.notification.count({ where: { userId: c.id, title: { contains: "seat opened" } } })).toBe(1);
  });

  it("concurrent cancellations promote distinct members without overbooking", async () => {
    const e = await makeEvent({ capacity: 3 });
    const confirmed = await Promise.all(Array.from({ length: 3 }, () => makeUser()));
    for (const u of confirmed) await reg(e.id, u.id);
    const waiting = await Promise.all(Array.from({ length: 5 }, () => makeUser()));
    for (const u of waiting) await reg(e.id, u.id);

    await Promise.all(confirmed.map((u) => cancelRegistration({ eventId: e.id, userId: u.id })));
    expect(await db.eventRegistration.count({ where: { eventId: e.id, status: "CONFIRMED" } })).toBe(3);
    expect(await db.eventRegistration.count({ where: { eventId: e.id, status: "WAITLISTED" } })).toBe(2);
  });

  it("cancelling a waitlisted member promotes nobody; double cancel is rejected", async () => {
    const e = await makeEvent({ capacity: 1 });
    const [a, b] = await Promise.all([makeUser(), makeUser()]);
    await reg(e.id, a.id); await reg(e.id, b.id);
    expect(await cancelRegistration({ eventId: e.id, userId: b.id })).toMatchObject({ ok: true, promotedUserId: null });
    expect(await cancelRegistration({ eventId: e.id, userId: b.id })).toMatchObject({ ok: false, code: "ALREADY_CANCELLED" });
  });

  it("refuses cancellation after the event started", async () => {
    const e = await makeEvent();
    const u = await makeUser();
    await reg(e.id, u.id);
    await db.event.update({ where: { id: e.id }, data: { startsAt: new Date(Date.now() - 60_000) } });
    expect(await cancelRegistration({ eventId: e.id, userId: u.id })).toMatchObject({ ok: false, code: "EVENT_STARTED" });
  });

  it("re-registering after cancelling issues a new pass generation", async () => {
    const e = await makeEvent();
    const u = await makeUser();
    await reg(e.id, u.id);
    const v1 = (await db.eventRegistration.findFirstOrThrow({ where: { userId: u.id } })).qrVersion;
    await cancelRegistration({ eventId: e.id, userId: u.id });
    await reg(e.id, u.id);
    const after = await db.eventRegistration.findFirstOrThrow({ where: { userId: u.id } });
    expect(after.status).toBe("CONFIRMED");
    expect(after.qrVersion).toBeGreaterThan(v1 + 1 - 1);
    expect(await db.eventRegistration.count({ where: { userId: u.id } })).toBe(1);
  });

  it("fillFromWaitlist uses seats freed by raising capacity", async () => {
    const e = await makeEvent({ capacity: 1 });
    const admin = await makeUser();
    const [a, b, c] = await Promise.all([makeUser(), makeUser(), makeUser()]);
    for (const u of [a, b, c]) await reg(e.id, u.id);
    await db.event.update({ where: { id: e.id }, data: { capacity: 3 } });
    expect(await fillFromWaitlist(e.id, admin.id)).toBe(2);
    expect(await fillFromWaitlist(e.id, admin.id)).toBe(0);
  });
});
