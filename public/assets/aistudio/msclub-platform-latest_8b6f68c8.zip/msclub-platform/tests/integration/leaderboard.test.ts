import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import { assignRanks, getLeaderboard, periodStart } from "@/lib/queries/leaderboard";
import { makeEvent, makeUser, resetDb } from "../helpers/db";

beforeEach(resetDb);

const xp = (userId: string, amount: number, createdAt = new Date(), n = Math.random()) =>
  db.xPTransaction.create({ data: { userId, amount, activityKey: "t", referenceType: "COMMUNITY", description: "t", idempotencyKey: `k-${n}`, createdAt } });

describe("ranking helpers", () => {
  it("shares ranks on ties (1,2,2,4)", () => {
    expect(assignRanks([{ value: 90 }, { value: 80 }, { value: 80 }, { value: 10 }]).map((r) => r.rank)).toEqual([1, 2, 2, 4]);
  });
  it("period starts are UTC month / Monday-week boundaries", () => {
    const wed = new Date("2026-11-11T15:00:00Z");
    expect(periodStart("monthly", wed)?.toISOString()).toBe("2026-11-01T00:00:00.000Z");
    expect(periodStart("weekly", wed)?.toISOString()).toBe("2026-11-09T00:00:00.000Z");
    expect(periodStart("all", wed)).toBeNull();
  });
});

describe("getLeaderboard", () => {
  it("respects per-member privacy and account status in every scope", async () => {
    const shown = await makeUser({ totalXp: 100 });
    const hidden = await makeUser({ totalXp: 900, leaderboardVisible: false });
    const suspended = await makeUser({ totalXp: 800, status: "SUSPENDED" });
    const zero = await makeUser({ totalXp: 0 });
    const list = await getLeaderboard({ scope: "global", period: "all" });
    expect(list.map((e) => e.userId)).toEqual([shown.id]);
    for (const u of [hidden, suspended, zero]) expect(list.some((e) => e.userId === u.id)).toBe(false);

    await xp(hidden.id, 50);
    await xp(shown.id, 10);
    const monthly = await getLeaderboard({ scope: "global", period: "monthly" });
    expect(monthly.map((e) => e.userId)).toEqual([shown.id]);
  });

  it("monthly counts only XP earned this period and ignores net-negative members", async () => {
    const a = await makeUser(); const b = await makeUser(); const c = await makeUser();
    await xp(a.id, 100, new Date(Date.now() - 90 * 86400_000)); // long ago
    await xp(a.id, 20); await xp(b.id, 50); await xp(b.id, -10); await xp(c.id, 5); await xp(c.id, -30);
    const rows = await getLeaderboard({ scope: "global", period: "monthly" });
    expect(rows.map((r) => [r.userId, r.value])).toEqual([[b.id, 40], [a.id, 20]]);
    expect(rows.map((r) => r.rank)).toEqual([1, 2]);
  });

  it("team and track scopes only include ACTIVE members of that team / track's teams", async () => {
    const track = await db.learningTrack.create({ data: { slug: "web", name: "Web" } });
    const t1 = await db.team.create({ data: { slug: "t1", name: "T1", trackId: track.id } });
    const t2 = await db.team.create({ data: { slug: "t2", name: "T2" } });
    const [m1, m2, left, outsider] = [await makeUser({ totalXp: 30 }), await makeUser({ totalXp: 20 }), await makeUser({ totalXp: 99 }), await makeUser({ totalXp: 500 })];
    await db.teamMembership.createMany({ data: [
      { userId: m1.id, teamId: t1.id }, { userId: m2.id, teamId: t1.id }, { userId: left.id, teamId: t1.id, status: "LEFT" }, { userId: outsider.id, teamId: t2.id },
    ] });
    expect((await getLeaderboard({ scope: "team", period: "all", refId: t1.id })).map((e) => e.userId)).toEqual([m1.id, m2.id]);
    expect((await getLeaderboard({ scope: "track", period: "all", refId: track.id })).map((e) => e.userId)).toEqual([m1.id, m2.id]);
    expect(await getLeaderboard({ scope: "team", period: "all" })).toEqual([]); // no ref → nothing, never "everyone"
  });

  it("event scope ranks by the XP earned at that event", async () => {
    const e = await makeEvent(); const other = await makeEvent();
    const [a, b, c] = [await makeUser(), await makeUser(), await makeUser({ leaderboardVisible: false })];
    await db.attendance.createMany({ data: [
      { eventId: e.id, userId: a.id, pointsAwarded: 20 }, { eventId: e.id, userId: b.id, pointsAwarded: 35 },
      { eventId: e.id, userId: c.id, pointsAwarded: 99 }, { eventId: other.id, userId: a.id, pointsAwarded: 500 },
    ] });
    expect((await getLeaderboard({ scope: "event", period: "all", refId: e.id })).map((r) => [r.userId, r.value])).toEqual([[b.id, 35], [a.id, 20]]);
  });
});
