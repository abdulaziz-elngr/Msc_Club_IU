import { beforeEach, describe, expect, it, vi } from "vitest";
import { ctxFor, fd, session, signInAs } from "../helpers/auth";
import { makeEvent, makeUser, resetDb, seedRules } from "../helpers/db";

vi.mock("@/lib/auth/dal", async (importOriginal) => {
  const real = await importOriginal<typeof import("@/lib/auth/dal")>();
  return { ...real, getAuthContext: async () => session.current };
});

import {
  correctAttendanceAction, deleteEventAction, saveEventAction, saveFormFieldsAction,
} from "@/app/actions/admin-events";
import { scanPassAction, searchRegistrantsAction, selfCheckInAction } from "@/app/actions/checkin";
import { GET as exportGET } from "@/app/api/events/[id]/export/route";
import { GET as cronGET } from "@/app/api/cron/event-reminders/route";
import { GET as tokenGET } from "@/app/api/events/[id]/rotating-token/route";
import { checkInByToken, checkInWithRotatingCode, issueRotatingToken } from "@/lib/attendance";
import { db } from "@/lib/db";
import { issuePassToken } from "@/lib/qr";
import { registerForEvent } from "@/lib/registration";

beforeEach(async () => {
  await resetDb();
  await seedRules();
  signInAs(null);
});

const ADMIN_PERMS = ["events.read", "events.create", "events.update", "events.publish", "events.delete", "events.manage_registrations", "events.manage_attendance", "events.correct_attendance", "events.export_registrations"] as const;
const admin = async (perms: readonly string[] = ADMIN_PERMS) => {
  const u = await makeUser();
  const ctx = ctxFor(u, [...perms] as never);
  signInAs(ctx);
  return { u, ctx };
};
const iso = (offsetH: number) => new Date(Date.now() + offsetH * 3600_000).toISOString();
const validEvent = (over: Record<string, string> = {}) => fd({
  title: "Intro to Azure", category: "WORKSHOP", status: "DRAFT", startsAt: iso(48), endsAt: iso(50),
  attendancePoints: "30", completionPoints: "0", qrRotateSeconds: "120", waitlistEnabled: "on", ...over,
});
const params = (id: string) => ({ params: Promise.resolve({ id }) });

describe("authorization", () => {
  it("rejects anonymous callers", async () => {
    expect(await saveEventAction(null, undefined, validEvent())).toMatchObject({ ok: false, code: "UNAUTHENTICATED" });
  });

  it("rejects members without the permission and writes nothing", async () => {
    await admin([]);
    expect(await saveEventAction(null, undefined, validEvent())).toMatchObject({ ok: false, code: "FORBIDDEN" });
    expect(await db.event.count()).toBe(0);
  });

  it("creating drafts needs events.create, publishing needs events.publish", async () => {
    await admin(["events.create"]);
    expect(await saveEventAction(null, undefined, validEvent())).toMatchObject({ ok: true });
    expect(await saveEventAction(null, undefined, validEvent({ status: "PUBLISHED", title: "Other" }))).toMatchObject({ ok: false, code: "FORBIDDEN" });
    expect(await db.event.count()).toBe(1);
  });

  it("delete, export, scan, correction and rotating-token each enforce their own permission", async () => {
    const e = await makeEvent();
    await admin(["events.read"]);
    expect(await deleteEventAction(e.id)).toMatchObject({ code: "FORBIDDEN" });
    expect(await scanPassAction(e.id, "x".repeat(40))).toMatchObject({ code: "FORBIDDEN" });
    expect(await correctAttendanceAction("a".repeat(12), undefined, fd({ toStatus: "ABSENT", reason: "OTHER" }))).toMatchObject({ code: "FORBIDDEN" });
    expect((await exportGET(new Request("http://x/api?type=registrations"), params(e.id))).status).toBe(403);
    expect((await tokenGET(new Request("http://x"), params(e.id))).status).toBe(403);
    signInAs(null);
    expect((await exportGET(new Request("http://x"), params(e.id))).status).toBe(401);
  });
});

describe("saveEventAction", () => {
  it("creates an event, audits it, and ignores fields outside the schema (no mass assignment)", async () => {
    const { u } = await admin();
    const victim = await makeUser();
    const res = await saveEventAction(null, undefined, validEvent({ organizerId: victim.id, publishedAt: "2000-01-01T00:00:00Z", id: "hacked-id-000000", slug: "intro-azure" }));
    expect(res).toMatchObject({ ok: true });
    const ev = await db.event.findFirstOrThrow();
    expect(ev.organizerId).toBe(u.id);          // server-assigned, not client-supplied
    expect(ev.publishedAt).toBeNull();          // draft stays unpublished
    expect(ev.id).not.toBe("hacked-id-000000");
    expect(await db.auditLog.count({ where: { action: "event.create", actorId: u.id } })).toBe(1);
  });

  it("stores the instant it was given (timezone-safe) and validates the schedule", async () => {
    await admin();
    const start = "2027-03-01T10:00:00.000Z";
    await saveEventAction(null, undefined, validEvent({ startsAt: start, endsAt: "2027-03-01T12:00:00.000Z" }));
    expect((await db.event.findFirstOrThrow()).startsAt.toISOString()).toBe(start);

    const bad = await saveEventAction(null, undefined, validEvent({ startsAt: iso(5), endsAt: iso(4), title: "Bad" }));
    expect(bad).toMatchObject({ ok: false, code: "INVALID", fieldErrors: { endsAt: "invalid" } });
    const missing = await saveEventAction(null, undefined, fd({ category: "WORKSHOP", status: "DRAFT" }));
    expect(missing).toMatchObject({ ok: false, fieldErrors: { title: "required" } });
  });

  it("rejects non-http(s) join links and unknown categories", async () => {
    await admin();
    expect(await saveEventAction(null, undefined, validEvent({ onlineUrl: "javascript:alert(1)" }))).toMatchObject({ ok: false, fieldErrors: { onlineUrl: expect.any(String) } });
    expect(await saveEventAction(null, undefined, validEvent({ category: "HACK" }))).toMatchObject({ ok: false, code: "INVALID" });
  });

  it("raising capacity promotes the waitlist; cancelling notifies registrants", async () => {
    await admin();
    const e = await makeEvent({ capacity: 1 });
    const [a, b] = [await makeUser(), await makeUser()];
    await registerForEvent({ eventId: e.id, userId: a.id, answers: {} });
    await registerForEvent({ eventId: e.id, userId: b.id, answers: {} });
    expect((await db.eventRegistration.findFirstOrThrow({ where: { userId: b.id } })).status).toBe("WAITLISTED");

    const form = (over: Record<string, string>) => validEvent({ title: e.title, status: "REGISTRATION_OPEN", ...over });
    await saveEventAction(e.id, undefined, form({ capacity: "5", startsAt: e.startsAt.toISOString(), endsAt: e.endsAt.toISOString() }));
    expect((await db.eventRegistration.findFirstOrThrow({ where: { userId: b.id } })).status).toBe("CONFIRMED");

    await saveEventAction(e.id, undefined, form({ capacity: "5", status: "CANCELLED", startsAt: e.startsAt.toISOString(), endsAt: e.endsAt.toISOString() }));
    expect(await db.notification.count({ where: { type: "EVENT_CANCELLED" } })).toBe(2);
  });
});

describe("deleteEventAction", () => {
  it("deletes empty events but never events with registrations (history is kept)", async () => {
    await admin();
    const empty = await makeEvent();
    expect(await deleteEventAction(empty.id)).toMatchObject({ ok: true });
    const used = await makeEvent();
    await registerForEvent({ eventId: used.id, userId: (await makeUser()).id, answers: {} });
    expect(await deleteEventAction(used.id)).toMatchObject({ ok: false, code: "CONFLICT" });
    expect(await db.event.count({ where: { id: used.id } })).toBe(1);
  });
});

describe("form builder", () => {
  const rows = (r: Array<[string, string, string, string, string]>) => fd({
    f_key: r.map((x) => x[0]), f_label: r.map((x) => x[1]), f_labelAr: r.map(() => ""), f_type: r.map((x) => x[2]),
    f_options: r.map((x) => x[3]), f_required: r.map((x) => x[4]),
  });

  it("saves valid fields and they drive registration validation", async () => {
    await admin();
    const e = await makeEvent();
    expect(await saveFormFieldsAction(e.id, undefined, rows([["laptop", "Bring a laptop?", "select", "yes\nno", "yes"], ["notes", "Notes", "text", "", "no"]]))).toMatchObject({ ok: true });
    expect(await db.eventFormField.count({ where: { eventId: e.id } })).toBe(2);
    const u = await makeUser();
    expect(await registerForEvent({ eventId: e.id, userId: u.id, answers: {} })).toMatchObject({ code: "INVALID_ANSWERS" });
    expect(await registerForEvent({ eventId: e.id, userId: u.id, answers: { laptop: "yes" } })).toMatchObject({ ok: true });
  });

  it("rejects duplicate keys, bad keys, and selects with fewer than two options", async () => {
    await admin();
    const e = await makeEvent();
    expect((await saveFormFieldsAction(e.id, undefined, rows([["a", "A", "text", "", "no"], ["a", "B", "text", "", "no"]]))).ok).toBe(false);
    expect((await saveFormFieldsAction(e.id, undefined, rows([["Bad Key!", "A", "text", "", "no"]]))).ok).toBe(false);
    expect((await saveFormFieldsAction(e.id, undefined, rows([["pick", "A", "select", "only-one", "no"]]))).ok).toBe(false);
    expect(await db.eventFormField.count({ where: { eventId: e.id } })).toBe(0);
  });
});

describe("staff scanner actions", () => {
  const live = () => makeEvent({ startsAt: new Date(Date.now() - 10 * 60_000), endsAt: new Date(Date.now() + 3600_000) });
  let sid = 20260042;
  async function registeredFor(eventId: string) {
    const user = await makeUser({ studentId: String(sid++) });
    await db.event.update({ where: { id: eventId }, data: { startsAt: new Date(Date.now() + 3600_000), endsAt: new Date(Date.now() + 7200_000) } });
    await registerForEvent({ eventId, userId: user.id, answers: {} });
    await db.event.update({ where: { id: eventId }, data: { startsAt: new Date(Date.now() - 10 * 60_000), endsAt: new Date(Date.now() + 3600_000) } });
    const reg = await db.eventRegistration.findFirstOrThrow({ where: { eventId, userId: user.id } });
    return { user, token: issuePassToken(reg.id, reg.qrVersion) };
  }

  it("returns the attendee card (name, student id, statuses, points) and never the e-mail", async () => {
    const e = await live();
    const { user, token } = await registeredFor(e.id);
    await admin();
    const res = await scanPassAction(e.id, token);
    expect(res).toMatchObject({ ok: true, points: 20, attendee: { name: user.name, studentId: expect.stringMatching(/^2026\d+$/), registrationStatus: "CONFIRMED", attendanceStatus: "PRESENT" } });
    expect(JSON.stringify(res)).not.toContain(user.email);

    const again = await scanPassAction(e.id, token);
    expect(again).toMatchObject({ ok: false, scanCode: "ALREADY_CHECKED_IN", attendee: { attendanceStatus: "PRESENT" } });
    expect(await scanPassAction(e.id, "z".repeat(60))).toMatchObject({ ok: false, scanCode: "TOKEN_NOT_FOUND" });
  });

  it("only searches confirmed registrants of that event, with a minimum query length", async () => {
    const e = await live();
    const other = await live();
    const { user } = await registeredFor(e.id);
    await registeredFor(other.id);
    await admin();
    const hits = (await searchRegistrantsAction(e.id, user.name.slice(0, 6))).hits;
    expect(hits.map((h) => h.userId)).toEqual([user.id]);
    expect((await searchRegistrantsAction(e.id, "a")).hits).toEqual([]);
  });

  it("correction demands a valid reason", async () => {
    const e = await live();
    const { token } = await registeredFor(e.id);
    const ok = await checkInByToken(token);
    if (!ok.ok) throw new Error("setup");
    await admin();
    expect(await correctAttendanceAction(ok.attendanceId, undefined, fd({ toStatus: "ABSENT" }))).toMatchObject({ ok: false, code: "INVALID" });
    expect(await correctAttendanceAction(ok.attendanceId, undefined, fd({ toStatus: "ABSENT", reason: "MIS_SCAN", note: "wrong person" }))).toMatchObject({ ok: true });
    expect((await db.attendance.findUniqueOrThrow({ where: { id: ok.attendanceId } })).status).toBe("ABSENT");
  });
});

describe("rotating venue code (self check-in)", () => {
  async function liveWithRegistered() {
    const e = await makeEvent({ rotatingQrEnabled: true, qrRotateSeconds: 60 });
    const user = await makeUser();
    await registerForEvent({ eventId: e.id, userId: user.id, answers: {} });
    await db.event.update({ where: { id: e.id }, data: { startsAt: new Date(Date.now() - 10 * 60_000), endsAt: new Date(Date.now() + 3600_000) } });
    return { e, user };
  }

  it("lets a confirmed member check themselves in once, with identity from the session", async () => {
    const { e, user } = await liveWithRegistered();
    const issued = (await issueRotatingToken(e.id))!;
    signInAs(ctxFor(user));
    expect(await selfCheckInAction(e.id, issued.token)).toMatchObject({ ok: true, points: 20 });
    expect(await selfCheckInAction(e.id, issued.token)).toMatchObject({ ok: false, scanCode: "ALREADY_CHECKED_IN" });
    expect((await db.attendance.findFirstOrThrow({ where: { userId: user.id } })).method).toBe("CODE");
  });

  it("rejects expired, forged, wrong-event and unregistered attempts", async () => {
    const { e, user } = await liveWithRegistered();
    const issued = (await issueRotatingToken(e.id))!;
    await db.attendanceToken.updateMany({ data: { expiresAt: new Date(Date.now() - 1000) } });
    expect(await checkInWithRotatingCode({ eventId: e.id, code: issued.token, userId: user.id })).toMatchObject({ ok: false, code: "TOKEN_NOT_FOUND" });
    expect(await checkInWithRotatingCode({ eventId: e.id, code: "f".repeat(32), userId: user.id })).toMatchObject({ ok: false, code: "TOKEN_NOT_FOUND" });

    const fresh = (await issueRotatingToken(e.id))!;
    const other = await makeEvent();
    expect(await checkInWithRotatingCode({ eventId: other.id, code: fresh.token, userId: user.id })).toMatchObject({ ok: false });
    const stranger = await makeUser();
    expect(await checkInWithRotatingCode({ eventId: e.id, code: fresh.token, userId: stranger.id })).toMatchObject({ ok: false, code: "NOT_REGISTERED" });
  });

  it("only issues codes when the event enabled rotating QR; endpoint is staff-only", async () => {
    const off = await makeEvent({ rotatingQrEnabled: false });
    expect(await issueRotatingToken(off.id)).toBeNull();
    const on = await makeEvent({ rotatingQrEnabled: true });
    await admin();
    const res = await tokenGET(new Request("http://x"), params(on.id));
    expect(res.status).toBe(200);
    expect(res.headers.get("cache-control")).toBe("no-store");
    expect((await res.json()).token).toHaveLength(32); // 24 random bytes = 192 bits, base64url
  });
});

describe("CSV export route", () => {
  it("includes custom answers and neutralises formula injection", async () => {
    const e = await makeEvent();
    await db.eventFormField.create({ data: { eventId: e.id, key: "note", label: "Note", type: "text" } });
    const u = await makeUser({ name: "=cmd|' /C calc'!A0" });
    await registerForEvent({ eventId: e.id, userId: u.id, answers: { note: "+1+1" } });
    await admin();
    const res = await exportGET(new Request("http://x/api?type=registrations"), params(e.id));
    const csv = await res.text();
    expect(res.headers.get("content-disposition")).toContain(`${e.slug}-registrations.csv`);
    expect(csv).toContain("Note");
    expect(csv).toContain("'+1+1");
    expect(csv).toContain("'=cmd");
    expect(await db.auditLog.count({ where: { action: "event.export.registrations" } })).toBe(1);
  });
});

describe("cron reminders", () => {
  const call = (token?: string) => cronGET(new Request("http://x/api/cron/event-reminders", { headers: token ? { authorization: `Bearer ${token}` } : {} }));

  it("is protected by the shared secret", async () => {
    expect((await call()).status).toBe(401);
    expect((await call("wrong-secret-wrong-secret")).status).toBe(401);
  });

  it("notifies confirmed members once, even when run repeatedly or concurrently", async () => {
    const e = await makeEvent();
    const users = await Promise.all([makeUser(), makeUser(), makeUser()]);
    for (const u of users) await registerForEvent({ eventId: e.id, userId: u.id, answers: {} });
    await db.eventReminder.create({ data: { eventId: e.id, sendAt: new Date(Date.now() - 1000) } });
    await db.eventReminder.create({ data: { eventId: e.id, sendAt: new Date(Date.now() + 3600_000) } }); // not due

    const runs = await Promise.all([call("test-cron-secret-0123456789"), call("test-cron-secret-0123456789"), call("test-cron-secret-0123456789")]);
    expect(runs.every((r) => r.status === 200)).toBe(true);
    expect(await db.notification.count({ where: { type: "EVENT_REMINDER" } })).toBe(3); // 3 members, once
    expect(await db.eventReminder.count({ where: { sentAt: null } })).toBe(1);
  });

  it("skips cancelled events", async () => {
    const e = await makeEvent({ status: "CANCELLED" });
    await db.eventReminder.create({ data: { eventId: e.id, sendAt: new Date(Date.now() - 1000) } });
    await call("test-cron-secret-0123456789");
    expect(await db.notification.count()).toBe(0);
  });
});
