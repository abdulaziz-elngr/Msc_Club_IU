import { beforeEach, describe, expect, it } from "vitest";
import { db } from "@/lib/db";
import { checkInByToken, checkInManually, correctAttendance, exportAttendanceCsv } from "@/lib/attendance";
import { issuePassToken } from "@/lib/qr";
import { cancelRegistration, registerForEvent } from "@/lib/registration";
import { makeEvent, makeUser, resetDb, seedRules } from "../helpers/db";

beforeEach(async () => {
  await resetDb();
  await seedRules();
});

/** An event whose check-in window is open right now. */
const liveEvent = (extra: Record<string, unknown> = {}) =>
  makeEvent({ startsAt: new Date(Date.now() - 10 * 60_000), endsAt: new Date(Date.now() + 60 * 60_000), ...extra });

async function registered(eventId: string) {
  const user = await makeUser();
  // Register while the event is "upcoming", as real members would.
  const ev = await db.event.findUniqueOrThrow({ where: { id: eventId } });
  await db.event.update({ where: { id: eventId }, data: { startsAt: new Date(Date.now() + 3600_000), endsAt: new Date(Date.now() + 7200_000) } });
  await registerForEvent({ eventId, userId: user.id, answers: {} });
  await db.event.update({ where: { id: eventId }, data: { startsAt: ev.startsAt, endsAt: ev.endsAt } });
  const r = await db.eventRegistration.findFirstOrThrow({ where: { eventId, userId: user.id } });
  return { user, reg: r, token: issuePassToken(r.id, r.qrVersion) };
}

describe("QR check-in", () => {
  it("accepts a valid pass, records attendance + log, and awards the EVENT's points", async () => {
    const e = await liveEvent({ attendancePoints: 20 });
    const { user, token } = await registered(e.id);
    const res = await checkInByToken(token, { actorId: null });
    expect(res).toMatchObject({ ok: true, points: 20 }); // rule default is 10; event value wins
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).totalXp).toBe(20);
    expect(await db.attendanceLog.count()).toBe(1);
    expect((await db.eventRegistration.findFirstOrThrow({ where: { userId: user.id } })).checkedInAt).not.toBeNull();
  });

  it("rejects forged, tampered, wrong-version and cancelled passes with one generic message", async () => {
    const e = await liveEvent();
    const { reg, token } = await registered(e.id);
    const [id] = token.split(".");
    const forged = await checkInByToken(`${id}.${"A".repeat(43)}`);
    const tampered = await checkInByToken(token.slice(0, -2) + "zz");
    const stale = await checkInByToken(issuePassToken(reg.id, reg.qrVersion + 1));
    for (const r of [forged, tampered, stale]) expect(r).toMatchObject({ ok: false, code: "TOKEN_NOT_FOUND", message: "Invalid pass." });

    await cancelRegistration({ eventId: e.id, userId: reg.userId, now: new Date(Date.now() - 3 * 3600_000) });
    expect(await checkInByToken(token)).toMatchObject({ ok: false, code: "TOKEN_NOT_FOUND" }); // version bumped
  });

  it("rejects a pass scanned at the wrong event", async () => {
    const a = await liveEvent();
    const b = await liveEvent();
    const { token } = await registered(a.id);
    expect(await checkInByToken(token, { eventId: b.id })).toMatchObject({ ok: false, code: "WRONG_EVENT" });
  });

  it("is idempotent: duplicate and 10 concurrent scans create one attendance and one XP award", async () => {
    const e = await liveEvent();
    const { user, token } = await registered(e.id);
    const results = await Promise.all(Array.from({ length: 10 }, () => checkInByToken(token)));
    expect(results.filter((r) => r.ok)).toHaveLength(1);
    expect(results.filter((r) => !r.ok && r.code === "ALREADY_CHECKED_IN")).toHaveLength(9);
    expect(await db.attendance.count({ where: { userId: user.id } })).toBe(1);
    expect(await db.xPTransaction.count({ where: { userId: user.id } })).toBe(1);
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).totalXp).toBe(20);
  });

  it("enforces the event time window and status", async () => {
    const early = await makeEvent({ startsAt: new Date(Date.now() + 5 * 3600_000), endsAt: new Date(Date.now() + 7 * 3600_000) });
    const { token } = await registered(early.id);
    expect(await checkInByToken(token)).toMatchObject({ ok: false, code: "EVENT_WINDOW" });

    const cancelled = await liveEvent({ status: "CANCELLED" });
    const r2 = await registered(cancelled.id).catch(() => null);
    expect(r2).toBeNull(); // cannot even register for a cancelled event
  });

  it("does not check in waitlisted members", async () => {
    const e = await liveEvent({ capacity: 1 });
    await registered(e.id);
    const { token } = await registered(e.id);
    expect(await checkInByToken(token)).toMatchObject({ ok: false, code: "REGISTRATION_NOT_CONFIRMED" });
  });

  it("self-heals: a check-in whose XP award failed gets its points on the next scan", async () => {
    const e = await liveEvent();
    const { user, token } = await registered(e.id);
    await checkInByToken(token);
    // simulate a lost award
    await db.xPTransaction.deleteMany({ where: { userId: user.id } });
    await db.attendance.updateMany({ where: { userId: user.id }, data: { pointsAwarded: 0 } });
    await db.user.update({ where: { id: user.id }, data: { totalXp: 0 } });
    expect(await checkInByToken(token)).toMatchObject({ ok: false, code: "ALREADY_CHECKED_IN" });
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).totalXp).toBe(20);
  });
});

describe("manual check-in & corrections", () => {
  it("manual check-in works for confirmed members only", async () => {
    const e = await liveEvent();
    const staff = await makeUser();
    const { user } = await registered(e.id);
    expect(await checkInManually({ eventId: e.id, userId: user.id, actorId: staff.id })).toMatchObject({ ok: true });
    const stranger = await makeUser();
    expect(await checkInManually({ eventId: e.id, userId: stranger.id, actorId: staff.id })).toMatchObject({ ok: false, code: "NOT_REGISTERED" });
    const att = await db.attendance.findFirstOrThrow({ where: { userId: user.id } });
    expect(att).toMatchObject({ method: "MANUAL", recordedById: staff.id });
  });

  it("correction to ABSENT logs, audits, and reverses the XP with a compensating row", async () => {
    const e = await liveEvent();
    const staff = await makeUser();
    const { user, token } = await registered(e.id);
    const ok = await checkInByToken(token);
    if (!ok.ok) throw new Error("setup");
    const res = await correctAttendance({ attendanceId: ok.attendanceId, toStatus: "ABSENT", reason: "MIS_SCAN", note: "scanned wrong person", actorId: staff.id, ip: "198.51.100.9" });
    expect(res.ok).toBe(true);
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).totalXp).toBe(0);
    expect(await db.attendanceLog.count({ where: { attendanceId: ok.attendanceId, action: "CORRECTED" } })).toBe(1);
    const audit = await db.auditLog.findFirstOrThrow({ where: { action: "attendance.correct" } });
    expect(audit).toMatchObject({ actorId: staff.id, ip: "198.51.100.9" });
    expect(audit.reason).toContain("MIS_SCAN");
    // history preserved: original +20 and reversal -20
    expect((await db.xPTransaction.findMany({ where: { userId: user.id }, orderBy: { createdAt: "asc" } })).map((x) => x.amount)).toEqual([20, -20]);
  });

  it("correcting back to PRESENT re-grants the points exactly once", async () => {
    const e = await liveEvent();
    const staff = await makeUser();
    const { user, token } = await registered(e.id);
    const ok = await checkInByToken(token);
    if (!ok.ok) throw new Error("setup");
    await correctAttendance({ attendanceId: ok.attendanceId, toStatus: "ABSENT", reason: "MIS_SCAN", actorId: staff.id });
    await correctAttendance({ attendanceId: ok.attendanceId, toStatus: "PRESENT", reason: "OTHER", actorId: staff.id });
    expect((await db.user.findUniqueOrThrow({ where: { id: user.id } })).totalXp).toBe(20);
  });
});

describe("CSV export", () => {
  it("neutralises formula injection in attendee names", async () => {
    const e = await liveEvent();
    const { user, token } = await registered(e.id);
    await db.user.update({ where: { id: user.id }, data: { name: '=HYPERLINK("http://evil","click")' } });
    await checkInByToken(token);
    const csv = await exportAttendanceCsv(e.id);
    expect(csv).toContain(`'=HYPERLINK`);
    expect(csv).not.toMatch(/(^|,)"?=HYPERLINK/m);
  });
});
