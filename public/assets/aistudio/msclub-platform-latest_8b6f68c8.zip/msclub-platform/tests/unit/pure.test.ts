import { describe, expect, it } from "vitest";
import { landingFor, safeNext } from "@/lib/auth/policy";
import { extractYouTubeId, youtubeEmbedUrl } from "@/lib/youtube";
import { csvCell, toCsv } from "@/lib/csv";
import { validateAnswers } from "@/lib/event-forms";
import { pickLevel } from "@/lib/xp";
import { meetsCriteria, parseCriteria } from "@/lib/badges";
import { issuePassToken, parsePassToken, verifyPassSignature } from "@/lib/qr";

describe("safeNext (open-redirect guard)", () => {
  it.each(["https://evil.com", "//evil.com", "/\\evil.com", "javascript:alert(1)", "/login", "/register?x=1"])(
    "rejects %s",
    (value) => expect(safeNext(value)).toBeNull(),
  );
  it("accepts same-origin paths", () => expect(safeNext("/dashboard/events?x=1")).toBe("/dashboard/events?x=1"));
});

describe("landingFor", () => {
  it("never lets suspended users in", () =>
    expect(landingFor({ status: "SUSPENDED", emailVerified: new Date(), next: "/admin" })).toBe("/login?error=suspended"));
  it("requires verification", () =>
    expect(landingFor({ status: "APPLICANT", emailVerified: null })).toBe("/verify-email"));
});

describe("youtube", () => {
  const id = "dQw4w9WgXcQ";
  it.each([
    `https://www.youtube.com/watch?v=${id}`,
    `https://youtu.be/${id}`,
    `https://www.youtube.com/embed/${id}`,
    `https://www.youtube.com/shorts/${id}`,
    `https://m.youtube.com/watch?feature=share&v=${id}`,
  ])("extracts id from %s", (url) => expect(extractYouTubeId(url)).toBe(id));
  it.each([
    "https://evil.com/watch?v=dQw4w9WgXcQ",
    "https://youtube.com.evil.com/watch?v=dQw4w9WgXcQ",
    '"><script>alert(1)</script>',
    "https://www.youtube.com/watch?v=short",
  ])("rejects %s", (url) => expect(extractYouTubeId(url)).toBeNull());
  it("embeds via the no-cookie host", () => expect(youtubeEmbedUrl(id)).toContain("youtube-nocookie.com/embed/"));
});

describe("csv", () => {
  it("neutralises formula injection", () => {
    expect(csvCell("=HYPERLINK(\"x\")")).toBe('"\'=HYPERLINK(""x"")"');
    expect(csvCell("+1+1")).toBe("'+1+1");
    expect(csvCell("@SUM(A1)")).toBe("'@SUM(A1)");
  });
  it("leaves plain numbers and text alone", () => {
    expect(csvCell(-5)).toBe("-5");
    expect(csvCell("Ahmed, M.")).toBe('"Ahmed, M."');
  });
  it("writes a BOM + CRLF rows", () => expect(toCsv(["a"], [["b"]])).toBe("\uFEFFa\r\nb"));
});

describe("event form answers", () => {
  const fields = [
    { key: "name", type: "text", options: [], required: true },
    { key: "size", type: "select", options: ["S", "M"], required: true },
    { key: "site", type: "url", options: [], required: false },
    { key: "agree", type: "checkbox", options: [], required: true },
  ];
  it("drops unknown keys and accepts valid input", () => {
    const r = validateAnswers(fields, { name: " Sara ", size: "M", agree: "on", isAdmin: true });
    expect(r).toEqual({ ok: true, answers: { name: "Sara", size: "M", agree: true } });
  });
  it("reports required/invalid per field", () => {
    const r = validateAnswers(fields, { name: "", size: "XL", site: "javascript:alert(1)", agree: "" });
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors).toEqual({ name: "required", size: "notAnOption", site: "invalid", agree: "required" });
  });
});

describe("levels & badges (pure)", () => {
  const levels = [{ minXp: 0 }, { minXp: 50 }, { minXp: 150 }];
  it("picks the highest threshold reached", () => {
    expect(pickLevel(levels, 0)).toEqual({ minXp: 0 });
    expect(pickLevel(levels, 149)).toEqual({ minXp: 50 });
    expect(pickLevel(levels, 150)).toEqual({ minXp: 150 });
  });
  it("evaluates criteria", () => {
    const stats = { totalXp: 100, levelOrder: 2, eventsAttended: 3, coursesCompleted: 0, lessonsCompleted: 0, tasksApproved: 0, certificates: 0, badgesCount: 0 };
    expect(meetsCriteria(parseCriteria({ type: "events_attended", threshold: 3 })!, stats)).toBe(true);
    expect(meetsCriteria(parseCriteria({ type: "total_xp", threshold: 101 })!, stats)).toBe(false);
    expect(parseCriteria("nope")).toBeNull();
  });
});

describe("QR passes", () => {
  const id = "clx0abcd1234efgh5678ijkl";
  it("round-trips and carries no personal data", () => {
    const token = issuePassToken(id, 1);
    const parsed = parsePassToken(token)!;
    expect(parsed.registrationId).toBe(id);
    expect(verifyPassSignature(id, 1, parsed.signature)).toBe(true);
    expect(token).not.toMatch(/@|\s/);
  });
  it("is bound to the version (revocation)", () => {
    const parsed = parsePassToken(issuePassToken(id, 1))!;
    expect(verifyPassSignature(id, 2, parsed.signature)).toBe(false);
  });
  it("is bound to the registration id", () => {
    const parsed = parsePassToken(issuePassToken(id, 1))!;
    expect(verifyPassSignature("clx0other1234efgh5678ijkl", 1, parsed.signature)).toBe(false);
  });
  it("has at least 256 bits of signature", () => {
    expect(Buffer.from(parsePassToken(issuePassToken(id, 1))!.signature, "base64url").length).toBe(32);
  });
  it.each(["", "abc", "a.b", `${id}.${"x".repeat(43)}.extra`, `${id}.${"!".repeat(43)}`])("rejects malformed %s", (v) =>
    expect(parsePassToken(v)).toBeNull(),
  );
});

import { buildCsp, hasSessionCookie, isProtectedPath } from "@/lib/proxy-rules";

describe("proxy rules", () => {
  it.each(["/dashboard", "/dashboard/events", "/admin", "/admin/members", "/team/web/tasks", "/events/abc/manage", "/events/abc/check-in", "/learning/web-track", "/learning/c/l"])(
    "protects %s", (p) => expect(isProtectedPath(p)).toBe(true));
  it.each(["/", "/about", "/events", "/events/my-slug", "/learning", "/teams", "/leaderboard", "/verify/ABC123", "/login", "/administrator-fan"])(
    "leaves %s public", (p) => expect(isProtectedPath(p)).toBe(false));
  it("detects Auth.js cookies (plain, secure, chunked) and nothing else", () => {
    expect(hasSessionCookie(["authjs.session-token"])).toBe(true);
    expect(hasSessionCookie(["__Secure-authjs.session-token.1"])).toBe(true);
    expect(hasSessionCookie(["msclub_locale", "authjs.csrf-token"])).toBe(false);
  });
  it("CSP is nonce-based, blocks inline script/eval in production and frames", () => {
    const csp = buildCsp("abc", false);
    expect(csp).toContain("'nonce-abc'");
    expect(csp).not.toContain("'unsafe-eval'"); // JS eval stays blocked in production
    expect(csp).toContain("'wasm-unsafe-eval'"); // WASM only (QR decoder), served from our origin
    expect(csp).toContain("frame-ancestors 'none'");
    expect(csp).toContain("object-src 'none'");
    expect(csp).toContain("frame-src https://www.youtube-nocookie.com");
    expect(buildCsp("abc", true)).toContain("'unsafe-eval'");
    expect(csp).not.toMatch(/script-src[^;]*https?:/); // no remote script hosts
  });
});
