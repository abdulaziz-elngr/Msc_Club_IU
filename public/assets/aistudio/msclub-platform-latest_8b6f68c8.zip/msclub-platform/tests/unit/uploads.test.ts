import { mkdtempSync, rmSync, readdirSync } from "node:fs";
import { tmpdir } from "node:os";
import path from "node:path";
import { afterAll, describe, expect, it, vi } from "vitest";
import { MAX_IMAGE_BYTES, detectImageType, saveImage } from "@/lib/uploads";

const PNG = Uint8Array.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0]);
const JPG = Uint8Array.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0]);
const WEBP = Uint8Array.from([0x52, 0x49, 0x46, 0x46, 1, 2, 3, 4, 0x57, 0x45, 0x42, 0x50]);
const SVG = new TextEncoder().encode('<svg xmlns="http://www.w3.org/2000/svg"><script>alert(1)</script></svg>');
const HTML_AS_PNG = new TextEncoder().encode("<html><script>alert(1)</script></html>");

const file = (bytes: Uint8Array, name = "x.png", type = "image/png") => new File([bytes as BlobPart], name, { type });

describe("detectImageType (magic bytes)", () => {
  it("recognises png, jpeg and webp", () => {
    expect(detectImageType(PNG)?.ext).toBe("png");
    expect(detectImageType(JPG)?.ext).toBe("jpg");
    expect(detectImageType(WEBP)?.ext).toBe("webp");
  });
  it("refuses svg, html, gif, empty and truncated input", () => {
    for (const bytes of [SVG, HTML_AS_PNG, new TextEncoder().encode("GIF89a"), new Uint8Array(0), PNG.slice(0, 4)]) expect(detectImageType(bytes)).toBeNull();
  });
});

describe("saveImage", () => {
  const cwd = mkdtempSync(path.join(tmpdir(), "uploads-"));
  vi.spyOn(process, "cwd").mockReturnValue(cwd);
  afterAll(() => rmSync(cwd, { recursive: true, force: true }));

  it("rejects a script disguised as an image (client MIME and name are ignored)", async () => {
    expect(await saveImage(file(HTML_AS_PNG, "logo.png", "image/png"), "team-logo")).toEqual({ ok: false, code: "BAD_TYPE" });
    expect(await saveImage(file(SVG, "logo.svg", "image/svg+xml"), "team-logo")).toEqual({ ok: false, code: "BAD_TYPE" });
  });
  it("enforces the size limit and missing files", async () => {
    const big = new Uint8Array(MAX_IMAGE_BYTES + 1); big.set(PNG);
    expect(await saveImage(file(big), "avatar")).toEqual({ ok: false, code: "TOO_LARGE" });
    expect(await saveImage(null, "avatar")).toEqual({ ok: false, code: "NO_FILE" });
    expect(await saveImage(file(new Uint8Array(0)), "avatar")).toEqual({ ok: false, code: "NO_FILE" });
  });
  it("stores under a random name with an extension from the DETECTED type, never the user's filename", async () => {
    const r = await saveImage(file(JPG, "../../etc/passwd.png", "image/png"), "avatar");
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.url).toMatch(/^\/uploads\/avatar\/[0-9a-f]{32}\.jpg$/);
    expect(readdirSync(path.join(cwd, "public/uploads/avatar"))).toHaveLength(1);
  });
});
