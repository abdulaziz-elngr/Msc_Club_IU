import pg from "pg";

const url =
  process.env.DATABASE_URL ?? "postgresql://postgres:postgres@localhost:51214/template1?sslmode=disable";

const dbName = process.env.DB_NAME ?? "msclub";

const client = new pg.Client({ connectionString: url });
await client.connect();
const exists = await client.query("select 1 from pg_database where datname = $1", [dbName]);
if (exists.rowCount === 0) {
  await client.query(`CREATE DATABASE "${dbName}"`);
  console.log(`created database ${dbName}`);
} else {
  console.log(`database ${dbName} already exists`);
}
await client.end();
