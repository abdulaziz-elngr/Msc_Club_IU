// Applies all Prisma migrations to the TEST database (cross-platform: no shell env syntax).
// Usage: npm run test:db   (set TEST_DATABASE_URL, or the default local URL is used)
import { spawnSync } from "node:child_process";

const url = process.env.TEST_DATABASE_URL ?? "postgresql://msclub:msclub@localhost:5432/msclub_test";
const name = new URL(url).pathname.replace(/^\//, "");
if (!/test/i.test(name)) {
  console.error(`Refusing to migrate "${name}": the test database name must contain "test".`);
  process.exit(1);
}

const result = spawnSync("npx", ["prisma", "migrate", "deploy"], {
  stdio: "inherit",
  shell: true,
  env: { ...process.env, DATABASE_URL: url, DIRECT_URL: url },
});
process.exit(result.status ?? 1);
