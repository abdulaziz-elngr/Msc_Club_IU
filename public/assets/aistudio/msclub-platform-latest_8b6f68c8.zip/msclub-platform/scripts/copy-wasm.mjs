// Copies the QR decoder (WASM) next to the app so the scanner never fetches code from a CDN
// (our Content-Security-Policy forbids that). Runs after `npm install`; safe to re-run.
import { copyFileSync, existsSync, mkdirSync } from "node:fs";

const from = "node_modules/zxing-wasm/dist/reader/zxing_reader.wasm";
if (existsSync(from)) {
  mkdirSync("public/zxing", { recursive: true });
  copyFileSync(from, "public/zxing/zxing_reader.wasm");
} else {
  console.warn("[copy-wasm] zxing-wasm not installed yet; skipping.");
}
