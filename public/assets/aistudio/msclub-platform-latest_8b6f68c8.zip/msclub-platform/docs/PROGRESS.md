# Progress — Microsoft Student Clubs Platform

_Last updated: 2026-11-09. Honest status: what is done and verified, what is written but not yet exposed in the UI, and what is not built._

## Verification (final state of this hand-off)

| Check | Result |
|---|---|
| `npx prisma validate` | valid |
| `npx tsc --noEmit` | clean |
| `npm run lint` | clean |
| Migrations (`init` + `hardening_phase2` + `learning_phase5`) on a **fresh** PostgreSQL 16 | apply cleanly |
| `npm run seed` on that fresh DB | works |
| `npm test` (Vitest, real PostgreSQL) | **161 passing in 13 files** |
| `npm run build` | passes (48 routes) |
| Live server probe (`next start`) | public pages 200; `/dashboard`, `/admin/*`, `/team/*`, `/learning/*`, `/events/x/check-in` → 307 to `/login?next=…`; members export 401; cron 503 until `CRON_SECRET` is set; nonce CSP + security headers present |

Not verifiable in the authoring sandbox (please run locally): `prisma migrate diff --from-migrations prisma/migrations --to-schema prisma/schema.prisma --exit-code` (migrations 2 and 3 were hand-written), Playwright browsers (no e2e specs exist yet), real camera scanning, real e-mail delivery.

The Arabic and English certificate PDFs were **rasterised and inspected visually** (RTL order, joined letters, spaces, digits).

## Phase 0 — Audit: bugs found and fixed
1. **XP reversal could never work**: `xp_transactions.reversesId` had an FK to `users`. Fixed (self-relation) — proven by a failing test first.
2. **Auth bypass**: Auth.js `authorize()` skipped status + throttling; suspended users could sign in by POSTing to `/api/auth/callback/credentials`. Fixed; login timing no longer reveals which e-mails exist; throttle is DB-backed.
3. **Un-revocable sessions**: `User.sessionVersion` — suspension / password reset invalidate all JWTs; blocked accounts never get an auth context.
4. **QR tokens**: were `cuid()` and stored in clear → now HMAC-SHA256 (256-bit), nothing stored, revocable per pass or globally.
5. **XP lost-update race**: row lock added (mutation-tested: removing it fails tests).
6. Check-in non-atomic / un-retryable XP; XP ignored per-event points; manual check-in of cancelled registrations; CSV formula injection; audit `ip` dropped; level-ups never notified; case-sensitive e-mail lookups; lint errors; unvetted `cn` package; Google-Fonts build dependency (fonts self-hosted); `prisma7.config.ts` not auto-detected.

## What exists

### Public site
`/`, `/about` (live stats), `/events` (filters, pagination), `/events/[slug]` (custom-field registration, waitlist, capacity, cancel), `/teams`, `/teams/[slug]` (roster respects privacy), `/leaderboard` (global / team / event / track × weekly / monthly / all-time; privacy + admin visibility respected), auth pages.

### Member portal (`/dashboard`)
Overview (real data), `/dashboard/events` (QR pass), `/dashboard/events/checkin` (self check-in from the venue's rotating QR).

### Admin (`/admin`) — permission-filtered, command palette (Ctrl/⌘+K), breadcrumbs, RTL-aware
Overview (KPIs + Recharts), **Events** (CRUD, form builder, registrations, attendance report + corrections, reminders, rotating QR, CSV exports, waitlist fill), **camera scanner** (`/events/[id]/check-in`, mobile-first, manual fallback), **Applications** (workflow + history + e-mail), **Members** (profile, suspend/reactivate, roles with escalation guards, export), **Roles** (read-only matrix), **Teams** (CRUD, archive, leadership, members, logo upload), **Settings** (site, required application fields, leaderboard, YouTube notice), **Audit log** (filters + pagination), **Content** (social links, testimonials), **Messages** (inbox), **Points** (rules CRUD, award, adjust, reversal, ledger), **Levels**, **Badges**, **Leaderboard**.

### Team workspace (`/team/[slug]/…`)
`dashboard`, `members`, `analytics` — guarded with `requireTeamAccess` (cross-team isolation tested; missing and forbidden teams both return 404).

### Engines / services (tested)
Registration (row-locked capacity, waitlist auto-promotion), attendance (QR, manual, rotating code, corrections), XP ledger (idempotent, locked, reversible, level-ups), applications workflow, role assignment guards, team administration, leaderboard queries, **certificates** (idempotent issue, public verification with masked name, revoke, bilingual PDF), **learning engine** (enrol + prerequisites, sequential lessons, server-credited watch time, completion, XP/certificate once), uploads (magic-byte validation), CSV, cron reminders (secret-protected, claim-once).

## Not built yet (honest list)
- **Learning UI**: `/learning` catalog, `/learning/[slug]`, `/learning/[slug]/[lesson]`, `/dashboard/learning`, `VideoProvider` + secure YouTube player, `/admin/learning` CRUD (tracks/courses/modules/lessons, ordering, prerequisites UI), `/team/[slug]/learning`. _(The engine behind them is done and tested; `proxy.ts` already protects `/learning/*`.)_
- **Tasks**: service + `/dashboard/tasks`, `/admin/tasks`, `/team/[slug]/tasks` (schema and XP rule `task.approved` exist).
- **Certificates UI/routes**: `/api/certificates/[code]/pdf`, `/verify/[code]`, `/dashboard/certificates`, `/admin/certificates` (+ templates).
- **Notifications UI** (`/dashboard/notifications` + preferences), branded e-mail templates (welcome, verify, reset, registration, reminder, QR, achievement), QR e-mail.
- **Analytics**: `/admin/analytics`.
- **Public**: `/join` (application form), `/contact` (store + e-mail), `/workshops`, public member profile `/members/[id]` (leaderboard already links to it for public profiles), testimonials + social links on the homepage/footer still use static values (admin editors exist and store data).
- **Portal**: `/dashboard/profile` (edit, privacy, avatar), `/dashboard/points`, `/dashboard/achievements`, level-up animation.
- Auth server-action messages are still English-only.
- Playwright e2e specs; full audit-coverage review of the not-yet-built actions.

## Known limitations / design notes
- A manually revoked **auto** badge can be re-awarded on the next evaluation (no "never re-award" flag yet).
- "Watch time" is time-on-lesson credited by heartbeats (capped by real elapsed time on the server); it does not prove the YouTube player was playing. Unlisted YouTube videos are not private — the admin notice says so.
- Local upload fallback (`public/uploads`) is development-only; configure Cloudinary on serverless hosts.
- Member-action rate limiting is per instance (in-memory); login throttling is DB-backed.
- Rotating `QR_SECRET` invalidates every issued pass.
- No secrets in this repo; the original `.env` was never copied.
