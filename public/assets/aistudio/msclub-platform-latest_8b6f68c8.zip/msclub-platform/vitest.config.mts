import path from "node:path";
import { defineConfig } from "vitest/config";

export default defineConfig({
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "src"),
      // Next ships CJS entry points without an exports map; point Vite at the files directly.
      "next/server": path.resolve(import.meta.dirname, "node_modules/next/server.js"),
      "next/navigation": path.resolve(import.meta.dirname, "node_modules/next/navigation.js"),
      // `server-only` throws when imported outside a React Server environment.
      "server-only": path.resolve(import.meta.dirname, "tests/helpers/server-only-stub.ts"),
    },
  },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    setupFiles: ["tests/helpers/setup.ts"],
    // Integration tests share one database, so files run one after another.
    fileParallelism: false,
    testTimeout: 30_000,
    hookTimeout: 30_000,
  },
});
