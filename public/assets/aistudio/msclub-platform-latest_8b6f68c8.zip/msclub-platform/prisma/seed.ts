import "dotenv/config";
import { hash } from "bcryptjs";
import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient, type RoleKey, type TrackKind, type EventCategory, type EventStatus } from "../src/generated/client";
import { ALL_PERMISSION_KEYS, PERMISSION_GROUPS } from "../src/lib/rbac/permissions";
import { DEFAULT_ROLE_PERMISSIONS, ROLE_LABELS, ROLE_KEYS } from "../src/lib/rbac/roles";

/**
 * Idempotent database seed.
 *
 * Run with `npm run db:seed`. Every write is an upsert keyed on a natural
 * unique column, so re-running never duplicates rows and never clobbers an
 * administrator's customisation of an existing record's label.
 *
 * What it creates:
 *   1. RBAC      — permissions, roles, default grants
 *   2. Progress  — level ladder, points catalogue, badges
 *   3. Content   — technical departments, learning tracks, site settings
 *   4. Templates — certificate templates
 *   5. Accounts  — the super administrator from SEED_ADMIN_*
 *   6. Demo data — a small, clearly-documented set of events/courses so the
 *                  analytics, leaderboards and public pages are not empty
 */

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  throw new Error("DATABASE_URL is not set — copy .env.example to .env first.");
}
// Prisma 7 requires an explicit driver adapter; the seed runs outside the
// Next.js runtime so it builds its own client from the same connection string.
const prisma = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

// ------------------------------------------------------------------------------
// 1. RBAC
// ------------------------------------------------------------------------------
async function seedRbac() {
  const groupOf = new Map<string, string>();
  for (const [group, list] of Object.entries(PERMISSION_GROUPS)) {
    for (const permission of list) groupOf.set(permission.key, group);
  }

  const permissionRows = Object.values(PERMISSION_GROUPS)
    .flatMap((group) => group)
    .map((permission) => ({
      key: permission.key,
      label: permission.label,
      labelAr: permission.labelAr,
      group: groupOf.get(permission.key) ?? "other",
    }));

  // Ensure every catalogue key exists even if a group entry was missed.
  const seen = new Set(permissionRows.map((p) => p.key));
  for (const key of ALL_PERMISSION_KEYS) {
    if (!seen.has(key)) permissionRows.push({ key, label: key, labelAr: key, group: "other" });
  }

  for (const permission of permissionRows) {
    await prisma.permission.upsert({
      where: { key: permission.key },
      create: permission,
      update: { label: permission.label, labelAr: permission.labelAr, group: permission.group },
    });
  }

  for (const key of ROLE_KEYS) {
    const label = ROLE_LABELS[key];
    await prisma.role.upsert({
      where: { key: key as RoleKey },
      create: { key: key as RoleKey, name: label.en, nameAr: label.ar },
      update: { name: label.en, nameAr: label.ar },
    });
  }

  // Add any missing default grant. Existing grants are left alone so an
  // administrator's edits survive a re-seed.
  let grantsAdded = 0;
  for (const key of ROLE_KEYS) {
    const role = await prisma.role.findUnique({ where: { key: key as RoleKey }, select: { id: true } });
    if (!role) continue;
    const desired = DEFAULT_ROLE_PERMISSIONS[key];
    const existing = await prisma.rolePermission.findMany({
      where: { roleId: role.id },
      select: { permissionId: true },
    });
    const have = new Set(existing.map((g) => g.permissionId));

    const permissions = await prisma.permission.findMany({
      where: { key: { in: desired } },
      select: { id: true },
    });
    const missing = permissions.filter((p) => !have.has(p.id));

    if (missing.length > 0) {
      await prisma.rolePermission.createMany({
        data: missing.map((permission) => ({ roleId: role.id, permissionId: permission.id })),
        skipDuplicates: true,
      });
      grantsAdded += missing.length;
    }
  }

  console.log(`  • ${permissionRows.length} permissions, ${ROLE_KEYS.length} roles, ${grantsAdded} grants added`);
}

// ------------------------------------------------------------------------------
// 2. Progression: levels, points, badges
// ------------------------------------------------------------------------------
const LEVELS = [
  { key: "rookie", name: "Rookie", nameAr: "مبتدئ", minXp: 0, icon: "seedling", color: "#7C8A9C" },
  { key: "explorer", name: "Explorer", nameAr: "مستكشف", minXp: 100, icon: "compass", color: "#599FE4" },
  { key: "builder", name: "Builder", nameAr: "بانٍ", minXp: 300, icon: "hammer", color: "#1B6AC4" },
  { key: "developer", name: "Developer", nameAr: "مطوّر", minXp: 700, icon: "code", color: "#16569F" },
  { key: "engineer", name: "Engineer", nameAr: "مهندس", minXp: 1400, icon: "wrench", color: "#123F6E" },
  { key: "architect", name: "Architect", nameAr: "معماري", minXp: 2500, icon: "layers", color: "#0B2545" },
  { key: "specialist", name: "Specialist", nameAr: "أخصائي", minXp: 4000, icon: "badge-check", color: "#039855" },
  { key: "mentor", name: "Mentor", nameAr: "مرشد", minXp: 6000, icon: "users", color: "#7C3AED" },
  { key: "champion", name: "Champion", nameAr: "بطل", minXp: 9000, icon: "trophy", color: "#F59E0B" },
  { key: "legend", name: "Legend", nameAr: "أسطورة", minXp: 14000, icon: "sparkles", color: "#DC6803" },
];

const POINTS_RULES = [
  { key: "event.register", activityType: "EVENT", label: "Register for an event", labelAr: "التسجيل في فعالية", points: 10, referenceType: "EVENT" as const, maxAwardsPerUser: null },
  { key: "event.attendance", activityType: "ATTENDANCE", label: "Attend an event", labelAr: "حضور فعالية", points: 50, referenceType: "ATTENDANCE" as const, maxAwardsPerUser: null },
  { key: "event.completion", activityType: "EVENT", label: "Complete an event", labelAr: "إتمام فعالية", points: 30, referenceType: "EVENT" as const, maxAwardsPerUser: null },
  { key: "course.enroll", activityType: "COURSE", label: "Enroll in a course", labelAr: "الالتحاق بدورة", points: 15, referenceType: "COURSE" as const, maxAwardsPerUser: null },
  { key: "lesson.complete", activityType: "LESSON", label: "Complete a lesson", labelAr: "إتمام درس", points: 10, referenceType: "LESSON" as const, maxAwardsPerUser: null },
  { key: "course.complete", activityType: "COURSE", label: "Complete a course", labelAr: "إتمام دورة", points: 250, referenceType: "COURSE" as const, maxAwardsPerUser: null },
  { key: "task.assigned", activityType: "TASK", label: "Task assigned", labelAr: "إسناد مهمة", points: 5, referenceType: "TASK" as const, maxAwardsPerUser: null },
  { key: "task.approved", activityType: "TASK", label: "Task approved", labelAr: "اعتماد المهمة", points: 80, referenceType: "TASK" as const, maxAwardsPerUser: null },
  { key: "submission.approved", activityType: "SUBMISSION", label: "Submission approved", labelAr: "اعتماد التسليم", points: 60, referenceType: "SUBMISSION" as const, maxAwardsPerUser: null },
  { key: "profile.completed", activityType: "ADMIN_ADJUSTMENT", label: "Complete your profile", labelAr: "إكمال الملف الشخصي", points: 20, referenceType: "ADMIN_ADJUSTMENT" as const, maxAwardsPerUser: 1 },
  { key: "welcome", activityType: "ADMIN_ADJUSTMENT", label: "Welcome bonus", labelAr: "مكافأة الترحيب", points: 25, referenceType: "ADMIN_ADJUSTMENT" as const, maxAwardsPerUser: 1 },
  { key: "admin.adjustment", activityType: "ADMIN_ADJUSTMENT", label: "Manual adjustment", labelAr: "تعديل يدوي", points: 0, referenceType: "ADMIN_ADJUSTMENT" as const, maxAwardsPerUser: null },
];

const BADGES = [
  { key: "first-steps", name: "First Steps", nameAr: "الخطوة الأولى", description: "Joined the club and completed your profile.", descriptionAr: "انضممت إلى النادي وأكملت ملفك الشخصي.", icon: "footprints", tier: "bronze", order: 1, criteria: { type: "total_xp", threshold: 50 } },
  { key: "event-rookie", name: "Event Rookie", nameAr: "مبتدئ الفعاليات", description: "Attended your first club event.", descriptionAr: "حضرت أول فعالية للنادٍ.", icon: "calendar-check", tier: "bronze", order: 2, criteria: { type: "events_attended", threshold: 1 } },
  { key: "regular", name: "Regular", nameAr: "منظم", description: "Attended 5 club events.", descriptionAr: "حضرت 5 فعاليات للنادٍ.", icon: "calendar-days", tier: "silver", order: 3, criteria: { type: "events_attended", threshold: 5 } },
  { key: "course-completer", name: "Course Completer", nameAr: "مكمل الدورات", description: "Finished your first course.", descriptionAr: "أكملت أول دورة لك.", icon: "graduation-cap", tier: "silver", order: 4, criteria: { type: "courses_completed", threshold: 1 } },
  { key: "lifelong-learner", name: "Lifelong Learner", nameAr: "متعلم دائم", description: "Completed 3 courses.", descriptionAr: "أكملت 3 دورات.", icon: "book-open", tier: "gold", order: 5, criteria: { type: "courses_completed", threshold: 3 } },
  { key: "task-master", name: "Task Master", nameAr: "متقن المهام", description: "Had 5 tasks approved.", descriptionAr: "تم اعتماد 5 مهام لك.", icon: "clipboard-check", tier: "gold", order: 6, criteria: { type: "tasks_approved", threshold: 5 } },
  { key: "certified", name: "Certified", nameAr: "معتمد", description: "Earned a club certificate.", descriptionAr: "حصلت على شهادة من النادي.", icon: "award", tier: "silver", order: 7, criteria: { type: "certificates", threshold: 1 } },
  { key: "level-5", name: "Level 5", nameAr: "المستوى الخامس", description: "Reached the Engineer level.", descriptionAr: "وصلت إلى مستوى المهندس.", icon: "star", tier: "gold", order: 8, criteria: { type: "level", threshold: 5 } },
  { key: "century", name: "Century", nameAr: "المئة", description: "Accumulated 1000 XP.", descriptionAr: "جمعت 1000 نقطة خبرة.", icon: "zap", tier: "gold", order: 9, criteria: { type: "total_xp", threshold: 1000 } },
  { key: "collector", name: "Collector", nameAr: "جامع الشارات", description: "Earned 5 badges.", descriptionAr: "حصلت على 5 شارات.", icon: "medal", tier: "platinum", order: 10, criteria: { type: "badges_count", threshold: 5 } },
];

async function seedProgression() {
  for (const [index, level] of LEVELS.entries()) {
    await prisma.level.upsert({
      where: { key: level.key },
      create: { key: level.key, name: level.name, nameAr: level.nameAr, minXp: level.minXp, order: index + 1, icon: level.icon, color: level.color },
      update: { name: level.name, nameAr: level.nameAr, minXp: level.minXp, order: index + 1, icon: level.icon, color: level.color },
    });
  }

  for (const rule of POINTS_RULES) {
    await prisma.pointsRule.upsert({
      where: { key: rule.key },
      create: {
        key: rule.key,
        activityType: rule.activityType,
        label: rule.label,
        labelAr: rule.labelAr,
        points: rule.points,
        referenceType: rule.referenceType,
        maxAwardsPerUser: rule.maxAwardsPerUser,
      },
      update: {
        label: rule.label,
        labelAr: rule.labelAr,
        points: rule.points,
        referenceType: rule.referenceType,
        maxAwardsPerUser: rule.maxAwardsPerUser,
      },
    });
  }

  for (const badge of BADGES) {
    await prisma.badge.upsert({
      where: { key: badge.key },
      create: {
        key: badge.key,
        name: badge.name,
        nameAr: badge.nameAr,
        description: badge.description,
        descriptionAr: badge.descriptionAr,
        icon: badge.icon,
        tier: badge.tier,
        order: badge.order,
        criteria: badge.criteria,
      },
      update: {
        name: badge.name,
        nameAr: badge.nameAr,
        description: badge.description,
        descriptionAr: badge.descriptionAr,
        icon: badge.icon,
        tier: badge.tier,
        order: badge.order,
        criteria: badge.criteria,
      },
    });
  }

  console.log(`  • ${LEVELS.length} levels, ${POINTS_RULES.length} point rules, ${BADGES.length} badges`);
}

// ------------------------------------------------------------------------------
// 3. Tracks & settings
// ------------------------------------------------------------------------------
const TRACKS: {
  slug: string;
  name: string;
  nameAr: string;
  description: string;
  descriptionAr: string;
  icon: string;
  kind: TrackKind;
  order: number;
}[] = [
  { slug: "web-development", name: "Web Development", nameAr: "تطوير الويب", description: "React, Next.js and the full TypeScript stack.", descriptionAr: "React وNext.js ومكدس TypeScript بالكامل.", icon: "code-2", kind: "BOTH", order: 1 },
  { slug: "ai-data", name: "AI & Data", nameAr: "الذكاء الاصطناعي والبيانات", description: "Machine learning, Azure AI and data engineering.", descriptionAr: "تعلم الآلة وAzure AI وهندسة البيانات.", icon: "brain", kind: "BOTH", order: 2 },
  { slug: "cloud-devops", name: "Cloud & DevOps", nameAr: "السحابة وعمليات التطوير", description: "Azure, containers, CI/CD and infrastructure as code.", descriptionAr: "Azure والحاويات وCI/CD والبنية التحتية كشيفرة.", icon: "cloud", kind: "BOTH", order: 3 },
  { slug: "cybersecurity", name: "Cybersecurity", nameAr: "الأمن السيبراني", description: "Defensive security, identity and secure development.", descriptionAr: "الأمن الدفاعي والهوية والتطوير الآمن.", icon: "shield", kind: "BOTH", order: 4 },
  { slug: "mobile", name: "Mobile Development", nameAr: "تطوير التطبيقات", description: ".NET MAUI, React Native and cross-platform delivery.", descriptionAr: ".NET MAUI وReact Native والتطوير متعدد المنصات.", icon: "smartphone", kind: "BOTH", order: 5 },
  { slug: "product-design", name: "Product & Design", nameAr: "المنتج والتصميم", description: "Fluent design, UX research and product thinking.", descriptionAr: "تصميم Fluent وبحث تجربة المستخدم والتفكير المنتجي.", icon: "palette", kind: "BOTH", order: 6 },
  { slug: "foundations", name: "Programming Foundations", nameAr: "أساسيات البرمجة", description: "Beginner-friendly track for first-year members.", descriptionAr: "مسار للمبتدئين لأعضاء السنة الأولى.", icon: "book-open", kind: "LEARNING", order: 7 },
  { slug: "certification-prep", name: "Certification Prep", nameAr: "التحضير للشهادات", description: "AZ-900, PL-900 and MD-102 study paths.", descriptionAr: "مسارات تحضير AZ-900 وPL-900 وMD-102.", icon: "badge-check", kind: "LEARNING", order: 8 },
];

const SETTINGS: { key: string; value: unknown; type: string; label: string; labelAr: string }[] = [
  { key: "site.name", value: "Microsoft Student Clubs", type: "string", label: "Site name", labelAr: "اسم الموقع" },
  { key: "site.tagline", value: "Innovation University", type: "string", label: "Tagline", labelAr: "الشعار النصي" },
  { key: "site.contactEmail", value: "clubs@innovationuniversity.edu", type: "string", label: "Contact email", labelAr: "بريد التواصل" },
  { key: "site.contactPhone", value: "+20 100 000 0000", type: "string", label: "Contact phone", labelAr: "هاتف التواصل" },
  { key: "site.address", value: "Innovation University, Campus 1, Building C", type: "string", label: "Address", labelAr: "العنوان" },
  {
    key: "site.social",
    value: { instagram: "https://instagram.com/", linkedin: "https://linkedin.com/", youtube: "https://youtube.com/", github: "https://github.com/" },
    type: "json",
    label: "Social links",
    labelAr: "روابط التواصل الاجتماعي",
  },
  { key: "registration.open", value: true, type: "boolean", label: "Accept new applications", labelAr: "قبول طلبات جديدة" },
  { key: "leaderboard.period", value: "monthly", type: "string", label: "Leaderboard period", labelAr: "فترة لوحة المتصدرين" },
  { key: "xp.welcome", value: 25, type: "number", label: "Welcome XP", labelAr: "نقاط الترحيب" },
];

async function seedContent() {
  for (const track of TRACKS) {
    await prisma.learningTrack.upsert({
      where: { slug: track.slug },
      create: track,
      update: { name: track.name, nameAr: track.nameAr, description: track.description, descriptionAr: track.descriptionAr, icon: track.icon, kind: track.kind, order: track.order },
    });
  }

  for (const setting of SETTINGS) {
    await prisma.siteSettings.upsert({
      where: { key: setting.key },
      create: { key: setting.key, value: setting.value as never, type: setting.type, label: setting.label, labelAr: setting.labelAr },
      update: { value: setting.value as never, type: setting.type, label: setting.label, labelAr: setting.labelAr },
    });
  }

  const templates = [
    { key: "course-completion", name: "Course completion", nameAr: "إتمام دورة", type: "COURSE" as const, heading: "Certificate of Completion", headingAr: "شهادة إتمام", body: "This is to certify that", bodyAr: "تشهد هذه الشهادة أن" },
    { key: "event-participation", name: "Event participation", nameAr: "المشاركة في فعالية", type: "PARTICIPATION" as const, heading: "Certificate of Participation", headingAr: "شهادة مشاركة", body: "This is to certify that", bodyAr: "تشهد هذه الشهادة أن" },
    { key: "achievement", name: "Achievement", nameAr: "إنجاز", type: "ACHIEVEMENT" as const, heading: "Certificate of Achievement", headingAr: "شهادة إنجاز", body: "This is to certify that", bodyAr: "تشهد هذه الشهادة أن" },
    { key: "event-completion", name: "Event completion", nameAr: "إتمام فعالية", type: "EVENT" as const, heading: "Certificate of Completion", headingAr: "شهادة إتمام", body: "This is to certify that", bodyAr: "تشهد هذه الشهادة أن" },
  ];

  for (const template of templates) {
    await prisma.certificateTemplate.upsert({
      where: { key: template.key },
      create: template,
      update: { name: template.name, nameAr: template.nameAr, type: template.type, heading: template.heading, headingAr: template.headingAr, body: template.body, bodyAr: template.bodyAr },
    });
  }

  const testimonials = [
    { name: "Mariam Adel", nameAr: "مريم عادل", role: "Team Lead, Web Development", roleAr: "قائدة فريق تطوير الويب", quote: "I joined with zero project experience. Six months later I was leading a team shipping a real product.", quoteAr: "انضممت بلا خبرة في المشاريع. بعد ستة أشهر كنت أقود فريقًا يطلق منتجًا حقيقيًا.", approved: true, order: 1 },
    { name: "Omar Khaled", nameAr: "عمر خالد", role: "Member since 2024", roleAr: "عضو منذ 2024", quote: "The learning hub and the XP system made studying feel like a game I actually wanted to win.", quoteAr: "مركز التعلم ونظام النقاط جعل الدراسة تبدو لعبة أردتها الفوز بها.", approved: true, order: 2 },
    { name: "Salma Hassan", nameAr: "سلمى حسن", role: "HR Lead", roleAr: "قائدة الموارد البشرية", quote: "Reviewing applications taught me more about people than any course on my transcript.", quoteAr: "مراجعة الطلبات علّمني عن الناس أكثر من أي مادة في كشف الدرجات.", approved: true, order: 3 },
  ];

  for (const testimonial of testimonials) {
    const existing = await prisma.testimonial.findFirst({ where: { name: testimonial.name }, select: { id: true } });
    if (existing) {
      await prisma.testimonial.update({ where: { id: existing.id }, data: testimonial });
    } else {
      await prisma.testimonial.create({ data: testimonial });
    }
  }

  console.log(`  • ${TRACKS.length} tracks, ${SETTINGS.length} settings, ${templates.length} certificate templates`);
}

// ------------------------------------------------------------------------------
// 4. Accounts
// ------------------------------------------------------------------------------
async function seedAccounts() {
  const email = (process.env.SEED_ADMIN_EMAIL ?? "admin@innovationuniversity.edu").toLowerCase();
  const password = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMe!12345";
  const passwordHash = await hash(password, 12);

  const admin = await prisma.user.upsert({
    where: { email },
    create: {
      email,
      name: "Club Administrator",
      passwordHash,
      status: "ACTIVE",
      emailVerified: new Date(),
      bio: "Seeded super administrator account.",
      roles: { create: [{ role: { connect: { key: "SUPER_ADMIN" } } }] },
    },
    update: { passwordHash, status: "ACTIVE", emailVerified: new Date() },
    select: { id: true, roles: { select: { role: { select: { key: true } } } } },
  });

  // Re-grant SUPER_ADMIN if the link was removed manually.
  const hasSuperAdmin = admin.roles.some((r) => r.role.key === "SUPER_ADMIN");
  if (!hasSuperAdmin) {
    const role = await prisma.role.findUnique({
      where: { key: "SUPER_ADMIN" },
      select: { id: true },
    });
    if (role) {
      await prisma.userRole.upsert({
        where: { userId_roleId: { userId: admin.id, roleId: role.id } },
        create: { userId: admin.id, roleId: role.id },
        update: {},
      });
    }
  }

  console.log(`  • super admin: ${email}`);
}

// ------------------------------------------------------------------------------
// 5. Demo content (documented sample data — replace or delete freely)
// ------------------------------------------------------------------------------
async function seedDemoContent() {
  if (process.env.SEED_DEMO === "false") {
    console.log("  • demo content skipped (SEED_DEMO=false)");
    return;
  }

  const organizer = await prisma.user.findUnique({
    where: { email: (process.env.SEED_ADMIN_EMAIL ?? "admin@innovationuniversity.edu").toLowerCase() },
    select: { id: true },
  });

  const events: {
    slug: string;
    title: string;
    titleAr: string;
    summary: string;
    category: EventCategory;
    status: EventStatus;
    daysFromNow: number;
    durationHours: number;
    capacity: number;
    attendancePoints: number;
    location: string;
  }[] = [
    { slug: "nextjs-workshop", title: "Next.js App Router Workshop", titleAr: "ورشة عمل Next.js", summary: "Build and deploy a full-stack app in one session.", category: "WORKSHOP", status: "REGISTRATION_OPEN", daysFromNow: 7, durationHours: 3, capacity: 40, attendancePoints: 50, location: "Lab C-201" },
    { slug: "azure-ai-session", title: "Intro to Azure OpenAI", titleAr: "مقدمة إلى Azure OpenAI", summary: "Prompt design, responsible AI and a live demo.", category: "TECHNICAL_SESSION", status: "REGISTRATION_OPEN", daysFromNow: 14, durationHours: 2, capacity: 60, attendancePoints: 40, location: "Main Hall" },
    { slug: "campus-hackathon", title: "Innovation Campus Hackathon", titleAr: "هاكاثون الحرم الجامعي", summary: "24 hours, one theme, teams of four.", category: "HACKATHON", status: "PUBLISHED", daysFromNow: 30, durationHours: 24, capacity: 80, attendancePoints: 120, location: "Innovation Center" },
    { slug: "fluent-design-bootcamp", title: "Fluent Design Bootcamp", titleAr: "معسكر تصميم Fluent", summary: "Design accessible interfaces with the Fluent system.", category: "BOOTCAMP", status: "COMPLETED", daysFromNow: -21, durationHours: 5, capacity: 35, attendancePoints: 60, location: "Studio B" },
    { slug: "career-day", title: "Industry Career Day", titleAr: "يوم الوظائف الصناعية", summary: "Recruiters, mock interviews and portfolio reviews.", category: "COMMUNITY", status: "COMPLETED", daysFromNow: -45, durationHours: 6, capacity: 120, attendancePoints: 70, location: "Auditorium" },
  ];

  for (const event of events) {
    const startsAt = new Date(Date.now() + event.daysFromNow * 86_400_000);
    const endsAt = new Date(startsAt.getTime() + event.durationHours * 3_600_000);
    const publishedAt = event.status === "DRAFT" ? null : new Date(Date.now() - 5 * 86_400_000);

    await prisma.event.upsert({
      where: { slug: event.slug },
      create: {
        slug: event.slug,
        title: event.title,
        titleAr: event.titleAr,
        summary: event.summary,
        description: `${event.summary}\n\nMembers bring their own laptops. Attendance is recorded with a QR pass issued in the member portal.`,
        category: event.category,
        status: event.status,
        startsAt,
        endsAt,
        capacity: event.capacity,
        attendancePoints: event.attendancePoints,
        completionPoints: Math.round(event.attendancePoints / 2),
        certificateEnabled: true,
        location: event.location,
        organizerId: organizer?.id ?? null,
        publishedAt,
      },
      update: {
        title: event.title,
        titleAr: event.titleAr,
        summary: event.summary,
        category: event.category,
        status: event.status,
        startsAt,
        endsAt,
        capacity: event.capacity,
        attendancePoints: event.attendancePoints,
        location: event.location,
        publishedAt,
      },
    });
  }

  const courses: { slug: string; title: string; titleAr: string; summary: string; trackSlug: string; lessons: number; published: boolean; featured?: boolean }[] = [
    { slug: "typescript-fundamentals", title: "TypeScript Fundamentals", titleAr: "أساسيات TypeScript", summary: "Types, generics and tooling for modern JavaScript.", trackSlug: "web-development", lessons: 8, published: true, featured: true },
    { slug: "azure-fundamentals-az-900", title: "Azure Fundamentals (AZ-900)", titleAr: "أساسيات Azure (AZ-900)", summary: "Cloud concepts, core services and governance.", trackSlug: "certification-prep", lessons: 6, published: true, featured: true },
    { slug: "python-for-data", title: "Python for Data", titleAr: "بايثون للبيانات", summary: "NumPy, pandas and your first analysis notebook.", trackSlug: "ai-data", lessons: 7, published: true },
  ];

  for (const course of courses) {
    const track = await prisma.learningTrack.findUnique({ where: { slug: course.trackSlug }, select: { id: true } });
    const existing = await prisma.course.findUnique({ where: { slug: course.slug }, select: { id: true } });
    const data = {
      title: course.title,
      titleAr: course.titleAr,
      summary: course.summary,
      description: course.summary,
      trackId: track?.id ?? null,
      published: course.published,
      featured: course.featured ?? false,
      difficulty: "BEGINNER" as const,
      durationMinutes: course.lessons * 45,
      objectives: ["Understand the core concepts", "Apply them in a small project", "Know where to go next"],
      xpReward: course.lessons * 10 + 250,
      certificateEnabled: true,
      createdById: organizer?.id ?? null,
    };

    const courseRow = existing
      ? await prisma.course.update({ where: { id: existing.id }, data, select: { id: true } })
      : await prisma.course.create({ data: { slug: course.slug, ...data }, select: { id: true } });

    const moduleCount = existing ? await prisma.courseModule.count({ where: { courseId: courseRow.id } }) : 0;
    if (moduleCount === 0) {
      const courseModule = await prisma.courseModule.create({
        data: { courseId: courseRow.id, title: "Core concepts", order: 1 },
        select: { id: true },
      });
      for (let i = 1; i <= course.lessons; i += 1) {
        await prisma.lesson.create({
          data: {
            moduleId: courseModule.id,
            courseId: courseRow.id,
            title: `Lesson ${i}`,
            order: i,
            durationSeconds: 45 * 60,
            xpReward: 10,
          },
        });
      }
    }
  }

  console.log(`  • ${events.length} events, ${courses.length} courses`);
}

async function main() {
  console.log("Seeding Microsoft Student Clubs platform…");
  await seedRbac();
  await seedProgression();
  await seedContent();
  await seedAccounts();
  await seedDemoContent();
  console.log("Seed complete.");
}

main()
  .catch((error) => {
    console.error("Seed failed:", error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
