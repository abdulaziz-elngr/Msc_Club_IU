-- Hardening pass (Phase 0 audit)
--  1. xp_transactions.reversesId pointed at users(id); reversals reference another ledger row.
--  2. event_registrations.qrToken used cuid() (low entropy) and was stored in clear.
--     QR passes are now HMAC-signed from (registration id, qrVersion) and not stored at all.
--  3. users.sessionVersion lets password changes / suspensions revoke existing JWTs.
--  4. contact_messages backs the public /contact form.

-- 1 ---------------------------------------------------------------------------
ALTER TABLE "xp_transactions" DROP CONSTRAINT "xp_transactions_reversesId_fkey";
UPDATE "xp_transactions" SET "reversesId" = NULL
  WHERE "reversesId" IS NOT NULL AND "reversesId" NOT IN (SELECT "id" FROM "xp_transactions");
ALTER TABLE "xp_transactions"
  ADD CONSTRAINT "xp_transactions_reversesId_fkey"
  FOREIGN KEY ("reversesId") REFERENCES "xp_transactions"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- 2 ---------------------------------------------------------------------------
DROP INDEX IF EXISTS "event_registrations_qrToken_key";
ALTER TABLE "event_registrations" DROP COLUMN "qrToken";
ALTER TABLE "event_registrations" ADD COLUMN "qrVersion" INTEGER NOT NULL DEFAULT 1;

-- 3 ---------------------------------------------------------------------------
ALTER TABLE "users" ADD COLUMN "sessionVersion" INTEGER NOT NULL DEFAULT 0;

-- 4 ---------------------------------------------------------------------------
CREATE TABLE "contact_messages" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "locale" "Locale" NOT NULL DEFAULT 'EN',
    "ip" TEXT,
    "readAt" TIMESTAMP(3),
    "repliedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "contact_messages_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "contact_messages_readAt_createdAt_idx" ON "contact_messages"("readAt", "createdAt");
