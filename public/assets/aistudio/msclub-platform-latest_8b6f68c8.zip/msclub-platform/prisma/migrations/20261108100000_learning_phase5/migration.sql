-- Phase 5: real course prerequisites, sequential lessons, server-side watch-time tracking.

ALTER TABLE "courses" ADD COLUMN "sequential" BOOLEAN NOT NULL DEFAULT false;

ALTER TABLE "lesson_progress" ADD COLUMN "lastHeartbeatAt" TIMESTAMP(3);

CREATE TABLE "course_prerequisites" (
    "courseId" TEXT NOT NULL,
    "requiresId" TEXT NOT NULL,
    CONSTRAINT "course_prerequisites_pkey" PRIMARY KEY ("courseId","requiresId"),
    CONSTRAINT "course_prerequisites_not_self" CHECK ("courseId" <> "requiresId")
);

CREATE INDEX "course_prerequisites_requiresId_idx" ON "course_prerequisites"("requiresId");

ALTER TABLE "course_prerequisites" ADD CONSTRAINT "course_prerequisites_courseId_fkey" FOREIGN KEY ("courseId") REFERENCES "courses"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "course_prerequisites" ADD CONSTRAINT "course_prerequisites_requiresId_fkey" FOREIGN KEY ("requiresId") REFERENCES "courses"("id") ON DELETE CASCADE ON UPDATE CASCADE;
