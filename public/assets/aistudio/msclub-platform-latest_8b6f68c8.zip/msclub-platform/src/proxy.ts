import { NextResponse, type NextRequest } from "next/server";
import { buildCsp, hasSessionCookie, isProtectedPath } from "@/lib/proxy-rules";
import { loginPathWithNext } from "@/lib/auth/policy";

/**
 * Next.js 16 `proxy` (formerly middleware).
 *  1. Optimistic auth gate: anonymous visitors to protected routes are sent to
 *     /login?next=… without hitting the renderer. Real authorization happens in
 *     the pages / actions via `lib/auth/dal.ts`.
 *  2. Per-request CSP nonce.
 */
export function proxy(request: NextRequest) {
  const { pathname, search } = request.nextUrl;

  if (isProtectedPath(pathname) && !hasSessionCookie(request.cookies.getAll().map((c) => c.name))) {
    return NextResponse.redirect(new URL(loginPathWithNext(pathname, search), request.url));
  }

  const nonce = Buffer.from(crypto.randomUUID()).toString("base64");
  const csp = buildCsp(nonce, process.env.NODE_ENV === "development");

  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-nonce", nonce);
  requestHeaders.set("Content-Security-Policy", csp);

  const response = NextResponse.next({ request: { headers: requestHeaders } });
  response.headers.set("Content-Security-Policy", csp);
  return response;
}

export const config = {
  matcher: [
    {
      // Skip static assets, image optimisation and prefetches.
      source: "/((?!api/|_next/static|_next/image|favicon.ico|icon.svg|brand/|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)",
      missing: [
        { type: "header", key: "next-router-prefetch" },
        { type: "header", key: "purpose", value: "prefetch" },
      ],
    },
  ],
};
