import type { DefaultSession } from "next-auth";

declare module "next-auth" {
  interface Session {
    /** Session generation; compared with `users.sessionVersion` on every request. */
    sv: number;
    user: {
      id: string;
    } & DefaultSession["user"];
  }

  interface User {
    id: string;
    sessionVersion?: number;
  }
}

declare module "next-auth/jwt" {
  interface JWT {
    sub?: string;
    sv?: number;
  }
}
