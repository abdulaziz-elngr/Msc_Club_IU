"use client";

import { ThemeProvider } from "next-themes";
import { TooltipProvider } from "@/components/ui/tooltip";
import { Toaster } from "@/components/ui/sonner";
import { LocaleProvider } from "@/components/i18n/locale-provider";
import { DirectionProvider } from "@/components/ui/direction";
import { localeDirection, type Locale } from "@/lib/i18n";

/**
 * Client-side application shell.
 *
 * Order matters: theming wraps everything, then language, then directional
 * (RTL/LTR) primitives so Radix-based components flip correctly for Arabic.
 */
export function AppProviders({ locale, children }: { locale: Locale; children: React.ReactNode }) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="system"
      enableSystem
      disableTransitionOnChange
    >
      <LocaleProvider locale={locale}>
        <DirectionProvider dir={localeDirection(locale)}>
          <TooltipProvider delayDuration={200}>{children}</TooltipProvider>
          <Toaster position="top-center" richColors closeButton />
        </DirectionProvider>
      </LocaleProvider>
    </ThemeProvider>
  );
}
