"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Eye, EyeOff, LockKeyhole, Mail } from "lucide-react";
import { useState } from "react";
import { loginAction } from "@/app/actions/auth";
import { Field, FormMessage, SubmitButton } from "@/components/shared/form";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function LoginForm({ next, notice }: { next?: string; notice?: string }) {
  const t = useT();
  const [state, formAction, pending] = useActionState(loginAction, undefined);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <h1 className="text-xl font-semibold tracking-tight">{t("auth.loginTitle")}</h1>
        <p className="text-sm text-muted-foreground">{t("auth.loginSubtitle")}</p>
      </div>

      {notice ? (
        <div
          role="status"
          className="rounded-lg border border-success-500/30 bg-success-50 px-3 py-2.5 text-sm text-success-700 dark:bg-success-500/10 dark:text-success-500"
        >
          {notice}
        </div>
      ) : null}

      <FormMessage state={state} />

      {next ? <input type="hidden" name="next" value={next} /> : null}

      <Field label={t("auth.email")} htmlFor="email" error={state?.errors?.email} required>
        <div className="relative">
          <Mail
            className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            required
            dir="ltr"
            placeholder="student@innovation.edu"
            defaultValue={state?.values?.email ?? ""}
            className="ps-9"
          />
        </div>
      </Field>

      <Field label={t("auth.password")} htmlFor="password" error={state?.errors?.password} required>
        <div className="relative">
          <LockKeyhole
            className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="password"
            name="password"
            type={showPassword ? "text" : "password"}
            autoComplete="current-password"
            required
            dir="ltr"
            className="pe-10 ps-9"
          />
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            className="absolute inset-y-0 end-1 my-auto"
            aria-label={showPassword ? "Hide password" : "Show password"}
            onClick={() => setShowPassword((v) => !v)}
          >
            {showPassword ? <EyeOff aria-hidden /> : <Eye aria-hidden />}
          </Button>
        </div>
      </Field>

      <div className="flex items-center justify-end">
        <Link
          href="/forgot-password"
          className="text-sm font-medium text-primary hover:underline underline-offset-4"
        >
          {t("auth.forgotPassword")}
        </Link>
      </div>

      <SubmitButton pending={pending}>{t("common.signIn")}</SubmitButton>

      <p className="text-center text-sm text-muted-foreground">
        {t("auth.noAccount")}{" "}
        <Link href="/register" className="font-medium text-primary hover:underline underline-offset-4">
          {t("auth.createAccount")}
        </Link>
      </p>
    </form>
  );
}
