"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Mail, ShieldCheck } from "lucide-react";
import { resendVerificationAction, verifyEmailAction } from "@/app/actions/auth";
import { DevLinkHint, Field, FormMessage, SubmitButton } from "@/components/shared/form";
import { useT } from "@/components/i18n/locale-provider";
import { Input } from "@/components/ui/input";

/** Confirms an emailed token, or lets the member request a fresh link. */
export function VerifyEmailPanel({
  token,
  email,
  devUrl,
}: {
  token?: string;
  email?: string;
  devUrl?: string;
}) {
  const t = useT();
  const [verifyState, verifyAction, verifyPending] = useActionState(verifyEmailAction, undefined);
  const [resendState, resendAction, resendPending] = useActionState(resendVerificationAction, undefined);

  if (token) {
    return (
      <form action={verifyAction} className="space-y-4">
        <div className="space-y-1.5">
          <span className="flex size-11 items-center justify-center rounded-full bg-primary/10 text-primary">
            <ShieldCheck className="size-5" aria-hidden />
          </span>
          <h1 className="text-xl font-semibold tracking-tight">{t("auth.checkInbox")}</h1>
          <p className="text-sm text-muted-foreground">
            Confirm this address to activate your account.
          </p>
        </div>

        <input type="hidden" name="token" value={token} />
        {email ? <input type="hidden" name="email" value={email} /> : null}

        <FormMessage state={verifyState} />
        <SubmitButton pending={verifyPending}>Verify email address</SubmitButton>

        <p className="text-center text-sm text-muted-foreground">
          <Link href="/login" className="font-medium text-primary hover:underline underline-offset-4">
            {t("common.signIn")}
          </Link>
        </p>
      </form>
    );
  }

  return (
    <form action={resendAction} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <span className="flex size-11 items-center justify-center rounded-full bg-primary/10 text-primary">
          <Mail className="size-5" aria-hidden />
        </span>
        <h1 className="text-xl font-semibold tracking-tight">{t("auth.checkInbox")}</h1>
        <p className="text-sm text-muted-foreground">{t("auth.verificationSent", { email: email ?? "" })}</p>
      </div>

      <FormMessage state={resendState} />
      <DevLinkHint url={resendState?.values?.devVerifyUrl ?? devUrl} />

      <Field label={t("auth.email")} htmlFor="email" error={resendState?.errors?.email} required>
        <Input
          id="email"
          name="email"
          type="email"
          autoComplete="email"
          inputMode="email"
          required
          dir="ltr"
          defaultValue={email ?? ""}
          placeholder="student@innovation.edu"
        />
      </Field>

      <SubmitButton pending={resendPending}>{t("auth.resendEmail")}</SubmitButton>

      <p className="text-center text-sm text-muted-foreground">
        <Link href="/login" className="font-medium text-primary hover:underline underline-offset-4">
          {t("common.signIn")}
        </Link>
      </p>
    </form>
  );
}
