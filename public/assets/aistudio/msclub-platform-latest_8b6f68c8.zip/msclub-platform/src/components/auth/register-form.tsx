"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { Eye, EyeOff, LockKeyhole, Mail, UserRound } from "lucide-react";
import { registerAction } from "@/app/actions/auth";
import { DevLinkHint, Field, FormMessage, SubmitButton } from "@/components/shared/form";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

export type TrackOption = { id: string; name: string; nameAr: string | null };

export function RegisterForm({ tracks }: { tracks: TrackOption[] }) {
  const t = useT();
  const [state, formAction, pending] = useActionState(registerAction, undefined);
  const [showPassword, setShowPassword] = useState(false);
  const [trackId, setTrackId] = useState(state?.values?.preferredTrackId ?? "");

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <h1 className="text-xl font-semibold tracking-tight">{t("auth.registerTitle")}</h1>
        <p className="text-sm text-muted-foreground">{t("auth.registerSubtitle")}</p>
      </div>

      <FormMessage state={state} />
      <DevLinkHint url={state?.values?.devVerifyUrl} />

      <Field label={t("auth.fullName")} htmlFor="name" error={state?.errors?.name} required>
        <div className="relative">
          <UserRound
            className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="name"
            name="name"
            autoComplete="name"
            required
            defaultValue={state?.values?.name ?? ""}
            placeholder="Sara Ahmed"
            className="ps-9"
          />
        </div>
      </Field>

      <Field label={t("auth.email")} htmlFor="email" error={state?.errors?.email} required>
        <div className="relative">
          <Mail
            className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            required
            dir="ltr"
            placeholder="student@innovation.edu"
            defaultValue={state?.values?.email ?? ""}
            className="ps-9"
          />
        </div>
      </Field>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field
          label={t("auth.password")}
          htmlFor="password"
          error={state?.errors?.password}
          hint={t("auth.passwordRules")}
          required
        >
          <div className="relative">
            <LockKeyhole
              className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
              aria-hidden
            />
            <Input
              id="password"
              name="password"
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              required
              dir="ltr"
              className="pe-10 ps-9"
            />
            <Button
              type="button"
              variant="ghost"
              size="icon-sm"
              className="absolute inset-y-0 end-1 my-auto"
              aria-label={showPassword ? "Hide password" : "Show password"}
              onClick={() => setShowPassword((v) => !v)}
            >
              {showPassword ? <EyeOff aria-hidden /> : <Eye aria-hidden />}
            </Button>
          </div>
        </Field>

        <Field
          label={t("auth.confirmPassword")}
          htmlFor="confirmPassword"
          error={state?.errors?.confirmPassword}
          required
        >
          <Input
            id="confirmPassword"
            name="confirmPassword"
            type="password"
            autoComplete="new-password"
            required
            dir="ltr"
          />
        </Field>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <Field label={t("auth.studentId")} htmlFor="studentId" error={state?.errors?.studentId} hint={t("common.optional")}>
          <Input id="studentId" name="studentId" defaultValue={state?.values?.studentId ?? ""} dir="ltr" />
        </Field>
        <Field label={t("auth.phone")} htmlFor="phone" error={state?.errors?.phone} hint={t("common.optional")}>
          <Input id="phone" name="phone" type="tel" autoComplete="tel" defaultValue={state?.values?.phone ?? ""} dir="ltr" />
        </Field>
        <Field label={t("auth.faculty")} htmlFor="faculty" error={state?.errors?.faculty} hint={t("common.optional")}>
          <Input id="faculty" name="faculty" defaultValue={state?.values?.faculty ?? ""} />
        </Field>
        <Field label={t("auth.department")} htmlFor="department" error={state?.errors?.department} hint={t("common.optional")}>
          <Input id="department" name="department" defaultValue={state?.values?.department ?? ""} />
        </Field>
        <Field label={t("auth.academicYear")} htmlFor="academicYear" error={state?.errors?.academicYear} hint={t("common.optional")}>
          <Input id="academicYear" name="academicYear" defaultValue={state?.values?.academicYear ?? ""} />
        </Field>
      </div>

      <Field
        label={t("auth.preferredTrack")}
        htmlFor="preferredTrackId"
        error={state?.errors?.preferredTrackId}
        hint={t("common.optional")}
      >
        <Select value={trackId} onValueChange={setTrackId}>
          <SelectTrigger id="preferredTrackId" className="w-full">
            <SelectValue placeholder={t("common.none")} />
          </SelectTrigger>
          <SelectContent>
            {tracks.map((track) => (
              <SelectItem key={track.id} value={track.id}>
                {track.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {/* Uncontrolled fallback so the value posts even if the select never mounts. */}
        <input type="hidden" name="preferredTrackId" value={trackId} />
      </Field>

      <div className="space-y-2 rounded-lg bg-muted/50 p-3">
        <Field label={t("auth.motivation")} htmlFor="motivation" hint={t("common.optional")}>
          <Textarea
            id="motivation"
            name="motivation"
            rows={3}
            maxLength={1000}
            defaultValue={state?.values?.motivation ?? ""}
          />
        </Field>
      </div>

      <div className="space-y-1.5">
        <div className="flex items-start gap-2.5">
          <Checkbox id="agree" name="agree" value="true" className="mt-0.5" />
          <Label htmlFor="agree" className="leading-snug font-normal text-muted-foreground">
            {t("auth.agreeTerms")}
          </Label>
        </div>
        {state?.errors?.agree ? (
          <p className="text-xs text-danger-600 dark:text-danger-500" role="alert">
            {state.errors.agree[0]}
          </p>
        ) : null}
      </div>

      <SubmitButton pending={pending}>{t("auth.createAccount")}</SubmitButton>

      <p className="text-center text-sm text-muted-foreground">
        {t("auth.haveAccount")}{" "}
        <Link href="/login" className="font-medium text-primary hover:underline underline-offset-4">
          {t("common.signIn")}
        </Link>
      </p>
    </form>
  );
}
