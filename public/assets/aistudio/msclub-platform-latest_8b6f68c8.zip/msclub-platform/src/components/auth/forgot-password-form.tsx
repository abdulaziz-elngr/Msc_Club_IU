"use client";

import Link from "next/link";
import { useActionState } from "react";
import { Mail } from "lucide-react";
import { forgotPasswordAction } from "@/app/actions/auth";
import { DevLinkHint, Field, FormMessage, SubmitButton } from "@/components/shared/form";
import { useT } from "@/components/i18n/locale-provider";
import { Input } from "@/components/ui/input";

export function ForgotPasswordForm() {
  const t = useT();
  const [state, formAction, pending] = useActionState(forgotPasswordAction, undefined);

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <h1 className="text-xl font-semibold tracking-tight">{t("auth.resetPassword")}</h1>
        <p className="text-sm text-muted-foreground">
          Enter your account email and we will send you a link to choose a new password.
        </p>
      </div>

      <FormMessage state={state} />
      <DevLinkHint url={state?.values?.devVerifyUrl} />

      <Field label={t("auth.email")} htmlFor="email" error={state?.errors?.email} required>
        <div className="relative">
          <Mail
            className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="email"
            name="email"
            type="email"
            autoComplete="email"
            inputMode="email"
            required
            dir="ltr"
            placeholder="student@innovation.edu"
            defaultValue={state?.values?.email ?? ""}
            className="ps-9"
          />
        </div>
      </Field>

      <SubmitButton pending={pending}>{t("auth.sendResetLink")}</SubmitButton>

      <p className="text-center text-sm text-muted-foreground">
        <Link href="/login" className="font-medium text-primary hover:underline underline-offset-4">
          {t("common.back")} — {t("common.signIn")}
        </Link>
      </p>
    </form>
  );
}
