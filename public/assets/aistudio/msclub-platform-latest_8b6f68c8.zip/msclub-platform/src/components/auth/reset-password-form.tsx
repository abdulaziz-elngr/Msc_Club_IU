"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { Eye, EyeOff, LockKeyhole } from "lucide-react";
import { resetPasswordAction } from "@/app/actions/auth";
import { Field, FormMessage, SubmitButton } from "@/components/shared/form";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function ResetPasswordForm({ token, email }: { token: string; email?: string }) {
  const t = useT();
  const [state, formAction, pending] = useActionState(resetPasswordAction, undefined);
  const [showPassword, setShowPassword] = useState(false);

  return (
    <form action={formAction} className="space-y-4" noValidate>
      <div className="space-y-1.5">
        <h1 className="text-xl font-semibold tracking-tight">{t("auth.resetPassword")}</h1>
        <p className="text-sm text-muted-foreground">Choose a new password for your account.</p>
      </div>

      <FormMessage state={state} />

      <input type="hidden" name="token" value={token} />
      {email ? <input type="hidden" name="email" value={email} /> : null}

      <Field
        label={t("auth.password")}
        htmlFor="password"
        error={state?.errors?.password}
        hint={t("auth.passwordRules")}
        required
      >
        <div className="relative">
          <LockKeyhole
            className="pointer-events-none absolute inset-y-0 start-3 my-auto size-4 text-muted-foreground"
            aria-hidden
          />
          <Input
            id="password"
            name="password"
            type={showPassword ? "text" : "password"}
            autoComplete="new-password"
            required
            dir="ltr"
            className="pe-10 ps-9"
          />
          <Button
            type="button"
            variant="ghost"
            size="icon-sm"
            className="absolute inset-y-0 end-1 my-auto"
            aria-label={showPassword ? "Hide password" : "Show password"}
            onClick={() => setShowPassword((v) => !v)}
          >
            {showPassword ? <EyeOff aria-hidden /> : <Eye aria-hidden />}
          </Button>
        </div>
      </Field>

      <Field
        label={t("auth.confirmPassword")}
        htmlFor="confirmPassword"
        error={state?.errors?.confirmPassword}
        required
      >
        <Input
          id="confirmPassword"
          name="confirmPassword"
          type="password"
          autoComplete="new-password"
          required
          dir="ltr"
        />
      </Field>

      <SubmitButton pending={pending}>{t("auth.resetPassword")}</SubmitButton>

      <p className="text-center text-sm text-muted-foreground">
        <Link href="/login" className="font-medium text-primary hover:underline underline-offset-4">
          {t("common.signIn")}
        </Link>
      </p>
    </form>
  );
}
