import Link from "next/link";
import { ArrowRight, BookOpen, Users } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { TRACK_ICONS } from "@/lib/track-icons";
import type { Locale } from "@/lib/i18n";

type TrackCardData = {
  id: string;
  slug: string;
  name: string;
  nameAr: string | null;
  description: string | null;
  descriptionAr: string | null;
  icon: string;
  color: string;
  _count: { members: number; courses: number };
};

/** Department / learning-track tile used on the homepage and catalog. */
export function TrackCard({ track, locale }: { track: TrackCardData; locale: Locale }) {
  const arabic = locale === "ar";
  const name = arabic && track.nameAr ? track.nameAr : track.name;
  const description = arabic && track.descriptionAr ? track.descriptionAr : track.description;
  const Icon: LucideIcon = TRACK_ICONS[track.icon] ?? BookOpen;

  return (
    <Link
      href={`/learning?track=${track.slug}`}
      className="group relative flex h-full flex-col gap-4 overflow-hidden rounded-xl bg-card p-5 ring-1 ring-foreground/10 transition-all outline-none hover:ring-primary/40 focus-visible:ring-2 focus-visible:ring-ring lift"
    >
      <span
        className="absolute inset-x-0 top-0 h-0.5 opacity-80"
        style={{ backgroundColor: track.color }}
        aria-hidden
      />
      <div className="flex items-start justify-between gap-3">
        <span
          className="flex size-10 shrink-0 items-center justify-center rounded-lg"
          style={{ backgroundColor: `${track.color}1a`, color: track.color }}
        >
          <Icon className="size-5" aria-hidden />
        </span>
        <ArrowRight
          className="size-4 text-muted-foreground transition-all group-hover:translate-x-0.5 group-hover:text-primary rtl:rotate-180 rtl:group-hover:-translate-x-0.5"
          aria-hidden
        />
      </div>

      <div className="space-y-1.5">
        <h3 className="text-base leading-snug font-semibold text-balance transition-colors group-hover:text-primary">
          {name}
        </h3>
        {description ? (
          <p className="line-clamp-3 text-sm leading-relaxed text-muted-foreground">{description}</p>
        ) : null}
      </div>

      <dl className="mt-auto flex items-center gap-4 pt-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <Users className="size-3.5" aria-hidden />
          <dd>{track._count.members}</dd>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <BookOpen className="size-3.5" aria-hidden />
          <dd>{track._count.courses}</dd>
        </span>
      </dl>
    </Link>
  );
}
