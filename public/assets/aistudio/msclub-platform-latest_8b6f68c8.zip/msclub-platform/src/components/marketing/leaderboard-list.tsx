import { cn } from "@/lib/utils";
import { Medal, Trophy } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatNumber } from "@/lib/format";
import type { Locale } from "@/lib/i18n";

export type LeaderboardRow = {
  rank: number;
  id: string;
  name: string;
  image: string | null;
  totalXp: number;
  periodXp: number;
  joinedAt: Date;
  level: { key: string; name: string; nameAr: string | null; color: string; icon: string } | null;
};

const RANK_TONE: Record<number, string> = {
  1: "bg-warning-50 text-warning-700 ring-warning-500/30 dark:bg-warning-500/15 dark:text-warning-500",
  2: "bg-slate-100 text-slate-600 ring-slate-400/30 dark:bg-slate-400/15 dark:text-slate-300",
  3: "bg-danger-50 text-danger-700 ring-danger-500/30 dark:bg-danger-500/15 dark:text-danger-500",
};

function initials(name: string) {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0]?.toUpperCase())
    .join("");
}

/** Ranked member list — used on the homepage preview and the leaderboard page. */
export function LeaderboardList({
  rows,
  locale,
  highlightId,
  compact = false,
}: {
  rows: LeaderboardRow[];
  locale: Locale;
  highlightId?: string;
  compact?: boolean;
}) {
  if (rows.length === 0) {
    return <p className="py-8 text-center text-sm text-muted-foreground">—</p>;
  }

  return (
    <ol className="divide-y divide-border/70">
      {rows.map((row) => {
        const arabic = locale === "ar";
        const levelName = arabic && row.level?.nameAr ? row.level.nameAr : row.level?.name;
        const isYou = highlightId === row.id;

        return (
          <li
            key={row.id}
            className={cn(
              "flex items-center gap-3 px-1 py-3",
              isYou && "rounded-lg bg-primary/5 ps-3 ring-1 ring-primary/20",
            )}
          >
            <span
              className={cn(
                "flex size-8 shrink-0 items-center justify-center rounded-full text-xs font-semibold ring-1",
                RANK_TONE[row.rank] ?? "bg-muted text-muted-foreground ring-border",
              )}
              aria-label={`#${row.rank}`}
            >
              {row.rank <= 3 ? <Trophy className="size-3.5" aria-hidden /> : row.rank}
            </span>

            <Avatar className="size-8">
              <AvatarImage src={row.image ?? undefined} alt="" />
              <AvatarFallback className="text-[0.7rem]">{initials(row.name)}</AvatarFallback>
            </Avatar>

            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1.5 truncate text-sm font-medium">
                <span className="truncate">{row.name}</span>
                {isYou ? (
                  <span className="shrink-0 rounded-full bg-primary/10 px-1.5 py-px text-[0.65rem] font-semibold text-primary">
                    •
                  </span>
                ) : null}
              </p>
              {levelName && !compact ? (
                <p className="flex items-center gap-1 text-xs text-muted-foreground">
                  <Medal className="size-3" aria-hidden />
                  {levelName}
                </p>
              ) : null}
            </div>

            <div className="shrink-0 text-end">
              <p className="text-sm font-semibold tabular-nums">
                {formatNumber(row.periodXp, locale)}
              </p>
              {!compact ? (
                <p className="text-[0.7rem] text-muted-foreground tabular-nums">
                  {formatNumber(row.totalXp, locale)} total
                </p>
              ) : null}
            </div>
          </li>
        );
      })}
    </ol>
  );
}
