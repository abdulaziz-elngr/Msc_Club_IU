import Link from "next/link";
import { Clock, MapPin, Monitor, Users, Zap } from "lucide-react";
import { cn } from "@/lib/utils";
import { formatDate, formatDateTime } from "@/lib/format";
import { getTranslations, type Locale, type TranslationKey } from "@/lib/i18n";

type EventCardData = {
  id: string;
  slug: string;
  title: string;
  titleAr: string | null;
  summary: string | null;
  category: string;
  status: string;
  startsAt: Date;
  endsAt: Date;
  location: string | null;
  isOnline: boolean;
  capacity: number | null;
  attendancePoints: number;
  _count?: { registrations: number };
};

const CATEGORY_TONE: Record<string, string> = {
  WORKSHOP: "bg-primary/10 text-primary",
  TECHNICAL_SESSION: "bg-[#7C3AED]/10 text-[#7C3AED]",
  BOOTCAMP: "bg-warning-50 text-warning-700 dark:bg-warning-500/15 dark:text-warning-500",
  COMPETITION: "bg-danger-50 text-danger-700 dark:bg-danger-500/15 dark:text-danger-500",
  HACKATHON: "bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-500",
  COMMUNITY: "bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-500",
  WEBINAR: "bg-secondary text-secondary-foreground",
  OTHER: "bg-secondary text-secondary-foreground",
};

export function EventCard({
  event,
  locale,
  href,
}: {
  event: EventCardData;
  locale: Locale;
  href?: string;
}) {
  const t = getTranslations(locale);
  const title = locale === "ar" && event.titleAr ? event.titleAr : event.title;
  const taken = event._count?.registrations ?? 0;
  const seatsLeft = event.capacity === null ? null : Math.max(0, event.capacity - taken);
  const target = href ?? `/events/${event.slug}`;

  return (
    <Link
      href={target}
      className="group flex h-full flex-col gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10 transition-all outline-none hover:ring-primary/40 focus-visible:ring-2 focus-visible:ring-ring lift"
    >
      <div className="flex items-start justify-between gap-3">
        <span
          className={cn(
            "rounded-full px-2.5 py-0.5 text-[0.7rem] font-semibold tracking-wide uppercase",
            CATEGORY_TONE[event.category] ?? CATEGORY_TONE.OTHER,
          )}
        >
          {t(`events.categories.${event.category}` as TranslationKey)}
        </span>
        <time
          dateTime={event.startsAt.toISOString()}
          className="shrink-0 text-end text-xs text-muted-foreground"
        >
          {formatDate(event.startsAt, locale)}
        </time>
      </div>

      <div className="space-y-1.5">
        <h3 className="text-base leading-snug font-semibold text-balance transition-colors group-hover:text-primary">
          {title}
        </h3>
        {event.summary ? (
          <p className="line-clamp-2 text-sm text-muted-foreground">{event.summary}</p>
        ) : null}
      </div>

      <dl className="mt-auto space-y-1.5 text-xs text-muted-foreground">
        <div className="flex items-center gap-2">
          <Clock className="size-3.5 shrink-0 text-primary" aria-hidden />
          <dd>{formatDateTime(event.startsAt, locale)}</dd>
        </div>
        <div className="flex items-center gap-2">
          {event.isOnline ? (
            <Monitor className="size-3.5 shrink-0 text-primary" aria-hidden />
          ) : (
            <MapPin className="size-3.5 shrink-0 text-primary" aria-hidden />
          )}
          <dd className="truncate">{event.isOnline ? t("events.online") : (event.location ?? t("events.tba"))}</dd>
        </div>
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 pt-1">
          {seatsLeft !== null ? (
            <span className="inline-flex items-center gap-1.5">
              <Users className="size-3.5" aria-hidden />
              {seatsLeft > 0 ? t("events.seatsLeftShort", { count: seatsLeft }) : t("events.full")}
            </span>
          ) : (
            <span className="inline-flex items-center gap-1.5">
              <Users className="size-3.5" aria-hidden />
              {t("events.registeredCount", { count: taken })}
            </span>
          )}
          {event.attendancePoints > 0 ? (
            <span className="inline-flex items-center gap-1.5 font-medium text-primary">
              <Zap className="size-3.5" aria-hidden />
              {event.attendancePoints} XP
            </span>
          ) : null}
        </div>
      </dl>
    </Link>
  );
}

export function EventRow({
  event,
  locale,
}: {
  event: {
    slug: string;
    title: string;
    titleAr: string | null;
    startsAt: Date;
    category: string;
    _count: { attendance: number };
  };
  locale: Locale;
}) {
  const t = getTranslations(locale);
  return (
    <Link
      href={`/events/${event.slug}`}
      className="flex items-center gap-4 rounded-lg px-3 py-2.5 transition-colors hover:bg-muted/60"
    >
      <time
        dateTime={event.startsAt.toISOString()}
        className="flex size-11 shrink-0 flex-col items-center justify-center rounded-lg bg-primary/10 text-primary"
      >
        <span className="text-[0.65rem] leading-none font-medium uppercase">
          {event.startsAt.toLocaleString(locale === "ar" ? "ar-EG" : "en-US", { month: "short" })}
        </span>
        <span className="text-sm leading-tight font-semibold">{event.startsAt.getDate()}</span>
      </time>
      <div className="min-w-0 flex-1">
        <p className="truncate text-sm font-medium">
          {locale === "ar" && event.titleAr ? event.titleAr : event.title}
        </p>
        <p className="text-xs text-muted-foreground">{t(`events.categories.${event.category}` as TranslationKey)}</p>
      </div>
      <span className="shrink-0 text-xs text-muted-foreground">
        {t("events.attendedCount", { count: event._count.attendance })}
      </span>
    </Link>
  );
}
