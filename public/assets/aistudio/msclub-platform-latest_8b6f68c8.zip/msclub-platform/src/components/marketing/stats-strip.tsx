import type { LucideIcon } from "lucide-react";
import { formatCompact } from "@/lib/format";
import type { Locale } from "@/lib/i18n";

export type StatItem = {
  key: string;
  label: string;
  value: number;
  icon: LucideIcon;
  suffix?: string;
};

/**
 * Public statistics strip. Values are passed in from a real database
 * aggregate — nothing here is fabricated.
 */
export function StatsStrip({ items, locale }: { items: StatItem[]; locale: Locale }) {
  return (
    <dl className="grid grid-cols-2 gap-px overflow-hidden rounded-xl bg-border/60 ring-1 ring-foreground/10 sm:grid-cols-4">
      {items.map((item) => {
        const Icon = item.icon;
        return (
          <div key={item.key} className="flex flex-col gap-2 bg-card px-5 py-6">
            <span className="flex size-8 items-center justify-center rounded-lg bg-primary/10 text-primary">
              <Icon className="size-4" aria-hidden />
            </span>
            <dd className="text-2xl leading-none font-semibold tracking-tight tabular-nums sm:text-[1.75rem]">
              {formatCompact(item.value, locale)}
              {item.suffix ? (
                <span className="ms-0.5 text-base font-medium text-primary">{item.suffix}</span>
              ) : null}
            </dd>
            <dt className="text-xs text-muted-foreground">{item.label}</dt>
          </div>
        );
      })}
    </dl>
  );
}
