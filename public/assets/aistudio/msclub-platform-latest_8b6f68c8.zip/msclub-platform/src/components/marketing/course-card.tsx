import Link from "next/link";
import { Award, BookOpen, Clock, PlayCircle, UserRound } from "lucide-react";
import { cn } from "@/lib/utils";
import { Badge } from "@/components/ui/badge";
import type { Locale } from "@/lib/i18n";

type CourseCardData = {
  id: string;
  slug: string;
  title: string;
  titleAr: string | null;
  summary: string | null;
  difficulty: string;
  durationMinutes: number;
  instructor: string | null;
  featured: boolean;
  xpReward: number;
  certificateEnabled: boolean;
  track: { name: string; nameAr: string | null; color: string; icon: string } | null;
  _count: { lessons: number; enrollments: number };
};

const DIFFICULTY_TONE: Record<string, string> = {
  BEGINNER: "bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-500",
  INTERMEDIATE: "bg-warning-50 text-warning-700 dark:bg-warning-500/15 dark:text-warning-500",
  ADVANCED: "bg-danger-50 text-danger-700 dark:bg-danger-500/15 dark:text-danger-500",
};

export function CourseCard({
  course,
  locale,
  href,
}: {
  course: CourseCardData;
  locale: Locale;
  href?: string;
}) {
  const title = locale === "ar" && course.titleAr ? course.titleAr : course.title;
  const target = href ?? `/learning/${course.slug}`;

  return (
    <Link
      href={target}
      className="group flex h-full flex-col gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10 transition-all outline-none hover:ring-primary/40 focus-visible:ring-2 focus-visible:ring-ring lift"
    >
      <div className="flex items-start justify-between gap-3">
        <span
          className="inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-[0.7rem] font-semibold tracking-wide uppercase"
          style={{
            backgroundColor: `${course.track?.color ?? "#1B6AC4"}1a`,
            color: course.track?.color ?? "#1B6AC4",
          }}
        >
          {locale === "ar" && course.track?.nameAr ? course.track.nameAr : (course.track?.name ?? "Course")}
        </span>
        <Badge variant="outline" className={cn("border-0 text-[0.7rem]", DIFFICULTY_TONE[course.difficulty])}>
          {course.difficulty}
        </Badge>
      </div>

      <div className="space-y-1.5">
        <h3 className="text-base leading-snug font-semibold text-balance transition-colors group-hover:text-primary">
          {title}
        </h3>
        {course.summary ? (
          <p className="line-clamp-2 text-sm text-muted-foreground">{course.summary}</p>
        ) : null}
      </div>

      <dl className="mt-auto flex flex-wrap items-center gap-x-4 gap-y-1.5 pt-1 text-xs text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <BookOpen className="size-3.5" aria-hidden />
          {course._count.lessons} lessons
        </span>
        {course.durationMinutes > 0 ? (
          <span className="inline-flex items-center gap-1.5">
            <Clock className="size-3.5" aria-hidden />
            {Math.round(course.durationMinutes / 60)}h
          </span>
        ) : null}
        {course.instructor ? (
          <span className="inline-flex min-w-0 items-center gap-1.5">
            <UserRound className="size-3.5 shrink-0" aria-hidden />
            <span className="truncate">{course.instructor}</span>
          </span>
        ) : null}
        {course.certificateEnabled ? (
          <span className="inline-flex items-center gap-1.5 text-primary">
            <Award className="size-3.5" aria-hidden />
            Certificate
          </span>
        ) : null}
        {course.xpReward > 0 ? (
          <span className="inline-flex items-center gap-1.5 font-medium text-primary">
            <PlayCircle className="size-3.5" aria-hidden />
            {course.xpReward} XP
          </span>
        ) : null}
      </dl>
    </Link>
  );
}
