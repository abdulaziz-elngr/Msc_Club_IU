import { Quote } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import type { Locale } from "@/lib/i18n";

export type TestimonialData = {
  id: string;
  name: string;
  nameAr: string | null;
  role: string | null;
  roleAr: string | null;
  quote: string;
  quoteAr: string | null;
  image: string | null;
};

export function TestimonialCard({
  testimonial,
  locale,
}: {
  testimonial: TestimonialData;
  locale: Locale;
}) {
  const arabic = locale === "ar";
  const name = arabic && testimonial.nameAr ? testimonial.nameAr : testimonial.name;
  const role = arabic && testimonial.roleAr ? testimonial.roleAr : testimonial.role;
  const quote = arabic && testimonial.quoteAr ? testimonial.quoteAr : testimonial.quote;

  return (
    <figure className="flex h-full flex-col gap-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
      <Quote className="size-5 text-primary/60" aria-hidden />
      <blockquote className="flex-1 text-sm leading-relaxed text-pretty text-muted-foreground">
        “{quote}”
      </blockquote>
      <figcaption className="flex items-center gap-3 border-t pt-4">
        <Avatar className="size-9">
          <AvatarImage src={testimonial.image ?? undefined} alt="" />
          <AvatarFallback>{name.charAt(0).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="min-w-0">
          <p className="truncate text-sm font-medium">{name}</p>
          {role ? <p className="truncate text-xs text-muted-foreground">{role}</p> : null}
        </div>
      </figcaption>
    </figure>
  );
}
