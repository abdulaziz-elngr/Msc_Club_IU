import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

/**
 * Single metric tile. Values are always supplied by the caller from a real
 * database aggregate — this component never invents numbers.
 */
export function StatCard({
  label,
  value,
  hint,
  icon: Icon,
  trend,
  tone = "neutral",
  className,
}: {
  label: string;
  value: React.ReactNode;
  hint?: React.ReactNode;
  icon?: LucideIcon;
  trend?: { direction: "up" | "down" | "flat"; label: string };
  tone?: "neutral" | "brand" | "success" | "warning" | "danger";
  className?: string;
}) {
  const toneClass = {
    neutral: "bg-muted text-muted-foreground",
    brand: "bg-primary/10 text-primary",
    success: "bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-500",
    warning: "bg-warning-50 text-warning-700 dark:bg-warning-500/15 dark:text-warning-500",
    danger: "bg-danger-50 text-danger-700 dark:bg-danger-500/15 dark:text-danger-500",
  }[tone];

  return (
    <div
      className={cn(
        "flex flex-col gap-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10 sm:p-5",
        className,
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <p className="text-sm text-muted-foreground">{label}</p>
        {Icon ? (
          <span className={cn("flex size-8 shrink-0 items-center justify-center rounded-lg", toneClass)}>
            <Icon className="size-4" aria-hidden />
          </span>
        ) : null}
      </div>
      <div className="flex items-baseline gap-2">
        <span className="text-2xl leading-none font-semibold tracking-tight sm:text-[1.75rem]">
          {value}
        </span>
        {trend ? (
          <span
            className={cn(
              "text-xs font-medium",
              trend.direction === "up" && "text-success-600 dark:text-success-500",
              trend.direction === "down" && "text-danger-600 dark:text-danger-500",
              trend.direction === "flat" && "text-muted-foreground",
            )}
          >
            {trend.label}
          </span>
        ) : null}
      </div>
      {hint ? <p className="text-xs text-muted-foreground">{hint}</p> : null}
    </div>
  );
}
