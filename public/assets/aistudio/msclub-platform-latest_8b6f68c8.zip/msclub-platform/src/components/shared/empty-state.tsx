import type { LucideIcon } from "lucide-react";
import { Inbox } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button, buttonVariants } from "@/components/ui/button";
import Link from "next/link";

/**
 * Empty / error state used across lists, tables and dashboards so every
 * "nothing to show" surface looks and reads the same.
 */
export function EmptyState({
  icon: Icon = Inbox,
  title,
  description,
  action,
  actionHref,
  actionLabel,
  className,
  size = "default",
}: {
  icon?: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  actionHref?: string;
  actionLabel?: string;
  className?: string;
  size?: "default" | "compact";
}) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center rounded-xl border border-dashed bg-muted/30 text-center",
        size === "default" ? "gap-3 px-6 py-14" : "gap-2 px-5 py-8",
        className,
      )}
    >
      <span className="flex size-11 items-center justify-center rounded-full bg-primary/10 text-primary">
        <Icon className={size === "default" ? "size-5" : "size-4"} aria-hidden />
      </span>
      <div className="space-y-1">
        <p className="text-sm font-medium">{title}</p>
        {description ? (
          <p className="mx-auto max-w-sm text-sm text-muted-foreground">{description}</p>
        ) : null}
      </div>
      {action ??
        (actionHref && actionLabel ? (
          <Link href={actionHref} className={cn(buttonVariants({ size: "sm" }), "mt-1")}>
            {actionLabel}
          </Link>
        ) : null)}
    </div>
  );
}

/** Inline, non-blocking fallback used inside Suspense boundaries. */
export function InlineLoading({ label = "Loading…" }: { label?: string }) {
  return (
    <div className="flex items-center gap-2 px-1 py-3 text-sm text-muted-foreground" role="status">
      <Spinner />
      <span>{label}</span>
    </div>
  );
}

export function Spinner({ className }: { className?: string }) {
  return (
    <svg
      className={cn("size-4 animate-spin text-current", className)}
      viewBox="0 0 24 24"
      fill="none"
      aria-hidden
    >
      <circle cx="12" cy="12" r="10" stroke="currentColor" strokeOpacity="0.25" strokeWidth="3" />
      <path d="M22 12a10 10 0 0 0-10-10" stroke="currentColor" strokeWidth="3" strokeLinecap="round" />
    </svg>
  );
}

export { Button };
