import { Award, BookOpen, Code2, Compass, Crown, Flame, Gem, GraduationCap, Hammer, Heart, Medal, Rocket, Shield, Sprout, Star, Target, Trophy, Wrench, Zap, type LucideIcon } from "lucide-react";

const MAP: Record<string, LucideIcon> = {
  star: Star, award: Award, trophy: Trophy, medal: Medal, zap: Zap, flame: Flame, rocket: Rocket, code: Code2, compass: Compass,
  hammer: Hammer, wrench: Wrench, seedling: Sprout, sprout: Sprout, "book-open": BookOpen, "graduation-cap": GraduationCap,
  target: Target, shield: Shield, crown: Crown, gem: Gem, heart: Heart,
};

/** Renders a stored icon name; unknown names fall back to a star (stored data is never trusted). */
export function NamedIcon({ name, className, color }: { name: string; className?: string; color?: string }) {
  const Icon = MAP[name] ?? Star;
  const safe = color && /^#[0-9a-fA-F]{6}$/.test(color) ? color : undefined;
  return <Icon className={className} style={safe ? { color: safe } : undefined} aria-hidden />;
}
