"use client";

import { useT } from "@/components/i18n/locale-provider";
import { CircleCheckBig, CircleExclamationPoint } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Spinner } from "@/components/shared/empty-state";
import type { FormState } from "@/lib/forms";

/**
 * Form primitives shared by every `useActionState`-driven form.
 *
 * Errors are rendered from the server-produced `FormState`, so a form works
 * identically with JavaScript enabled or disabled and validation always runs
 * on the server.
 */

export function FormMessage({
  state,
  className,
}: {
  state: FormState;
  className?: string;
}) {
  if (!state?.message) return null;

  const ok = state.ok === true;
  return (
    <div
      role={ok ? "status" : "alert"}
      className={cn(
        "flex items-start gap-2 rounded-lg border px-3 py-2.5 text-sm leading-relaxed",
        ok
          ? "border-success-500/30 bg-success-50 text-success-700 dark:bg-success-500/10 dark:text-success-500"
          : "border-destructive/30 bg-danger-50 text-danger-700 dark:bg-destructive/10 dark:text-destructive",
        className,
      )}
    >
      {ok ? (
        <CircleCheckBig className="mt-0.5 size-4 shrink-0" aria-hidden />
      ) : (
        <CircleExclamationPoint className="mt-0.5 size-4 shrink-0" aria-hidden />
      )}
      <span>{state.message}</span>
    </div>
  );
}

export function FieldError({ errors }: { errors?: string[] }) {
  if (!errors || errors.length === 0) return null;
  return (
    <p className="text-xs leading-snug text-danger-600 dark:text-danger-500" role="alert">
      {errors[0]}
    </p>
  );
}

/**
 * Label + control + error wrapper. Renders a real `<label>` bound to the
 * control so keyboard and screen-reader users get a proper association.
 */
export function Field({
  label,
  htmlFor,
  error,
  hint,
  required,
  className,
  children,
}: {
  label: React.ReactNode;
  htmlFor?: string;
  error?: string[];
  hint?: React.ReactNode;
  required?: boolean;
  className?: string;
  children: React.ReactNode;
}) {
  return (
    <div className={cn("space-y-1.5", className)}>
      <label
        htmlFor={htmlFor}
        className="flex items-center gap-1 text-sm font-medium text-foreground"
      >
        {label}
        {required ? (
          <span className="text-danger-600 dark:text-danger-500" aria-hidden>
            *
          </span>
        ) : null}
      </label>
      {children}
      {error && error.length > 0 ? (
        <FieldError errors={error} />
      ) : hint ? (
        <p className="text-xs text-muted-foreground">{hint}</p>
      ) : null}
    </div>
  );
}

/** Submit button that reflects the pending state of `useActionState`. */
export function SubmitButton({
  pending,
  children,
  className,
  disabled,
}: {
  pending: boolean;
  children: React.ReactNode;
  className?: string;
  disabled?: boolean;
}) {
  const t = useT();
  return (
    <Button type="submit" disabled={pending || disabled} className={cn("w-full", className)}>
      {pending ? (
        <>
          <Spinner className="size-4" />
          <span>{t("common.pleaseWait")}</span>
        </>
      ) : (
        children
      )}
    </Button>
  );
}

/** Dev-only helper surfaced by the auth actions when no mail provider is set. */
export function DevLinkHint({ url }: { url?: string }) {
  if (!url || process.env.NODE_ENV === "production") return null;
  return (
    <p className="rounded-lg border border-dashed bg-muted/40 px-3 py-2 text-xs text-muted-foreground">
      Development mail link:{" "}
      <a href={url} className="font-medium text-primary underline underline-offset-2">
        {url}
      </a>
    </p>
  );
}
