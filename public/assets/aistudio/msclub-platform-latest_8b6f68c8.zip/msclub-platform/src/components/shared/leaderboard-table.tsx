import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { formatNumber } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import type { Locale } from "@/lib/i18n";
import type { LeaderboardEntry } from "@/lib/queries/leaderboard";
import { cn } from "@/lib/utils";

const initials = (n: string) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "?";

/** Rank table. Names link to the profile only when that member made the profile public. */
export function LeaderboardTable({ rows, locale, meId }: { rows: LeaderboardEntry[]; locale: Locale; meId?: string }) {
  const t = getTranslations(locale);
  return (
    <div className="overflow-x-auto rounded-xl bg-card ring-1 ring-foreground/10">
      <table className="w-full text-sm">
        <caption className="sr-only">{t("leaderboard.title")}</caption>
        <thead>
          <tr className="border-b text-start text-xs text-muted-foreground">
            <th scope="col" className="w-16 px-4 py-3 text-start font-medium">{t("leaderboard.rank")}</th>
            <th scope="col" className="px-4 py-3 text-start font-medium">{t("leaderboard.member")}</th>
            <th scope="col" className="hidden px-4 py-3 text-start font-medium sm:table-cell">{t("leaderboard.level")}</th>
            <th scope="col" className="px-4 py-3 text-end font-medium">{t("leaderboard.score")}</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.userId} className={cn("border-b last:border-0", r.userId === meId && "bg-primary/5")}>
              <td className="px-4 py-3 tabular-nums"><span className={cn("inline-flex size-7 items-center justify-center rounded-full text-xs font-semibold", r.rank <= 3 ? "bg-primary text-primary-foreground" : "text-muted-foreground")}>{r.rank}</span></td>
              <td className="px-4 py-3">
                <div className="flex items-center gap-3">
                  <Avatar className="size-8">{r.image ? <AvatarImage src={r.image} alt="" /> : null}<AvatarFallback className="text-xs">{initials(r.name)}</AvatarFallback></Avatar>
                  {r.profilePublic ? <Link href={`/members/${r.userId}`} className="font-medium hover:text-primary">{r.name}</Link> : <span className="font-medium">{r.name}</span>}
                  {r.userId === meId ? <span className="rounded-full bg-primary/10 px-2 py-0.5 text-[0.65rem] font-medium text-primary">{t("leaderboard.you")}</span> : null}
                </div>
              </td>
              <td className="hidden px-4 py-3 text-muted-foreground sm:table-cell">{r.level ? (locale === "ar" && r.level.nameAr ? r.level.nameAr : r.level.name) : "—"}</td>
              <td className="px-4 py-3 text-end font-semibold tabular-nums">{formatNumber(r.value, locale)} XP</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
