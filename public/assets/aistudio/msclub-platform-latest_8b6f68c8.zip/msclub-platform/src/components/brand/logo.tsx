import Link from "next/link";
import { cn } from "@/lib/utils";
import { ClubMark } from "@/components/brand/mark";

type Tone = "default" | "onDark";

const TONES: Record<Tone, { primary: string; secondary: string }> = {
  default: { primary: "text-slate-900", secondary: "text-slate-600" },
  onDark: { primary: "text-white", secondary: "text-slate-300" },
};

/**
 * Full logo lockup: emblem + wordmark.
 *
 * `variant`:
 *  • `stacked` — emblem above the two-line wordmark (hero, login, footer)
 *  • `inline`  — emblem beside a single-line wordmark (navigation, sidebar)
 *  • `mark`    — emblem only
 */
export function ClubLogo({
  variant = "inline",
  tone = "default",
  href = "/",
  size = 32,
  className,
  linkClassName,
}: {
  variant?: "stacked" | "inline" | "mark";
  tone?: Tone;
  href?: string | null;
  size?: number;
  className?: string;
  linkClassName?: string;
}) {
  const colors = TONES[tone];

  const mark = (
    <ClubMark
      size={variant === "stacked" ? Math.max(size, 64) : size}
      title="Microsoft Student Clubs — Innovation University"
    />
  );

  if (variant === "mark") {
    return href ? (
      <Link href={href} aria-label="Microsoft Student Clubs home" className={cn("inline-flex", linkClassName)}>
        {mark}
      </Link>
    ) : (
      mark
    );
  }

  const text =
    variant === "stacked" ? (
      <span className="flex flex-col items-center text-center">
        <span
          className={cn(
            "font-semibold tracking-tight text-pretty",
            colors.primary,
            size >= 64 ? "text-2xl" : "text-base",
          )}
        >
          Microsoft Student Clubs
        </span>
        <span
          className={cn(
            "font-normal",
            colors.secondary,
            size >= 64 ? "text-base" : "text-xs",
          )}
        >
          Innovation University
        </span>
      </span>
    ) : (
      <span className="flex flex-col leading-tight">
        <span className={cn("text-sm font-semibold tracking-tight", colors.primary)}>
          Microsoft Student Clubs
        </span>
        <span className={cn("text-[0.68rem] font-normal", colors.secondary)}>
          Innovation University
        </span>
      </span>
    );

  const content =
    variant === "stacked" ? (
      <span className="flex flex-col items-center gap-3">
        {mark}
        {text}
      </span>
    ) : (
      <span className="flex items-center gap-2.5">
        {mark}
        {text}
      </span>
    );

  if (!href) return <span className={cn("inline-flex", className)}>{content}</span>;

  return (
    <Link
      href={href}
      aria-label="Microsoft Student Clubs — home"
      className={cn("inline-flex outline-none focus-visible:ring-2 focus-visible:ring-ring rounded-md", linkClassName)}
    >
      {content}
    </Link>
  );
}
