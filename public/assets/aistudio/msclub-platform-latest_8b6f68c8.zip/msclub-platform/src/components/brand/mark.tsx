import { cn } from "@/lib/utils";

/**
 * The official club emblem, inlined so it can be recoloured, scaled and used
 * in every surface (navigation, dashboard, certificates, e-mails) without
 * extra requests. The static equivalents live in `/public/brand/`.
 *
 * Colours are taken directly from the supplied logo:
 *   primary  #1B6AC4
 *   deep     #123F6E
 *   interior #FFFFFF
 */
export function ClubMark({
  className,
  size = 32,
  title,
}: {
  className?: string;
  size?: number;
  title?: string;
}) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 0 128 128"
      width={size}
      height={size}
      role={title ? "img" : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
      focusable="false"
      className={cn("shrink-0", className)}
    >
      {title ? <title>{title}</title> : null}
      <rect x="0" y="0" width="128" height="128" rx="12" fill="#1B6AC4" />
      <rect x="18" y="18" width="92" height="92" rx="6" fill="#FFFFFF" />
      <rect x="18" y="18" width="30" height="30" rx="4" fill="#123F6E" />
      <g
        fill="none"
        stroke="#1B6AC4"
        strokeWidth="11"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        <circle cx="66" cy="52" r="15" />
        <path d="M66 67 v16 a13 13 0 0 1 -13 13 h-8" />
      </g>
    </svg>
  );
}
