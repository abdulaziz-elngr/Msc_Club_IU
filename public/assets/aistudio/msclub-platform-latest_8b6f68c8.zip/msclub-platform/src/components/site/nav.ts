import type { TranslationKey } from "@/lib/i18n";

/** Primary public navigation, in display order. */
export const PUBLIC_NAV: { href: string; labelKey: TranslationKey }[] = [
  { href: "/", labelKey: "nav.home" },
  { href: "/about", labelKey: "nav.about" },
  { href: "/events", labelKey: "nav.events" },
  { href: "/learning", labelKey: "nav.learning" },
  { href: "/teams", labelKey: "nav.teams" },
  { href: "/leaderboard", labelKey: "nav.leaderboard" },
];

/** Secondary links shown in the footer. */
export const FOOTER_NAV: { href: string; labelKey: TranslationKey }[] = [
  { href: "/about", labelKey: "nav.about" },
  { href: "/events", labelKey: "nav.events" },
  { href: "/learning", labelKey: "nav.learning" },
  { href: "/leaderboard", labelKey: "nav.leaderboard" },
  { href: "/join", labelKey: "nav.join" },
  { href: "/contact", labelKey: "nav.contact" },
];

/** Signed-in member destinations shown in the account menu. */
export const MEMBER_NAV: { href: string; labelKey: TranslationKey }[] = [
  { href: "/dashboard", labelKey: "nav.dashboard" },
  { href: "/dashboard/events", labelKey: "events.myRegistrations" },
  { href: "/dashboard/points", labelKey: "nav.points" },
  { href: "/dashboard/achievements", labelKey: "nav.achievements" },
  { href: "/dashboard/certificates", labelKey: "nav.certificates" },
  { href: "/dashboard/profile", labelKey: "nav.profile" },
];
