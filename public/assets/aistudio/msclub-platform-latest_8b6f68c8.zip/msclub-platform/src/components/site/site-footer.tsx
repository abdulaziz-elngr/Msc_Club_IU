import Link from "next/link";
import { AtSign, Briefcase, Camera, Code, Globe, Mail, MapPin, MessageCircle, Phone, Play } from "lucide-react";
import { ClubLogo } from "@/components/brand/logo";
import { FOOTER_NAV } from "@/components/site/nav";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { SETTING_KEYS, getSocialLinks, getString } from "@/lib/settings";

const SOCIAL_ICONS: Record<string, typeof Globe> = {
  github: Code,
  instagram: Camera,
  linkedin: Briefcase,
  youtube: Play,
  x: AtSign,
  twitter: AtSign,
  discord: MessageCircle,
  website: Globe,
};

/** Public footer: brand, quick links, real contact details from settings. */
export async function SiteFooter() {
  const locale = await resolveLocale();
  const t = getTranslations(locale);

  const [email, phone, address, social] = await Promise.all([
    getString(SETTING_KEYS.CONTACT_EMAIL),
    getString(SETTING_KEYS.CONTACT_PHONE),
    getString(SETTING_KEYS.ADDRESS),
    getSocialLinks(),
  ]);

  return (
    <footer className="border-t bg-muted/40">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="grid gap-10 md:grid-cols-[1.4fr_1fr_1fr]">
          <div className="space-y-4">
            <ClubLogo variant="inline" size={36} href="/" />
            <p className="max-w-sm text-sm leading-relaxed text-muted-foreground">
              {t("footer.description")}
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              {email ? (
                <li className="flex items-center gap-2">
                  <Mail className="size-4 shrink-0 text-primary" aria-hidden />
                  <a href={`mailto:${email}`} className="hover:text-foreground">
                    {email}
                  </a>
                </li>
              ) : null}
              {phone ? (
                <li className="flex items-center gap-2">
                  <Phone className="size-4 shrink-0 text-primary" aria-hidden />
                  <a href={`tel:${phone.replace(/\s/g, "")}`} className="hover:text-foreground">
                    {phone}
                  </a>
                </li>
              ) : null}
              {address ? (
                <li className="flex items-start gap-2">
                  <MapPin className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                  <span>{address}</span>
                </li>
              ) : null}
            </ul>
          </div>

          <nav aria-label={t("footer.quickLinks")}>
            <h2 className="mb-3 text-sm font-semibold">{t("footer.quickLinks")}</h2>
            <ul className="space-y-2 text-sm">
              {FOOTER_NAV.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="text-muted-foreground transition-colors hover:text-foreground"
                  >
                    {t(item.labelKey)}
                  </Link>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="mb-3 text-sm font-semibold">{t("footer.followUs")}</h2>
            {Object.keys(social).length > 0 ? (
              <ul className="flex flex-wrap gap-2">
                {Object.entries(social).map(([network, url]) => {
                  const Icon = SOCIAL_ICONS[network];
                  if (!Icon) return null;
                  return (
                    <li key={network}>
                      <a
                        href={url}
                        target="_blank"
                        rel="noopener noreferrer"
                        aria-label={network}
                        className="flex size-9 items-center justify-center rounded-lg bg-background text-muted-foreground ring-1 ring-border transition-colors hover:text-primary hover:ring-primary/40"
                      >
                        <Icon className="size-4" aria-hidden />
                      </a>
                    </li>
                  );
                })}
              </ul>
            ) : (
              <p className="text-sm text-muted-foreground">{t("common.none")}</p>
            )}
          </div>
        </div>

        <div className="mt-10 flex flex-col gap-2 border-t pt-6 text-xs text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
          <p>
            © {new Date().getFullYear()} {t("common.appName")} — {t("common.tagline")}.{" "}
            {t("footer.rights")}
          </p>
          <div className="flex gap-4">
            <Link href="/privacy" className="hover:text-foreground">
              {t("footer.privacy")}
            </Link>
            <Link href="/terms" className="hover:text-foreground">
              {t("footer.terms")}
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
