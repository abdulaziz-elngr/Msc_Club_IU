import Link from "next/link";
import { ClubLogo } from "@/components/brand/logo";
import { SiteHeaderClient, type HeaderUser } from "@/components/site/site-header-client";
import { getAuthContext } from "@/lib/auth/dal";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { unreadCount } from "@/lib/notifications";

/**
 * Public site header.
 *
 * Everything requiring authentication or the notification count is resolved
 * here on the server; the client half only handles interaction.
 */
export async function SiteHeader() {
  const ctx = await getAuthContext();
  const locale = await resolveLocale(ctx?.locale === "AR" ? "ar" : ctx?.locale === "EN" ? "en" : null);
  const t = getTranslations(locale);

  let user: HeaderUser | null = null;
  if (ctx) {
    const unread = ctx.isActive ? await unreadCount(ctx.userId).catch(() => 0) : 0;
    user = {
      name: ctx.name,
      email: ctx.email,
      isAdmin: ctx.isSuperAdmin || ctx.permissions.has("admin.dashboard"),
      unread,
    };
  }

  return (
    <header className="sticky top-0 z-40 border-b bg-background/85 backdrop-blur-md supports-[backdrop-filter]:bg-background/70">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link
          href="/"
          className="flex shrink-0 items-center gap-2.5 rounded-md outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={`${t("common.appName")} — ${t("common.tagline")}`}
        >
          <ClubLogo variant="inline" size={34} href={null} />
        </Link>

        <SiteHeaderClient user={user} />
      </div>
    </header>
  );
}
