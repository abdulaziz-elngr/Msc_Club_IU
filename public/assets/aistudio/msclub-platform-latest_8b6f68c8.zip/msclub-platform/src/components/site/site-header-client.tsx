"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useMemo, useState, useTransition } from "react";
import {
  Bell,
  ChevronDown,
  LayoutDashboard,
  LogOut,
  Menu,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { cn } from "@/lib/utils";
import { logoutAction } from "@/app/actions/auth";
import { ClubLogo } from "@/components/brand/logo";
import { LanguageSwitcher } from "@/components/i18n/language-switcher";
import { ThemeSwitcher } from "@/components/theme/theme-switcher";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { MEMBER_NAV, PUBLIC_NAV } from "@/components/site/nav";
import type { TranslationKey } from "@/lib/i18n";

export type HeaderUser = {
  name: string;
  email: string;
  isAdmin: boolean;
  unread: number;
};

function NavLink({
  href,
  labelKey,
  onNavigate,
}: {
  href: string;
  labelKey: TranslationKey;
  onNavigate?: () => void;
}) {
  const t = useT();
  const pathname = usePathname();
  const active = href === "/" ? pathname === "/" : pathname.startsWith(href);

  return (
    <Link
      href={href}
      onClick={onNavigate}
      aria-current={active ? "page" : undefined}
      className={cn(
        "relative rounded-md px-2.5 py-1.5 text-sm font-medium transition-colors outline-none",
        "focus-visible:ring-2 focus-visible:ring-ring",
        active ? "text-primary" : "text-muted-foreground hover:text-foreground",
      )}
    >
      {t(labelKey)}
      {active ? (
        <span className="absolute inset-x-2.5 -bottom-0.5 h-0.5 rounded-full bg-primary" aria-hidden />
      ) : null}
    </Link>
  );
}

function AuthActions({ user, compactNav }: { user: HeaderUser | null; compactNav?: boolean }) {
  const t = useT();
  const [pending, startTransition] = useTransition();

  if (!user) {
    return (
      <div className="flex items-center gap-1.5">
        <Button asChild variant="ghost" size="sm">
          <Link href="/login">{t("common.signIn")}</Link>
        </Button>
        <Button asChild size="sm" className={compactNav ? "hidden sm:inline-flex" : ""}>
          <Link href="/join">{t("nav.join")}</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="flex items-center gap-0.5">
      <Button asChild variant="ghost" size="icon-sm" aria-label={t("nav.notifications")}>
        <Link href="/notifications">
          <span className="relative inline-flex">
            <Bell className="size-4" aria-hidden />
            {user.unread > 0 ? (
              <span className="absolute -top-1.5 -end-1.5 flex size-3.5 items-center justify-center rounded-full bg-primary text-[9px] font-semibold text-primary-foreground">
                {user.unread > 9 ? "9+" : user.unread}
              </span>
            ) : null}
          </span>
        </Link>
      </Button>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="gap-1.5" disabled={pending}>
            <span className="max-w-28 truncate">{user.name}</span>
            <ChevronDown className="size-3.5 opacity-60" aria-hidden />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel className="truncate text-xs font-normal text-muted-foreground">
            {user.email}
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem asChild>
            <Link href="/dashboard">
              <LayoutDashboard aria-hidden />
              {t("nav.dashboard")}
            </Link>
          </DropdownMenuItem>
          <DropdownMenuItem asChild>
            <Link href="/profile">
              <UserRound aria-hidden />
              {t("nav.profile")}
            </Link>
          </DropdownMenuItem>
          {user.isAdmin ? (
            <DropdownMenuItem asChild>
              <Link href="/admin">
                <ShieldCheck aria-hidden />
                {t("nav.admin")}
              </Link>
            </DropdownMenuItem>
          ) : null}
          <DropdownMenuSeparator />
          <DropdownMenuItem
            variant="destructive"
            disabled={pending}
            onSelect={(event) => {
              event.preventDefault();
              startTransition(() => logoutAction().catch(() => undefined));
            }}
          >
            <LogOut aria-hidden />
            {t("common.signOut")}
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}

/**
 * Interactive half of the public header: responsive navigation, account menu
 * and the language/theme controls. Receives only plain serialised data from
 * the server — no database access happens on the client.
 */
export function SiteHeaderClient({ user }: { user: HeaderUser | null }) {
  const t = useT();
  const [open, setOpen] = useState(false);
  const links = useMemo(() => PUBLIC_NAV, []);

  return (
    <div className="flex items-center gap-2">
      <nav className="hidden items-center gap-0.5 lg:flex" aria-label="Primary">
        {links.map((item) => (
          <NavLink key={item.href} href={item.href} labelKey={item.labelKey} />
        ))}
      </nav>

      <div className="ms-auto flex items-center gap-1 lg:ms-0">
        <div className="hidden items-center sm:flex">
          <LanguageSwitcher compact />
          <ThemeSwitcher compact />
        </div>

        <AuthActions user={user} compactNav />

        <Sheet open={open} onOpenChange={setOpen}>
          <SheetTrigger asChild>
            <Button variant="ghost" size="icon-sm" className="lg:hidden" aria-label={t("nav.openMenu")}>
              <Menu className="size-5" aria-hidden />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-80 gap-0">
            <SheetHeader>
              <SheetTitle className="flex items-center gap-2">
                <ClubLogo variant="mark" size={28} href={null} />
                <span className="text-base font-semibold">{t("common.appName")}</span>
              </SheetTitle>
            </SheetHeader>

            <nav className="flex flex-col gap-1" aria-label="Mobile">
              {links.map((item) => (
                <NavLink
                  key={item.href}
                  href={item.href}
                  labelKey={item.labelKey}
                  onNavigate={() => setOpen(false)}
                />
              ))}
            </nav>

            <div className="border-t pt-3">
              {user ? (
                <nav className="flex flex-col gap-1" aria-label="Member">
                  {MEMBER_NAV.map((item) => (
                    <NavLink
                      key={item.href}
                      href={item.href}
                      labelKey={item.labelKey}
                      onNavigate={() => setOpen(false)}
                    />
                  ))}
                </nav>
              ) : (
                <div className="flex flex-col gap-2">
                  <Button asChild variant="outline">
                    <Link href="/login" onClick={() => setOpen(false)}>
                      {t("common.signIn")}
                    </Link>
                  </Button>
                  <Button asChild>
                    <Link href="/join" onClick={() => setOpen(false)}>
                      {t("nav.join")}
                    </Link>
                  </Button>
                </div>
              )}
            </div>

            <div className="mt-auto flex items-center gap-1 border-t pt-3">
              <LanguageSwitcher />
              <div className="ms-auto">
                <ThemeSwitcher compact />
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </div>
  );
}
