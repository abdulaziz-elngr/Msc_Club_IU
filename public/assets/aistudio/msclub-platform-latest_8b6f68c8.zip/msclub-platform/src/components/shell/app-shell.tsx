"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, useTransition } from "react";
import {
  Award, BarChart3, Bell, CalendarCheck, ClipboardList, ExternalLink, FileText, GraduationCap, KeyRound, LayoutDashboard,
  ListChecks, LogOut, Mail, Medal, Menu, ScrollText, Search, Settings, Shield, TrendingUp, Trophy, User, Users, UsersRound, Zap, type LucideIcon,
} from "lucide-react";
import { logoutAction } from "@/app/actions/auth";
import { ClubMark } from "@/components/brand/mark";
import { LanguageSwitcher } from "@/components/i18n/language-switcher";
import { useI18n } from "@/components/i18n/locale-provider";
import { ThemeSwitcher } from "@/components/theme/theme-switcher";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList,
} from "@/components/ui/command";
import { cn } from "@/lib/utils";

/** Icons are referenced by name so server components can pass plain data. */
const ICONS = {
  dashboard: LayoutDashboard, events: CalendarCheck, learning: GraduationCap, points: Zap, achievements: Trophy,
  tasks: ListChecks, certificates: Award, notifications: Bell, profile: User, members: Users, settings: Settings, shield: Shield, applications: ClipboardList, teams: UsersRound,
  levels: TrendingUp, badges: Medal, leaderboard: Trophy, analytics: BarChart3, content: FileText, messages: Mail, audit: ScrollText, roles: KeyRound,
} satisfies Record<string, LucideIcon>;

export type ShellIcon = keyof typeof ICONS;
export type ShellNavItem = { href: string; label: string; icon: ShellIcon; exact?: boolean };

type Props = {
  nav: ShellNavItem[];
  /** Shown above the nav (e.g. "Member portal"). */
  areaLabel: string;
  user: { name: string; email: string; image: string | null };
  unreadCount?: number;
  notificationsHref?: string;
  /** Optional shortcut to another area the user may access. */
  crossLink?: { href: string; label: string };
  /** Enables the Ctrl/⌘+K command palette over the navigation items. */
  palette?: boolean;
  children: React.ReactNode;
};

function initials(name: string) {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "?";
}

function NavList({ nav, onNavigate }: { nav: ShellNavItem[]; onNavigate?: () => void }) {
  const pathname = usePathname();
  return (
    <nav aria-label="Primary" className="flex flex-col gap-0.5">
      {nav.map((item) => {
        const Icon = ICONS[item.icon];
        const active = item.exact ? pathname === item.href : pathname === item.href || pathname.startsWith(`${item.href}/`);
        return (
          <Link
            key={item.href}
            href={item.href}
            onClick={onNavigate}
            aria-current={active ? "page" : undefined}
            className={cn(
              "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium outline-none transition-colors focus-visible:ring-2 focus-visible:ring-ring",
              active ? "bg-primary/10 text-primary" : "text-muted-foreground hover:bg-muted hover:text-foreground",
            )}
          >
            <Icon className="size-4 shrink-0" aria-hidden />
            <span className="truncate">{item.label}</span>
          </Link>
        );
      })}
    </nav>
  );
}

function Brand({ areaLabel }: { areaLabel: string }) {
  return (
    <Link href="/" className="flex items-center gap-2.5 rounded-lg outline-none focus-visible:ring-2 focus-visible:ring-ring">
      <ClubMark size={30} />
      <span className="min-w-0 leading-tight">
        <span className="block truncate text-sm font-semibold">Microsoft Student Clubs</span>
        <span className="block truncate text-xs text-muted-foreground">{areaLabel}</span>
      </span>
    </Link>
  );
}

function CommandPalette({ nav }: { nav: ShellNavItem[] }) {
  const { t } = useI18n();
  const router = useRouter();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  return (
    <>
      <Button type="button" variant="outline" size="sm" className="hidden h-9 gap-2 text-muted-foreground sm:inline-flex" onClick={() => setOpen(true)} aria-label={t("common.search")}>
        <Search className="size-4" aria-hidden />
        <span className="text-xs">{t("common.search")}</span>
        <kbd className="rounded border bg-muted px-1.5 text-[0.65rem]">Ctrl K</kbd>
      </Button>
      <Button type="button" variant="ghost" size="icon" className="sm:hidden" onClick={() => setOpen(true)} aria-label={t("common.search")}>
        <Search className="size-4.5" aria-hidden />
      </Button>
      <CommandDialog open={open} onOpenChange={setOpen}>
        <CommandInput placeholder={t("admin.ui.searchPlaceholder")} />
        <CommandList>
          <CommandEmpty>{t("admin.ui.noResults")}</CommandEmpty>
          <CommandGroup>
            {nav.map((item) => {
              const Icon = ICONS[item.icon];
              return (
                <CommandItem key={item.href} value={item.label} onSelect={() => { setOpen(false); router.push(item.href); }}>
                  <Icon aria-hidden /> {item.label}
                </CommandItem>
              );
            })}
          </CommandGroup>
        </CommandList>
      </CommandDialog>
    </>
  );
}

export function AppShell({ nav, areaLabel, user, unreadCount = 0, notificationsHref, crossLink, palette, children }: Props) {
  const { t, dir } = useI18n();
  const pathname = usePathname();
  const current = [...nav].sort((a, b) => b.href.length - a.href.length).find((i) => (i.exact ? pathname === i.href : pathname === i.href || pathname.startsWith(`${i.href}/`)));
  const [open, setOpen] = useState(false);
  const [, startTransition] = useTransition();

  return (
    <div className="flex min-h-dvh bg-muted/30">
      <aside className="sticky top-0 hidden h-dvh w-64 shrink-0 flex-col gap-6 border-e bg-card px-4 py-5 lg:flex">
        <Brand areaLabel={areaLabel} />
        <div className="flex-1 overflow-y-auto"><NavList nav={nav} /></div>
        <Link href="/" className="flex items-center gap-2 px-3 text-xs text-muted-foreground hover:text-foreground">
          <ExternalLink className="size-3.5" aria-hidden /> {t("dashboard.backToSite")}
        </Link>
      </aside>

      <div className="flex min-w-0 flex-1 flex-col">
        <header className="sticky top-0 z-30 flex h-14 items-center gap-2 border-b bg-card/95 px-3 backdrop-blur-sm sm:px-5">
          <Button type="button" variant="ghost" size="icon" className="lg:hidden" aria-label={t("nav.openMenu")} onClick={() => setOpen(true)}>
            <Menu className="size-5" aria-hidden />
          </Button>
          <nav aria-label="Breadcrumb" className="hidden min-w-0 items-center gap-1.5 text-sm sm:flex">
            <span className="truncate text-muted-foreground">{areaLabel}</span>
            {current ? (<><span aria-hidden className="text-muted-foreground">/</span><span className="truncate font-medium">{current.label}</span></>) : null}
          </nav>
          <div className="flex-1" />
          {palette ? <CommandPalette nav={nav} /> : null}
          <LanguageSwitcher compact />
          <ThemeSwitcher compact />
          {notificationsHref ? (
            <Button asChild variant="ghost" size="icon" className="relative" aria-label={t("nav.notifications")}>
              <Link href={notificationsHref}>
                <Bell className="size-4.5" aria-hidden />
                {unreadCount > 0 ? (
                  <span className="absolute end-1 top-1 flex min-w-4 items-center justify-center rounded-full bg-primary px-1 text-[0.6rem] leading-4 font-semibold text-primary-foreground">
                    {unreadCount > 99 ? "99+" : unreadCount}
                  </span>
                ) : null}
              </Link>
            </Button>
          ) : null}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button type="button" variant="ghost" className="h-9 gap-2 px-1.5" aria-label={user.name}>
                <Avatar className="size-7">
                  {user.image ? <AvatarImage src={user.image} alt="" /> : null}
                  <AvatarFallback className="text-xs">{initials(user.name)}</AvatarFallback>
                </Avatar>
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-56">
              <DropdownMenuLabel className="space-y-0.5">
                <span className="block truncate text-sm font-medium">{user.name}</span>
                <span className="block truncate text-xs font-normal text-muted-foreground">{user.email}</span>
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              {crossLink ? (
                <DropdownMenuItem asChild><Link href={crossLink.href}>{crossLink.label}</Link></DropdownMenuItem>
              ) : null}
              <DropdownMenuItem asChild><Link href="/dashboard/profile">{t("nav.profile")}</Link></DropdownMenuItem>
              <DropdownMenuItem
                onSelect={(e) => {
                  e.preventDefault();
                  startTransition(() => logoutAction().catch(() => undefined));
                }}
              >
                <LogOut aria-hidden /> {t("common.signOut")}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </header>

        <Sheet open={open} onOpenChange={setOpen}>
          <SheetContent side={dir === "rtl" ? "right" : "left"} className="w-72 gap-4 p-4">
            <SheetHeader className="p-0"><SheetTitle className="sr-only">{t("nav.menu")}</SheetTitle></SheetHeader>
            <Brand areaLabel={areaLabel} />
            <NavList nav={nav} onNavigate={() => setOpen(false)} />
          </SheetContent>
        </Sheet>

        <main id="main-content" className="mx-auto w-full max-w-6xl flex-1 space-y-6 px-4 py-6 sm:px-6 lg:py-8">{children}</main>
      </div>
    </div>
  );
}
