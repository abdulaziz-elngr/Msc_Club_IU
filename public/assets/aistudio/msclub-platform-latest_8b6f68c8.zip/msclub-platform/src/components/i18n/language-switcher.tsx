"use client";

import { useTransition } from "react";
import { Languages } from "lucide-react";
import { setLocale } from "@/app/actions/locale";
import { localeLabel, type Locale } from "@/lib/i18n";
import { useI18n } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";

/**
 * Toggles EN ⇄ AR. The action writes both a cookie (anonymous visitors) and,
 * when signed in, the user record (follows them across devices).
 */
export function LanguageSwitcher({ compact = false }: { compact?: boolean }) {
  const { locale } = useI18n();
  const [pending, startTransition] = useTransition();
  const next: Locale = locale === "en" ? "ar" : "en";

  return (
    <Button
      type="button"
      variant="ghost"
      size="sm"
      disabled={pending}
      aria-label={`Switch language to ${localeLabel(next)}`}
      onClick={() => {
        startTransition(async () => {
          try {
            await setLocale(next);
          } catch {
            // A failed locale write is non-fatal — the UI simply stays put.
          }
        });
      }}
      className={compact ? "gap-1.5" : "gap-2"}
    >
      <Languages className="size-4" aria-hidden />
      <span className="text-sm font-medium">{localeLabel(next)}</span>
    </Button>
  );
}
