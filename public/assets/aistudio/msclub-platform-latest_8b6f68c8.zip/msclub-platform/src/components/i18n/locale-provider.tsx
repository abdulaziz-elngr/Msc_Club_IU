"use client";

import { createContext, useContext, useMemo, type ReactNode } from "react";
import {
  getDictionary,
  localeDirection,
  translate,
  type Dictionary,
  type Locale,
  type TranslationKey,
  type TranslationParams,
} from "@/lib/i18n";

type I18nValue = {
  locale: Locale;
  dir: "ltr" | "rtl";
  dictionary: Dictionary;
  t: (key: TranslationKey, params?: TranslationParams) => string;
};

const I18nContext = createContext<I18nValue | null>(null);

export function LocaleProvider({
  locale,
  children,
}: {
  locale: Locale;
  children: ReactNode;
}) {
  const value = useMemo<I18nValue>(() => {
    const dictionary = getDictionary(locale);
    return {
      locale,
      dir: localeDirection(locale),
      dictionary,
      t: (key, params) => translate(dictionary, key, params),
    };
  }, [locale]);

  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) {
    throw new Error("useI18n must be used inside <LocaleProvider>");
  }
  return ctx;
}

/** Shorthand: `const t = useT(); t("nav.home")` */
export function useT() {
  return useI18n().t;
}
