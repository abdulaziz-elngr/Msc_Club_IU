"use client";

import { useState, useTransition } from "react";
import { selfCheckInAction } from "@/app/actions/checkin";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import type { TranslationKey } from "@/lib/i18n";

export function SelfCheckIn({ eventId, code }: { eventId: string; code: string }) {
  const t = useT();
  const [pending, start] = useTransition();
  const [state, setState] = useState<{ ok: boolean; scanCode?: string; points?: number } | null>(null);

  if (state?.ok) {
    return <p role="status" className="rounded-lg bg-success-50 p-4 text-sm font-medium text-success-700 dark:bg-success-500/10 dark:text-success-500">{t("admin.scan.selfDone")}{state.points ? ` +${state.points} XP` : ""}</p>;
  }
  return (
    <div className="space-y-3">
      {state && !state.ok ? (
        <p role="alert" className="text-sm text-danger-700 dark:text-danger-500">
          {t(`admin.scan.codes.${state.scanCode ?? "TOKEN_NOT_FOUND"}` as TranslationKey)}
        </p>
      ) : null}
      <Button type="button" size="lg" className="w-full" disabled={pending} onClick={() => start(async () => setState(await selfCheckInAction(eventId, code)))}>
        {t("admin.scan.selfConfirm")}
      </Button>
    </div>
  );
}
