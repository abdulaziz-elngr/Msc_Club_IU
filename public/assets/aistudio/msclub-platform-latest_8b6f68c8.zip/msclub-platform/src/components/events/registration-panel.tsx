"use client";

import Link from "next/link";
import { useActionState, useState, useTransition } from "react";
import { CheckCircle2, Clock, Lock, Users } from "lucide-react";
import { cancelRegistrationAction, registerForEventAction, type EventActionState } from "@/app/actions/events";
import { useI18n } from "@/components/i18n/locale-provider";
import { Field, SubmitButton } from "@/components/shared/form";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { TranslationKey } from "@/lib/i18n";
import type { RegistrationWindow } from "@/lib/queries/events";
import { cn } from "@/lib/utils";

export type PanelField = {
  key: string;
  label: string;
  labelAr: string | null;
  type: string;
  options: string[];
  required: boolean;
};

export type PanelProps = {
  eventId: string;
  window: RegistrationWindow;
  signedIn: boolean;
  /** Account is an ACTIVE member. */
  active: boolean;
  loginHref: string;
  registration: { status: "CONFIRMED" | "WAITLISTED"; position: number | null; checkedIn: boolean } | null;
  full: boolean;
  waitlistEnabled: boolean;
  seatsLeft: number | null;
  opensAtLabel: string | null;
  fields: PanelField[];
};

const INPUT = "h-10";
const NATIVE =
  "h-10 w-full rounded-lg border border-input bg-transparent px-3 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50";

function errorKey(code: string | undefined): TranslationKey {
  return `events.errors.${code && code in ERROR_CODES ? code : "GENERIC"}` as TranslationKey;
}
const ERROR_CODES: Record<string, true> = {
  EVENT_NOT_FOUND: true, REGISTRATION_CLOSED: true, NOT_ELIGIBLE: true, ALREADY_REGISTERED: true, FULL: true,
  INVALID_ANSWERS: true, NOT_REGISTERED: true, ALREADY_CANCELLED: true, EVENT_STARTED: true, RATE_LIMITED: true,
  UNAUTHENTICATED: true, GENERIC: true,
};

export function RegistrationPanel(props: PanelProps) {
  const { t, locale } = useI18n();
  const [state, formAction, pending] = useActionState<EventActionState, FormData>(
    registerForEventAction.bind(null, props.eventId),
    undefined,
  );
  const [cancelMsg, setCancelMsg] = useState<{ ok: boolean; code?: string } | null>(null);
  const [cancelling, startCancel] = useTransition();

  const shell = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";

  // --- already registered ----------------------------------------------------
  if (props.registration) {
    const confirmed = props.registration.status === "CONFIRMED";
    return (
      <section className={shell} aria-live="polite">
        <div className="flex items-start gap-3">
          <span
            className={cn(
              "flex size-9 shrink-0 items-center justify-center rounded-full",
              confirmed ? "bg-success-50 text-success-700 dark:bg-success-500/15 dark:text-success-500" : "bg-warning-50 text-warning-700 dark:bg-warning-500/15 dark:text-warning-500",
            )}
          >
            {confirmed ? <CheckCircle2 className="size-5" aria-hidden /> : <Clock className="size-5" aria-hidden />}
          </span>
          <div className="space-y-0.5">
            <p className="text-sm font-semibold">{t(confirmed ? "statuses.CONFIRMED" : "statuses.WAITLISTED")}</p>
            <p className="text-sm text-muted-foreground">
              {confirmed
                ? props.registration.checkedIn
                  ? t("events.checkedIn")
                  : t("events.confirmedHint")
                : props.registration.position
                  ? t("events.waitlistPosition", { position: props.registration.position })
                  : t("events.waitlistedHint")}
            </p>
          </div>
        </div>

        {state?.ok ? (
          <p role="status" className="text-sm text-success-700 dark:text-success-500">
            {state.status === "WAITLISTED" ? t("events.waitlistSuccess", { position: state.position ?? 1 }) : t("events.registerSuccess")}
          </p>
        ) : null}
        {cancelMsg && !cancelMsg.ok ? (
          <p role="alert" className="text-sm text-danger-700 dark:text-danger-500">{t(errorKey(cancelMsg.code))}</p>
        ) : null}

        <div className="flex flex-wrap gap-2">
          {confirmed ? (
            <Link href="/dashboard/events" className={buttonVariants({ size: "sm" })}>
              {t("events.viewQr")}
            </Link>
          ) : null}
          {!props.registration.checkedIn ? (
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button type="button" variant="outline" size="sm" disabled={cancelling}>
                  {t("events.cancelRegistration")}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>{t("events.cancelConfirmTitle")}</AlertDialogTitle>
                  <AlertDialogDescription>{t("events.cancelConfirmBody")}</AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>{t("events.keepRegistration")}</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() =>
                      startCancel(async () => {
                        const result = await cancelRegistrationAction(props.eventId);
                        setCancelMsg(result ?? { ok: false });
                      })
                    }
                  >
                    {t("events.cancelRegistration")}
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          ) : null}
        </div>
      </section>
    );
  }

  // --- cannot register -------------------------------------------------------
  const blocked =
    props.window === "cancelled" ? "events.errors.REGISTRATION_CLOSED"
    : props.window === "ended" || props.window === "closed" ? "events.registrationClosedNote"
    : null;

  if (blocked) {
    return (
      <section className={shell}>
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Lock className="size-4" aria-hidden /> {t(blocked as TranslationKey)}
        </p>
      </section>
    );
  }
  if (props.window === "not_yet") {
    return (
      <section className={shell}>
        <p className="flex items-center gap-2 text-sm text-muted-foreground">
          <Clock className="size-4" aria-hidden /> {t("events.registrationNotYetOpen", { date: props.opensAtLabel ?? "" })}
        </p>
      </section>
    );
  }
  if (!props.signedIn) {
    return (
      <section className={shell}>
        <Link href={props.loginHref} className={cn(buttonVariants({ size: "lg" }), "w-full")}>
          {t("events.signInToRegister")}
        </Link>
      </section>
    );
  }
  if (!props.active) {
    return (
      <section className={shell}>
        <p className="text-sm text-muted-foreground">{t("events.membersOnly")}</p>
      </section>
    );
  }
  if (props.full && !props.waitlistEnabled) {
    return (
      <section className={shell}>
        <p className="flex items-center gap-2 text-sm font-medium">
          <Users className="size-4" aria-hidden /> {t("events.full")}
        </p>
      </section>
    );
  }

  // --- registration form -----------------------------------------------------
  const fieldError = (key: string) => {
    const code = state?.fieldErrors?.[key];
    return code ? [t(`events.fieldErrors.${code}` as TranslationKey)] : undefined;
  };

  return (
    <section className={shell}>
      <form action={formAction} className="space-y-4" noValidate>
        {props.fields.length > 0 ? (
          <div className="space-y-4">
            <h3 className="text-sm font-semibold">{t("events.registrationForm")}</h3>
            {props.fields.map((f) => {
              const id = `field-${f.key}`;
              const label = locale === "ar" && f.labelAr ? f.labelAr : f.label;
              const initial = state?.values?.[f.key];
              return (
                <Field key={f.key} label={label} htmlFor={id} required={f.required} error={fieldError(f.key)}>
                  {f.type === "textarea" ? (
                    <Textarea id={id} name={f.key} defaultValue={initial} maxLength={2000} rows={3} aria-invalid={Boolean(state?.fieldErrors?.[f.key])} />
                  ) : f.type === "select" ? (
                    <select id={id} name={f.key} defaultValue={initial ?? ""} className={NATIVE} aria-invalid={Boolean(state?.fieldErrors?.[f.key])}>
                      <option value="" disabled>—</option>
                      {f.options.map((o) => (
                        <option key={o} value={o}>{o}</option>
                      ))}
                    </select>
                  ) : f.type === "checkbox" ? (
                    <input id={id} name={f.key} type="checkbox" defaultChecked={initial === "on"} className="size-5 rounded border-input accent-[var(--color-primary)]" />
                  ) : (
                    <Input
                      id={id}
                      name={f.key}
                      defaultValue={initial}
                      type={f.type === "number" ? "number" : f.type === "url" ? "url" : "text"}
                      inputMode={f.type === "number" ? "decimal" : undefined}
                      maxLength={f.type === "url" ? 500 : 300}
                      className={INPUT}
                      aria-invalid={Boolean(state?.fieldErrors?.[f.key])}
                    />
                  )}
                </Field>
              );
            })}
          </div>
        ) : null}

        {state && !state.ok ? (
          <p role="alert" className="text-sm text-danger-700 dark:text-danger-500">{t(errorKey(state.code))}</p>
        ) : null}

        {props.seatsLeft !== null && !props.full ? (
          <p className="text-xs text-muted-foreground">{t("events.seatsLeft", { count: props.seatsLeft })}</p>
        ) : null}

        <SubmitButton pending={pending}>{props.full ? t("events.waitlist") : t("events.register")}</SubmitButton>
      </form>
    </section>
  );
}
