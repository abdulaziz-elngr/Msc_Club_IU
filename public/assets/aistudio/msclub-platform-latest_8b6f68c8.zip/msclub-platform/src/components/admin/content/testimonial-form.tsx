"use client";

import { ActionForm, Field } from "@/components/admin/forms";
import { useT } from "@/components/i18n/locale-provider";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/actions/admin";

export type TestimonialValues = { name: string; nameAr: string; role: string; roleAr: string; quote: string; quoteAr: string; approved: boolean; order: number };
export const EMPTY_TESTIMONIAL: TestimonialValues = { name: "", nameAr: "", role: "", roleAr: "", quote: "", quoteAr: "", approved: true, order: 0 };

export function TestimonialForm({ action, values, isNew }: { action: (prev: ActionResult | undefined, fd: FormData) => Promise<ActionResult>; values: TestimonialValues; isNew: boolean }) {
  const t = useT();
  return (
    <ActionForm action={action} resetOnSuccess={isNew} successKey={isNew ? "admin.ui.created" : "admin.ui.saved"}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field name="name" label={t("admin.cnt.tName")} required>{(p) => <Input {...p} defaultValue={values.name} maxLength={100} className="h-10" />}</Field>
        <Field name="nameAr" label={t("admin.cnt.tNameAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.nameAr} maxLength={100} className="h-10" />}</Field>
        <Field name="role" label={t("admin.cnt.tRole")}>{(p) => <Input {...p} defaultValue={values.role} maxLength={120} className="h-10" />}</Field>
        <Field name="roleAr" label={t("admin.cnt.tRoleAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.roleAr} maxLength={120} className="h-10" />}</Field>
        <Field name="quote" label={t("admin.cnt.tQuote")} required>{(p) => <Textarea {...p} defaultValue={values.quote} rows={3} maxLength={600} />}</Field>
        <Field name="quoteAr" label={t("admin.cnt.tQuoteAr")}>{(p) => <Textarea {...p} dir="rtl" defaultValue={values.quoteAr} rows={3} maxLength={600} />}</Field>
        <Field name="order" label={t("admin.cnt.tOrder")}>{(p) => <Input {...p} type="number" min={0} max={1000} defaultValue={values.order} className="h-10" />}</Field>
        <Field name="approved" label={t("admin.cnt.tApproved")}>{(p) => <input {...p} type="checkbox" defaultChecked={values.approved} className="size-5 rounded border-input accent-[var(--color-primary)]" />}</Field>
      </div>
    </ActionForm>
  );
}
