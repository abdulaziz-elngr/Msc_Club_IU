"use client";

import { ActionForm, Field, NATIVE_SELECT } from "@/components/admin/forms";
import { useT } from "@/components/i18n/locale-provider";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/actions/admin";
import type { TranslationKey } from "@/lib/i18n";

export type TeamFormValues = {
  name: string; nameAr: string; slug: string; description: string; descriptionAr: string; trackId: string; visibility: string; order: number; logo: string | null;
};
export const EMPTY_TEAM: TeamFormValues = { name: "", nameAr: "", slug: "", description: "", descriptionAr: "", trackId: "", visibility: "PUBLIC", order: 0, logo: null };

export function TeamForm({
  action, values, tracks, isNew,
}: {
  action: (prev: ActionResult | undefined, formData: FormData) => Promise<ActionResult>;
  values: TeamFormValues;
  tracks: { id: string; name: string }[];
  isNew: boolean;
}) {
  const t = useT();
  return (
    <ActionForm action={action} successKey={isNew ? "admin.ui.created" : "admin.ui.saved"}>
      <div className="grid gap-4 sm:grid-cols-2">
        <Field name="name" label={t("admin.team.fName")} required>{(p) => <Input {...p} defaultValue={values.name} maxLength={100} className="h-10" />}</Field>
        <Field name="nameAr" label={t("admin.team.fNameAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.nameAr} maxLength={100} className="h-10" />}</Field>
      </div>
      {isNew ? <Field name="slug" label={t("admin.team.fSlug")} hint={t("admin.ev.fSlugHint")}>{(p) => <Input {...p} dir="ltr" maxLength={60} className="h-10" />}</Field> : null}
      <div className="grid gap-4 sm:grid-cols-2">
        <Field name="description" label={t("admin.team.fDescription")}>{(p) => <Textarea {...p} defaultValue={values.description} rows={4} maxLength={2000} />}</Field>
        <Field name="descriptionAr" label={t("admin.team.fDescriptionAr")}>{(p) => <Textarea {...p} dir="rtl" defaultValue={values.descriptionAr} rows={4} maxLength={2000} />}</Field>
      </div>
      <div className="grid gap-4 sm:grid-cols-3">
        <Field name="trackId" label={t("admin.team.fTrack")}>
          {(p) => (
            <select {...p} defaultValue={values.trackId} className={NATIVE_SELECT}>
              <option value="">{t("admin.team.noTrack")}</option>
              {tracks.map((tr) => <option key={tr.id} value={tr.id}>{tr.name}</option>)}
            </select>
          )}
        </Field>
        <Field name="visibility" label={t("admin.team.fVisibility")} required>
          {(p) => (
            <select {...p} defaultValue={values.visibility} className={NATIVE_SELECT}>
              {(["PUBLIC", "PRIVATE", "HIDDEN"] as const).map((v) => <option key={v} value={v}>{t(`admin.team.visibility.${v}` as TranslationKey)}</option>)}
            </select>
          )}
        </Field>
        <Field name="order" label={t("admin.team.fOrder")}>{(p) => <Input {...p} type="number" min={0} max={1000} defaultValue={values.order} className="h-10" />}</Field>
      </div>
      <Field name="logo" label={t("admin.team.fLogo")} hint={t("admin.team.logoHint")}>
        {(p) => (
          <div className="flex items-center gap-3">
            {values.logo ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={values.logo} alt="" className="size-12 rounded-lg object-cover ring-1 ring-foreground/10" />
            ) : null}
            <input {...p} type="file" accept="image/png,image/jpeg,image/webp" className="text-sm file:me-3 file:rounded-lg file:border-0 file:bg-primary/10 file:px-3 file:py-2 file:text-sm file:font-medium file:text-primary" />
          </div>
        )}
      </Field>
    </ActionForm>
  );
}
