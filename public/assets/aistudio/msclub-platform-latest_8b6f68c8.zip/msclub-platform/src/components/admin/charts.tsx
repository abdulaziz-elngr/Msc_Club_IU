"use client";

import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { useI18n } from "@/components/i18n/locale-provider";

type Series = { key: string; label: string; color: string };

/** Grouped bar chart. Colours come from the brand palette; RTL flips the axes. */
export function BarsChart({
  data, series, height = 260, emptyLabel,
}: {
  data: Record<string, string | number>[];
  series: Series[];
  height?: number;
  emptyLabel: string;
}) {
  const { dir } = useI18n();
  const hasData = data.some((row) => series.some((s) => Number(row[s.key]) > 0));
  if (!hasData) {
    return <div className="flex items-center justify-center rounded-lg bg-muted/40 text-sm text-muted-foreground" style={{ height }}>{emptyLabel}</div>;
  }
  return (
    <div dir="ltr" style={{ height }} role="img" aria-label={series.map((s) => s.label).join(", ")}>
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={dir === "rtl" ? [...data].reverse() : data} margin={{ top: 8, right: 8, left: -12, bottom: 0 }}>
          <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="var(--border)" />
          <XAxis dataKey="label" tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" interval={0} />
          <YAxis allowDecimals={false} tickLine={false} axisLine={false} fontSize={11} stroke="var(--muted-foreground)" orientation={dir === "rtl" ? "right" : "left"} />
          <Tooltip cursor={{ fill: "var(--muted)" }} contentStyle={{ borderRadius: 8, border: "1px solid var(--border)", background: "var(--popover)", color: "var(--popover-foreground)", fontSize: 12 }} />
          {series.length > 1 ? <Legend iconType="circle" wrapperStyle={{ fontSize: 12 }} /> : null}
          {series.map((s) => (
            <Bar key={s.key} dataKey={s.key} name={s.label} fill={s.color} radius={[4, 4, 0, 0]} maxBarSize={36} />
          ))}
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
