"use client";

import { ActionForm, Field, NATIVE_SELECT } from "@/components/admin/forms";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/actions/admin";
import type { TranslationKey } from "@/lib/i18n";

const STATUSES = ["PRESENT", "LATE", "ABSENT", "EXCUSED"] as const;
const REASONS = ["MIS_SCAN", "LATE_ARRIVAL", "TECHNICAL_ISSUE", "ADMIN_ADJUSTMENT", "OTHER"] as const;

/** Attendance correction dialog. A reason is mandatory and recorded in both logs. */
export function AttendanceCorrection({
  action, current,
}: {
  action: (prev: ActionResult | undefined, formData: FormData) => Promise<ActionResult>;
  current: string;
}) {
  const t = useT();
  return (
    <Dialog>
      <DialogTrigger asChild><Button type="button" variant="outline" size="sm">{t("admin.ev.correct")}</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{t("admin.ev.correctTitle")}</DialogTitle></DialogHeader>
        <ActionForm action={action} submitLabel={t("common.save")}>
          <Field name="toStatus" label={t("admin.ev.toStatus")} required>
            {(p) => (
              <select {...p} defaultValue={current === "PRESENT" ? "ABSENT" : "PRESENT"} className={NATIVE_SELECT}>
                {STATUSES.map((s) => <option key={s} value={s}>{t(`admin.ev.attStatus.${s}` as TranslationKey)}</option>)}
              </select>
            )}
          </Field>
          <Field name="reason" label={t("admin.ev.reason")} hint={t("admin.ui.reasonHint")} required>
            {(p) => (
              <select {...p} defaultValue="" required className={NATIVE_SELECT}>
                <option value="" disabled>{t("admin.ui.selectPlaceholder")}</option>
                {REASONS.map((r) => <option key={r} value={r}>{t(`admin.ev.reasons.${r}` as TranslationKey)}</option>)}
              </select>
            )}
          </Field>
          <Field name="note" label={t("admin.ev.note")}>{(p) => <Textarea {...p} rows={3} maxLength={500} />}</Field>
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}
