"use client";

import { useRouter } from "next/navigation";
import { createContext, useContext, useEffect, useId, useRef, useState, useTransition } from "react";
import { toast } from "sonner";
import type { ActionResult } from "@/lib/actions/admin";
import { useActionState } from "react";
import { useT } from "@/components/i18n/locale-provider";
import { SubmitButton } from "@/components/shared/form";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription,
  AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { TranslationKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";

const FormState = createContext<ActionResult | undefined>(undefined);
export const useFormResult = () => useContext(FormState);

function errorText(t: ReturnType<typeof useT>, code?: string) {
  const known = ["FORBIDDEN", "UNAUTHENTICATED", "RATE_LIMITED", "INVALID", "NOT_FOUND", "CONFLICT", "GENERIC"];
  return t(`admin.ui.errors.${code && known.includes(code) ? code : "GENERIC"}` as TranslationKey);
}

/**
 * Generic form bound to a server action returning `ActionResult`.
 * Shows a localized error/success message, per-field errors (via <Field>), and
 * navigates / refreshes after success.
 */
export function ActionForm({
  action, children, submitLabel, successKey = "admin.ui.saved", className, resetOnSuccess, hideSubmit, submitClassName,
}: {
  action: (prev: ActionResult | undefined, formData: FormData) => Promise<ActionResult>;
  children: React.ReactNode;
  submitLabel?: string;
  successKey?: TranslationKey;
  className?: string;
  resetOnSuccess?: boolean;
  hideSubmit?: boolean;
  submitClassName?: string;
}) {
  const t = useT();
  const router = useRouter();
  const ref = useRef<HTMLFormElement>(null);
  const [state, formAction, pending] = useActionState(action, undefined);

  useEffect(() => {
    if (!state?.ok) return;
    toast.success(t(successKey));
    if (resetOnSuccess) ref.current?.reset();
    if (state.redirectTo) router.push(state.redirectTo);
    else router.refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [state]);

  return (
    <FormState.Provider value={state}>
      <form ref={ref} action={formAction} className={cn("space-y-4", className)} noValidate>
        {children}
        {state && !state.ok ? (
          <p role="alert" className="text-sm text-danger-700 dark:text-danger-500">{errorText(t, state.code)}</p>
        ) : null}
        {hideSubmit ? null : <SubmitButton pending={pending} className={cn("sm:w-auto", submitClassName)}>{submitLabel ?? t("common.save")}</SubmitButton>}
      </form>
    </FormState.Provider>
  );
}

/** Label + control + localized field error, reading errors from the surrounding ActionForm. */
export function Field({
  name, label, hint, required, children, className,
}: {
  name: string;
  label: React.ReactNode;
  hint?: React.ReactNode;
  required?: boolean;
  children: (props: { id: string; name: string; "aria-invalid": boolean; "aria-describedby"?: string }) => React.ReactNode;
  className?: string;
}) {
  const t = useT();
  const id = useId();
  const code = useFormResult()?.fieldErrors?.[name];
  const errId = `${id}-err`;
  return (
    <div className={cn("space-y-1.5", className)}>
      <label htmlFor={id} className="flex items-center gap-1 text-sm font-medium">
        {label}
        {required ? <span aria-hidden className="text-danger-600">*</span> : null}
      </label>
      {children({ id, name, "aria-invalid": Boolean(code), "aria-describedby": code ? errId : undefined })}
      {code ? (
        <p id={errId} className="text-xs text-danger-700 dark:text-danger-500">{t(`admin.ui.fieldErrors.${code}` as TranslationKey)}</p>
      ) : hint ? (
        <p className="text-xs text-muted-foreground">{hint}</p>
      ) : null}
    </div>
  );
}

export const NATIVE_SELECT =
  "h-10 w-full rounded-lg border border-input bg-transparent px-3 text-sm outline-none focus-visible:border-ring focus-visible:ring-3 focus-visible:ring-ring/50 aria-invalid:border-destructive";

/**
 * Timezone-correct date/time input. The visible control uses the browser's local
 * time; a hidden field submits an absolute ISO-8601 instant.
 */
export function DateTimeField({ name, defaultValue, ...rest }: { name: string; defaultValue?: string | null } & Omit<React.ComponentProps<typeof Input>, "defaultValue" | "name" | "type">) {
  const toLocal = (iso?: string | null) => {
    if (!iso) return "";
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return "";
    const pad = (n: number) => String(n).padStart(2, "0");
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };
  const [local, setLocal] = useState(() => toLocal(defaultValue));
  const iso = local ? new Date(local).toISOString() : "";
  return (
    <>
      <Input {...rest} type="datetime-local" value={local} onChange={(e) => setLocal(e.target.value)} className="h-10" />
      <input type="hidden" name={name} value={iso} />
    </>
  );
}

/** Destructive / confirm-first action button. */
export function ConfirmAction({
  action, label, title, description, variant = "outline", size = "sm", successKey = "admin.ui.done", disabled, className,
}: {
  action: () => Promise<ActionResult>;
  label: React.ReactNode;
  title?: string;
  description?: string;
  variant?: "outline" | "destructive" | "default" | "ghost";
  size?: "sm" | "default" | "icon";
  successKey?: TranslationKey;
  disabled?: boolean;
  className?: string;
}) {
  const t = useT();
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button type="button" variant={variant} size={size} disabled={disabled || pending} className={className}>{label}</Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{title ?? t("admin.ui.confirmTitle")}</AlertDialogTitle>
          {description ? <AlertDialogDescription>{description}</AlertDialogDescription> : null}
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>{t("common.cancel")}</AlertDialogCancel>
          <AlertDialogAction
            onClick={() =>
              start(async () => {
                const r = await action();
                if (r.ok) { toast.success(t(successKey)); if (r.redirectTo) router.push(r.redirectTo); else router.refresh(); }
                else toast.error(errorText(t, r.code));
              })
            }
          >
            {t("common.confirm")}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

/** One-click action (no confirmation), e.g. publish/unpublish, move up/down. */
export function QuickAction({
  action, children, variant = "outline", size = "sm", successKey = "admin.ui.done", className, ariaLabel, disabled,
}: {
  action: () => Promise<ActionResult>;
  children: React.ReactNode;
  variant?: "outline" | "ghost" | "default" | "destructive";
  size?: "sm" | "default" | "icon";
  successKey?: TranslationKey;
  className?: string;
  ariaLabel?: string;
  disabled?: boolean;
}) {
  const t = useT();
  const router = useRouter();
  const [pending, start] = useTransition();
  return (
    <Button
      type="button" variant={variant} size={size} className={className} aria-label={ariaLabel} disabled={pending || disabled}
      onClick={() =>
        start(async () => {
          const r = await action();
          if (r.ok) { toast.success(t(successKey)); router.refresh(); }
          else toast.error(errorText(t, r.code));
        })
      }
    >
      {children}
    </Button>
  );
}
