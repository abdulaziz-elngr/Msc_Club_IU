"use client";

import { Plus, Trash2 } from "lucide-react";
import { useState } from "react";
import { ActionForm, NATIVE_SELECT, useFormResult } from "@/components/admin/forms";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/actions/admin";
import type { TranslationKey } from "@/lib/i18n";
import { FIELD_TYPES } from "@/lib/schemas/event";

function FieldsError() {
  const t = useT();
  const code = useFormResult()?.fieldErrors?.fields;
  return code ? <p role="alert" className="text-sm text-danger-700 dark:text-danger-500">{t("admin.ui.fieldErrors.invalid")}</p> : null;
}

export type BuilderField = { uid: string; key: string; label: string; labelAr: string; type: string; options: string; required: boolean };

/** Registration form builder. Rows submit as parallel arrays and are re-validated server-side. */
export function FormBuilder({
  action, initial,
}: {
  action: (prev: ActionResult | undefined, formData: FormData) => Promise<ActionResult>;
  initial: Omit<BuilderField, "uid">[];
}) {
  const t = useT();
  const [rows, setRows] = useState<BuilderField[]>(() => initial.map((f, i) => ({ ...f, uid: `r${i}` })));
  const [counter, setCounter] = useState(initial.length);

  const patch = (uid: string, change: Partial<BuilderField>) => setRows((rs) => rs.map((r) => (r.uid === uid ? { ...r, ...change } : r)));

  return (
    <ActionForm action={action}>
      <p className="text-sm text-muted-foreground">{t("admin.ev.formBuilderHint")}</p>
      <FieldsError />
      <ul className="space-y-4">
        {rows.map((r, i) => (
          <li key={r.uid} className="space-y-3 rounded-lg border p-4">
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1.5">
                <label className="text-sm font-medium" htmlFor={`k-${r.uid}`}>{t("admin.ev.fieldKey")}</label>
                <Input id={`k-${r.uid}`} name="f_key" dir="ltr" value={r.key} onChange={(e) => patch(r.uid, { key: e.target.value })} maxLength={31} pattern="[a-z][a-z0-9_]*" required className="h-10" />
                <p className="text-xs text-muted-foreground">{t("admin.ev.fieldKeyHint")}</p>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium" htmlFor={`t-${r.uid}`}>{t("admin.ev.fieldType")}</label>
                <select id={`t-${r.uid}`} name="f_type" value={r.type} onChange={(e) => patch(r.uid, { type: e.target.value })} className={NATIVE_SELECT}>
                  {FIELD_TYPES.map((ft) => <option key={ft} value={ft}>{t(`admin.ev.types.${ft}` as TranslationKey)}</option>)}
                </select>
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium" htmlFor={`l-${r.uid}`}>{t("admin.ev.fieldLabel")}</label>
                <Input id={`l-${r.uid}`} name="f_label" value={r.label} onChange={(e) => patch(r.uid, { label: e.target.value })} maxLength={120} required className="h-10" />
              </div>
              <div className="space-y-1.5">
                <label className="text-sm font-medium" htmlFor={`a-${r.uid}`}>{t("admin.ev.fieldLabelAr")}</label>
                <Input id={`a-${r.uid}`} name="f_labelAr" dir="rtl" value={r.labelAr} onChange={(e) => patch(r.uid, { labelAr: e.target.value })} maxLength={120} className="h-10" />
              </div>
            </div>
            {r.type === "select" ? (
              <div className="space-y-1.5">
                <label className="text-sm font-medium" htmlFor={`o-${r.uid}`}>{t("admin.ev.fieldOptions")}</label>
                <Textarea id={`o-${r.uid}`} name="f_options" value={r.options} onChange={(e) => patch(r.uid, { options: e.target.value })} rows={3} />
              </div>
            ) : (
              <input type="hidden" name="f_options" value="" />
            )}
            <div className="flex items-center justify-between gap-3">
              <label className="flex items-center gap-2 text-sm">
                <input type="hidden" name="f_required" value={r.required ? "yes" : "no"} />
                <input type="checkbox" checked={r.required} onChange={(e) => patch(r.uid, { required: e.target.checked })} className="size-5 rounded border-input accent-[var(--color-primary)]" />
                {t("admin.ev.fieldRequired")}
              </label>
              <Button type="button" variant="ghost" size="sm" onClick={() => setRows((rs) => rs.filter((x) => x.uid !== r.uid))} aria-label={`${t("admin.ev.removeField")} ${i + 1}`}>
                <Trash2 className="size-4" aria-hidden /> {t("admin.ev.removeField")}
              </Button>
            </div>
          </li>
        ))}
      </ul>
      <Button
        type="button" variant="outline" size="sm" disabled={rows.length >= 30}
        onClick={() => { setRows((rs) => [...rs, { uid: `n${counter}`, key: "", label: "", labelAr: "", type: "text", options: "", required: false }]); setCounter((c) => c + 1); }}
      >
        <Plus className="size-4" aria-hidden /> {t("admin.ev.addField")}
      </Button>
    </ActionForm>
  );
}
