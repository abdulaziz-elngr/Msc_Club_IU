"use client";

import { CheckCircle2, CircleAlert, Loader2, Pause, Play, Search, XCircle } from "lucide-react";
import { useCallback, useEffect, useRef, useState, type ComponentType } from "react";
import { manualCheckInAction } from "@/app/actions/admin-events";
import { scanPassAction, searchRegistrantsAction, type RegistrantHit, type ScanResult } from "@/app/actions/checkin";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { TranslationKey } from "@/lib/i18n";
import { cn } from "@/lib/utils";

type ScannerProps = {
  onScan: (codes: { rawValue: string }[]) => void;
  onError?: (error: unknown) => void;
  constraints?: MediaTrackConstraints;
  formats?: string[];
  paused?: boolean;
  sound?: boolean;
  scanDelay?: number;
  components?: Record<string, boolean>;
};

type Feedback = { kind: "ok" | "dup" | "fail"; result: ScanResult };

function ResultCard({ feedback }: { feedback: Feedback }) {
  const t = useT();
  const { kind, result } = feedback;
  const a = result.attendee;
  const tone = kind === "ok" ? "border-success-500/40 bg-success-50 dark:bg-success-500/10" : kind === "dup" ? "border-warning-500/40 bg-warning-50 dark:bg-warning-500/10" : "border-danger-500/40 bg-danger-50 dark:bg-danger-500/10";
  const Icon = kind === "ok" ? CheckCircle2 : kind === "dup" ? CircleAlert : XCircle;
  const title = kind === "ok" ? t("admin.scan.okTitle") : kind === "dup" ? t("admin.scan.dupTitle") : t("admin.scan.failTitle");
  const detail = kind === "ok" ? null : t(`admin.scan.codes.${result.scanCode ?? "TOKEN_NOT_FOUND"}` as TranslationKey);

  return (
    <section role="status" aria-live="assertive" className={cn("space-y-3 rounded-xl border-2 p-4", tone)}>
      <div className="flex items-center gap-2 text-base font-semibold"><Icon className="size-5" aria-hidden /> {title}</div>
      {detail ? <p className="text-sm">{detail}</p> : null}
      {a ? (
        <dl className="grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
          <div className="col-span-2"><dt className="text-xs text-muted-foreground">{t("common.name")}</dt><dd className="text-lg font-semibold">{a.name}</dd></div>
          <div><dt className="text-xs text-muted-foreground">{t("admin.scan.student")}</dt><dd className="font-medium tabular-nums" dir="ltr">{a.studentId ?? "—"}</dd></div>
          <div><dt className="text-xs text-muted-foreground">{t("admin.scan.points")}</dt><dd className="font-medium tabular-nums">{kind === "ok" ? (result.points ?? 0) : a.points}</dd></div>
          <div><dt className="text-xs text-muted-foreground">{t("admin.scan.regStatus")}</dt><dd className="font-medium">{a.registrationStatus ? t(`statuses.${a.registrationStatus}` as TranslationKey) : "—"}</dd></div>
          <div><dt className="text-xs text-muted-foreground">{t("admin.scan.attStatus")}</dt><dd className="font-medium">{a.attendanceStatus ? t(`statuses.${a.attendanceStatus}` as TranslationKey) : "—"}</dd></div>
        </dl>
      ) : null}
    </section>
  );
}

/** Mobile-first staff scanner with manual fallback. The server decides every outcome. */
export function CheckInScanner({ eventId }: { eventId: string }) {
  const t = useT();
  const [Scanner, setScanner] = useState<ComponentType<ScannerProps> | null>(null);
  const [cameraError, setCameraError] = useState<"denied" | "unsupported" | null>(null);
  const [paused, setPaused] = useState(false);
  const [feedback, setFeedback] = useState<Feedback | null>(null);
  const busy = useRef(false);
  const last = useRef<{ value: string; at: number } | null>(null);

  const [query, setQuery] = useState("");
  const [hits, setHits] = useState<RegistrantHit[] | null>(null);
  const [searching, setSearching] = useState(false);

  // Load the scanner lazily on the client and point its decoder at our own origin
  // (the CSP forbids fetching WASM from a CDN).
  useEffect(() => {
    let alive = true;
    import("@yudiel/react-qr-scanner")
      .then((m) => {
        m.setZXingModuleOverrides({ locateFile: (path: string, prefix: string) => (path.endsWith(".wasm") ? `/zxing/${path}` : prefix + path) });
        if (alive) setScanner(() => m.Scanner as unknown as ComponentType<ScannerProps>);
      })
      .catch(() => alive && setCameraError("unsupported"));
    return () => { alive = false; };
  }, []);

  const handle = useCallback((result: ScanResult) => {
    const kind: Feedback["kind"] = result.ok ? "ok" : result.scanCode === "ALREADY_CHECKED_IN" ? "dup" : "fail";
    setFeedback({ kind, result });
    if (typeof navigator !== "undefined" && "vibrate" in navigator) navigator.vibrate(kind === "ok" ? 60 : [90, 50, 90]);
  }, []);

  const onScan = useCallback(async (codes: { rawValue: string }[]) => {
    const value = codes[0]?.rawValue;
    if (!value || busy.current) return;
    const now = Date.now();
    if (last.current && last.current.value === value && now - last.current.at < 4000) return; // same pass still in frame
    busy.current = true;
    last.current = { value, at: now };
    try {
      handle(await scanPassAction(eventId, value));
    } catch {
      handle({ ok: false, code: "GENERIC", scanCode: "TOKEN_NOT_FOUND" });
    } finally {
      busy.current = false;
    }
  }, [eventId, handle]);

  async function search(e: React.FormEvent) {
    e.preventDefault();
    if (query.trim().length < 2) return;
    setSearching(true);
    const r = await searchRegistrantsAction(eventId, query);
    setHits(r.hits);
    setSearching(false);
  }

  async function manual(hit: RegistrantHit) {
    const r = await manualCheckInAction(eventId, hit.userId);
    handle(r.ok
      ? { ok: true, attendee: { ...hit, attendanceStatus: "PRESENT" }, points: 0 }
      : { ok: false, code: r.code, scanCode: r.checkInCode, attendee: hit });
    setHits((hs) => hs?.map((h) => (h.userId === hit.userId ? { ...h, attendanceStatus: "PRESENT" } : h)) ?? null);
  }

  return (
    <div className="mx-auto w-full max-w-md space-y-4">
      <div className="overflow-hidden rounded-2xl bg-black ring-1 ring-foreground/10" style={{ aspectRatio: "1 / 1" }}>
        {cameraError ? (
          <p role="alert" className="flex h-full items-center justify-center p-6 text-center text-sm text-white/90">
            {t(cameraError === "denied" ? "admin.scan.denied" : "admin.scan.unsupported")}
          </p>
        ) : Scanner ? (
          <Scanner
            onScan={onScan}
            onError={(err) => setCameraError((err as { name?: string })?.name === "NotAllowedError" ? "denied" : "unsupported")}
            constraints={{ facingMode: "environment" }}
            formats={["qr_code"]}
            paused={paused}
            sound={false}
            scanDelay={500}
            components={{ finder: true, torch: true }}
          />
        ) : (
          <p className="flex h-full items-center justify-center gap-2 text-sm text-white/80"><Loader2 className="size-4 animate-spin" aria-hidden /> {t("admin.scan.starting")}</p>
        )}
      </div>

      <div className="flex items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">{t("admin.scan.pointCamera")}</p>
        <Button type="button" variant="outline" size="sm" onClick={() => setPaused((p) => !p)} disabled={Boolean(cameraError)}>
          {paused ? <Play className="size-4" aria-hidden /> : <Pause className="size-4" aria-hidden />}
          {paused ? t("admin.scan.resume") : t("admin.scan.pause")}
        </Button>
      </div>

      {feedback ? <ResultCard feedback={feedback} /> : null}

      <section aria-labelledby="manual-h" className="space-y-3 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
        <div>
          <h2 id="manual-h" className="text-sm font-semibold">{t("admin.scan.manual")}</h2>
          <p className="text-xs text-muted-foreground">{t("admin.scan.manualHint")}</p>
        </div>
        <form onSubmit={search} className="flex gap-2" role="search">
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={t("admin.scan.searchPlaceholder")} aria-label={t("admin.scan.manual")} maxLength={60} className="h-10" />
          <Button type="submit" size="icon" disabled={searching} aria-label={t("common.search")}>
            {searching ? <Loader2 className="size-4 animate-spin" aria-hidden /> : <Search className="size-4" aria-hidden />}
          </Button>
        </form>
        {hits ? (
          hits.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("admin.scan.noHits")}</p>
          ) : (
            <ul className="divide-y">
              {hits.map((h) => (
                <li key={h.userId} className="flex items-center justify-between gap-3 py-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{h.name}</p>
                    <p className="text-xs text-muted-foreground" dir="ltr">{h.studentId ?? "—"}</p>
                  </div>
                  {h.attendanceStatus === "PRESENT" || h.attendanceStatus === "LATE" ? (
                    <span className="text-xs font-medium text-success-700 dark:text-success-500">{t("admin.scan.okTitle")}</span>
                  ) : (
                    <Button type="button" size="sm" onClick={() => manual(h)}>{t("admin.ev.checkIn")}</Button>
                  )}
                </li>
              ))}
            </ul>
          )
        ) : null}
      </section>
    </div>
  );
}
