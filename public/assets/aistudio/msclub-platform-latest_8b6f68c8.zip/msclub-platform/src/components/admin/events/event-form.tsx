"use client";

import { ActionForm, DateTimeField, Field, NATIVE_SELECT } from "@/components/admin/forms";
import { useT } from "@/components/i18n/locale-provider";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/actions/admin";
import type { TranslationKey } from "@/lib/i18n";
import { EVENT_CATEGORIES, EVENT_STATUSES } from "@/lib/schemas/event";

export type EventFormValues = {
  title: string; titleAr: string; slug: string; summary: string; description: string; descriptionAr: string;
  category: string; status: string; isOnline: boolean; location: string; onlineUrl: string;
  startsAt: string; endsAt: string; registrationOpensAt: string; registrationClosesAt: string;
  capacity: string; waitlistEnabled: boolean; attendancePoints: number; completionPoints: number; certificateEnabled: boolean;
  speakerName: string; speakerTitle: string; speakerBio: string; teamId: string; rotatingQrEnabled: boolean; qrRotateSeconds: number;
};

export const EMPTY_EVENT: EventFormValues = {
  title: "", titleAr: "", slug: "", summary: "", description: "", descriptionAr: "", category: "WORKSHOP", status: "DRAFT",
  isOnline: false, location: "", onlineUrl: "", startsAt: "", endsAt: "", registrationOpensAt: "", registrationClosesAt: "",
  capacity: "", waitlistEnabled: true, attendancePoints: 20, completionPoints: 0, certificateEnabled: false,
  speakerName: "", speakerTitle: "", speakerBio: "", teamId: "", rotatingQrEnabled: false, qrRotateSeconds: 120,
};

const CHECK = "size-5 rounded border-input accent-[var(--color-primary)]";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <fieldset className="space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
      <legend className="px-1 text-sm font-semibold">{title}</legend>
      {children}
    </fieldset>
  );
}

export function EventForm({
  action, values, teams, isNew,
}: {
  action: (prev: ActionResult | undefined, formData: FormData) => Promise<ActionResult>;
  values: EventFormValues;
  teams: { id: string; name: string }[];
  isNew: boolean;
}) {
  const t = useT();
  const v = values;
  const grid = "grid gap-4 sm:grid-cols-2";

  return (
    <ActionForm action={action} className="space-y-6" successKey={isNew ? "admin.ui.created" : "admin.ui.saved"}>
      <Section title={t("admin.ev.sectionDetails")}>
        <div className={grid}>
          <Field name="title" label={t("admin.ev.fTitle")} required>{(p) => <Input {...p} defaultValue={v.title} maxLength={160} className="h-10" />}</Field>
          <Field name="titleAr" label={t("admin.ev.fTitleAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={v.titleAr} maxLength={160} className="h-10" />}</Field>
        </div>
        {isNew ? (
          <Field name="slug" label={t("admin.ev.fSlug")} hint={t("admin.ev.fSlugHint")}>{(p) => <Input {...p} dir="ltr" defaultValue={v.slug} maxLength={80} className="h-10" />}</Field>
        ) : null}
        <Field name="summary" label={t("admin.ev.fSummary")}>{(p) => <Input {...p} defaultValue={v.summary} maxLength={300} className="h-10" />}</Field>
        <div className={grid}>
          <Field name="description" label={t("admin.ev.fDescription")}>{(p) => <Textarea {...p} defaultValue={v.description} rows={5} maxLength={8000} />}</Field>
          <Field name="descriptionAr" label={t("admin.ev.fDescriptionAr")}>{(p) => <Textarea {...p} dir="rtl" defaultValue={v.descriptionAr} rows={5} maxLength={8000} />}</Field>
        </div>
        <div className={grid}>
          <Field name="category" label={t("admin.ev.fCategory")} required>
            {(p) => (
              <select {...p} defaultValue={v.category} className={NATIVE_SELECT}>
                {EVENT_CATEGORIES.map((c) => <option key={c} value={c}>{t(`events.categories.${c}` as TranslationKey)}</option>)}
              </select>
            )}
          </Field>
          <Field name="status" label={t("admin.ev.fStatus")} hint={t("admin.ev.statusHint")} required>
            {(p) => (
              <select {...p} defaultValue={v.status} className={NATIVE_SELECT}>
                {EVENT_STATUSES.map((s) => <option key={s} value={s}>{t(`statuses.${s}` as TranslationKey)}</option>)}
              </select>
            )}
          </Field>
        </div>
        <div className={grid}>
          <Field name="location" label={t("admin.ev.fLocation")}>{(p) => <Input {...p} defaultValue={v.location} maxLength={200} className="h-10" />}</Field>
          <Field name="onlineUrl" label={t("admin.ev.fOnlineUrl")}>{(p) => <Input {...p} type="url" dir="ltr" defaultValue={v.onlineUrl} maxLength={500} className="h-10" />}</Field>
        </div>
        <Field name="isOnline" label={t("admin.ev.fOnline")}>{(p) => <input {...p} type="checkbox" defaultChecked={v.isOnline} className={CHECK} />}</Field>
        <Field name="teamId" label={t("admin.ev.fTeam")}>
          {(p) => (
            <select {...p} defaultValue={v.teamId} className={NATIVE_SELECT}>
              <option value="">{t("admin.ev.noTeam")}</option>
              {teams.map((tm) => <option key={tm.id} value={tm.id}>{tm.name}</option>)}
            </select>
          )}
        </Field>
      </Section>

      <Section title={t("admin.ev.sectionSchedule")}>
        <div className={grid}>
          <Field name="startsAt" label={t("admin.ev.fStarts")} required>{(p) => <DateTimeField {...p} defaultValue={v.startsAt} />}</Field>
          <Field name="endsAt" label={t("admin.ev.fEnds")} required>{(p) => <DateTimeField {...p} defaultValue={v.endsAt} />}</Field>
          <Field name="registrationOpensAt" label={t("admin.ev.fOpens")}>{(p) => <DateTimeField {...p} defaultValue={v.registrationOpensAt} />}</Field>
          <Field name="registrationClosesAt" label={t("admin.ev.fCloses")}>{(p) => <DateTimeField {...p} defaultValue={v.registrationClosesAt} />}</Field>
          <Field name="capacity" label={t("admin.ev.fCapacity")} hint={t("admin.ev.fCapacityHint")}>{(p) => <Input {...p} type="number" min={1} inputMode="numeric" defaultValue={v.capacity} className="h-10" />}</Field>
          <Field name="waitlistEnabled" label={t("admin.ev.fWaitlist")}>{(p) => <input {...p} type="checkbox" defaultChecked={v.waitlistEnabled} className={CHECK} />}</Field>
        </div>
      </Section>

      <Section title={t("admin.ev.sectionPoints")}>
        <div className={grid}>
          <Field name="attendancePoints" label={t("admin.ev.fAttendancePoints")} required>{(p) => <Input {...p} type="number" min={0} max={10000} defaultValue={v.attendancePoints} className="h-10" />}</Field>
          <Field name="completionPoints" label={t("admin.ev.fCompletionPoints")} required>{(p) => <Input {...p} type="number" min={0} max={10000} defaultValue={v.completionPoints} className="h-10" />}</Field>
        </div>
        <Field name="certificateEnabled" label={t("admin.ev.fCertificate")}>{(p) => <input {...p} type="checkbox" defaultChecked={v.certificateEnabled} className={CHECK} />}</Field>
      </Section>

      <Section title={t("admin.ev.sectionSpeaker")}>
        <div className={grid}>
          <Field name="speakerName" label={t("admin.ev.fSpeakerName")}>{(p) => <Input {...p} defaultValue={v.speakerName} maxLength={120} className="h-10" />}</Field>
          <Field name="speakerTitle" label={t("admin.ev.fSpeakerTitle")}>{(p) => <Input {...p} defaultValue={v.speakerTitle} maxLength={160} className="h-10" />}</Field>
        </div>
        <Field name="speakerBio" label={t("admin.ev.fSpeakerBio")}>{(p) => <Textarea {...p} defaultValue={v.speakerBio} rows={3} maxLength={2000} />}</Field>
      </Section>

      <Section title={t("admin.ev.sectionAttendance")}>
        <div className={grid}>
          <Field name="rotatingQrEnabled" label={t("admin.ev.fRotating")}>{(p) => <input {...p} type="checkbox" defaultChecked={v.rotatingQrEnabled} className={CHECK} />}</Field>
          <Field name="qrRotateSeconds" label={t("admin.ev.fRotateSeconds")}>{(p) => <Input {...p} type="number" min={30} max={900} defaultValue={v.qrRotateSeconds} className="h-10" />}</Field>
        </div>
      </Section>
    </ActionForm>
  );
}
