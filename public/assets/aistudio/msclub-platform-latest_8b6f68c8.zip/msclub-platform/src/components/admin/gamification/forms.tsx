"use client";

import { ActionForm, Field, NATIVE_SELECT } from "@/components/admin/forms";
import { useT } from "@/components/i18n/locale-provider";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import type { ActionResult } from "@/lib/actions/admin";
import { ICON_NAMES } from "@/lib/icons";
import type { TranslationKey } from "@/lib/i18n";

type Act = (prev: ActionResult | undefined, fd: FormData) => Promise<ActionResult>;
const CHECK = "size-5 rounded border-input accent-[var(--color-primary)]";
const REFS = ["EVENT", "ATTENDANCE", "COURSE", "LESSON", "TASK", "SUBMISSION", "BADGE", "LEVEL", "ADMIN_ADJUSTMENT", "COMMUNITY"] as const;
const CRITERIA = ["total_xp", "level", "events_attended", "courses_completed", "lessons_completed", "tasks_approved", "certificates", "badges_count"] as const;

function IconSelect({ p, value }: { p: Record<string, unknown>; value: string }) {
  return (
    <select {...p} defaultValue={value} className={NATIVE_SELECT}>
      {ICON_NAMES.map((i) => <option key={i} value={i}>{i}</option>)}
    </select>
  );
}

export type RuleValues = { key: string; label: string; labelAr: string; activityType: string; points: number; maxAwardsPerUser: string; requiresApproval: boolean; enabled: boolean; referenceType: string };
export const EMPTY_RULE: RuleValues = { key: "", label: "", labelAr: "", activityType: "", points: 10, maxAwardsPerUser: "", requiresApproval: false, enabled: true, referenceType: "COMMUNITY" };

export function RuleForm({ action, values, isNew }: { action: Act; values: RuleValues; isNew: boolean }) {
  const t = useT();
  return (
    <ActionForm action={action} resetOnSuccess={isNew} successKey={isNew ? "admin.ui.created" : "admin.ui.saved"}>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {isNew ? <Field name="key" label={t("admin.pts.fKey")} hint={t("admin.pts.fKeyHint")} required>{(p) => <Input {...p} dir="ltr" maxLength={60} className="h-10" />}</Field> : null}
        <Field name="label" label={t("admin.pts.fLabel")} required>{(p) => <Input {...p} defaultValue={values.label} maxLength={120} className="h-10" />}</Field>
        <Field name="labelAr" label={t("admin.pts.fLabelAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.labelAr} maxLength={120} className="h-10" />}</Field>
        <Field name="activityType" label={t("admin.pts.fType")} required>{(p) => <Input {...p} defaultValue={values.activityType} maxLength={60} className="h-10" />}</Field>
        <Field name="points" label={t("admin.pts.fPoints")} required>{(p) => <Input {...p} type="number" min={-10000} max={10000} defaultValue={values.points} className="h-10" />}</Field>
        <Field name="maxAwardsPerUser" label={t("admin.pts.fMax")} hint={t("admin.pts.fMaxHint")}>{(p) => <Input {...p} type="number" min={1} defaultValue={values.maxAwardsPerUser} className="h-10" />}</Field>
        <Field name="referenceType" label={t("admin.pts.fReference")} required>{(p) => <select {...p} defaultValue={values.referenceType} className={NATIVE_SELECT}>{REFS.map((r) => <option key={r} value={r}>{r}</option>)}</select>}</Field>
        <Field name="requiresApproval" label={t("admin.pts.fApproval")}>{(p) => <input {...p} type="checkbox" defaultChecked={values.requiresApproval} className={CHECK} />}</Field>
        <Field name="enabled" label={t("admin.pts.fEnabled")}>{(p) => <input {...p} type="checkbox" defaultChecked={values.enabled} className={CHECK} />}</Field>
      </div>
    </ActionForm>
  );
}

/** Award / adjust forms carry a server-generated nonce so repeating a submission can never apply twice. */
export function AwardForm({ action, rules, nonce }: { action: Act; rules: { key: string; label: string; points: number }[]; nonce: string }) {
  const t = useT();
  return (
    <ActionForm action={action} submitLabel={t("admin.pts.award")} key={nonce} resetOnSuccess>
      <input type="hidden" name="nonce" value={nonce} />
      <Field name="email" label={t("admin.pts.memberEmail")} required>{(p) => <Input {...p} type="email" dir="ltr" className="h-10" />}</Field>
      <Field name="ruleKey" label={t("admin.pts.rule")} required>
        {(p) => (
          <select {...p} defaultValue="" className={NATIVE_SELECT}>
            <option value="" disabled>{t("admin.ui.selectPlaceholder")}</option>
            {rules.map((r) => <option key={r.key} value={r.key}>{r.label} ({r.points > 0 ? "+" : ""}{r.points})</option>)}
          </select>
        )}
      </Field>
    </ActionForm>
  );
}

export function AdjustForm({ action, nonce }: { action: Act; nonce: string }) {
  const t = useT();
  return (
    <ActionForm action={action} submitLabel={t("admin.pts.adjust")} key={nonce} resetOnSuccess>
      <input type="hidden" name="nonce" value={nonce} />
      <Field name="email" label={t("admin.pts.memberEmail")} required>{(p) => <Input {...p} type="email" dir="ltr" className="h-10" />}</Field>
      <Field name="amount" label={t("admin.pts.amount")} hint={t("admin.pts.amountHint")} required>{(p) => <Input {...p} type="number" min={-10000} max={10000} className="h-10" />}</Field>
      <Field name="reason" label={t("admin.pts.reason")} hint={t("admin.ui.reasonHint")} required>{(p) => <Textarea {...p} rows={2} maxLength={300} />}</Field>
    </ActionForm>
  );
}

export function ReverseDialog({ action }: { action: Act }) {
  const t = useT();
  return (
    <Dialog>
      <DialogTrigger asChild><Button type="button" variant="ghost" size="sm">{t("admin.pts.reverse")}</Button></DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>{t("admin.pts.reverseTitle")}</DialogTitle><DialogDescription>{t("admin.pts.reverseBody")}</DialogDescription></DialogHeader>
        <ActionForm action={action} submitLabel={t("admin.pts.reverse")}>
          <Field name="reason" label={t("admin.pts.reason")} hint={t("admin.ui.reasonHint")} required>{(p) => <Textarea {...p} rows={3} maxLength={300} />}</Field>
        </ActionForm>
      </DialogContent>
    </Dialog>
  );
}

export type LevelValues = { key: string; name: string; nameAr: string; minXp: number; description: string; descriptionAr: string; icon: string; color: string; rewards: string; enabled: boolean };
export const EMPTY_LEVEL: LevelValues = { key: "", name: "", nameAr: "", minXp: 0, description: "", descriptionAr: "", icon: "star", color: "#1B6AC4", rewards: "", enabled: true };

export function LevelForm({ action, values, isNew }: { action: Act; values: LevelValues; isNew: boolean }) {
  const t = useT();
  return (
    <ActionForm action={action} resetOnSuccess={isNew} successKey={isNew ? "admin.ui.created" : "admin.ui.saved"}>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {isNew ? <Field name="key" label={t("admin.lvl.fKey")} required>{(p) => <Input {...p} dir="ltr" maxLength={40} className="h-10" />}</Field> : null}
        <Field name="name" label={t("admin.lvl.fName")} required>{(p) => <Input {...p} defaultValue={values.name} maxLength={60} className="h-10" />}</Field>
        <Field name="nameAr" label={t("admin.lvl.fNameAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.nameAr} maxLength={60} className="h-10" />}</Field>
        <Field name="minXp" label={t("admin.lvl.fMinXp")} required>{(p) => <Input {...p} type="number" min={0} defaultValue={values.minXp} className="h-10" />}</Field>
        <Field name="icon" label={t("admin.lvl.fIcon")}>{(p) => <IconSelect p={p} value={values.icon} />}</Field>
        <Field name="color" label={t("admin.lvl.fColor")}>{(p) => <Input {...p} type="color" defaultValue={values.color} className="h-10 w-20 p-1" />}</Field>
        <Field name="description" label={t("admin.lvl.fDescription")}>{(p) => <Input {...p} defaultValue={values.description} maxLength={300} className="h-10" />}</Field>
        <Field name="descriptionAr" label={t("admin.lvl.fDescriptionAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.descriptionAr} maxLength={300} className="h-10" />}</Field>
        <Field name="enabled" label={t("admin.lvl.fEnabled")}>{(p) => <input {...p} type="checkbox" defaultChecked={values.enabled} className={CHECK} />}</Field>
      </div>
      <Field name="rewards" label={t("admin.lvl.fRewards")}>{(p) => <Textarea {...p} defaultValue={values.rewards} rows={2} maxLength={1000} />}</Field>
    </ActionForm>
  );
}

export type BadgeValues = { key: string; name: string; nameAr: string; description: string; descriptionAr: string; icon: string; color: string; tier: string; criteriaType: string; threshold: string; autoAward: boolean; enabled: boolean };
export const EMPTY_BADGE: BadgeValues = { key: "", name: "", nameAr: "", description: "", descriptionAr: "", icon: "award", color: "#1B6AC4", tier: "bronze", criteriaType: "manual", threshold: "", autoAward: true, enabled: true };

export function BadgeForm({ action, values, isNew }: { action: Act; values: BadgeValues; isNew: boolean }) {
  const t = useT();
  return (
    <ActionForm action={action} resetOnSuccess={isNew} successKey={isNew ? "admin.ui.created" : "admin.ui.saved"}>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {isNew ? <Field name="key" label={t("admin.bdg.fKey")} required>{(p) => <Input {...p} dir="ltr" maxLength={40} className="h-10" />}</Field> : null}
        <Field name="name" label={t("admin.bdg.fName")} required>{(p) => <Input {...p} defaultValue={values.name} maxLength={60} className="h-10" />}</Field>
        <Field name="nameAr" label={t("admin.bdg.fNameAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.nameAr} maxLength={60} className="h-10" />}</Field>
        <Field name="description" label={t("admin.bdg.fDescription")}>{(p) => <Input {...p} defaultValue={values.description} maxLength={300} className="h-10" />}</Field>
        <Field name="descriptionAr" label={t("admin.bdg.fDescriptionAr")}>{(p) => <Input {...p} dir="rtl" defaultValue={values.descriptionAr} maxLength={300} className="h-10" />}</Field>
        <Field name="icon" label={t("admin.bdg.fIcon")}>{(p) => <IconSelect p={p} value={values.icon} />}</Field>
        <Field name="color" label={t("admin.bdg.fColor")}>{(p) => <Input {...p} type="color" defaultValue={values.color} className="h-10 w-20 p-1" />}</Field>
        <Field name="tier" label={t("admin.bdg.fTier")}>{(p) => <select {...p} defaultValue={values.tier} className={NATIVE_SELECT}>{(["bronze", "silver", "gold", "platinum"] as const).map((x) => <option key={x} value={x}>{t(`admin.bdg.tiers.${x}` as TranslationKey)}</option>)}</select>}</Field>
        <Field name="criteriaType" label={t("admin.bdg.fCriteria")}>
          {(p) => (
            <select {...p} defaultValue={values.criteriaType} className={NATIVE_SELECT}>
              <option value="manual">{t("admin.bdg.manualOnly")}</option>
              {CRITERIA.map((c) => <option key={c} value={c}>{t(`admin.bdg.criteria.${c}` as TranslationKey)}</option>)}
            </select>
          )}
        </Field>
        <Field name="threshold" label={t("admin.bdg.fThreshold")}>{(p) => <Input {...p} type="number" min={1} defaultValue={values.threshold} className="h-10" />}</Field>
        <Field name="autoAward" label={t("admin.bdg.fAuto")}>{(p) => <input {...p} type="checkbox" defaultChecked={values.autoAward} className={CHECK} />}</Field>
        <Field name="enabled" label={t("admin.bdg.fEnabled")}>{(p) => <input {...p} type="checkbox" defaultChecked={values.enabled} className={CHECK} />}</Field>
      </div>
    </ActionForm>
  );
}

export function BadgeHolderForm({ action, badges, submitLabel }: { action: Act; badges: { id: string; name: string }[]; submitLabel: string }) {
  const t = useT();
  return (
    <ActionForm action={action} submitLabel={submitLabel} resetOnSuccess className="flex flex-wrap items-end gap-3 space-y-0">
      <Field name="email" label={t("admin.pts.memberEmail")} required>{(p) => <Input {...p} type="email" dir="ltr" className="h-10 w-64 max-w-full" />}</Field>
      <Field name="badgeId" label={t("admin.bdg.badge")} required>
        {(p) => (
          <select {...p} defaultValue="" className={`${NATIVE_SELECT} w-56`}>
            <option value="" disabled>{t("admin.ui.selectPlaceholder")}</option>
            {badges.map((b) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        )}
      </Field>
    </ActionForm>
  );
}
