import Link from "next/link";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { cn } from "@/lib/utils";

export type Column<T> = { header: React.ReactNode; cell: (row: T) => React.ReactNode; className?: string };

/** Responsive, accessible table. Wide tables scroll inside their own container. */
export function DataTable<T extends { id: string }>({
  columns, rows, empty, caption,
}: {
  columns: Column<T>[];
  rows: T[];
  empty: React.ReactNode;
  caption?: string;
}) {
  if (rows.length === 0) return <>{empty}</>;
  return (
    <div className="overflow-x-auto rounded-xl bg-card ring-1 ring-foreground/10">
      <Table>
        {caption ? <caption className="sr-only">{caption}</caption> : null}
        <TableHeader>
          <TableRow>
            {columns.map((c, i) => (
              <TableHead key={i} className={cn("whitespace-nowrap", c.className)}>{c.header}</TableHead>
            ))}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              {columns.map((c, i) => (
                <TableCell key={i} className={c.className}>{c.cell(row)}</TableCell>
              ))}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

export const PAGE_SIZE = 20;

export function parsePage(value: string | string[] | undefined) {
  const raw = Array.isArray(value) ? value[0] : value;
  return Math.max(1, Math.min(10_000, Number.parseInt(raw ?? "1", 10) || 1));
}

/** Prev/next links that preserve every other query parameter. */
export function Pagination({
  page, pages, total, basePath, params, labels,
}: {
  page: number; pages: number; total: number; basePath: string;
  params: Record<string, string | undefined>;
  labels: { previous: string; next: string; summary: string };
}) {
  if (pages <= 1) return <p className="text-xs text-muted-foreground">{labels.summary}</p>;
  const href = (p: number) => {
    const q = new URLSearchParams();
    for (const [k, v] of Object.entries(params)) if (v) q.set(k, v);
    if (p > 1) q.set("page", String(p));
    const s = q.toString();
    return s ? `${basePath}?${s}` : basePath;
  };
  const btn = "inline-flex h-8 items-center rounded-lg px-3 text-sm ring-1 ring-foreground/10 bg-card hover:ring-primary/40";
  void total;
  return (
    <nav className="flex items-center justify-between gap-3" aria-label="Pagination">
      <p className="text-xs text-muted-foreground">{labels.summary}</p>
      <div className="flex items-center gap-2">
        {page > 1 ? <Link href={href(page - 1)} rel="prev" className={btn}>{labels.previous}</Link> : null}
        {page < pages ? <Link href={href(page + 1)} rel="next" className={btn}>{labels.next}</Link> : null}
      </div>
    </nav>
  );
}
