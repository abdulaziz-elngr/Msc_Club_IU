"use client";

import QRCode from "qrcode";
import { useEffect, useState } from "react";
import { useT } from "@/components/i18n/locale-provider";

/** Venue screen: fetches a fresh rotating code on a timer and renders it as a QR. */
export function RotatingQr({ eventId }: { eventId: string }) {
  const t = useT();
  const [img, setImg] = useState<string | null>(null);
  const [left, setLeft] = useState(0);
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    let alive = true;
    let timer: ReturnType<typeof setTimeout>;
    const tick = setInterval(() => setLeft((s) => Math.max(0, s - 1)), 1000);

    async function refresh() {
      try {
        const res = await fetch(`/api/events/${eventId}/rotating-token`, { cache: "no-store" });
        if (!res.ok) throw new Error(String(res.status));
        const { token, seconds } = (await res.json()) as { token: string; seconds: number };
        const url = `${window.location.origin}/dashboard/events/checkin?e=${encodeURIComponent(eventId)}&c=${encodeURIComponent(token)}`;
        const data = await QRCode.toDataURL(url, { errorCorrectionLevel: "M", margin: 2, width: 420, color: { dark: "#0B2545", light: "#FFFFFF" } });
        if (!alive) return;
        setImg(data); setLeft(seconds); setFailed(false);
        // Refresh a little before the code expires so the screen never shows a dead code.
        timer = setTimeout(refresh, Math.max(10, seconds - 5) * 1000);
      } catch {
        if (!alive) return;
        setFailed(true);
        timer = setTimeout(refresh, 8000);
      }
    }
    refresh();
    return () => { alive = false; clearTimeout(timer); clearInterval(tick); };
  }, [eventId]);

  return (
    <div className="flex flex-col items-center gap-3 text-center">
      {img ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={img} alt={t("admin.ev.rotatingTitle")} className="size-72 max-w-full rounded-xl bg-white p-2 ring-1 ring-foreground/10 sm:size-96" />
      ) : (
        <div className="size-72 animate-pulse rounded-xl bg-muted sm:size-96" />
      )}
      <p className="text-sm text-muted-foreground" aria-live="off">
        {failed ? t("admin.ev.rotatingOff") : img ? t("admin.ev.rotatingExpires", { seconds: left }) : t("common.loading")}
      </p>
    </div>
  );
}
