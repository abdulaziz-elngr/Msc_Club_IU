import { addTeamMemberAction, removeTeamMemberAction } from "@/app/actions/admin-teams";
import { ActionForm, ConfirmAction, Field } from "@/components/admin/forms";
import { DataTable } from "@/components/admin/table";
import { PageHeader } from "@/components/shared/page-header";
import { Input } from "@/components/ui/input";
import { ForbiddenError } from "@/lib/auth/dal";
import { formatNumber } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getTeamMembers } from "@/lib/queries/team";
import { authorizeTeam } from "@/lib/teams-admin";
import { loadTeamForUser } from "@/lib/team-access";

export const dynamic = "force-dynamic";

export default async function TeamMembersPage({ params }: { params: Promise<{ slug: string }> }) {
  const { team, ctx } = await loadTeamForUser((await params).slug);
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const members = await getTeamMembers(team.id);

  let canManage = true;
  try { authorizeTeam(ctx, team.id, "manage_members"); } catch (e) { if (e instanceof ForbiddenError) canManage = false; else throw e; }

  return (
    <>
      <PageHeader title={t("admin.teamArea.members")} />
      <DataTable
        rows={members.map((m) => ({ id: m.user.id, ...m }))}
        empty={<p className="text-sm text-muted-foreground">{t("admin.teamArea.noMembers")}</p>}
        columns={[
          { header: t("common.name"), cell: (m) => <span className="font-medium">{m.user.name}</span> },
          { header: t("admin.team.role"), cell: (m) => t(`admin.team.roles.${m.role}` as TranslationKey) },
          { header: t("admin.mem.colLevel"), cell: (m) => (m.user.level ? (locale === "ar" && m.user.level.nameAr ? m.user.level.nameAr : m.user.level.name) : "—") },
          { header: "XP", className: "tabular-nums", cell: (m) => formatNumber(m.user.totalXp, locale) },
          { header: t("common.actions"), cell: (m) => (canManage && m.role === "MEMBER" ? <ConfirmAction variant="ghost" label={t("admin.team.remove")} title={t("admin.team.removeTitle")} action={removeTeamMemberAction.bind(null, team.id, m.user.id)} /> : null) },
        ]}
      />
      {canManage && team.status === "ACTIVE" ? (
        <ActionForm action={addTeamMemberAction.bind(null, team.id)} submitLabel={t("admin.team.addMember")} className="flex flex-wrap items-end gap-3 space-y-0" resetOnSuccess>
          <Field name="email" label={t("admin.team.memberEmail")} required>{(p) => <Input {...p} type="email" dir="ltr" className="h-10 w-72 max-w-full" />}</Field>
        </ActionForm>
      ) : null}
    </>
  );
}
