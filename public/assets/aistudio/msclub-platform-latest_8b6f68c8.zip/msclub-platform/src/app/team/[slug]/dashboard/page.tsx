import Link from "next/link";
import { CalendarCheck, ListChecks, Users, Zap } from "lucide-react";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { formatDateTime, formatNumber } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getTeamOverview } from "@/lib/queries/team";
import { loadTeamForUser } from "@/lib/team-access";

export const dynamic = "force-dynamic";

export default async function TeamDashboardPage({ params }: { params: Promise<{ slug: string }> }) {
  const { team, ctx } = await loadTeamForUser((await params).slug);
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const o = await getTeamOverview(team.id);

  return (
    <>
      <PageHeader title={locale === "ar" && team.nameAr ? team.nameAr : team.name} description={t("admin.teamArea.title")} />
      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label={t("admin.teamArea.memberCount")} value={formatNumber(o.members, locale)} icon={Users} tone="brand" />
        <StatCard label={t("admin.teamArea.xpTotal")} value={formatNumber(o.xp, locale)} icon={Zap} tone="brand" />
        <StatCard label={t("admin.teamArea.openTasks")} value={formatNumber(o.openTasks, locale)} icon={ListChecks} tone={o.openTasks > 0 ? "warning" : "neutral"} />
      </div>
      <section className="space-y-3">
        <SectionHeading title={t("admin.teamArea.upcomingEvents")} />
        {o.upcoming.length === 0 ? <p className="text-sm text-muted-foreground">{t("admin.teamArea.noEvents")}</p> : (
          <ul className="divide-y rounded-xl bg-card ring-1 ring-foreground/10">
            {o.upcoming.map((e) => (
              <li key={e.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <Link href={`/events/${e.slug}`} className="flex min-w-0 items-center gap-2 text-sm font-medium hover:text-primary"><CalendarCheck className="size-4 shrink-0 text-primary" aria-hidden /><span className="truncate">{locale === "ar" && e.titleAr ? e.titleAr : e.title}</span></Link>
                <span className="shrink-0 text-xs text-muted-foreground">{formatDateTime(e.startsAt, locale)}</span>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
