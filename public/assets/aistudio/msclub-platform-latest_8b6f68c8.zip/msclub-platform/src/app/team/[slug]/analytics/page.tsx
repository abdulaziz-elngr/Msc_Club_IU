import { Percent, Trophy } from "lucide-react";
import { BarsChart } from "@/components/admin/charts";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { formatMonthYear, formatNumber, formatPercent } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getTeamAnalytics } from "@/lib/queries/team";
import { loadTeamForUser } from "@/lib/team-access";

export const dynamic = "force-dynamic";

export default async function TeamAnalyticsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { team, ctx } = await loadTeamForUser((await params).slug);
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const a = await getTeamAnalytics(team.id);

  return (
    <>
      <PageHeader title={t("admin.teamArea.analytics")} />
      <div className="grid gap-4 sm:grid-cols-2">
        <StatCard label={t("admin.teamArea.attendanceRate")} value={a.attendanceRate === null ? "—" : formatPercent(a.attendanceRate, locale)} icon={Percent} tone="success" />
        <StatCard label={t("admin.teamArea.tasksApproved")} value={formatNumber(a.approved, locale)} icon={Trophy} tone="brand" />
      </div>
      <section className="space-y-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
        <SectionHeading as="h3" title={t("admin.teamArea.xpPerMonth")} />
        <BarsChart emptyLabel={t("admin.charts.noData")} series={[{ key: "xp", label: t("admin.teamArea.xpSeries"), color: "var(--primary)" }]} data={a.series.map((s) => ({ label: formatMonthYear(s.date, locale), xp: s.xp }))} />
      </section>
      <section className="space-y-3">
        <SectionHeading title={t("admin.teamArea.topMembers")} />
        <ol className="divide-y rounded-xl bg-card ring-1 ring-foreground/10">
          {a.top.map((m, i) => (
            <li key={m.id} className="flex items-center justify-between gap-3 px-4 py-3 text-sm"><span><span className="me-3 tabular-nums text-muted-foreground">{i + 1}</span>{m.name}</span><span className="tabular-nums font-medium">{formatNumber(m.totalXp, locale)} XP</span></li>
          ))}
          {a.top.length === 0 ? <li className="px-4 py-3 text-sm text-muted-foreground">{t("admin.teamArea.noMembers")}</li> : null}
        </ol>
      </section>
    </>
  );
}
