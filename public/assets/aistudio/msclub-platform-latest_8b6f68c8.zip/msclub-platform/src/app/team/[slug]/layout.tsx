import { AppShell, type ShellNavItem } from "@/components/shell/app-shell";
import { loadTeamForUser } from "@/lib/team-access";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { unreadCount } from "@/lib/notifications";

export const dynamic = "force-dynamic";

export default async function TeamLayout({ children, params }: { children: React.ReactNode; params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const { team, ctx } = await loadTeamForUser(slug);
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const base = `/team/${team.slug}`;
  const nav: ShellNavItem[] = [
    { href: `${base}/dashboard`, label: t("admin.teamArea.dashboard"), icon: "dashboard", exact: true },
    { href: `${base}/members`, label: t("admin.teamArea.members"), icon: "members" },
    { href: `${base}/tasks`, label: t("admin.teamArea.tasks"), icon: "tasks" },
    { href: `${base}/learning`, label: t("admin.teamArea.learning"), icon: "learning" },
    { href: `${base}/analytics`, label: t("admin.teamArea.analytics"), icon: "analytics" },
  ];

  return (
    <AppShell
      nav={nav}
      areaLabel={locale === "ar" && team.nameAr ? team.nameAr : team.name}
      user={{ name: ctx.name, email: ctx.email, image: ctx.image }}
      unreadCount={await unreadCount(ctx.userId)}
      notificationsHref="/dashboard/notifications"
      crossLink={{ href: "/dashboard", label: t("dashboard.portalTitle") }}
    >
      {children}
    </AppShell>
  );
}
