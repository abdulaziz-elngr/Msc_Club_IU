import Link from "next/link";
import type { Metadata } from "next";
import { Award, CalendarCheck, GraduationCap, Zap } from "lucide-react";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { buttonVariants } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { requireAuth } from "@/lib/auth/dal";
import { formatDateTime, formatNumber } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getMemberOverview } from "@/lib/queries/member";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("dashboard.overview") };
}

export default async function DashboardPage() {
  const ctx = await requireAuth("/dashboard");
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const data = await getMemberOverview(ctx.userId);

  const levelName = data.user.level ? (locale === "ar" && data.user.level.nameAr ? data.user.level.nameAr : data.user.level.name) : null;
  const nextName = data.next ? (locale === "ar" && data.next.nameAr ? data.next.nameAr : data.next.name) : null;
  const floor = data.user.level?.minXp ?? 0;
  const pct = data.next ? Math.min(100, Math.round(((data.user.totalXp - floor) / Math.max(1, data.next.minXp - floor)) * 100)) : 100;

  return (
    <>
      <PageHeader
        title={t("dashboard.welcome", { name: ctx.name.split(" ")[0] ?? ctx.name })}
        description={data.rank ? t("dashboard.rank", { rank: data.rank }) : undefined}
      />

      <section aria-label={t("dashboard.yourLevel")} className="rounded-xl bg-card p-5 ring-1 ring-foreground/10">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-xs text-muted-foreground">{t("dashboard.yourLevel")}</p>
            <p className="text-xl font-semibold">{levelName ?? "—"}</p>
          </div>
          <p className="text-2xl font-semibold tabular-nums">
            {formatNumber(data.user.totalXp, locale)} <span className="text-sm font-normal text-muted-foreground">XP</span>
          </p>
        </div>
        <Progress value={pct} className="mt-4" aria-label={t("dashboard.yourLevel")} />
        <p className="mt-2 text-xs text-muted-foreground">
          {data.next && nextName
            ? t("dashboard.nextLevel", { xp: formatNumber(data.next.minXp - data.user.totalXp, locale), level: nextName })
            : t("dashboard.topLevel")}
        </p>
      </section>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label={t("dashboard.xpEarned")} value={formatNumber(data.user.totalXp, locale)} icon={Zap} />
        <StatCard label={t("dashboard.eventsAttended")} value={formatNumber(data.attended, locale)} icon={CalendarCheck} />
        <StatCard label={t("dashboard.coursesCompleted")} value={formatNumber(data.coursesDone, locale)} icon={GraduationCap} />
        <StatCard label={t("dashboard.badgesEarned")} value={formatNumber(data.badges, locale)} icon={Award} />
      </div>

      <section className="space-y-3">
        <SectionHeading
          title={t("dashboard.upcomingEvents")}
          actions={<Link href="/dashboard/events" className="text-sm font-medium text-primary hover:underline">{t("common.viewAll")}</Link>}
        />
        {data.upcoming.length === 0 ? (
          <EmptyState size="compact" icon={CalendarCheck} title={t("dashboard.noUpcoming")} action={<Link href="/events" className={buttonVariants({ size: "sm" })}>{t("dashboard.browseEvents")}</Link>} />
        ) : (
          <ul className="divide-y rounded-xl bg-card ring-1 ring-foreground/10">
            {data.upcoming.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <div className="min-w-0">
                  <Link href={`/events/${r.event.slug}`} className="block truncate text-sm font-medium hover:text-primary">
                    {locale === "ar" && r.event.titleAr ? r.event.titleAr : r.event.title}
                  </Link>
                  <p className="text-xs text-muted-foreground">{formatDateTime(r.event.startsAt, locale)}</p>
                </div>
                <span className="shrink-0 rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">{t(`statuses.${r.status}` as "statuses.CONFIRMED")}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="space-y-3">
        <SectionHeading title={t("dashboard.yourTeams")} />
        {data.teams.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("dashboard.noTeams")}</p>
        ) : (
          <ul className="flex flex-wrap gap-2">
            {data.teams.map((m) => (
              <li key={m.team.slug}>
                <Link href={`/team/${m.team.slug}/dashboard`} className="inline-flex rounded-full bg-card px-3.5 py-1.5 text-sm font-medium ring-1 ring-foreground/10 hover:ring-primary/40">
                  {locale === "ar" && m.team.nameAr ? m.team.nameAr : m.team.name}
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </>
  );
}
