import { redirect } from "next/navigation";
import { AppShell, type ShellNavItem } from "@/components/shell/app-shell";
import { can, requireAuth } from "@/lib/auth/dal";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { unreadCount } from "@/lib/notifications";

export const dynamic = "force-dynamic";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  // Authoritative check — the proxy only did an optimistic cookie test.
  const ctx = await requireAuth("/dashboard");
  if (ctx.status === "UNVERIFIED") redirect("/verify-email");

  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const nav: ShellNavItem[] = [
    { href: "/dashboard", label: t("dashboard.nav.overview"), icon: "dashboard", exact: true },
    { href: "/dashboard/events", label: t("dashboard.nav.events"), icon: "events" },
    { href: "/dashboard/learning", label: t("dashboard.nav.learning"), icon: "learning" },
    { href: "/dashboard/tasks", label: t("dashboard.nav.tasks"), icon: "tasks" },
    { href: "/dashboard/points", label: t("dashboard.nav.points"), icon: "points" },
    { href: "/dashboard/achievements", label: t("dashboard.nav.achievements"), icon: "achievements" },
    { href: "/dashboard/certificates", label: t("dashboard.nav.certificates"), icon: "certificates" },
    { href: "/dashboard/notifications", label: t("dashboard.nav.notifications"), icon: "notifications" },
    { href: "/dashboard/profile", label: t("dashboard.nav.profile"), icon: "profile" },
  ];

  return (
    <AppShell
      nav={nav}
      areaLabel={t("dashboard.portalTitle")}
      user={{ name: ctx.name, email: ctx.email, image: ctx.image }}
      unreadCount={await unreadCount(ctx.userId)}
      notificationsHref="/dashboard/notifications"
      crossLink={can(ctx, "admin.dashboard") ? { href: "/admin", label: t("dashboard.adminArea") } : undefined}
    >
      {ctx.status !== "ACTIVE" ? (
        <div role="status" className="rounded-xl border border-warning-500/30 bg-warning-50 p-4 text-sm text-warning-700 dark:bg-warning-500/10 dark:text-warning-500">
          <p className="font-semibold">{t("dashboard.notActiveTitle")}</p>
          <p>{t("dashboard.notActiveBody")}</p>
        </div>
      ) : null}
      {children}
    </AppShell>
  );
}
