import { notFound } from "next/navigation";
import { SelfCheckIn } from "@/components/events/self-check-in";
import { PageHeader } from "@/components/shared/page-header";
import { requireAuth } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";
type SP = Promise<Record<string, string | string[] | undefined>>;
const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

/** Landing page for the venue's rotating QR. Nothing is written until the member confirms (POST). */
export default async function SelfCheckInPage({ searchParams }: { searchParams: SP }) {
  const sp = await searchParams;
  const eventId = recordId.safeParse(one(sp.e));
  const code = one(sp.c);
  const here = `/dashboard/events/checkin?e=${encodeURIComponent(one(sp.e) ?? "")}&c=${encodeURIComponent(code ?? "")}`;
  const ctx = await requireAuth(here);
  if (!eventId.success || !code || code.length > 100) notFound();

  const event = await db.event.findUnique({ where: { id: eventId.data }, select: { id: true, title: true, titleAr: true } });
  if (!event) notFound();
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  return (
    <div className="mx-auto max-w-md space-y-6">
      <PageHeader title={t("admin.scan.selfTitle")} description={t("admin.scan.selfBody")} />
      <section className="space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
        <p className="text-base font-semibold">{locale === "ar" && event.titleAr ? event.titleAr : event.title}</p>
        <SelfCheckIn eventId={event.id} code={code} />
      </section>
    </div>
  );
}
