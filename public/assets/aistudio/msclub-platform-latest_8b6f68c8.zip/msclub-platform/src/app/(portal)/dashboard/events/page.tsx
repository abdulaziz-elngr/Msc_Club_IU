import Link from "next/link";
import type { Metadata } from "next";
import { CalendarCheck, CheckCircle2 } from "lucide-react";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { buttonVariants } from "@/components/ui/button";
import { requireAuth } from "@/lib/auth/dal";
import { formatDateTime } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getMyRegistrations } from "@/lib/queries/member";
import { passQrDataUrl } from "@/lib/qr-image";
import { waitlistRank } from "@/lib/registration";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("dashboard.nav.events") };
}

export default async function MyEventsPage() {
  const ctx = await requireAuth("/dashboard/events");
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const registrations = await getMyRegistrations(ctx.userId);
  const now = new Date();
  const upcoming = registrations.filter((r) => r.event.endsAt >= now && r.event.status !== "CANCELLED");
  const past = registrations.filter((r) => !upcoming.includes(r));

  // Passes are generated for the signed-in member's own CONFIRMED registrations only.
  const cards = await Promise.all(
    upcoming.map(async (r) => ({
      r,
      qr: r.status === "CONFIRMED" ? await passQrDataUrl(r.id, r.qrVersion) : null,
      position: r.status === "WAITLISTED" ? await waitlistRank(r.event.id, ctx.userId) : null,
    })),
  );

  return (
    <>
      <PageHeader title={t("events.myRegistrations")} description={t("events.qrHint")} />

      {cards.length === 0 ? (
        <EmptyState
          icon={CalendarCheck}
          title={t("events.noRegistrations")}
          action={<Link href="/events" className={buttonVariants({ size: "sm" })}>{t("dashboard.browseEvents")}</Link>}
        />
      ) : (
        <ul className="grid gap-5 md:grid-cols-2">
          {cards.map(({ r, qr, position }) => {
            const title = locale === "ar" && r.event.titleAr ? r.event.titleAr : r.event.title;
            return (
              <li key={r.id} className="flex flex-col items-center gap-4 rounded-xl bg-card p-5 text-center ring-1 ring-foreground/10">
                <div className="space-y-1">
                  <Link href={`/events/${r.event.slug}`} className="text-base font-semibold hover:text-primary">{title}</Link>
                  <p className="text-xs text-muted-foreground">{formatDateTime(r.event.startsAt, locale)}</p>
                </div>

                {qr ? (
                  <>
                    {/* White tile keeps the code scannable in dark mode. */}
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img src={qr} alt={t("events.passFor", { event: title })} width={224} height={224} className="size-56 rounded-lg bg-white p-1 ring-1 ring-foreground/10" />
                    <p className="max-w-xs text-xs text-muted-foreground">{t("events.qrHint")}</p>
                  </>
                ) : (
                  <p className="rounded-lg bg-muted px-3 py-6 text-sm text-muted-foreground">
                    {position ? t("events.waitlistPosition", { position }) : t("events.passUnavailable")}
                  </p>
                )}

                {r.checkedInAt ? (
                  <p className="inline-flex items-center gap-1.5 text-xs font-medium text-success-700 dark:text-success-500">
                    <CheckCircle2 className="size-4" aria-hidden /> {t("events.checkedIn")}
                  </p>
                ) : (
                  <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">{t(`statuses.${r.status}` as "statuses.CONFIRMED")}</span>
                )}
              </li>
            );
          })}
        </ul>
      )}

      {past.length > 0 ? (
        <section className="space-y-3">
          <h2 className="text-lg font-semibold">{t("dashboard.pastRegistrations")}</h2>
          <ul className="divide-y rounded-xl bg-card ring-1 ring-foreground/10">
            {past.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 px-4 py-3">
                <Link href={`/events/${r.event.slug}`} className="truncate text-sm font-medium hover:text-primary">
                  {locale === "ar" && r.event.titleAr ? r.event.titleAr : r.event.title}
                </Link>
                <span className="shrink-0 text-xs text-muted-foreground">{formatDateTime(r.event.startsAt, locale)}</span>
              </li>
            ))}
          </ul>
        </section>
      ) : null}
    </>
  );
}
