import { NextResponse } from "next/server";
import { ForbiddenError, assertPermission, getAuthContext } from "@/lib/auth/dal";
import { issueRotatingToken } from "@/lib/attendance";
import { db } from "@/lib/db";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";

/** Current rotating check-in code for the venue screen. Staff only. */
export async function GET(_req: Request, { params }: { params: Promise<{ id: string }> }) {
  const ctx = await getAuthContext();
  if (!ctx) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  try {
    assertPermission(ctx, "events.manage_attendance");
  } catch (e) {
    if (e instanceof ForbiddenError) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
    throw e;
  }
  const id = recordId.safeParse((await params).id);
  if (!id.success) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });
  if (!rateLimit(clientKey("rotating-token", ctx.userId), 120, 60_000).ok) {
    return NextResponse.json({ error: "RATE_LIMITED" }, { status: 429 });
  }

  const issued = await issueRotatingToken(id.data);
  if (!issued) return NextResponse.json({ error: "DISABLED" }, { status: 409 });
  const event = await db.event.findUnique({ where: { id: id.data }, select: { qrRotateSeconds: true } });
  return NextResponse.json(
    { token: issued.token, expiresAt: issued.expiresAt.toISOString(), seconds: event?.qrRotateSeconds ?? 120 },
    { headers: { "Cache-Control": "no-store" } },
  );
}
