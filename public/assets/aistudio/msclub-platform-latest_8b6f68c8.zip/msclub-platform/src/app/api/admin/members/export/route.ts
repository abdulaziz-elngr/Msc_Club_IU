import { NextResponse } from "next/server";
import { ForbiddenError, assertPermission, getAuthContext } from "@/lib/auth/dal";
import { logAudit } from "@/lib/audit";
import { toCsv } from "@/lib/csv";
import { db } from "@/lib/db";

export const dynamic = "force-dynamic";

/** Members CSV. Requires `members.export`; exports are audited. */
export async function GET() {
  const ctx = await getAuthContext();
  if (!ctx) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  try {
    assertPermission(ctx, "members.export");
  } catch (e) {
    if (e instanceof ForbiddenError) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
    throw e;
  }
  const users = await db.user.findMany({
    where: { status: { in: ["ACTIVE", "SUSPENDED", "ARCHIVED"] } },
    orderBy: { name: "asc" },
    select: { name: true, email: true, studentId: true, department: true, status: true, totalXp: true, joinedAt: true, level: { select: { name: true } } },
  });
  await logAudit({ actorId: ctx.userId, action: "members.export", entityType: "User", after: { count: users.length } });
  const csv = toCsv(
    ["Name", "Email", "Student ID", "Department", "Status", "Level", "XP", "Joined"],
    users.map((u) => [u.name, u.email, u.studentId ?? "", u.department ?? "", u.status, u.level?.name ?? "", u.totalXp, u.joinedAt]),
  );
  return new NextResponse(csv, { headers: { "Content-Type": "text/csv; charset=utf-8", "Content-Disposition": 'attachment; filename="members.csv"', "Cache-Control": "no-store" } });
}
