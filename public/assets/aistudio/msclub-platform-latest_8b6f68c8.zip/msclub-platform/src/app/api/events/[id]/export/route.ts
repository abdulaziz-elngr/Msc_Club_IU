import { NextResponse } from "next/server";
import { ForbiddenError, assertPermission, getAuthContext } from "@/lib/auth/dal";
import { exportAttendanceCsv } from "@/lib/attendance";
import { logAudit } from "@/lib/audit";
import { toCsv } from "@/lib/csv";
import { db } from "@/lib/db";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";

/** CSV exports: `?type=registrations` (with custom-field answers) or `?type=attendance`. */
export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  const ctx = await getAuthContext();
  if (!ctx) return NextResponse.json({ error: "UNAUTHENTICATED" }, { status: 401 });
  try {
    assertPermission(ctx, "events.export_registrations");
  } catch (e) {
    if (e instanceof ForbiddenError) return NextResponse.json({ error: "FORBIDDEN" }, { status: 403 });
    throw e;
  }
  const id = recordId.safeParse((await params).id);
  if (!id.success) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });

  const event = await db.event.findUnique({
    where: { id: id.data },
    select: { slug: true, formFields: { orderBy: { order: "asc" }, select: { key: true, label: true } } },
  });
  if (!event) return NextResponse.json({ error: "NOT_FOUND" }, { status: 404 });

  const type = new URL(req.url).searchParams.get("type") === "attendance" ? "attendance" : "registrations";
  let csv: string;
  if (type === "attendance") {
    csv = await exportAttendanceCsv(id.data);
  } else {
    const regs = await db.eventRegistration.findMany({
      where: { eventId: id.data },
      orderBy: { createdAt: "asc" },
      include: { user: { select: { name: true, email: true, studentId: true } } },
    });
    csv = toCsv(
      ["Name", "Email", "Student ID", "Status", "Waitlist position", "Registered at", ...event.formFields.map((f) => f.label)],
      regs.map((r) => {
        const answers = (r.answers ?? {}) as Record<string, unknown>;
        return [r.user.name, r.user.email, r.user.studentId ?? "", r.status, r.waitlistPos ?? "", r.createdAt, ...event.formFields.map((f) => answers[f.key] ?? "")];
      }),
    );
  }

  await logAudit({ actorId: ctx.userId, action: `event.export.${type}`, entityType: "Event", entityId: id.data });
  return new NextResponse(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${event.slug}-${type}.csv"`,
      "Cache-Control": "no-store",
    },
  });
}
