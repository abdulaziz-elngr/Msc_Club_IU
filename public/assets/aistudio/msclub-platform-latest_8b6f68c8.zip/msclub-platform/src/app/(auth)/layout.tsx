import Link from "next/link";
import { ClubLogo } from "@/components/brand/logo";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

/**
 * Shared chrome for every authentication route: brand lockup, a single
 * framed panel, and no site navigation so the task stays focused.
 */
export default async function AuthLayout({ children }: { children: React.ReactNode }) {
  const locale = await resolveLocale();
  const t = getTranslations(locale);

  return (
    <div className="relative flex min-h-dvh flex-col">
      <div className="hero-grid hero-grid-anim pointer-events-none absolute inset-x-0 top-0 h-72 opacity-60" aria-hidden />

      <header className="relative z-10 mx-auto flex w-full max-w-7xl items-center justify-between px-4 py-5 sm:px-6">
        <Link
          href="/"
          className="rounded-md outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label={`${t("common.appName")} — ${t("common.tagline")}`}
        >
          <ClubLogo variant="inline" size={34} href={null} />
        </Link>
        <Link
          href="/"
          className="text-sm font-medium text-muted-foreground transition-colors hover:text-foreground"
        >
          {t("nav.home")}
        </Link>
      </header>

      <main
        id="main-content"
        className="relative z-10 mx-auto flex w-full max-w-md flex-1 flex-col justify-center px-4 pb-16 sm:px-6"
      >
        <div className="rounded-2xl bg-card p-6 ring-1 ring-foreground/10 elevation-2 sm:p-8">
          {children}
        </div>
        <p className="mt-6 text-center text-xs text-muted-foreground">
          © {new Date().getFullYear()} {t("common.appName")} — {t("common.tagline")}
        </p>
      </main>
    </div>
  );
}
