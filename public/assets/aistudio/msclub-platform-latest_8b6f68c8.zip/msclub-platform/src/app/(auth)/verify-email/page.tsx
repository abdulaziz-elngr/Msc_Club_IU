import type { Metadata } from "next";
import { VerifyEmailPanel } from "@/components/auth/verify-email-panel";

export const metadata: Metadata = { title: "Verify your email" };

type SearchParams = Promise<{ token?: string; email?: string }>;

export default async function VerifyEmailPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  return <VerifyEmailPanel token={params.token} email={params.email} />;
}
