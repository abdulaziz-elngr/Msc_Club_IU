import type { Metadata } from "next";
import { ResetPasswordForm } from "@/components/auth/reset-password-form";

export const metadata: Metadata = { title: "Choose a new password" };

type SearchParams = Promise<{ token?: string; email?: string }>;

export default async function ResetPasswordPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;

  if (!params.token) {
    return (
      <div className="space-y-4 text-center">
        <h1 className="text-xl font-semibold tracking-tight">Invalid reset link</h1>
        <p className="text-sm text-muted-foreground">
          This password reset link is incomplete. Request a new one to continue.
        </p>
        <a
          href="/forgot-password"
          className="inline-flex h-8 items-center justify-center rounded-lg bg-primary px-3.5 text-sm font-medium text-primary-foreground"
        >
          Request a new link
        </a>
      </div>
    );
  }

  return <ResetPasswordForm token={params.token} email={params.email} />;
}
