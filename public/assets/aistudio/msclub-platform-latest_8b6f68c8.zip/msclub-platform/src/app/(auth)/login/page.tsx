import type { Metadata } from "next";
import { LoginForm } from "@/components/auth/login-form";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const metadata: Metadata = { title: "Sign in" };

type SearchParams = Promise<{ next?: string; error?: string; verified?: string; reset?: string }>;

const NOTICES: Record<string, string> = {
  verified: "Your email address has been verified. You can sign in now.",
  reset: "Your password was changed. Sign in with your new password.",
};

export default async function LoginPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const locale = await resolveLocale();
  const t = getTranslations(locale);

  const notice =
    (params.verified ? NOTICES.verified : undefined) ??
    (params.reset ? NOTICES.reset : undefined) ??
    (params.error === "suspended" ? t("auth.accountSuspended") : undefined);

  // Only same-origin relative targets are honoured (validated again server-side).
  const next = params.next && params.next.startsWith("/") && !params.next.startsWith("//") ? params.next : undefined;

  return <LoginForm next={next} notice={notice} />;
}
