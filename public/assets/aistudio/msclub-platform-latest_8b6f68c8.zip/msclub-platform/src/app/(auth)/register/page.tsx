import type { Metadata } from "next";
import { db } from "@/lib/db";
import { RegisterForm } from "@/components/auth/register-form";
import { SETTING_KEYS, getBoolean } from "@/lib/settings";

export const metadata: Metadata = { title: "Create an account" };

export const dynamic = "force-dynamic";

export default async function RegisterPage() {
  // Only enabled, non-archived departments are offered as preferences.
  const tracks = await db.learningTrack
    .findMany({
      where: { enabled: true, archivedAt: null, kind: { in: ["DEPARTMENT", "BOTH"] } },
      orderBy: { order: "asc" },
      select: { id: true, name: true, nameAr: true },
    })
    .catch(() => []);

  const registrationOpen = await getBoolean(SETTING_KEYS.REGISTRATION_OPEN, true);

  return (
    <div className="space-y-5">
      {!registrationOpen ? (
        <div
          role="status"
          className="rounded-lg border border-warning-500/40 bg-warning-50 px-3 py-2.5 text-sm text-warning-700 dark:bg-warning-500/10 dark:text-warning-500"
        >
          New membership applications are temporarily closed. You can still create an account and
          sign in — the application step will reopen shortly.
        </div>
      ) : null}
      <RegisterForm tracks={tracks} />
    </div>
  );
}
