import { notFound } from "next/navigation";
import { AppShell, type ShellNavItem } from "@/components/shell/app-shell";
import { ForbiddenError, assertPermission, can, requireAuth } from "@/lib/auth/dal";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { unreadCount } from "@/lib/notifications";
import type { PermissionKey } from "@/lib/rbac/permissions";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const ctx = await requireAuth("/admin");
  try {
    assertPermission(ctx, "admin.dashboard");
  } catch (e) {
    // Do not reveal that an admin area exists to people without access.
    if (e instanceof ForbiddenError) notFound();
    throw e;
  }

  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const items: (ShellNavItem & { perm: PermissionKey })[] = [
    { href: "/admin", label: t("admin.overview"), icon: "dashboard", exact: true, perm: "admin.dashboard" },
    { href: "/admin/members", label: t("admin.members"), icon: "members", perm: "members.read" },
    { href: "/admin/applications", label: t("admin.applications"), icon: "applications", perm: "applications.read" },
    { href: "/admin/teams", label: t("admin.teams"), icon: "teams", perm: "teams.read" },
    { href: "/admin/events", label: t("admin.events"), icon: "events", perm: "events.read" },
    { href: "/admin/learning", label: t("admin.learning"), icon: "learning", perm: "learning.read" },
    { href: "/admin/tasks", label: t("admin.tasks"), icon: "tasks", perm: "tasks.read" },
    { href: "/admin/points", label: t("admin.points"), icon: "points", perm: "points.read" },
    { href: "/admin/levels", label: t("admin.levels"), icon: "levels", perm: "levels.manage" },
    { href: "/admin/badges", label: t("admin.badges"), icon: "badges", perm: "badges.manage" },
    { href: "/admin/leaderboard", label: t("admin.leaderboard"), icon: "leaderboard", perm: "leaderboard.configure" },
    { href: "/admin/certificates", label: t("admin.certificates"), icon: "certificates", perm: "certificates.read" },
    { href: "/admin/analytics", label: t("admin.analytics"), icon: "analytics", perm: "admin.analytics.view" },
    { href: "/admin/content", label: t("admin.content"), icon: "content", perm: "content.manage" },
    { href: "/admin/messages", label: t("admin.navMessages"), icon: "messages", perm: "content.manage" },
    { href: "/admin/roles", label: t("admin.navRoles"), icon: "roles", perm: "admin.roles.read" },
    { href: "/admin/settings", label: t("admin.settings"), icon: "settings", perm: "admin.settings.manage" },
    { href: "/admin/audit-logs", label: t("admin.auditLogs"), icon: "audit", perm: "admin.audit.read" },
  ];
  // The menu is a convenience; every page and action re-checks its own permission.
  const nav = items.filter((i) => can(ctx, i.perm)).map(({ perm, ...rest }) => (void perm, rest));

  return (
    <AppShell
      nav={nav}
      areaLabel={t("admin.adminTitle")}
      user={{ name: ctx.name, email: ctx.email, image: ctx.image }}
      unreadCount={await unreadCount(ctx.userId)}
      notificationsHref="/dashboard/notifications"
      crossLink={{ href: "/dashboard", label: t("dashboard.portalTitle") }}
      palette
    >
      {children}
    </AppShell>
  );
}
