import { saveTeamAction } from "@/app/actions/admin-teams";
import { EMPTY_TEAM, TeamForm } from "@/components/admin/teams/team-form";
import { PageHeader } from "@/components/shared/page-header";
import { requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function NewTeamPage() {
  const ctx = await requirePermission("teams.create", { next: "/admin/teams/new" });
  const t = getTranslations(await resolveLocale(ctx.locale === "AR" ? "ar" : "en"));
  const tracks = await db.learningTrack.findMany({ where: { archivedAt: null }, orderBy: { order: "asc" }, select: { id: true, name: true } });
  return (
    <>
      <PageHeader title={t("admin.team.newTeam")} />
      <TeamForm action={saveTeamAction.bind(null, null)} values={EMPTY_TEAM} tracks={tracks} isNew />
    </>
  );
}
