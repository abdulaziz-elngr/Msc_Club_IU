import type { Metadata } from "next";
import { Award, CalendarCheck, ClipboardList, GraduationCap, Percent, UserCheck, Zap } from "lucide-react";
import { BarsChart } from "@/components/admin/charts";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { requirePermission } from "@/lib/auth/dal";
import { formatDateTime, formatMonthYear, formatNumber, formatPercent } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getAdminKpis, getEventAttendance, getMemberGrowth, getMembersByLevel, getRecentAudit } from "@/lib/queries/admin";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("admin.overviewTitle") };
}

export default async function AdminOverviewPage() {
  const ctx = await requirePermission("admin.dashboard", { next: "/admin" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const [kpi, growth, attendance, levels, audit] = await Promise.all([
    getAdminKpis(), getMemberGrowth(6), getEventAttendance(8), getMembersByLevel(), getRecentAudit(8),
  ]);
  const short = (s: string) => (s.length > 14 ? `${s.slice(0, 13)}…` : s);

  return (
    <>
      <PageHeader title={t("admin.overviewTitle")} />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label={t("admin.kpi.members")} value={formatNumber(kpi.members, locale)} icon={UserCheck} tone="brand" />
        <StatCard label={t("admin.kpi.pending")} value={formatNumber(kpi.pending, locale)} icon={ClipboardList} tone={kpi.pending > 0 ? "warning" : "neutral"} />
        <StatCard label={t("admin.kpi.upcoming")} value={formatNumber(kpi.upcoming, locale)} icon={CalendarCheck} tone="brand" />
        <StatCard label={t("admin.kpi.registrations")} value={formatNumber(kpi.registrations, locale)} icon={Award} tone="brand" />
        <StatCard label={t("admin.kpi.attendance")} value={kpi.attendanceRate === null ? "—" : formatPercent(kpi.attendanceRate, locale)} icon={Percent} tone="success" />
        <StatCard label={t("admin.kpi.courses")} value={formatNumber(kpi.courses, locale)} icon={GraduationCap} tone="brand" />
        <StatCard label={t("admin.kpi.xp")} value={formatNumber(kpi.xp, locale)} icon={Zap} tone="brand" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="space-y-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          <SectionHeading as="h3" title={t("admin.charts.growth")} />
          <BarsChart
            emptyLabel={t("admin.charts.noData")}
            series={[{ key: "count", label: t("admin.charts.growthSeries"), color: "var(--primary)" }]}
            data={growth.map((g) => ({ label: formatMonthYear(g.date, locale), count: g.count }))}
          />
        </section>
        <section className="space-y-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          <SectionHeading as="h3" title={t("admin.charts.events")} />
          <BarsChart
            emptyLabel={t("admin.charts.noData")}
            series={[
              { key: "registered", label: t("admin.charts.registered"), color: "var(--primary)" },
              { key: "attended", label: t("admin.charts.attended"), color: "var(--chart-2, #5B9BD5)" },
            ]}
            data={attendance.map((e) => ({ label: short(locale === "ar" && e.titleAr ? e.titleAr : e.title), registered: e.registered, attended: e.attended }))}
          />
        </section>
        <section className="space-y-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          <SectionHeading as="h3" title={t("admin.charts.levels")} />
          <BarsChart
            emptyLabel={t("admin.charts.noData")}
            series={[{ key: "count", label: t("admin.charts.members"), color: "var(--primary)" }]}
            data={levels.map((l) => ({ label: short(locale === "ar" && l.nameAr ? l.nameAr : l.name), count: l.count }))}
          />
        </section>
        <section className="space-y-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10">
          <SectionHeading as="h3" title={t("admin.recent")} />
          {audit.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("admin.noRecent")}</p>
          ) : (
            <ul className="divide-y text-sm">
              {audit.map((a) => (
                <li key={a.id} className="flex items-center justify-between gap-3 py-2">
                  <span className="min-w-0 truncate"><span className="font-medium">{a.actor?.name ?? "—"}</span> · <code className="text-xs text-muted-foreground">{a.action}</code></span>
                  <time className="shrink-0 text-xs text-muted-foreground" dateTime={a.createdAt.toISOString()}>{formatDateTime(a.createdAt, locale)}</time>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
    </>
  );
}
