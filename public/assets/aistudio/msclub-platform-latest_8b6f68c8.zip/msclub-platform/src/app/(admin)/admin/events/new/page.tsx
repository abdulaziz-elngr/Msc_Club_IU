import { PageHeader } from "@/components/shared/page-header";
import { EMPTY_EVENT, EventForm } from "@/components/admin/events/event-form";
import { saveEventAction } from "@/app/actions/admin-events";
import { requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function NewEventPage() {
  const ctx = await requirePermission("events.create", { next: "/admin/events/new" });
  const t = getTranslations(await resolveLocale(ctx.locale === "AR" ? "ar" : "en"));
  const teams = await db.team.findMany({ where: { status: "ACTIVE" }, orderBy: { name: "asc" }, select: { id: true, name: true } });
  return (
    <>
      <PageHeader title={t("admin.ev.newEvent")} />
      <EventForm action={saveEventAction.bind(null, null)} values={EMPTY_EVENT} teams={teams} isNew />
    </>
  );
}
