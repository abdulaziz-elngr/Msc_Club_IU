import { PageHeader } from "@/components/shared/page-header";
import { requirePermission } from "@/lib/auth/dal";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { listRolesWithPermissions } from "@/lib/queries/admin-people";

export const dynamic = "force-dynamic";

export default async function RolesPage() {
  const ctx = await requirePermission("admin.roles.read", { next: "/admin/roles" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const roles = await listRolesWithPermissions();

  return (
    <>
      <PageHeader title={t("admin.role.title")} description={t("admin.role.subtitle")} />
      <p className="text-sm text-muted-foreground">{t("admin.role.readOnlyNote")}</p>
      <div className="space-y-4">
        {roles.map((r) => {
          const groups = new Map<string, string[]>();
          for (const { permission: p } of r.permissions) {
            const label = locale === "ar" && p.labelAr ? p.labelAr : p.label;
            groups.set(p.group, [...(groups.get(p.group) ?? []), label]);
          }
          return (
            <details key={r.id} className="group rounded-xl bg-card ring-1 ring-foreground/10">
              <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-2 p-4 outline-none focus-visible:ring-2 focus-visible:ring-ring">
                <span className="font-semibold">{locale === "ar" && r.nameAr ? r.nameAr : r.name}</span>
                <span className="text-xs text-muted-foreground">
                  {t("admin.role.permissionsCount", { count: r.permissions.length })} · {t("admin.role.holders", { count: r._count.users })}
                </span>
              </summary>
              <div className="space-y-3 border-t p-4 text-sm">
                {r.key === "SUPER_ADMIN" ? <p className="text-muted-foreground">{t("admin.role.superAdminLocked")}</p> : null}
                {[...groups.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([group, labels]) => (
                  <div key={group}>
                    <p className="text-xs font-semibold tracking-wide text-muted-foreground uppercase">{group}</p>
                    <p className="mt-1 text-muted-foreground">{labels.join(" · ")}</p>
                  </div>
                ))}
              </div>
            </details>
          );
        })}
      </div>
    </>
  );
}
