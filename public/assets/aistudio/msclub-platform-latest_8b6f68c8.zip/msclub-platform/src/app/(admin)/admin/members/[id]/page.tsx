import Link from "next/link";
import { notFound } from "next/navigation";
import { changeMemberStatusAction, setMemberRoleAction, updateMemberProfileAction } from "@/app/actions/admin-people";
import { ActionForm, ConfirmAction, Field, NATIVE_SELECT } from "@/components/admin/forms";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { can, requirePermission } from "@/lib/auth/dal";
import { formatDate, formatDateTime, formatNumber } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getMember } from "@/lib/queries/admin-people";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";

export default async function MemberPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: raw } = await params;
  const ctx = await requirePermission("members.read", { next: `/admin/members/${raw}` });
  const id = recordId.safeParse(raw);
  if (!id.success) notFound();
  const data = await getMember(id.data);
  if (!data) notFound();
  const { user, xp, allRoles } = data;

  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const held = new Set(user.roles.map((r) => r.role.key));
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";
  const isSelf = user.id === ctx.userId;
  const canSuspend = can(ctx, "members.suspend") && !isSelf;
  const reactivating = user.status === "SUSPENDED" || user.status === "ARCHIVED";

  return (
    <>
      <PageHeader title={user.name} description={`${user.email} · ${t(`statuses.${user.status}` as TranslationKey)}`} />

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard label={t("admin.mem.xp")} value={formatNumber(user.totalXp, locale)} tone="brand" />
        <StatCard label={t("admin.mem.colLevel")} value={user.level ? (locale === "ar" && user.level.nameAr ? user.level.nameAr : user.level.name) : "—"} tone="brand" />
        <StatCard label={t("admin.mem.badges")} value={String(user._count.badges)} tone="brand" />
      </div>

      {can(ctx, "members.update") ? (
        <section className={box} aria-labelledby="prof">
          <SectionHeading as="h2" id="prof" title={t("admin.mem.editProfile")} />
          <ActionForm action={updateMemberProfileAction.bind(null, user.id)}>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field name="name" label={t("common.name")} required>{(p) => <Input {...p} defaultValue={user.name} maxLength={120} className="h-10" />}</Field>
              <Field name="studentId" label={t("admin.mem.colStudent")}>{(p) => <Input {...p} dir="ltr" defaultValue={user.studentId ?? ""} maxLength={20} className="h-10" />}</Field>
              <Field name="department" label={t("admin.mem.department")}>{(p) => <Input {...p} defaultValue={user.department ?? ""} maxLength={120} className="h-10" />}</Field>
              <Field name="phone" label={t("admin.mem.phone")}>{(p) => <Input {...p} type="tel" dir="ltr" defaultValue={user.phone ?? ""} maxLength={20} className="h-10" />}</Field>
            </div>
          </ActionForm>
        </section>
      ) : null}

      {can(ctx, "admin.roles.manage") ? (
        <section className={box} aria-labelledby="roles">
          <SectionHeading as="h2" id="roles" title={t("admin.mem.roles")} description={t("admin.mem.rolesHint")} />
          <ul className="divide-y">
            {allRoles.map((r) => {
              const has = held.has(r.key);
              return (
                <li key={r.key} className="flex items-center justify-between gap-3 py-2">
                  <span className="text-sm font-medium">{locale === "ar" && r.nameAr ? r.nameAr : r.name}</span>
                  <ConfirmAction
                    variant={has ? "outline" : "default"}
                    label={has ? t("admin.mem.revoke") : t("admin.mem.grant")}
                    action={setMemberRoleAction.bind(null, user.id, r.key, !has)}
                    disabled={r.key === "SUPER_ADMIN" && isSelf}
                  />
                </li>
              );
            })}
          </ul>
        </section>
      ) : (
        <section className={box}>
          <SectionHeading as="h2" title={t("admin.mem.roles")} />
          <p className="text-sm">{user.roles.map((r) => (locale === "ar" && r.role.nameAr ? r.role.nameAr : r.role.name)).join("، ") || "—"}</p>
        </section>
      )}

      <section className={box}>
        <SectionHeading as="h2" title={t("admin.mem.teams")} />
        {user.teamMemberships.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("admin.mem.noTeams")}</p>
        ) : (
          <ul className="flex flex-wrap gap-2">
            {user.teamMemberships.map((m) => (
              <li key={m.team.slug}><Link href={`/admin/teams`} className="inline-flex rounded-full bg-muted px-3 py-1 text-sm">{locale === "ar" && m.team.nameAr ? m.team.nameAr : m.team.name}</Link></li>
            ))}
          </ul>
        )}
      </section>

      <section className={box}>
        <SectionHeading as="h2" title={t("admin.mem.recentXp")} />
        {xp.length === 0 ? <p className="text-sm text-muted-foreground">{t("admin.mem.noXp")}</p> : (
          <ul className="divide-y text-sm">
            {xp.map((x) => (
              <li key={x.id} className="flex items-center justify-between gap-3 py-2">
                <span className="min-w-0 truncate">{x.description}</span>
                <span className="shrink-0 tabular-nums"><b className={x.amount < 0 ? "text-danger-700" : "text-success-700"}>{x.amount > 0 ? "+" : ""}{x.amount}</b> <span className="text-xs text-muted-foreground">{formatDateTime(x.createdAt, locale)}</span></span>
              </li>
            ))}
          </ul>
        )}
        <p className="text-xs text-muted-foreground">{t("admin.mem.colJoined")}: {formatDate(user.joinedAt, locale)}</p>
      </section>

      {canSuspend ? (
        <section className={box} aria-labelledby="acct">
          <SectionHeading as="h2" id="acct" title={t("admin.mem.account")} description={t("admin.mem.statusHint")} />
          <ActionForm action={changeMemberStatusAction.bind(null, user.id)} submitLabel={t("admin.mem.changeStatus")}>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field name="status" label={t("admin.mem.newStatus")} required>
                {(p) => (
                  <select {...p} defaultValue={reactivating ? "ACTIVE" : "SUSPENDED"} className={NATIVE_SELECT}>
                    {reactivating ? <option value="ACTIVE">{t("admin.mem.reactivate")}</option> : null}
                    <option value="SUSPENDED">{t("admin.mem.suspend")}</option>
                    <option value="ARCHIVED">{t("admin.mem.archive")}</option>
                  </select>
                )}
              </Field>
              <Field name="reason" label={t("admin.mem.statusReason")} hint={t("admin.ui.reasonHint")} required>{(p) => <Textarea {...p} rows={2} maxLength={500} />}</Field>
            </div>
          </ActionForm>
        </section>
      ) : null}
    </>
  );
}
