import Link from "next/link";
import { Download, UserX } from "lucide-react";
import { NATIVE_SELECT } from "@/components/admin/forms";
import { DataTable, PAGE_SIZE, Pagination, parsePage } from "@/components/admin/table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { can, requirePermission } from "@/lib/auth/dal";
import { formatDate, formatNumber } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { listMembers } from "@/lib/queries/admin-people";

export const dynamic = "force-dynamic";
const STATUSES = ["ACTIVE", "SUSPENDED", "ARCHIVED", "APPLICANT", "UNDER_REVIEW", "REJECTED", "UNVERIFIED"] as const;
const pick = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

export default async function MembersPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requirePermission("members.read", { next: "/admin/members" });
  const sp = await searchParams;
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const q = pick(sp.q)?.trim().slice(0, 80) || undefined;
  const sRaw = pick(sp.status);
  const status = (STATUSES as readonly string[]).includes(sRaw ?? "") ? sRaw : undefined;
  const page = parsePage(sp.page);
  const { rows, total, pages } = await listMembers({ q, status, page });

  return (
    <>
      <PageHeader
        title={t("admin.members")}
        actions={can(ctx, "members.export") ? <Button asChild variant="outline" size="sm"><a href="/api/admin/members/export"><Download className="size-4" aria-hidden /> {t("admin.mem.export")}</a></Button> : undefined}
      />
      <form className="flex flex-wrap gap-2" role="search">
        <Input name="q" defaultValue={q} placeholder={t("admin.ui.searchPlaceholder")} aria-label={t("common.search")} className="h-10 max-w-xs" />
        <select name="status" defaultValue={status ?? ""} aria-label={t("common.status")} className={`${NATIVE_SELECT} max-w-48`}>
          <option value="">{t("common.all")}</option>
          {STATUSES.map((s) => <option key={s} value={s}>{t(`statuses.${s}` as TranslationKey)}</option>)}
        </select>
        <Button type="submit" variant="outline">{t("common.filter")}</Button>
      </form>
      <DataTable
        rows={rows}
        empty={<EmptyState icon={UserX} title={t("admin.mem.empty")} />}
        columns={[
          { header: t("admin.mem.colName"), cell: (m) => (<div><Link href={`/admin/members/${m.id}`} className="font-medium hover:text-primary">{m.name}</Link><p className="text-xs text-muted-foreground" dir="ltr">{m.email}</p></div>) },
          { header: t("admin.mem.colStudent"), cell: (m) => <span dir="ltr" className="tabular-nums text-muted-foreground">{m.studentId ?? "—"}</span> },
          { header: t("admin.mem.colStatus"), cell: (m) => <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">{t(`statuses.${m.status}` as TranslationKey)}</span> },
          { header: t("admin.mem.colLevel"), cell: (m) => (m.level ? (locale === "ar" && m.level.nameAr ? m.level.nameAr : m.level.name) : "—") },
          { header: "XP", className: "tabular-nums", cell: (m) => formatNumber(m.totalXp, locale) },
          { header: t("admin.mem.colJoined"), cell: (m) => <span className="whitespace-nowrap text-muted-foreground">{formatDate(m.joinedAt, locale)}</span> },
        ]}
      />
      <Pagination page={page} pages={pages} total={total} basePath="/admin/members" params={{ q, status }}
        labels={{ previous: t("admin.ui.previous"), next: t("admin.ui.next"), summary: `${rows.length ? (page - 1) * PAGE_SIZE + 1 : 0}–${(page - 1) * PAGE_SIZE + rows.length} ${t("common.of")} ${total}` }} />
    </>
  );
}
