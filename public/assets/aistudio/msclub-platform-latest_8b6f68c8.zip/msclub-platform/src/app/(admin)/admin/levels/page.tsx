import { deleteLevelAction, recalculateLevelsAction, saveLevelAction } from "@/app/actions/admin-gamification";
import { ConfirmAction, QuickAction } from "@/components/admin/forms";
import { EMPTY_LEVEL, LevelForm } from "@/components/admin/gamification/forms";
import { DataTable } from "@/components/admin/table";
import { NamedIcon } from "@/components/shared/named-icon";
import { PageHeader } from "@/components/shared/page-header";
import { requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { formatNumber } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function LevelsPage() {
  const ctx = await requirePermission("levels.manage", { next: "/admin/levels" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const levels = await db.level.findMany({ orderBy: { minXp: "asc" }, include: { _count: { select: { users: true } } } });

  return (
    <>
      <PageHeader title={t("admin.levels")} description={t("admin.lvl.recalcHint")} actions={<QuickAction action={recalculateLevelsAction}>{t("admin.lvl.recalc")}</QuickAction>} />
      <DataTable
        rows={levels}
        empty={<p className="text-sm text-muted-foreground">{t("admin.lvl.empty")}</p>}
        columns={[
          { header: t("admin.lvl.colOrder"), className: "tabular-nums", cell: (l) => l.order },
          { header: t("admin.lvl.colName"), cell: (l) => <span className="flex items-center gap-2 font-medium"><NamedIcon name={l.icon} color={l.color} className="size-4" />{locale === "ar" && l.nameAr ? l.nameAr : l.name}{!l.enabled ? <span className="text-xs text-muted-foreground">({t("admin.ui.disabled")})</span> : null}</span> },
          { header: t("admin.lvl.colMinXp"), className: "tabular-nums", cell: (l) => `${formatNumber(l.minXp, locale)} XP` },
          { header: t("admin.lvl.colMembers"), className: "tabular-nums", cell: (l) => l._count.users },
        ]}
      />
      <div className="space-y-3">
        {levels.map((l) => (
          <details key={l.id} className="rounded-xl bg-card ring-1 ring-foreground/10">
            <summary className="cursor-pointer p-4 text-sm font-medium">{t("common.edit")} · {l.name}</summary>
            <div className="space-y-3 border-t p-4">
              <LevelForm action={saveLevelAction.bind(null, l.id)} isNew={false} values={{ key: l.key, name: l.name, nameAr: l.nameAr ?? "", minXp: l.minXp, description: l.description ?? "", descriptionAr: l.descriptionAr ?? "", icon: l.icon, color: l.color, rewards: Array.isArray(l.rewards) ? (l.rewards as string[]).join("\n") : "", enabled: l.enabled }} />
              <ConfirmAction variant="ghost" label={t("common.delete")} title={t("admin.lvl.deleteTitle")} action={deleteLevelAction.bind(null, l.id)} successKey="admin.ui.deleted" />
            </div>
          </details>
        ))}
        <details className="rounded-xl bg-card ring-1 ring-foreground/10" open={levels.length === 0}>
          <summary className="cursor-pointer p-4 text-sm font-semibold">{t("admin.lvl.newLevel")}</summary>
          <div className="border-t p-4"><LevelForm action={saveLevelAction.bind(null, null)} isNew values={EMPTY_LEVEL} /></div>
        </details>
      </div>
    </>
  );
}
