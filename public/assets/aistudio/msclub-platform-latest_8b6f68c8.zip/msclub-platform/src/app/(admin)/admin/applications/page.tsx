import Link from "next/link";
import { ClipboardX } from "lucide-react";
import { NATIVE_SELECT } from "@/components/admin/forms";
import { DataTable, PAGE_SIZE, Pagination, parsePage } from "@/components/admin/table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { requirePermission } from "@/lib/auth/dal";
import { formatDateTime } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { listApplications } from "@/lib/queries/admin-people";

export const dynamic = "force-dynamic";
const STATUSES = ["SUBMITTED", "UNDER_REVIEW", "ACCEPTED", "REJECTED", "WITHDRAWN"] as const;
const pick = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

export default async function ApplicationsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requirePermission("applications.read", { next: "/admin/applications" });
  const sp = await searchParams;
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const q = pick(sp.q)?.trim().slice(0, 80) || undefined;
  const sRaw = pick(sp.status);
  const status = (STATUSES as readonly string[]).includes(sRaw ?? "") ? sRaw : undefined;
  const page = parsePage(sp.page);
  const { rows, total, pages } = await listApplications({ q, status, page });

  return (
    <>
      <PageHeader title={t("admin.applications")} />
      <form className="flex flex-wrap gap-2" role="search">
        <Input name="q" defaultValue={q} placeholder={t("admin.ui.searchPlaceholder")} aria-label={t("common.search")} className="h-10 max-w-xs" />
        <select name="status" defaultValue={status ?? ""} aria-label={t("admin.app.statusFilter")} className={`${NATIVE_SELECT} max-w-48`}>
          <option value="">{t("statuses.PENDING")}</option>
          {STATUSES.map((s) => <option key={s} value={s}>{t(`statuses.${s}` as TranslationKey)}</option>)}
        </select>
        <Button type="submit" variant="outline">{t("common.filter")}</Button>
      </form>
      <DataTable
        rows={rows}
        empty={<EmptyState icon={ClipboardX} title={t("admin.app.empty")} />}
        columns={[
          { header: t("admin.app.colApplicant"), cell: (a) => (<div><Link href={`/admin/applications/${a.id}`} className="font-medium hover:text-primary">{a.user.name}</Link><p className="text-xs text-muted-foreground" dir="ltr">{a.user.email}</p></div>) },
          { header: t("admin.app.colTrack"), cell: (a) => (a.track ? (locale === "ar" && a.track.nameAr ? a.track.nameAr : a.track.name) : "—") },
          { header: t("admin.app.colSubmitted"), cell: (a) => <span className="whitespace-nowrap text-muted-foreground">{formatDateTime(a.submittedAt, locale)}</span> },
          { header: t("common.status"), cell: (a) => <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">{t(`statuses.${a.status}` as TranslationKey)}</span> },
        ]}
      />
      <Pagination page={page} pages={pages} total={total} basePath="/admin/applications" params={{ q, status }}
        labels={{ previous: t("admin.ui.previous"), next: t("admin.ui.next"), summary: `${rows.length ? (page - 1) * PAGE_SIZE + 1 : 0}–${(page - 1) * PAGE_SIZE + rows.length} ${t("common.of")} ${total}` }} />
    </>
  );
}
