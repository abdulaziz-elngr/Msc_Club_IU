import { notFound } from "next/navigation";
import { addTeamMemberAction, archiveTeamAction, removeTeamMemberAction, saveTeamAction, setLeadershipAction } from "@/app/actions/admin-teams";
import { ActionForm, ConfirmAction, Field } from "@/components/admin/forms";
import { DataTable } from "@/components/admin/table";
import { TeamForm } from "@/components/admin/teams/team-form";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { Input } from "@/components/ui/input";
import { can, requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";

export default async function AdminTeamPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: raw } = await params;
  const ctx = await requirePermission("teams.read", { next: `/admin/teams/${raw}` });
  const id = recordId.safeParse(raw);
  if (!id.success) notFound();

  const [team, tracks] = await Promise.all([
    db.team.findUnique({
      where: { id: id.data },
      include: {
        lead: { select: { email: true } }, coLead: { select: { email: true } },
        memberships: { where: { status: "ACTIVE" }, orderBy: [{ role: "asc" }, { joinedAt: "asc" }], select: { role: true, user: { select: { id: true, name: true, email: true } } } },
      },
    }),
    db.learningTrack.findMany({ where: { archivedAt: null }, orderBy: { order: "asc" }, select: { id: true, name: true } }),
  ]);
  if (!team) notFound();

  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";
  const mayEdit = can(ctx, "teams.update");
  const mayMembers = can(ctx, "teams.manage_members");

  return (
    <>
      <PageHeader title={locale === "ar" && team.nameAr ? team.nameAr : team.name} description={`/teams/${team.slug} · ${t(team.status === "ACTIVE" ? "statuses.ACTIVE" : "statuses.ARCHIVED")}`} />

      {mayEdit ? (
        <section className={box}>
          <TeamForm
            action={saveTeamAction.bind(null, team.id)} tracks={tracks} isNew={false}
            values={{ name: team.name, nameAr: team.nameAr ?? "", slug: team.slug, description: team.description ?? "", descriptionAr: team.descriptionAr ?? "", trackId: team.trackId ?? "", visibility: team.visibility, order: team.order, logo: team.logo }}
          />
        </section>
      ) : null}

      {mayEdit ? (
        <section className={box} aria-labelledby="lead">
          <SectionHeading as="h2" id="lead" title={t("admin.team.leadership")} description={t("admin.team.leadershipHint")} />
          <ActionForm action={setLeadershipAction.bind(null, team.id)} submitLabel={t("admin.team.saveLeadership")}>
            <div className="grid gap-4 sm:grid-cols-2">
              <Field name="leadEmail" label={t("admin.team.leadEmail")}>{(p) => <Input {...p} type="email" dir="ltr" defaultValue={team.lead?.email ?? ""} className="h-10" />}</Field>
              <Field name="coLeadEmail" label={t("admin.team.coLeadEmail")}>{(p) => <Input {...p} type="email" dir="ltr" defaultValue={team.coLead?.email ?? ""} className="h-10" />}</Field>
            </div>
          </ActionForm>
        </section>
      ) : null}

      <section className={box} aria-labelledby="mem">
        <SectionHeading as="h2" id="mem" title={`${t("admin.team.members")} (${team.memberships.length})`} />
        <DataTable
          rows={team.memberships.map((m) => ({ id: m.user.id, ...m }))}
          empty={<p className="text-sm text-muted-foreground">{t("admin.mem.noTeams")}</p>}
          columns={[
            { header: t("common.name"), cell: (m) => <span className="font-medium">{m.user.name}</span> },
            { header: t("common.email"), cell: (m) => <span dir="ltr" className="text-muted-foreground">{m.user.email}</span> },
            { header: t("admin.team.role"), cell: (m) => t(`admin.team.roles.${m.role}` as TranslationKey) },
            { header: t("common.actions"), cell: (m) => (mayMembers ? <ConfirmAction variant="ghost" label={t("admin.team.remove")} title={t("admin.team.removeTitle")} action={removeTeamMemberAction.bind(null, team.id, m.user.id)} /> : null) },
          ]}
        />
        {mayMembers && team.status === "ACTIVE" ? (
          <ActionForm action={addTeamMemberAction.bind(null, team.id)} submitLabel={t("admin.team.addMember")} className="flex flex-wrap items-end gap-3 space-y-0" resetOnSuccess>
            <Field name="email" label={t("admin.team.memberEmail")} required>{(p) => <Input {...p} type="email" dir="ltr" className="h-10 w-72 max-w-full" />}</Field>
          </ActionForm>
        ) : null}
      </section>

      {can(ctx, "teams.archive") ? (
        <section className={box}>
          <ConfirmAction
            variant={team.status === "ACTIVE" ? "destructive" : "outline"}
            label={team.status === "ACTIVE" ? t("admin.team.archive") : t("admin.team.restore")}
            title={t("admin.team.archiveTitle")} description={team.status === "ACTIVE" ? t("admin.team.archiveBody") : undefined}
            action={archiveTeamAction.bind(null, team.id, team.status === "ACTIVE")}
          />
        </section>
      ) : null}
    </>
  );
}
