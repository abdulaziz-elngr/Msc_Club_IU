import { ScrollText } from "lucide-react";
import { DataTable, PAGE_SIZE, Pagination, parsePage } from "@/components/admin/table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import type { Prisma } from "@/generated/client";
import { requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { formatDateTime } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";
const pick = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v)?.trim().slice(0, 80) || undefined;
const day = (v: string | undefined, end = false) => {
  if (!v || !/^\d{4}-\d{2}-\d{2}$/.test(v)) return undefined;
  const d = new Date(`${v}T${end ? "23:59:59.999" : "00:00:00.000"}Z`);
  return Number.isNaN(d.getTime()) ? undefined : d;
};

export default async function AuditLogsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requirePermission("admin.audit.read", { next: "/admin/audit-logs" });
  const sp = await searchParams;
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const action = pick(sp.action), entity = pick(sp.entity), actor = pick(sp.actor), from = pick(sp.from), to = pick(sp.to);
  const page = parsePage(sp.page);
  const where: Prisma.AuditLogWhereInput = {
    ...(action ? { action: { contains: action, mode: "insensitive" } } : {}),
    ...(entity ? { entityType: { equals: entity, mode: "insensitive" } } : {}),
    ...(actor ? { actor: { OR: [{ name: { contains: actor, mode: "insensitive" } }, { email: { contains: actor, mode: "insensitive" } }] } } : {}),
    ...(day(from) || day(to, true) ? { createdAt: { ...(day(from) ? { gte: day(from) } : {}), ...(day(to, true) ? { lte: day(to, true) } : {}) } } : {}),
  };
  const [total, rows] = await Promise.all([
    db.auditLog.count({ where }),
    db.auditLog.findMany({ where, orderBy: { createdAt: "desc" }, skip: (page - 1) * PAGE_SIZE, take: PAGE_SIZE, include: { actor: { select: { name: true } } } }),
  ]);
  const pages = Math.max(1, Math.ceil(total / PAGE_SIZE));

  return (
    <>
      <PageHeader title={t("admin.aud.title")} description={t("admin.aud.subtitle")} />
      <form className="grid gap-2 sm:grid-cols-2 lg:grid-cols-6" role="search">
        <Input name="action" defaultValue={action} placeholder={t("admin.aud.filterAction")} aria-label={t("admin.aud.filterAction")} className="h-10" />
        <Input name="entity" defaultValue={entity} placeholder={t("admin.aud.filterEntity")} aria-label={t("admin.aud.filterEntity")} className="h-10" />
        <Input name="actor" defaultValue={actor} placeholder={t("admin.aud.filterActor")} aria-label={t("admin.aud.filterActor")} className="h-10" />
        <Input name="from" type="date" defaultValue={from} aria-label={t("admin.aud.from")} className="h-10" />
        <Input name="to" type="date" defaultValue={to} aria-label={t("admin.aud.to")} className="h-10" />
        <Button type="submit" variant="outline">{t("common.filter")}</Button>
      </form>
      <DataTable
        rows={rows}
        empty={<EmptyState icon={ScrollText} title={t("admin.aud.empty")} />}
        columns={[
          { header: t("admin.aud.colWhen"), cell: (r) => <span className="whitespace-nowrap text-muted-foreground">{formatDateTime(r.createdAt, locale)}</span> },
          { header: t("admin.aud.colActor"), cell: (r) => r.actor?.name ?? <span className="text-muted-foreground">{t("admin.aud.system")}</span> },
          { header: t("admin.aud.colAction"), cell: (r) => <code className="text-xs">{r.action}</code> },
          { header: t("admin.aud.colEntity"), cell: (r) => <span className="text-xs">{r.entityType}{r.entityId ? <span className="text-muted-foreground" dir="ltr"> · {r.entityId.slice(0, 8)}</span> : null}</span> },
          {
            header: t("admin.aud.colDetails"),
            cell: (r) => (r.before || r.after || r.reason || r.ip ? (
              <details className="max-w-md text-xs">
                <summary className="cursor-pointer text-primary">…</summary>
                {/* JSON is rendered as TEXT (escaped by React); never as HTML. */}
                {r.reason ? <p className="mt-1"><b>{t("admin.aud.reason")}:</b> {r.reason}</p> : null}
                {r.before ? <pre className="mt-1 overflow-x-auto rounded bg-muted p-2" dir="ltr">{t("admin.aud.before")}: {JSON.stringify(r.before)}</pre> : null}
                {r.after ? <pre className="mt-1 overflow-x-auto rounded bg-muted p-2" dir="ltr">{t("admin.aud.after")}: {JSON.stringify(r.after)}</pre> : null}
                {r.ip ? <p className="mt-1 text-muted-foreground" dir="ltr">{t("admin.aud.ip")}: {r.ip}</p> : null}
              </details>
            ) : null),
          },
        ]}
      />
      <Pagination page={page} pages={pages} total={total} basePath="/admin/audit-logs" params={{ action, entity, actor, from, to }}
        labels={{ previous: t("admin.ui.previous"), next: t("admin.ui.next"), summary: `${rows.length ? (page - 1) * PAGE_SIZE + 1 : 0}–${(page - 1) * PAGE_SIZE + rows.length} ${t("common.of")} ${total}` }} />
    </>
  );
}
