import { randomUUID } from "node:crypto";
import { adjustPointsAction, awardPointsAction, reversePointsAction, savePointsRuleAction } from "@/app/actions/admin-gamification";
import { AdjustForm, AwardForm, EMPTY_RULE, ReverseDialog, RuleForm } from "@/components/admin/gamification/forms";
import { DataTable } from "@/components/admin/table";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { can, requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { formatDateTime } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function AdminPointsPage() {
  const ctx = await requirePermission("points.read", { next: "/admin/points" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const [rules, ledger] = await Promise.all([
    db.pointsRule.findMany({ orderBy: [{ enabled: "desc" }, { activityType: "asc" }, { key: "asc" }] }),
    db.xPTransaction.findMany({ orderBy: { createdAt: "desc" }, take: 40, include: { user: { select: { name: true } }, reversedBy: { select: { id: true } } } }),
  ]);
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";
  const mayRules = can(ctx, "points.adjust");
  const mayAward = can(ctx, "points.award");
  const mayAdjust = can(ctx, "points.adjust") || can(ctx, "points.award");
  const mayReverse = can(ctx, "points.reverse");

  return (
    <>
      <PageHeader title={t("admin.points")} />

      {mayAward || mayAdjust ? (
        <div className="grid gap-6 lg:grid-cols-2">
          {mayAward ? (
            <section className={box} aria-labelledby="aw">
              <SectionHeading as="h2" id="aw" title={t("admin.pts.award")} description={t("admin.pts.awardHint")} />
              <AwardForm action={awardPointsAction} nonce={randomUUID()} rules={rules.filter((r) => r.enabled).map((r) => ({ key: r.key, label: locale === "ar" && r.labelAr ? r.labelAr : r.label, points: r.points }))} />
            </section>
          ) : null}
          {mayAdjust ? (
            <section className={box} aria-labelledby="adj">
              <SectionHeading as="h2" id="adj" title={t("admin.pts.adjust")} description={t("admin.pts.adjustHint")} />
              <AdjustForm action={adjustPointsAction} nonce={randomUUID()} />
            </section>
          ) : null}
        </div>
      ) : null}

      <section className={box} aria-labelledby="led">
        <SectionHeading as="h2" id="led" title={t("admin.pts.ledger")} description={t("admin.pts.ledgerHint")} />
        <DataTable
          rows={ledger}
          empty={<p className="text-sm text-muted-foreground">{t("admin.pts.noLedger")}</p>}
          columns={[
            { header: t("admin.pts.colWhen"), cell: (x) => <span className="whitespace-nowrap text-muted-foreground">{formatDateTime(x.createdAt, locale)}</span> },
            { header: t("admin.pts.colMember"), cell: (x) => x.user.name },
            { header: t("admin.pts.colAmount"), className: "tabular-nums", cell: (x) => <b className={x.amount < 0 ? "text-danger-700 dark:text-danger-500" : "text-success-700 dark:text-success-500"}>{x.amount > 0 ? "+" : ""}{x.amount}</b> },
            { header: t("admin.pts.colDescription"), cell: (x) => <span className="line-clamp-2 max-w-xs">{locale === "ar" && x.descriptionAr ? x.descriptionAr : x.description}</span> },
            { header: t("common.actions"), cell: (x) => (x.reversedBy ? <span className="text-xs text-muted-foreground">{t("admin.pts.reversed")}</span> : mayReverse && x.amount > 0 && !x.reversesId ? <ReverseDialog action={reversePointsAction.bind(null, x.id)} /> : null) },
          ]}
        />
      </section>

      <section className={box} aria-labelledby="rul">
        <SectionHeading as="h2" id="rul" title={t("admin.pts.rules")} description={t("admin.pts.rulesHint")} />
        <DataTable
          rows={rules}
          empty={<p className="text-sm text-muted-foreground">{t("admin.pts.noRules")}</p>}
          columns={[
            { header: t("admin.pts.colKey"), cell: (r) => <code className="text-xs" dir="ltr">{r.key}</code> },
            { header: t("admin.pts.colLabel"), cell: (r) => (locale === "ar" && r.labelAr ? r.labelAr : r.label) },
            { header: t("admin.pts.colPoints"), className: "tabular-nums", cell: (r) => r.points },
            { header: t("admin.pts.colMax"), className: "tabular-nums", cell: (r) => r.maxAwardsPerUser ?? "∞" },
            { header: t("admin.pts.colState"), cell: (r) => (r.enabled ? t("admin.ui.enabled") : t("admin.ui.disabled")) },
          ]}
        />
        {mayRules ? (
          <div className="space-y-3">
            {rules.map((r) => (
              <details key={r.id} className="rounded-lg border">
                <summary className="cursor-pointer p-3 text-sm font-medium">{t("common.edit")} · <code className="text-xs" dir="ltr">{r.key}</code></summary>
                <div className="border-t p-4">
                  <RuleForm action={savePointsRuleAction.bind(null, r.id)} isNew={false} values={{ key: r.key, label: r.label, labelAr: r.labelAr ?? "", activityType: r.activityType, points: r.points, maxAwardsPerUser: r.maxAwardsPerUser?.toString() ?? "", requiresApproval: r.requiresApproval, enabled: r.enabled, referenceType: r.referenceType }} />
                </div>
              </details>
            ))}
            <details className="rounded-lg border" open={rules.length === 0}>
              <summary className="cursor-pointer p-3 text-sm font-semibold">{t("admin.pts.newRule")}</summary>
              <div className="border-t p-4"><RuleForm action={savePointsRuleAction.bind(null, null)} isNew values={EMPTY_RULE} /></div>
            </details>
          </div>
        ) : null}
      </section>
    </>
  );
}
