import Link from "next/link";
import { LeaderboardTable } from "@/components/shared/leaderboard-table";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { requirePermission } from "@/lib/auth/dal";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { countOptedOut, getLeaderboard } from "@/lib/queries/leaderboard";
import { SETTING_KEYS, getBoolean, getString } from "@/lib/settings";

export const dynamic = "force-dynamic";

export default async function AdminLeaderboardPage() {
  const ctx = await requirePermission("leaderboard.configure", { next: "/admin/leaderboard" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const [isPublic, period, rows, hidden] = await Promise.all([
    getBoolean(SETTING_KEYS.LEADERBOARD_PUBLIC, true), getString(SETTING_KEYS.LEADERBOARD_PERIOD, "monthly"),
    getLeaderboard({ scope: "global", period: "all", limit: 10 }), countOptedOut(),
  ]);
  return (
    <>
      <PageHeader title={t("admin.lb.title")} description={t("admin.lb.intro")} actions={<Button asChild size="sm" variant="outline"><Link href="/admin/settings">{t("admin.lb.openSettings")}</Link></Button>} />
      <p className="text-sm">{t("admin.lb.publicState")}: <b>{isPublic ? t("admin.lb.on") : t("admin.lb.off")}</b> · {t("admin.set.leaderboardPeriod")}: <b>{period}</b></p>
      <section className="space-y-3">
        <SectionHeading title={t("admin.lb.preview")} description={t("admin.lb.hiddenCount", { count: hidden })} />
        <LeaderboardTable rows={rows} locale={locale} />
      </section>
    </>
  );
}
