import { grantBadgeAction, revokeBadgeAction, saveBadgeAction } from "@/app/actions/admin-gamification";
import { BadgeForm, BadgeHolderForm, EMPTY_BADGE } from "@/components/admin/gamification/forms";
import { DataTable } from "@/components/admin/table";
import { NamedIcon } from "@/components/shared/named-icon";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { requirePermission } from "@/lib/auth/dal";
import { parseCriteria } from "@/lib/badges";
import { db } from "@/lib/db";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function BadgesPage() {
  const ctx = await requirePermission("badges.manage", { next: "/admin/badges" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const badges = await db.badge.findMany({ orderBy: [{ order: "asc" }, { name: "asc" }], include: { _count: { select: { users: true } } } });
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";
  const rule = (raw: unknown, auto: boolean) => {
    const c = parseCriteria(raw);
    return c && auto ? `${t(`admin.bdg.criteria.${c.type}` as TranslationKey)} ${c.threshold}` : t("admin.bdg.manualOnly");
  };

  return (
    <>
      <PageHeader title={t("admin.badges")} />
      <DataTable
        rows={badges}
        empty={<p className="text-sm text-muted-foreground">{t("admin.bdg.empty")}</p>}
        columns={[
          { header: t("admin.bdg.colBadge"), cell: (b) => <span className="flex items-center gap-2 font-medium"><NamedIcon name={b.icon} color={b.color} className="size-4" />{locale === "ar" && b.nameAr ? b.nameAr : b.name}{!b.enabled ? <span className="text-xs text-muted-foreground">({t("admin.ui.disabled")})</span> : null}</span> },
          { header: t("admin.bdg.colRule"), cell: (b) => rule(b.criteria, b.autoAward) },
          { header: t("admin.bdg.colHolders"), className: "tabular-nums", cell: (b) => b._count.users },
        ]}
      />

      <section className={box} aria-labelledby="man">
        <SectionHeading as="h2" id="man" title={t("admin.bdg.manual")} description={t("admin.bdg.manualHint")} />
        <div className="flex flex-wrap gap-x-8 gap-y-4">
          <BadgeHolderForm action={grantBadgeAction} badges={badges.map((b) => ({ id: b.id, name: b.name }))} submitLabel={t("admin.bdg.grant")} />
          <BadgeHolderForm action={revokeBadgeAction} badges={badges.map((b) => ({ id: b.id, name: b.name }))} submitLabel={t("admin.bdg.revoke")} />
        </div>
      </section>

      <div className="space-y-3">
        {badges.map((b) => {
          const c = parseCriteria(b.criteria);
          return (
            <details key={b.id} className="rounded-xl bg-card ring-1 ring-foreground/10">
              <summary className="cursor-pointer p-4 text-sm font-medium">{t("common.edit")} · {b.name}</summary>
              <div className="border-t p-4">
                <BadgeForm action={saveBadgeAction.bind(null, b.id)} isNew={false} values={{ key: b.key, name: b.name, nameAr: b.nameAr ?? "", description: b.description ?? "", descriptionAr: b.descriptionAr ?? "", icon: b.icon, color: b.color, tier: b.tier, criteriaType: c?.type ?? "manual", threshold: c ? String(c.threshold) : "", autoAward: b.autoAward, enabled: b.enabled }} />
              </div>
            </details>
          );
        })}
        <details className="rounded-xl bg-card ring-1 ring-foreground/10" open={badges.length === 0}>
          <summary className="cursor-pointer p-4 text-sm font-semibold">{t("admin.bdg.newBadge")}</summary>
          <div className="border-t p-4"><BadgeForm action={saveBadgeAction.bind(null, null)} isNew values={EMPTY_BADGE} /></div>
        </details>
      </div>
    </>
  );
}
