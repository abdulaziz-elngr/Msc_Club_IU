import Link from "next/link";
import { Plus, Users } from "lucide-react";
import { DataTable } from "@/components/admin/table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { can, requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function AdminTeamsPage() {
  const ctx = await requirePermission("teams.read", { next: "/admin/teams" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const teams = await db.team.findMany({
    orderBy: [{ status: "asc" }, { order: "asc" }, { name: "asc" }],
    select: { id: true, name: true, nameAr: true, status: true, lead: { select: { name: true } }, _count: { select: { memberships: { where: { status: "ACTIVE" } } } } },
  });
  return (
    <>
      <PageHeader title={t("admin.teams")} actions={can(ctx, "teams.create") ? <Button asChild size="sm"><Link href="/admin/teams/new"><Plus className="size-4" aria-hidden /> {t("admin.team.newTeam")}</Link></Button> : undefined} />
      <DataTable
        rows={teams}
        empty={<EmptyState icon={Users} title={t("admin.team.empty")} />}
        columns={[
          { header: t("admin.team.colName"), cell: (x) => <Link href={`/admin/teams/${x.id}`} className="font-medium hover:text-primary">{locale === "ar" && x.nameAr ? x.nameAr : x.name}</Link> },
          { header: t("admin.team.colLead"), cell: (x) => x.lead?.name ?? "—" },
          { header: t("admin.team.colMembers"), className: "tabular-nums", cell: (x) => x._count.memberships },
          { header: t("admin.team.colStatus"), cell: (x) => <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">{t(x.status === "ACTIVE" ? "statuses.ACTIVE" : "statuses.ARCHIVED")}</span> },
        ]}
      />
    </>
  );
}
