import { TriangleAlert } from "lucide-react";
import { saveSettingsAction } from "@/app/actions/admin-site";
import { ActionForm, Field, NATIVE_SELECT } from "@/components/admin/forms";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { Input } from "@/components/ui/input";
import { requirePermission } from "@/lib/auth/dal";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { APPLICATION_FIELD_KEYS, SETTING_KEYS, getRequiredApplicationFields, getSettings } from "@/lib/settings";

export const dynamic = "force-dynamic";
const CHECK = "size-5 rounded border-input accent-[var(--color-primary)]";

export default async function SettingsPage() {
  const ctx = await requirePermission("admin.settings.manage", { next: "/admin/settings" });
  const t = getTranslations(await resolveLocale(ctx.locale === "AR" ? "ar" : "en"));
  const [s, required] = await Promise.all([getSettings(), getRequiredApplicationFields()]);
  const str = (k: string) => (typeof s[k] === "string" ? (s[k] as string) : "");
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";

  return (
    <>
      <PageHeader title={t("admin.settings")} />
      <div role="note" className="flex gap-3 rounded-xl border border-warning-500/30 bg-warning-50 p-4 text-sm text-warning-700 dark:bg-warning-500/10 dark:text-warning-500">
        <TriangleAlert className="mt-0.5 size-4 shrink-0" aria-hidden />
        <div><p className="font-semibold">{t("admin.set.youtubeNoticeTitle")}</p><p>{t("admin.set.youtubeNotice")}</p></div>
      </div>

      <ActionForm action={saveSettingsAction} className="space-y-6">
        <fieldset className={box}>
          <SectionHeading as="h2" title={t("admin.set.general")} />
          <div className="grid gap-4 sm:grid-cols-2">
            <Field name="siteName" label={t("admin.set.siteName")} required>{(p) => <Input {...p} defaultValue={str(SETTING_KEYS.SITE_NAME)} maxLength={80} className="h-10" />}</Field>
            <Field name="tagline" label={t("admin.set.tagline")}>{(p) => <Input {...p} defaultValue={str(SETTING_KEYS.TAGLINE)} maxLength={160} className="h-10" />}</Field>
            <Field name="contactEmail" label={t("admin.set.contactEmail")} required>{(p) => <Input {...p} type="email" dir="ltr" defaultValue={str(SETTING_KEYS.CONTACT_EMAIL)} className="h-10" />}</Field>
            <Field name="contactPhone" label={t("admin.set.contactPhone")}>{(p) => <Input {...p} type="tel" dir="ltr" defaultValue={str(SETTING_KEYS.CONTACT_PHONE)} maxLength={40} className="h-10" />}</Field>
          </div>
          <Field name="address" label={t("admin.set.address")}>{(p) => <Input {...p} defaultValue={str(SETTING_KEYS.ADDRESS)} maxLength={200} className="h-10" />}</Field>
        </fieldset>

        <fieldset className={box}>
          <SectionHeading as="h2" title={t("admin.set.membership")} />
          <Field name="registrationOpen" label={t("admin.set.registrationOpen")}>{(p) => <input {...p} type="checkbox" defaultChecked={s[SETTING_KEYS.REGISTRATION_OPEN] !== false} className={CHECK} />}</Field>
          <div className="space-y-2">
            <p className="text-sm font-medium">{t("admin.set.requiredFields")}</p>
            <div className="flex flex-wrap gap-x-6 gap-y-2">
              {APPLICATION_FIELD_KEYS.map((k) => (
                <label key={k} className="flex items-center gap-2 text-sm"><input type="checkbox" name="requiredFields" value={k} defaultChecked={required.includes(k)} className={CHECK} /> {t(`admin.set.fields.${k}` as TranslationKey)}</label>
              ))}
            </div>
          </div>
          <Field name="welcomeXp" label={t("admin.set.welcomeXp")}>{(p) => <Input {...p} type="number" min={0} max={10000} defaultValue={typeof s[SETTING_KEYS.XP_WELCOME] === "number" ? (s[SETTING_KEYS.XP_WELCOME] as number) : 25} className="h-10 w-40" />}</Field>
        </fieldset>

        <fieldset className={box}>
          <SectionHeading as="h2" title={t("admin.set.leaderboard")} />
          <Field name="leaderboardPublic" label={t("admin.set.leaderboardPublic")}>{(p) => <input {...p} type="checkbox" defaultChecked={s[SETTING_KEYS.LEADERBOARD_PUBLIC] !== false} className={CHECK} />}</Field>
          <Field name="leaderboardPeriod" label={t("admin.set.leaderboardPeriod")}>
            {(p) => (
              <select {...p} defaultValue={str(SETTING_KEYS.LEADERBOARD_PERIOD) || "monthly"} className={`${NATIVE_SELECT} max-w-56`}>
                {(["weekly", "monthly", "all_time"] as const).map((x) => <option key={x} value={x}>{t(`admin.set.periods.${x}` as TranslationKey)}</option>)}
              </select>
            )}
          </Field>
        </fieldset>
      </ActionForm>
    </>
  );
}
