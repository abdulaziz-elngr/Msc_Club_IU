import { notFound } from "next/navigation";
import { decideApplicationAction } from "@/app/actions/admin-people";
import { ActionForm, Field } from "@/components/admin/forms";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { can, requirePermission } from "@/lib/auth/dal";
import { TRANSITIONS } from "@/lib/applications";
import { formatDateTime } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getApplication } from "@/lib/queries/admin-people";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";

const ANSWER_KEYS = [["motivation", "admin.app.motivation"], ["interests", "admin.app.interests"]] as const;

export default async function ApplicationPage({ params }: { params: Promise<{ id: string }> }) {
  const { id: raw } = await params;
  const ctx = await requirePermission("applications.read", { next: `/admin/applications/${raw}` });
  const id = recordId.safeParse(raw);
  if (!id.success) notFound();
  const app = await getApplication(id.data);
  if (!app) notFound();

  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const answers = (app.answers && typeof app.answers === "object" ? app.answers : {}) as Record<string, unknown>;
  const next = TRANSITIONS[app.status];
  const mayReview = can(ctx, "applications.review") && next.includes("UNDER_REVIEW");
  const mayDecide = can(ctx, "applications.decide") && (next.includes("ACCEPTED") || next.includes("REJECTED"));
  const box = "space-y-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10";

  return (
    <>
      <PageHeader title={app.user.name} description={`${app.user.email} · ${t(`statuses.${app.status}` as TranslationKey)}`} />

      <section className={box} aria-labelledby="ans">
        <SectionHeading as="h2" id="ans" title={t("admin.app.answers")} />
        <dl className="space-y-3 text-sm">
          {ANSWER_KEYS.map(([key, label]) => {
            const v = answers[key];
            return typeof v === "string" && v ? (
              <div key={key}><dt className="text-xs text-muted-foreground">{t(label as TranslationKey)}</dt><dd className="whitespace-pre-line">{v}</dd></div>
            ) : null;
          })}
          {app.track ? <div><dt className="text-xs text-muted-foreground">{t("admin.app.colTrack")}</dt><dd>{locale === "ar" && app.track.nameAr ? app.track.nameAr : app.track.name}</dd></div> : null}
          {app.user.studentId ? <div><dt className="text-xs text-muted-foreground">{t("admin.mem.colStudent")}</dt><dd dir="ltr">{app.user.studentId}</dd></div> : null}
          {app.user.department ? <div><dt className="text-xs text-muted-foreground">{t("admin.mem.department")}</dt><dd>{app.user.department}</dd></div> : null}
          {!ANSWER_KEYS.some(([k]) => typeof answers[k] === "string" && answers[k]) ? <p className="text-muted-foreground">{t("admin.app.noAnswers")}</p> : null}
        </dl>
      </section>

      {mayReview || mayDecide ? (
        <section className={box} aria-labelledby="decide">
          <SectionHeading as="h2" id="decide" title={t("admin.decisionNote")} />
          <ActionForm action={decideApplicationAction.bind(null, app.id)} hideSubmit successKey="admin.ui.saved">
            <Field name="note" label={t("admin.app.noteLabel")} hint={t("admin.app.noteRequiredHint")}>{(p) => <Textarea {...p} rows={4} maxLength={1000} />}</Field>
            <div className="flex flex-wrap gap-2">
              {mayReview ? <Button type="submit" name="to" value="UNDER_REVIEW" variant="outline">{app.status === "REJECTED" ? t("admin.app.reopen") : t("admin.app.startReview")}</Button> : null}
              {mayDecide && next.includes("ACCEPTED") ? <Button type="submit" name="to" value="ACCEPTED">{t("admin.app.accept")}</Button> : null}
              {mayDecide && next.includes("REJECTED") ? <Button type="submit" name="to" value="REJECTED" variant="destructive">{t("admin.app.rejectAction")}</Button> : null}
            </div>
          </ActionForm>
        </section>
      ) : null}

      <section className={box} aria-labelledby="hist">
        <SectionHeading as="h2" id="hist" title={t("admin.app.history")} />
        <ol className="space-y-3 text-sm">
          {app.history.map((h) => (
            <li key={h.id} className="border-s-2 border-primary/30 ps-3">
              <p className="font-medium">{h.fromStatus ? `${t(`statuses.${h.fromStatus}` as TranslationKey)} → ` : ""}{t(`statuses.${h.toStatus}` as TranslationKey)}</p>
              <p className="text-xs text-muted-foreground">{formatDateTime(h.createdAt, locale)}{h.actorId && app.actors[h.actorId] ? ` · ${t("admin.app.by", { name: app.actors[h.actorId] })}` : ""}</p>
              {h.note ? <p className="mt-1 whitespace-pre-line text-muted-foreground">{h.note}</p> : null}
            </li>
          ))}
          {app.history.length === 0 ? <li className="text-muted-foreground">{t("common.emptyBody")}</li> : null}
        </ol>
      </section>
    </>
  );
}
