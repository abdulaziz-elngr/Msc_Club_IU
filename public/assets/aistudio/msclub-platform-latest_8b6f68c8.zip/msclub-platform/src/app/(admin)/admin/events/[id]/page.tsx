import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Download, ExternalLink, ScanLine } from "lucide-react";
import {
  addReminderAction, adminCancelRegistrationAction, correctAttendanceAction, deleteEventAction, deleteReminderAction,
  fillWaitlistAction, manualCheckInAction, saveEventAction, saveFormFieldsAction, setRotatingQrAction,
} from "@/app/actions/admin-events";
import { AttendanceCorrection } from "@/components/admin/events/attendance-correction";
import { EventForm, type EventFormValues } from "@/components/admin/events/event-form";
import { FormBuilder } from "@/components/admin/events/form-builder";
import { RotatingQr } from "@/components/admin/events/rotating-qr";
import { ActionForm, ConfirmAction, Field, QuickAction } from "@/components/admin/forms";
import { DataTable } from "@/components/admin/table";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { can, requirePermission } from "@/lib/auth/dal";
import { formatDateTime } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getAdminEvent } from "@/lib/queries/admin-events";
import { recordId } from "@/lib/validation";

export const dynamic = "force-dynamic";
type Params = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { id } = await params;
  return { title: getTranslations(await resolveLocale())("admin.ev.editEvent") + ` · ${id.slice(0, 6)}` };
}

const iso = (d: Date | null) => (d ? d.toISOString() : "");

export default async function AdminEventPage({ params }: Params) {
  const { id: rawId } = await params;
  const ctx = await requirePermission("events.read", { next: `/admin/events/${rawId}` });
  const parsedId = recordId.safeParse(rawId);
  if (!parsedId.success) notFound();
  const data = await getAdminEvent(parsedId.data);
  if (!data) notFound();

  const { event, registrations, attendance, teams, stats, cap } = data;
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const mayUpdate = can(ctx, "events.update");
  const mayRegs = can(ctx, "events.manage_registrations");
  const mayAttend = can(ctx, "events.manage_attendance");
  const mayCorrect = can(ctx, "events.correct_attendance");

  const values: EventFormValues = {
    title: event.title, titleAr: event.titleAr ?? "", slug: event.slug, summary: event.summary ?? "",
    description: event.description ?? "", descriptionAr: event.descriptionAr ?? "", category: event.category, status: event.status,
    isOnline: event.isOnline, location: event.location ?? "", onlineUrl: event.onlineUrl ?? "",
    startsAt: iso(event.startsAt), endsAt: iso(event.endsAt), registrationOpensAt: iso(event.registrationOpensAt), registrationClosesAt: iso(event.registrationClosesAt),
    capacity: event.capacity?.toString() ?? "", waitlistEnabled: event.waitlistEnabled, attendancePoints: event.attendancePoints,
    completionPoints: event.completionPoints, certificateEnabled: event.certificateEnabled, speakerName: event.speakerName ?? "",
    speakerTitle: event.speakerTitle ?? "", speakerBio: event.speakerBio ?? "", teamId: event.teamId ?? "",
    rotatingQrEnabled: event.rotatingQrEnabled, qrRotateSeconds: event.qrRotateSeconds,
  };
  const title = locale === "ar" && event.titleAr ? event.titleAr : event.title;
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";

  return (
    <>
      <PageHeader
        title={title}
        description={`${t(`statuses.${event.status}` as TranslationKey)} · ${formatDateTime(event.startsAt, locale)}`}
        actions={
          <div className="flex flex-wrap gap-2">
            {mayAttend ? <Button asChild size="sm"><Link href={`/events/${event.id}/check-in`}><ScanLine className="size-4" aria-hidden /> {t("admin.ev.openScanner")}</Link></Button> : null}
            {event.publishedAt ? <Button asChild variant="outline" size="sm"><Link href={`/events/${event.slug}`}><ExternalLink className="size-4" aria-hidden /> {t("admin.ev.viewPublic")}</Link></Button> : null}
          </div>
        }
      />

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label={t("admin.ev.registered")} value={String(stats.confirmed)} tone="brand" />
        <StatCard label={t("admin.ev.waitlisted")} value={String(stats.waitlisted)} tone={stats.waitlisted > 0 ? "warning" : "neutral"} />
        <StatCard label={t("admin.ev.checkedInCount")} value={String(stats.present)} tone="success" />
        <StatCard label={t("admin.ev.seats")} value={event.capacity === null ? t("admin.ev.unlimited") : `${stats.confirmed} / ${event.capacity}`} tone="neutral" />
      </div>

      {mayUpdate ? <EventForm action={saveEventAction.bind(null, event.id)} values={values} teams={teams} isNew={false} /> : null}

      <section className={box} aria-labelledby="regs">
        <SectionHeading as="h2" id="regs" title={`${t("admin.ev.registrations")} (${registrations.length}${registrations.length >= cap ? "+" : ""})`}
          actions={
            <div className="flex flex-wrap gap-2">
              {mayRegs && stats.waitlisted > 0 ? <QuickAction action={fillWaitlistAction.bind(null, event.id)}>{t("admin.ev.fillWaitlist")}</QuickAction> : null}
              {can(ctx, "events.export_registrations") ? (
                <>
                  <Button asChild variant="outline" size="sm"><a href={`/api/events/${event.id}/export?type=registrations`}><Download className="size-4" aria-hidden /> {t("admin.ev.exportRegistrations")}</a></Button>
                  <Button asChild variant="outline" size="sm"><a href={`/api/events/${event.id}/export?type=attendance`}><Download className="size-4" aria-hidden /> {t("admin.ev.exportAttendance")}</a></Button>
                </>
              ) : null}
            </div>
          }
        />
        <DataTable
          rows={registrations}
          empty={<p className="text-sm text-muted-foreground">{t("admin.ev.noRegistrations")}</p>}
          columns={[
            { header: t("common.name"), cell: (r) => <span className="font-medium">{r.user.name}</span> },
            { header: t("admin.ev.student"), cell: (r) => <span dir="ltr" className="tabular-nums text-muted-foreground">{r.user.studentId ?? "—"}</span> },
            { header: t("common.status"), cell: (r) => `${t(`statuses.${r.status}` as TranslationKey)}${r.waitlistPos ? ` #${r.waitlistPos}` : ""}` },
            { header: t("common.date"), cell: (r) => <span className="whitespace-nowrap text-muted-foreground">{formatDateTime(r.createdAt, locale)}</span> },
            {
              header: t("common.actions"),
              cell: (r) => (
                <div className="flex flex-wrap gap-2">
                  {mayAttend && r.status === "CONFIRMED" && !r.checkedInAt ? (
                    <QuickAction action={manualCheckInAction.bind(null, event.id, r.user.id)}>{t("admin.ev.checkIn")}</QuickAction>
                  ) : null}
                  {mayRegs && (r.status === "CONFIRMED" || r.status === "WAITLISTED") && !r.checkedInAt ? (
                    <ConfirmAction variant="ghost" label={t("admin.ev.cancelRegistration")} action={adminCancelRegistrationAction.bind(null, event.id, r.user.id)} />
                  ) : null}
                </div>
              ),
            },
          ]}
        />
      </section>

      <section className={box} aria-labelledby="att">
        <SectionHeading as="h2" id="att" title={t("admin.ev.attendanceReport")} />
        <DataTable
          rows={attendance}
          empty={<p className="text-sm text-muted-foreground">{t("admin.ev.noAttendance")}</p>}
          columns={[
            { header: t("common.name"), cell: (a) => <span className="font-medium">{a.user.name}</span> },
            { header: t("admin.ev.student"), cell: (a) => <span dir="ltr" className="tabular-nums text-muted-foreground">{a.user.studentId ?? "—"}</span> },
            { header: t("common.status"), cell: (a) => t(`admin.ev.attStatus.${a.status}` as TranslationKey) },
            { header: t("admin.ev.method"), cell: (a) => a.method },
            { header: t("common.points"), className: "tabular-nums", cell: (a) => a.pointsAwarded },
            { header: t("common.time"), cell: (a) => <span className="whitespace-nowrap text-muted-foreground">{formatDateTime(a.createdAt, locale)}</span> },
            { header: t("common.actions"), cell: (a) => (mayCorrect ? <AttendanceCorrection action={correctAttendanceAction.bind(null, a.id)} current={a.status} /> : null) },
          ]}
        />
      </section>

      {mayUpdate ? (
        <section className={box} aria-labelledby="builder">
          <SectionHeading as="h2" id="builder" title={t("admin.ev.formBuilder")} />
          <FormBuilder
            action={saveFormFieldsAction.bind(null, event.id)}
            initial={event.formFields.map((f) => ({ key: f.key, label: f.label, labelAr: f.labelAr ?? "", type: f.type, options: f.options.join("\n"), required: f.required }))}
          />
        </section>
      ) : null}

      {mayUpdate ? (
        <section className={box} aria-labelledby="rem">
          <SectionHeading as="h2" id="rem" title={t("admin.ev.reminders")} />
          <p className="text-sm text-muted-foreground">{t("admin.ev.remindersHint")}</p>
          <ul className="divide-y text-sm">
            {event.reminders.map((r) => (
              <li key={r.id} className="flex items-center justify-between gap-3 py-2">
                <span>{formatDateTime(r.sendAt, locale)} · <span className="text-muted-foreground">{r.sentAt ? t("admin.ev.reminderSent") : t("admin.ev.reminderPending")}</span></span>
                {!r.sentAt ? <ConfirmAction variant="ghost" label={t("common.delete")} action={deleteReminderAction.bind(null, r.id)} successKey="admin.ui.deleted" /> : null}
              </li>
            ))}
          </ul>
          <ActionForm action={addReminderAction.bind(null, event.id)} submitLabel={t("admin.ev.addReminder")} className="flex flex-wrap items-end gap-3 space-y-0" resetOnSuccess>
            <Field name="hoursBefore" label={t("admin.ev.hoursBefore")} required>{(p) => <Input {...p} type="number" min={1} max={336} defaultValue={24} className="h-10 w-32" />}</Field>
          </ActionForm>
        </section>
      ) : null}

      {mayAttend ? (
        <section className={box} aria-labelledby="rot">
          <SectionHeading as="h2" id="rot" title={t("admin.ev.rotatingTitle")} />
          <p className="text-sm text-muted-foreground">{t("admin.ev.rotatingHint")}</p>
          {event.rotatingQrEnabled ? (
            <>
              <RotatingQr eventId={event.id} />
              <QuickAction action={setRotatingQrAction.bind(null, event.id, false, event.qrRotateSeconds)}>{t("admin.ev.rotatingDisable")}</QuickAction>
            </>
          ) : (
            <div className="flex flex-wrap items-center gap-3">
              <p className="text-sm text-muted-foreground">{t("admin.ev.rotatingOff")}</p>
              <QuickAction action={setRotatingQrAction.bind(null, event.id, true, event.qrRotateSeconds)}>{t("admin.ev.rotatingEnable")}</QuickAction>
            </div>
          )}
        </section>
      ) : null}

      {can(ctx, "events.delete") ? (
        <section className={box}>
          <ConfirmAction variant="destructive" label={t("admin.ev.deleteEvent")} title={t("admin.ev.deleteTitle")} description={t("admin.ev.deleteBody")} action={deleteEventAction.bind(null, event.id)} successKey="admin.ui.deleted" />
        </section>
      ) : null}
    </>
  );
}
