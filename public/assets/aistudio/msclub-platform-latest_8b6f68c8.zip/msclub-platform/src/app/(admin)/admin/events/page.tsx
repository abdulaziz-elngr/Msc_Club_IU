import Link from "next/link";
import type { Metadata } from "next";
import { CalendarX2, Plus } from "lucide-react";
import { DataTable, PAGE_SIZE, Pagination, parsePage } from "@/components/admin/table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { can, requirePermission } from "@/lib/auth/dal";
import { formatDateTime } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { listAdminEvents } from "@/lib/queries/admin-events";
import { EVENT_STATUSES } from "@/lib/schemas/event";
import { NATIVE_SELECT } from "@/components/admin/forms";

export const dynamic = "force-dynamic";
const pick = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("admin.events") };
}

export default async function AdminEventsPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const ctx = await requirePermission("events.read", { next: "/admin/events" });
  const sp = await searchParams;
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  const q = pick(sp.q)?.trim().slice(0, 80) || undefined;
  const statusRaw = pick(sp.status);
  const status = (EVENT_STATUSES as readonly string[]).includes(statusRaw ?? "") ? statusRaw : undefined;
  const page = parsePage(sp.page);
  const { rows, total, pages } = await listAdminEvents({ q, status, page });

  return (
    <>
      <PageHeader
        title={t("admin.events")}
        actions={can(ctx, "events.create") ? <Button asChild size="sm"><Link href="/admin/events/new"><Plus className="size-4" aria-hidden /> {t("admin.ev.newEvent")}</Link></Button> : undefined}
      />
      <form className="flex flex-wrap gap-2" role="search">
        <Input name="q" defaultValue={q} placeholder={t("admin.ui.searchPlaceholder")} aria-label={t("common.search")} className="h-10 max-w-xs" />
        <select name="status" defaultValue={status ?? ""} aria-label={t("admin.ev.statusFilter")} className={`${NATIVE_SELECT} max-w-48`}>
          <option value="">{t("common.all")}</option>
          {EVENT_STATUSES.map((s) => <option key={s} value={s}>{t(`statuses.${s}` as TranslationKey)}</option>)}
        </select>
        <Button type="submit" variant="outline">{t("common.filter")}</Button>
      </form>

      <DataTable
        caption={t("admin.events")}
        rows={rows}
        empty={<EmptyState icon={CalendarX2} title={t("admin.ev.listEmpty")} />}
        columns={[
          { header: t("admin.ev.colTitle"), cell: (e) => <Link href={`/admin/events/${e.id}`} className="font-medium hover:text-primary">{locale === "ar" && e.titleAr ? e.titleAr : e.title}</Link> },
          { header: t("admin.ev.colDate"), cell: (e) => <span className="whitespace-nowrap text-muted-foreground">{formatDateTime(e.startsAt, locale)}</span> },
          { header: t("admin.ev.colStatus"), cell: (e) => <span className="rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium">{t(`statuses.${e.status}` as TranslationKey)}</span> },
          { header: t("admin.ev.colRegistered"), className: "tabular-nums", cell: (e) => (e.capacity ? `${e._count.registrations} / ${e.capacity}` : e._count.registrations) },
        ]}
      />
      <Pagination page={page} pages={pages} total={total} basePath="/admin/events" params={{ q, status }}
        labels={{ previous: t("admin.ui.previous"), next: t("admin.ui.next"), summary: `${(page - 1) * PAGE_SIZE + Math.min(rows.length, 1)}–${(page - 1) * PAGE_SIZE + rows.length} ${t("common.of")} ${total}` }} />
    </>
  );
}
