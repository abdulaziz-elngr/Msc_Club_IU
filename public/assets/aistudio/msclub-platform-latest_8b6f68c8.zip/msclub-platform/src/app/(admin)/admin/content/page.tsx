import { deleteTestimonialAction, saveSocialLinksAction, saveTestimonialAction } from "@/app/actions/admin-site";
import { ActionForm, ConfirmAction, Field } from "@/components/admin/forms";
import { EMPTY_TESTIMONIAL, TestimonialForm } from "@/components/admin/content/testimonial-form";
import { PageHeader, SectionHeading } from "@/components/shared/page-header";
import { Input } from "@/components/ui/input";
import { can, requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getSocialLinks } from "@/lib/settings";

export const dynamic = "force-dynamic";
const NETWORKS = ["instagram", "linkedin", "youtube", "github", "x", "discord"] as const;

export default async function ContentPage() {
  const ctx = await requirePermission("content.manage", { next: "/admin/content" });
  const t = getTranslations(await resolveLocale(ctx.locale === "AR" ? "ar" : "en"));
  const [social, testimonials] = await Promise.all([getSocialLinks(), db.testimonial.findMany({ orderBy: [{ order: "asc" }, { createdAt: "desc" }] })]);
  const box = "space-y-4 rounded-xl bg-card p-5 ring-1 ring-foreground/10";
  const mayTestimonials = can(ctx, "content.testimonials.manage");

  return (
    <>
      <PageHeader title={t("admin.content")} />
      <section className={box} aria-labelledby="soc">
        <SectionHeading as="h2" id="soc" title={t("admin.cnt.social")} description={t("admin.cnt.socialHint")} />
        <ActionForm action={saveSocialLinksAction} submitLabel={t("admin.cnt.save")}>
          <div className="grid gap-4 sm:grid-cols-2">
            {NETWORKS.map((n) => <Field key={n} name={n} label={n[0].toUpperCase() + n.slice(1)}>{(p) => <Input {...p} type="url" dir="ltr" placeholder="https://" defaultValue={social[n] ?? ""} maxLength={300} className="h-10" />}</Field>)}
          </div>
        </ActionForm>
      </section>

      {mayTestimonials ? (
        <section className={box} aria-labelledby="tes">
          <SectionHeading as="h2" id="tes" title={t("admin.cnt.testimonials")} />
          {testimonials.length === 0 ? <p className="text-sm text-muted-foreground">{t("admin.cnt.noTestimonials")}</p> : null}
          <ul className="space-y-4">
            {testimonials.map((x) => (
              <li key={x.id} className="space-y-3 rounded-lg border p-4">
                <TestimonialForm action={saveTestimonialAction.bind(null, x.id)} isNew={false} values={{ name: x.name, nameAr: x.nameAr ?? "", role: x.role ?? "", roleAr: x.roleAr ?? "", quote: x.quote, quoteAr: x.quoteAr ?? "", approved: x.approved, order: x.order }} />
                <ConfirmAction variant="ghost" label={t("common.delete")} title={t("admin.cnt.deleteTitle")} action={deleteTestimonialAction.bind(null, x.id)} successKey="admin.ui.deleted" />
              </li>
            ))}
          </ul>
          <h3 className="pt-2 text-sm font-semibold">{t("admin.cnt.newTestimonial")}</h3>
          <TestimonialForm action={saveTestimonialAction.bind(null, null)} isNew values={EMPTY_TESTIMONIAL} />
        </section>
      ) : null}
    </>
  );
}
