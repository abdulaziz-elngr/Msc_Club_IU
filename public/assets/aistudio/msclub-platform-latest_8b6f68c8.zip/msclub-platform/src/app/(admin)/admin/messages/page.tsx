import { Inbox, Mail } from "lucide-react";
import { setMessageReadAction } from "@/app/actions/admin-site";
import { QuickAction } from "@/components/admin/forms";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { Button } from "@/components/ui/button";
import { requirePermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { formatDateTime } from "@/lib/format";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";

export const dynamic = "force-dynamic";

export default async function MessagesPage() {
  const ctx = await requirePermission("content.manage", { next: "/admin/messages" });
  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);
  const messages = await db.contactMessage.findMany({ orderBy: [{ readAt: { sort: "asc", nulls: "first" } }, { createdAt: "desc" }], take: 100 });

  return (
    <>
      <PageHeader title={t("admin.msg.title")} />
      {messages.length === 0 ? <EmptyState icon={Inbox} title={t("admin.msg.empty")} /> : (
        <ul className="space-y-3">
          {messages.map((m) => (
            <li key={m.id} className="space-y-2 rounded-xl bg-card p-4 ring-1 ring-foreground/10">
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="flex items-center gap-2 text-sm font-semibold">{!m.readAt ? <span className="rounded-full bg-primary px-2 py-0.5 text-[0.65rem] font-medium text-primary-foreground">{t("admin.msg.unread")}</span> : null}{m.subject}</p>
                  <p className="text-xs text-muted-foreground">{m.name} · <span dir="ltr">{m.email}</span> · {formatDateTime(m.createdAt, locale)}</p>
                </div>
                <div className="flex gap-2">
                  {/* mailto: with an encoded subject — message text is never interpolated into a URL. */}
                  <Button asChild variant="outline" size="sm"><a href={`mailto:${encodeURIComponent(m.email)}?subject=${encodeURIComponent(`Re: ${m.subject}`)}`}><Mail className="size-4" aria-hidden /> {t("admin.msg.replyByEmail")}</a></Button>
                  <QuickAction action={setMessageReadAction.bind(null, m.id, !m.readAt)}>{m.readAt ? t("admin.msg.markUnread") : t("admin.msg.markRead")}</QuickAction>
                </div>
              </div>
              <p className="text-sm whitespace-pre-line">{m.message}</p>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
