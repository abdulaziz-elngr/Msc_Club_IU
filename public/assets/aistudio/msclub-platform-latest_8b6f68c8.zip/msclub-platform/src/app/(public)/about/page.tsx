import type { Metadata } from "next";
import { CheckCircle2 } from "lucide-react";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { formatNumber } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getCommunityStats } from "@/lib/queries/about";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("nav.about") };
}

const OBJECTIVES = ["about.objective1", "about.objective2", "about.objective3", "about.objective4"] as const;
const GAINS = ["about.gain1", "about.gain2", "about.gain3", "about.gain4"] as const;

type Translate = ReturnType<typeof getTranslations>;

function BulletSection({ title, keys, t }: { title: string; keys: readonly TranslationKey[]; t: Translate }) {
  return (
    <section className="space-y-4">
      <h2 className="text-lg font-semibold">{title}</h2>
      <ul className="space-y-3">
        {keys.map((key) => (
          <li key={key} className="flex gap-3 text-sm text-muted-foreground">
            <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
            <span>{t(key)}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}

export default async function AboutPage() {
  const locale = await resolveLocale();
  const t = getTranslations(locale);
  const stats = await getCommunityStats();

  return (
    <div className="mx-auto max-w-5xl space-y-12 px-4 py-10 sm:px-6 lg:px-8">
      <PageHeader title={t("nav.about")} description={t("common.tagline")} />

      <div className="grid gap-6 md:grid-cols-2">
        <section className="space-y-2 rounded-xl bg-card p-6 ring-1 ring-foreground/10">
          <h2 className="text-lg font-semibold">{t("about.missionTitle")}</h2>
          <p className="text-sm leading-relaxed text-muted-foreground">{t("about.missionBody")}</p>
        </section>
        <section className="space-y-2 rounded-xl bg-card p-6 ring-1 ring-foreground/10">
          <h2 className="text-lg font-semibold">{t("about.visionTitle")}</h2>
          <p className="text-sm leading-relaxed text-muted-foreground">{t("about.visionBody")}</p>
        </section>
      </div>

      <div className="grid gap-10 md:grid-cols-2">
        <BulletSection title={t("about.objectivesTitle")} keys={OBJECTIVES} t={t} />
        <BulletSection title={t("about.gainsTitle")} keys={GAINS} t={t} />
      </div>

      <section aria-labelledby="achievements" className="space-y-4">
        <h2 id="achievements" className="text-lg font-semibold">{t("about.achievementsTitle")}</h2>
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label={t("about.statMembers")} value={formatNumber(stats.members, locale)} tone="brand" />
          <StatCard label={t("nav.events")} value={formatNumber(stats.events, locale)} tone="brand" />
          <StatCard label={t("dashboard.eventsAttended")} value={formatNumber(stats.attendees, locale)} tone="brand" />
          <StatCard label={t("learning.courses")} value={formatNumber(stats.courses, locale)} tone="brand" />
        </div>
      </section>
    </div>
  );
}
