import { notFound, redirect } from "next/navigation";
import { ForbiddenError, assertPermission, requireAuth } from "@/lib/auth/dal";
import { findEventByIdOrSlug } from "@/lib/queries/admin-events";

export const dynamic = "force-dynamic";

/** `/events/[id]/manage` is the spec'd entry point; the console itself lives under /admin. */
export default async function ManageRedirect({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const ctx = await requireAuth(`/events/${slug}/manage`);
  try {
    assertPermission(ctx, "events.read");
  } catch (e) {
    if (e instanceof ForbiddenError) notFound();
    throw e;
  }
  const event = await findEventByIdOrSlug(slug);
  if (!event) notFound();
  redirect(`/admin/events/${event.id}`);
}
