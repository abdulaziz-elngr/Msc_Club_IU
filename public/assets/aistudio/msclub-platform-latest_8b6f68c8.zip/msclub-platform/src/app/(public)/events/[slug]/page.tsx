import Link from "next/link";
import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { Award, CalendarDays, MapPin, Monitor, Users, Zap } from "lucide-react";
import { RegistrationPanel } from "@/components/events/registration-panel";
import { Badge } from "@/components/ui/badge";
import { getAuthContext } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { formatDateTime } from "@/lib/format";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getPublicEvent, registrationWindow } from "@/lib/queries/events";
import { waitlistRank } from "@/lib/registration";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const { slug } = await params;
  const event = await getPublicEvent(slug);
  if (!event) return {};
  const locale = await resolveLocale();
  return { title: locale === "ar" && event.titleAr ? event.titleAr : event.title, description: event.summary ?? undefined };
}

export default async function EventDetailPage({ params }: Params) {
  const { slug } = await params;
  const event = await getPublicEvent(slug);
  if (!event) notFound();

  const locale = await resolveLocale();
  const t = getTranslations(locale);
  const ctx = await getAuthContext();

  // The member's own registration is read here, on the server, by session id.
  const mine = ctx
    ? await db.eventRegistration.findUnique({
        where: { eventId_userId: { eventId: event.id, userId: ctx.userId } },
        select: { status: true, checkedInAt: true },
      })
    : null;
  const live = mine && (mine.status === "CONFIRMED" || mine.status === "WAITLISTED") ? mine : null;
  const position = live?.status === "WAITLISTED" && ctx ? await waitlistRank(event.id, ctx.userId) : null;

  const title = locale === "ar" && event.titleAr ? event.titleAr : event.title;
  const description = locale === "ar" && event.descriptionAr ? event.descriptionAr : event.description;
  const taken = event._count.registrations;
  const seatsLeft = event.capacity === null ? null : Math.max(0, event.capacity - taken);
  const full = seatsLeft === 0;

  return (
    <article className="mx-auto max-w-6xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <header className="max-w-3xl space-y-3">
        <div className="flex flex-wrap items-center gap-2">
          <Badge variant="outline" className="border-primary/30 bg-primary/5 text-primary">
            {t(`events.categories.${event.category}` as TranslationKey)}
          </Badge>
          {event.status === "CANCELLED" ? <Badge variant="destructive">{t("statuses.CANCELLED")}</Badge> : null}
        </div>
        <h1 className="text-3xl font-semibold tracking-tight text-balance sm:text-4xl">{title}</h1>
        {event.summary ? <p className="text-base text-muted-foreground">{event.summary}</p> : null}
      </header>

      <div className="grid gap-8 lg:grid-cols-[1fr_22rem]">
        <div className="space-y-8">
          <section aria-labelledby="when-where" className="rounded-xl bg-card p-5 ring-1 ring-foreground/10">
            <h2 id="when-where" className="mb-4 text-base font-semibold">{t("events.whenWhere")}</h2>
            <dl className="grid gap-4 text-sm sm:grid-cols-2">
              <div className="flex gap-3">
                <CalendarDays className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                <div>
                  <dt className="text-muted-foreground">{t("events.starts")}</dt>
                  <dd className="font-medium">{formatDateTime(event.startsAt, locale)}</dd>
                  <dt className="mt-2 text-muted-foreground">{t("events.ends")}</dt>
                  <dd className="font-medium">{formatDateTime(event.endsAt, locale)}</dd>
                </div>
              </div>
              <div className="flex gap-3">
                {event.isOnline ? <Monitor className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden /> : <MapPin className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />}
                <div>
                  <dt className="text-muted-foreground">{t("common.location")}</dt>
                  {/* The join URL of online events is deliberately never rendered publicly. */}
                  <dd className="font-medium">{event.isOnline ? t("events.online") : (event.location ?? t("events.tba"))}</dd>
                </div>
              </div>
              <div className="flex gap-3">
                <Users className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                <div>
                  <dt className="text-muted-foreground">{t("events.capacity")}</dt>
                  <dd className="font-medium">
                    {event.capacity === null ? t("events.registeredCount", { count: taken }) : `${taken} / ${event.capacity}`}
                    {event.waitlisted > 0 ? ` · ${t("statuses.WAITLISTED")}: ${event.waitlisted}` : ""}
                  </dd>
                </div>
              </div>
              {event.attendancePoints > 0 || event.certificateEnabled ? (
                <div className="flex gap-3">
                  <Zap className="mt-0.5 size-4 shrink-0 text-primary" aria-hidden />
                  <div>
                    <dt className="text-muted-foreground">{t("events.attendancePoints")}</dt>
                    <dd className="flex flex-wrap items-center gap-2 font-medium">
                      {event.attendancePoints} XP
                      {event.certificateEnabled ? <Award className="size-4 text-primary" aria-label={t("nav.certificates")} /> : null}
                    </dd>
                  </div>
                </div>
              ) : null}
            </dl>
          </section>

          {description ? (
            <section aria-labelledby="about-event" className="space-y-3">
              <h2 id="about-event" className="text-lg font-semibold">{t("events.aboutEvent")}</h2>
              {/* Plain text only: admin-authored content is never injected as HTML. */}
              <p className="max-w-prose text-sm leading-relaxed whitespace-pre-line text-muted-foreground">{description}</p>
            </section>
          ) : null}

          {event.speakerName ? (
            <section aria-labelledby="speaker" className="space-y-2">
              <h2 id="speaker" className="text-lg font-semibold">{t("events.speaker")}</h2>
              <p className="text-sm font-medium">{event.speakerName}</p>
              {event.speakerTitle ? <p className="text-sm text-muted-foreground">{event.speakerTitle}</p> : null}
              {event.speakerBio ? <p className="max-w-prose text-sm whitespace-pre-line text-muted-foreground">{event.speakerBio}</p> : null}
            </section>
          ) : null}

          {event.team ? (
            <p className="text-sm text-muted-foreground">
              {t("common.team")}:{" "}
              <Link href={`/teams/${event.team.slug}`} className="font-medium text-primary hover:underline">
                {locale === "ar" && event.team.nameAr ? event.team.nameAr : event.team.name}
              </Link>
            </p>
          ) : null}
        </div>

        <aside className="lg:sticky lg:top-24 lg:self-start" aria-label={t("events.register")}>
          <RegistrationPanel
            eventId={event.id}
            window={registrationWindow(event)}
            signedIn={Boolean(ctx)}
            active={ctx?.isActive ?? false}
            loginHref={`/login?next=${encodeURIComponent(`/events/${event.slug}`)}`}
            registration={
              live
                ? { status: live.status as "CONFIRMED" | "WAITLISTED", position, checkedIn: live.checkedInAt !== null }
                : null
            }
            full={full}
            waitlistEnabled={event.waitlistEnabled}
            seatsLeft={seatsLeft}
            opensAtLabel={event.registrationOpensAt ? formatDateTime(event.registrationOpensAt, locale) : null}
            fields={event.formFields}
          />
        </aside>
      </div>
    </article>
  );
}
