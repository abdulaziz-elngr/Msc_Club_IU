import Link from "next/link";
import type { Metadata } from "next";
import { Trophy } from "lucide-react";
import { LeaderboardTable } from "@/components/shared/leaderboard-table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { getAuthContext } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getLeaderboard, type LeaderboardPeriod, type LeaderboardScope } from "@/lib/queries/leaderboard";
import { SETTING_KEYS, getBoolean, getString } from "@/lib/settings";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";
const pick = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);
const SCOPES: LeaderboardScope[] = ["global", "team", "event", "track"];
const PERIODS: LeaderboardPeriod[] = ["monthly", "weekly", "all"];

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("leaderboard.title") };
}

export default async function LeaderboardPage({ searchParams }: { searchParams: Promise<Record<string, string | string[] | undefined>> }) {
  const sp = await searchParams;
  const locale = await resolveLocale();
  const t = getTranslations(locale);
  const ctx = await getAuthContext();

  // Public visibility is an admin setting; active members can always see it once signed in.
  const isPublic = await getBoolean(SETTING_KEYS.LEADERBOARD_PUBLIC, true);
  if (!isPublic && !ctx?.isActive) {
    return <div className="mx-auto max-w-3xl px-4 py-16"><EmptyState icon={Trophy} title={t("leaderboard.title")} description={t("leaderboard.notPublic")} /></div>;
  }

  const defaultPeriod = (await getString(SETTING_KEYS.LEADERBOARD_PERIOD, "monthly")) === "all_time" ? "all" : ((await getString(SETTING_KEYS.LEADERBOARD_PERIOD, "monthly")) as LeaderboardPeriod);
  const scope = (SCOPES as string[]).includes(pick(sp.scope) ?? "") ? (pick(sp.scope) as LeaderboardScope) : "global";
  const period = (PERIODS as string[]).includes(pick(sp.period) ?? "") ? (pick(sp.period) as LeaderboardPeriod) : PERIODS.includes(defaultPeriod) ? defaultPeriod : "monthly";
  const ref = pick(sp.ref)?.slice(0, 40);

  const [teams, events, tracks] = await Promise.all([
    db.team.findMany({ where: { status: "ACTIVE", visibility: "PUBLIC" }, orderBy: { name: "asc" }, select: { id: true, name: true, nameAr: true } }),
    db.event.findMany({ where: { publishedAt: { not: null }, status: { in: ["COMPLETED", "IN_PROGRESS"] } }, orderBy: { startsAt: "desc" }, take: 30, select: { id: true, title: true, titleAr: true } }),
    db.learningTrack.findMany({ where: { enabled: true, archivedAt: null }, orderBy: { order: "asc" }, select: { id: true, name: true, nameAr: true } }),
  ]);
  const options = scope === "team" ? teams : scope === "event" ? events.map((e) => ({ id: e.id, name: e.title, nameAr: e.titleAr })) : scope === "track" ? tracks : [];
  const validRef = options.some((o) => o.id === ref) ? ref : undefined;
  const rows = await getLeaderboard({ scope, period: scope === "event" ? "all" : period, refId: validRef });

  const href = (next: Record<string, string | undefined>) => {
    const q = new URLSearchParams();
    const merged = { scope, period, ref: validRef, ...next };
    for (const [k, v] of Object.entries(merged)) if (v && !(k === "scope" && v === "global") && !(k === "ref" && next.scope)) q.set(k, v);
    return `/leaderboard${q.toString() ? `?${q}` : ""}`;
  };
  const chip = (active: boolean) => cn("inline-flex h-8 items-center rounded-full px-3.5 text-sm font-medium ring-1 outline-none focus-visible:ring-2 focus-visible:ring-ring", active ? "bg-primary text-primary-foreground ring-primary" : "bg-card ring-foreground/10 hover:ring-primary/40");
  const label = (o: { name: string; nameAr: string | null }) => (locale === "ar" && o.nameAr ? o.nameAr : o.name);

  return (
    <div className="mx-auto max-w-4xl space-y-6 px-4 py-10 sm:px-6">
      <PageHeader title={t("leaderboard.title")} description={t("leaderboard.subtitle")} />
      <nav aria-label={t("leaderboard.title")} className="flex flex-wrap gap-2">
        {SCOPES.map((s) => <Link key={s} href={href({ scope: s, ref: undefined })} className={chip(s === scope)} aria-current={s === scope ? "page" : undefined}>{t(`leaderboard.scope${s[0].toUpperCase()}${s.slice(1)}` as TranslationKey)}</Link>)}
      </nav>
      {scope !== "event" ? (
        <nav aria-label={t("leaderboard.score")} className="flex flex-wrap gap-2">
          {PERIODS.map((p) => <Link key={p} href={href({ period: p })} className={chip(p === period)} aria-current={p === period ? "page" : undefined}>{t(p === "all" ? "leaderboard.allTime" : p === "monthly" ? "leaderboard.monthly" : "leaderboard.weekly")}</Link>)}
        </nav>
      ) : null}
      {options.length > 0 ? (
        <nav aria-label={t("leaderboard.choose")} className="flex flex-wrap gap-2">
          {options.map((o) => <Link key={o.id} href={href({ ref: o.id })} className={chip(o.id === validRef)} aria-current={o.id === validRef ? "page" : undefined}>{label(o)}</Link>)}
        </nav>
      ) : null}

      {rows.length === 0 ? <EmptyState icon={Trophy} title={t("leaderboard.empty")} /> : <LeaderboardTable rows={rows} locale={locale} meId={ctx?.userId} />}
      <p className="text-xs text-muted-foreground">{t("leaderboard.note")}</p>
    </div>
  );
}
