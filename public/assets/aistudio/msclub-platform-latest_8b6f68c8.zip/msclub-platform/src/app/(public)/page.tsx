import Link from "next/link";
import {
  ArrowRight,
  CalendarCheck,
  GraduationCap,
  Sparkles,
  Trophy,
  Users,
  Zap,
} from "lucide-react";
import { Button, buttonVariants } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CourseCard } from "@/components/marketing/course-card";
import { EventCard } from "@/components/marketing/event-card";
import { LeaderboardList } from "@/components/marketing/leaderboard-list";
import { StatsStrip } from "@/components/marketing/stats-strip";
import { TestimonialCard } from "@/components/marketing/testimonial-card";
import { TrackCard } from "@/components/marketing/track-card";
import { SectionHeading } from "@/components/shared/page-header";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import {
  getFeaturedCourses,
  getLeaderboard,
  getPublicStats,
  getPublicTracks,
  getTestimonials,
  getUpcomingEvents,
} from "@/lib/queries/public";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const locale = await resolveLocale();
  const t = getTranslations(locale);

  const [stats, tracks, events, courses, leaderboard, testimonials] = await Promise.all([
    getPublicStats(),
    getPublicTracks(),
    getUpcomingEvents(3),
    getFeaturedCourses(3),
    getLeaderboard(5, "monthly"),
    getTestimonials(3),
  ]);

  return (
    <>
      {/* ---------------------------------------------------------------- hero */}
      <section className="relative overflow-hidden border-b">
        <div className="hero-grid hero-grid-anim pointer-events-none absolute inset-0" aria-hidden />
        <div
          className="pointer-events-none absolute -top-40 end-[-10%] size-[36rem] rounded-full bg-primary/10 blur-3xl"
          aria-hidden
        />

        <div className="relative mx-auto grid max-w-7xl gap-12 px-4 py-16 sm:px-6 sm:py-20 lg:grid-cols-[1.05fr_0.95fr] lg:items-center lg:px-8 lg:py-24">
          <div className="max-w-2xl space-y-6">
            <Badge variant="outline" className="w-fit border-primary/30 bg-primary/5 text-primary">
              <Sparkles className="size-3.5" aria-hidden />
              {t("home.heroEyebrow")}
            </Badge>

            <h1 className="text-4xl leading-[1.08] font-semibold tracking-tight text-balance sm:text-5xl lg:text-[3.4rem]">
              {t("home.heroTitle")}
            </h1>

            <p className="max-w-xl text-base leading-relaxed text-muted-foreground sm:text-lg">
              {t("home.heroDescription")}
            </p>

            <div className="flex flex-wrap items-center gap-3">
              <Button asChild size="lg">
                <Link href="/join">
                  {t("home.joinCta")}
                  <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline">
                <Link href="/events">{t("home.exploreEvents")}</Link>
              </Button>
            </div>

            <dl className="flex flex-wrap items-center gap-x-6 gap-y-2 pt-2 text-xs text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Users className="size-3.5 text-primary" aria-hidden />
                <dd>{stats.members} {t("home.statsMembers")}</dd>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <CalendarCheck className="size-3.5 text-primary" aria-hidden />
                <dd>{stats.events} {t("home.statsEvents")}</dd>
              </span>
              <span className="inline-flex items-center gap-1.5">
                <GraduationCap className="size-3.5 text-primary" aria-hidden />
                <dd>{tracks.length} {t("catalog.browseTracks")}</dd>
              </span>
            </dl>
          </div>

          {/* Brand panel — the logo plus the three promises of the club. */}
          <div className="relative">
            <div className="rounded-2xl bg-card p-6 ring-1 ring-foreground/10 elevation-2 sm:p-7">
              <div className="space-y-4">
                {[
                  {
                    icon: Sparkles,
                    title: t("about.objective1"),
                    body: t("about.gain1"),
                  },
                  {
                    icon: Users,
                    title: t("about.objective2"),
                    body: t("about.gain2"),
                  },
                  {
                    icon: Trophy,
                    title: t("about.objective3"),
                    body: t("about.gain3"),
                  },
                ].map((item) => (
                  <div key={item.title} className="flex gap-3.5">
                    <span className="flex size-9 shrink-0 items-center justify-center rounded-lg bg-primary/10 text-primary">
                      <item.icon className="size-4.5" aria-hidden />
                    </span>
                    <div className="space-y-0.5">
                      <p className="text-sm font-medium">{item.title}</p>
                      <p className="text-sm leading-relaxed text-muted-foreground">{item.body}</p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex items-center justify-between gap-3 rounded-lg bg-muted/60 px-4 py-3">
                <div>
                  <p className="text-xs text-muted-foreground">{t("home.statsXp")}</p>
                  <p className="text-lg font-semibold tabular-nums">
                    {stats.xpAwarded.toLocaleString(locale === "ar" ? "ar-EG" : "en-US")}
                  </p>
                </div>
                <span className="flex size-10 items-center justify-center rounded-full bg-primary text-primary-foreground">
                  <Zap className="size-5" aria-hidden />
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* --------------------------------------------------------------- stats */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <StatsStrip
          locale={locale}
          items={[
            { key: "members", label: t("home.statsMembers"), value: stats.members, icon: Users },
            { key: "teams", label: t("home.statsTeams"), value: stats.teams, icon: Users },
            { key: "events", label: t("home.statsEvents"), value: stats.events, icon: CalendarCheck },
            { key: "xp", label: t("home.statsXp"), value: stats.xpAwarded, icon: Zap },
          ]}
        />
      </section>

      {/* -------------------------------------------------------------- tracks */}
      <section className="mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <SectionHeading
          title={t("home.tracksTitle")}
          description={t("home.tracksSubtitle")}
          actions={
            <Link
              href="/learning"
              className={cn(buttonVariants({ variant: "ghost", size: "sm" }))}
            >
              {t("common.viewAll")}
              <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
            </Link>
          }
        />
        <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {tracks.slice(0, 6).map((track) => (
            <TrackCard key={track.id} track={track} locale={locale} />
          ))}
        </div>
      </section>

      {/* -------------------------------------------------------------- events */}
      <section className="border-y bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <SectionHeading
            title={t("home.eventsTitle")}
            description={t("home.eventsSubtitle")}
            actions={
              <Link href="/events" className={cn(buttonVariants({ variant: "ghost", size: "sm" }))}>
                {t("common.viewAll")}
                <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
              </Link>
            }
          />
          {events.length > 0 ? (
            <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              {events.map((event) => (
                <EventCard key={event.id} event={event} locale={locale} />
              ))}
            </div>
          ) : (
            <p className="mt-5 rounded-xl border border-dashed bg-background/60 px-5 py-10 text-center text-sm text-muted-foreground">
              {t("common.emptyBody")}
            </p>
          )}
        </div>
      </section>

      {/* ------------------------------------------------------------- learning */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <SectionHeading
          title={t("home.learningTitle")}
          description={t("home.learningSubtitle")}
          actions={
            <Link href="/learning" className={cn(buttonVariants({ variant: "ghost", size: "sm" }))}>
              {t("common.viewAll")}
              <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
            </Link>
          }
        />
        {courses.length > 0 ? (
          <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {courses.map((course) => (
              <CourseCard key={course.id} course={course} locale={locale} />
            ))}
          </div>
        ) : (
          <p className="mt-5 rounded-xl border border-dashed px-5 py-10 text-center text-sm text-muted-foreground">
            {t("learning.noCourses")}
          </p>
        )}
      </section>

      {/* ----------------------------------------------------------- leaderboard */}
      <section className="border-y bg-muted/30">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <SectionHeading
            title={t("home.leaderboardTitle")}
            description={t("home.leaderboardSubtitle")}
            actions={
              <Link
                href="/leaderboard"
                className={cn(buttonVariants({ variant: "ghost", size: "sm" }))}
              >
                {t("common.viewAll")}
                <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
              </Link>
            }
          />
          <div className="mt-5 rounded-xl bg-card p-4 ring-1 ring-foreground/10 sm:p-5">
            <LeaderboardList rows={leaderboard} locale={locale} compact />
          </div>
        </div>
      </section>

      {/* --------------------------------------------------------- testimonials */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <SectionHeading title={t("home.testimonialsTitle")} />
        <div className="mt-5 grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {testimonials.map((testimonial) => (
            <TestimonialCard key={testimonial.id} testimonial={testimonial} locale={locale} />
          ))}
        </div>
      </section>

      {/* ------------------------------------------------------------------ cta */}
      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-2xl bg-brand-900 px-6 py-12 text-center text-white sm:px-10">
          <div
            className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_30%_20%,rgba(255,255,255,0.14),transparent_60%)]"
            aria-hidden
          />
          <div className="relative mx-auto max-w-2xl space-y-4">
            <h2 className="text-2xl font-semibold tracking-tight text-balance sm:text-3xl">
              {t("home.ctaTitle")}
            </h2>
            <p className="text-sm leading-relaxed text-white/75 sm:text-base">
              {t("home.ctaSubtitle")}
            </p>
            <div className="flex flex-wrap justify-center gap-3 pt-1">
              <Button asChild size="lg" variant="secondary">
                <Link href="/join">
                  {t("home.joinCta")}
                  <ArrowRight className="size-4 rtl:rotate-180" aria-hidden />
                </Link>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-white/30 bg-transparent text-white hover:bg-white/10 hover:text-white"
              >
                <Link href="/contact">{t("nav.contact")}</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
