import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { CheckInScanner } from "@/components/admin/events/scanner";
import { PageHeader } from "@/components/shared/page-header";
import { ForbiddenError, assertPermission, requireAuth } from "@/lib/auth/dal";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { findEventByIdOrSlug } from "@/lib/queries/admin-events";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("admin.scan.title"), robots: { index: false } };
}

/** Staff check-in scanner. Authorization is decided here on the server, per event. */
export default async function CheckInPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const ctx = await requireAuth(`/events/${slug}/check-in`);
  try {
    assertPermission(ctx, "events.manage_attendance");
  } catch (e) {
    if (e instanceof ForbiddenError) notFound();
    throw e;
  }
  const event = await findEventByIdOrSlug(slug);
  if (!event) notFound();

  const locale = await resolveLocale(ctx.locale === "AR" ? "ar" : "en");
  const t = getTranslations(locale);

  return (
    <div className="mx-auto max-w-2xl space-y-6 px-4 py-6 sm:px-6">
      <PageHeader title={t("admin.scan.title")} description={locale === "ar" && event.titleAr ? event.titleAr : event.title} />
      <CheckInScanner eventId={event.id} />
    </div>
  );
}
