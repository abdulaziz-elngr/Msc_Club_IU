import Link from "next/link";
import type { Metadata } from "next";
import { Users } from "lucide-react";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getPublicTeams } from "@/lib/queries/public";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  return { title: getTranslations(await resolveLocale())("teams.title") };
}

export default async function TeamsPage() {
  const locale = await resolveLocale();
  const t = getTranslations(locale);
  const teams = await getPublicTeams();

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <PageHeader title={t("teams.title")} description={t("teams.subtitle")} />
      {teams.length === 0 ? (
        <EmptyState icon={Users} title={t("teams.empty")} />
      ) : (
        <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {teams.map((team) => (
            <li key={team.id}>
              <Link
                href={`/teams/${team.slug}`}
                className="group flex h-full flex-col gap-3 rounded-xl bg-card p-5 ring-1 ring-foreground/10 outline-none transition-all hover:ring-primary/40 focus-visible:ring-2 focus-visible:ring-ring"
              >
                <h2 className="text-base font-semibold transition-colors group-hover:text-primary">
                  {locale === "ar" && team.nameAr ? team.nameAr : team.name}
                </h2>
                {team.description ? (
                  <p className="line-clamp-3 text-sm text-muted-foreground">
                    {locale === "ar" && team.descriptionAr ? team.descriptionAr : team.description}
                  </p>
                ) : null}
                <p className="mt-auto flex items-center justify-between gap-2 pt-2 text-xs text-muted-foreground">
                  <span className="inline-flex items-center gap-1.5">
                    <Users className="size-3.5" aria-hidden /> {t("teams.members", { count: team._count.memberships })}
                  </span>
                  {team.lead ? <span className="truncate">{t("teams.lead")}: {team.lead.name}</span> : null}
                </p>
              </Link>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
