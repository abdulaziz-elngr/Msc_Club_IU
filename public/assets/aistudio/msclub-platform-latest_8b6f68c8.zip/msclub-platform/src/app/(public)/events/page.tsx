import Link from "next/link";
import type { Metadata } from "next";
import { CalendarX2 } from "lucide-react";
import { EventCard } from "@/components/marketing/event-card";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { getTranslations, type TranslationKey } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { listPublicEvents, type EventWhen } from "@/lib/queries/events";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export async function generateMetadata(): Promise<Metadata> {
  const t = getTranslations(await resolveLocale());
  return { title: t("nav.events") };
}

const CATEGORIES = ["WORKSHOP", "TECHNICAL_SESSION", "BOOTCAMP", "COMPETITION", "HACKATHON", "COMMUNITY", "WEBINAR", "OTHER"] as const;
type Category = (typeof CATEGORIES)[number];
const WHEN: EventWhen[] = ["upcoming", "past", "all"];

const pick = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v);

export default async function EventsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const sp = await searchParams;
  const locale = await resolveLocale();
  const t = getTranslations(locale);

  const whenRaw = pick(sp.when);
  const when: EventWhen = WHEN.includes(whenRaw as EventWhen) ? (whenRaw as EventWhen) : "upcoming";
  const catRaw = pick(sp.category);
  const category = CATEGORIES.includes(catRaw as Category) ? (catRaw as Category) : undefined;
  const page = Math.max(1, Math.min(500, Number.parseInt(pick(sp.page) ?? "1", 10) || 1));

  const { events, total, pages } = await listPublicEvents({ when, category, page });

  const href = (next: { when?: EventWhen; category?: string | null; page?: number }) => {
    const q = new URLSearchParams();
    const w = next.when ?? when;
    const c = next.category === undefined ? category : (next.category ?? undefined);
    if (w !== "upcoming") q.set("when", w);
    if (c) q.set("category", c);
    if (next.page && next.page > 1) q.set("page", String(next.page));
    const qs = q.toString();
    return qs ? `/events?${qs}` : "/events";
  };

  const chip = (active: boolean) =>
    cn(
      "inline-flex h-8 items-center rounded-full px-3.5 text-sm font-medium ring-1 transition-colors outline-none focus-visible:ring-2 focus-visible:ring-ring",
      active ? "bg-primary text-primary-foreground ring-primary" : "bg-card text-foreground ring-foreground/10 hover:ring-primary/40",
    );

  return (
    <div className="mx-auto max-w-7xl space-y-8 px-4 py-10 sm:px-6 lg:px-8">
      <PageHeader title={t("nav.events")} description={t("home.eventsSubtitle")} />

      <div className="space-y-3">
        <nav aria-label={t("events.filterAll")} className="flex flex-wrap gap-2">
          {WHEN.map((w) => (
            <Link key={w} href={href({ when: w, page: 1 })} className={chip(w === when)} aria-current={w === when ? "page" : undefined}>
              {t(`events.filter${w[0].toUpperCase()}${w.slice(1)}` as TranslationKey)}
            </Link>
          ))}
        </nav>
        <nav aria-label={t("events.category")} className="flex flex-wrap gap-2">
          <Link href={href({ category: null, page: 1 })} className={chip(!category)} aria-current={!category ? "page" : undefined}>
            {t("events.allCategories")}
          </Link>
          {CATEGORIES.map((c) => (
            <Link key={c} href={href({ category: c, page: 1 })} className={chip(c === category)} aria-current={c === category ? "page" : undefined}>
              {t(`events.categories.${c}` as TranslationKey)}
            </Link>
          ))}
        </nav>
      </div>

      {events.length === 0 ? (
        <EmptyState icon={CalendarX2} title={t("events.noEvents")} description={t("common.emptyBody")} />
      ) : (
        <>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {events.map((event) => (
              <li key={event.id}>
                <EventCard event={event} locale={locale} />
              </li>
            ))}
          </ul>

          {pages > 1 ? (
            <nav aria-label={t("common.page")} className="flex items-center justify-between gap-4 pt-2">
              <p className="text-sm text-muted-foreground">{t("common.results", { count: total })}</p>
              <div className="flex items-center gap-2">
                {page > 1 ? (
                  <Link href={href({ page: page - 1 })} className={chip(false)} rel="prev">{t("common.back")}</Link>
                ) : null}
                <span className="text-sm tabular-nums">{page} {t("common.of")} {pages}</span>
                {page < pages ? (
                  <Link href={href({ page: page + 1 })} className={chip(false)} rel="next">{t("common.next")}</Link>
                ) : null}
              </div>
            </nav>
          ) : null}
        </>
      )}
    </div>
  );
}
