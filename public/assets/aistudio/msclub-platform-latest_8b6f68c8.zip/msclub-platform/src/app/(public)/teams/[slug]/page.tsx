import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { EventCard } from "@/components/marketing/event-card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getTranslations } from "@/lib/i18n";
import { resolveLocale } from "@/lib/i18n/cookie";
import { getPublicTeam } from "@/lib/queries/teams";

export const dynamic = "force-dynamic";

type Params = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Params): Promise<Metadata> {
  const team = await getPublicTeam((await params).slug);
  if (!team) return {};
  const locale = await resolveLocale();
  return { title: locale === "ar" && team.nameAr ? team.nameAr : team.name };
}

const initials = (name: string) => name.split(/\s+/).filter(Boolean).slice(0, 2).map((p) => p[0]?.toUpperCase()).join("") || "?";

export default async function TeamPage({ params }: Params) {
  const team = await getPublicTeam((await params).slug);
  if (!team) notFound();

  const locale = await resolveLocale();
  const t = getTranslations(locale);
  const name = locale === "ar" && team.nameAr ? team.nameAr : team.name;
  const description = locale === "ar" && team.descriptionAr ? team.descriptionAr : team.description;

  return (
    <div className="mx-auto max-w-5xl space-y-10 px-4 py-10 sm:px-6 lg:px-8">
      <header className="space-y-3">
        <h1 className="text-3xl font-semibold tracking-tight sm:text-4xl">{name}</h1>
        <p className="text-sm text-muted-foreground">
          {t("teams.members", { count: team._count.memberships })}
          {team.lead ? ` · ${t("teams.lead")}: ${team.lead.name}` : ""}
        </p>
      </header>

      {description ? (
        <section aria-labelledby="about-team" className="space-y-2">
          <h2 id="about-team" className="text-lg font-semibold">{t("teams.aboutTeam")}</h2>
          <p className="max-w-prose text-sm leading-relaxed whitespace-pre-line text-muted-foreground">{description}</p>
        </section>
      ) : null}

      {team.upcomingEvents.length > 0 ? (
        <section aria-labelledby="team-events" className="space-y-4">
          <h2 id="team-events" className="text-lg font-semibold">{t("dashboard.upcomingEvents")}</h2>
          <ul className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {team.upcomingEvents.map((e) => (
              <li key={e.id}><EventCard event={e} locale={locale} /></li>
            ))}
          </ul>
        </section>
      ) : null}

      <section aria-labelledby="roster" className="space-y-4">
        <h2 id="roster" className="text-lg font-semibold">{t("teams.roster")}</h2>
        {team.memberships.length === 0 ? (
          <p className="text-sm text-muted-foreground">{t("common.emptyBody")}</p>
        ) : (
          <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {team.memberships.map((m) => (
              <li key={m.id} className="flex items-center gap-3 rounded-xl bg-card p-3 ring-1 ring-foreground/10">
                <Avatar className="size-10">
                  {m.user.image ? <AvatarImage src={m.user.image} alt="" /> : null}
                  <AvatarFallback>{initials(m.user.name)}</AvatarFallback>
                </Avatar>
                <div className="min-w-0">
                  <p className="truncate text-sm font-medium">{m.user.name}</p>
                  {m.title ? <p className="truncate text-xs text-muted-foreground">{m.title}</p> : null}
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
