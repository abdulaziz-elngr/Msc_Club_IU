import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import { cookies } from "next/headers";
import { AppProviders } from "@/components/providers";
import { isLocale, localeDirection, type Locale } from "@/lib/i18n";
import { LOCALE_COOKIE } from "@/lib/i18n/cookie";
import "./globals.css";

/**
 * Typography — self-hosted (OFL-licensed variable fonts in `src/fonts`), so
 * builds never depend on Google being reachable and visitors' browsers never
 * contact Google. Inter carries Latin, Noto Sans Arabic carries Arabic; because
 * the Arabic family is second in the stack, browsers fall back per glyph.
 */
const inter = localFont({
  src: "../fonts/inter-latin-wght-normal.woff2",
  variable: "--font-latin",
  display: "swap",
  weight: "100 900",
});

const notoArabic = localFont({
  src: "../fonts/noto-sans-arabic-arabic-wght-normal.woff2",
  variable: "--font-arabic",
  display: "swap",
  weight: "100 900",
});

const APP_NAME = process.env.NEXT_PUBLIC_APP_NAME ?? "Microsoft Student Clubs";
const APP_URL = process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(APP_URL),
  title: {
    default: `${APP_NAME} — Innovation University`,
    template: `%s · ${APP_NAME}`,
  },
  description:
    "The official Microsoft Student Club of Innovation University: technical tracks, workshops, a private learning hub, events, XP and leaderboards.",
  applicationName: APP_NAME,
  icons: {
    icon: [{ url: "/icon.svg", type: "image/svg+xml" }],
    apple: [{ url: "/icon.svg" }],
  },
  openGraph: {
    type: "website",
    siteName: APP_NAME,
    url: APP_URL,
    title: `${APP_NAME} — Innovation University`,
    description:
      "Learn Microsoft technologies, ship real projects, and grow with the campus community.",
    images: [{ url: "/brand/logo.svg", width: 420, height: 128, alt: APP_NAME }],
  },
  twitter: {
    card: "summary_large_image",
    title: `${APP_NAME} — Innovation University`,
    description: "Learn Microsoft technologies, ship real projects, and grow with the campus community.",
  },
  robots: { index: true, follow: true },
};

export const viewport: Viewport = {
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#1B6AC4" },
    { media: "(prefers-color-scheme: dark)", color: "#0B1118" },
  ],
  width: "device-width",
  initialScale: 1,
};

async function readLocale(): Promise<Locale> {
  try {
    const store = await cookies();
    const value = store.get(LOCALE_COOKIE)?.value;
    if (isLocale(value)) return value;
  } catch {
    // Cookies are unavailable during static generation — fall back to English.
  }
  return "en";
}

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const locale = await readLocale();
  const dir = localeDirection(locale);

  return (
    <html
      lang={locale === "ar" ? "ar" : "en"}
      dir={dir}
      suppressHydrationWarning
      className={`${inter.variable} ${notoArabic.variable} h-full`}
    >
      <body className="flex min-h-full flex-col bg-background text-foreground antialiased">
        <a
          href="#main-content"
          className="sr-only focus:not-sr-only focus:absolute focus:start-4 focus:top-4 focus:z-50 focus:rounded-md focus:bg-primary focus:px-4 focus:py-2 focus:text-primary-foreground"
        >
          Skip to content
        </a>
        <AppProviders locale={locale}>{children}</AppProviders>
      </body>
    </html>
  );
}
