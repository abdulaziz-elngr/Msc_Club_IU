"use server";

import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { localeCookieOptions, LOCALE_COOKIE } from "@/lib/i18n/cookie";
import { isLocale, type Locale } from "@/lib/i18n";
import { db } from "@/lib/db";
import { getAuthContext } from "@/lib/auth/dal";

/**
 * Persists the interface language.
 *
 * The cookie is always written (so anonymous visitors keep their choice) and,
 * when signed in, the preference is also stored on the user record so it
 * follows them across devices.
 */
export async function setLocale(locale: Locale): Promise<{ ok: boolean }> {
  if (!isLocale(locale)) return { ok: false };

  const store = await cookies();
  const options = localeCookieOptions();
  store.set(LOCALE_COOKIE, locale, options);

  const ctx = await getAuthContext();
  if (ctx) {
    // The UI locale (`en` / `ar`) and the Prisma enum (`EN` / `AR`) differ.
    const dbLocale = locale === "ar" ? ("AR" as const) : ("EN" as const);
    await db.user.update({ where: { id: ctx.userId }, data: { locale: dbLocale } }).catch(() => undefined);
  }

  revalidatePath("/", "layout");
  return { ok: true };
}
