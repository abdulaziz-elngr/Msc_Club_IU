"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { runAction, type ActionResult } from "@/lib/actions/admin";
import { guardMutation } from "@/lib/actions/guard";
import { checkInByToken, checkInWithRotatingCode, type AttendeeSummary } from "@/lib/attendance";
import { db } from "@/lib/db";
import { recordId } from "@/lib/validation";

export type ScanResult = ActionResult & {
  /** Machine code from the check-in engine (TOKEN_NOT_FOUND, ALREADY_CHECKED_IN, …). */
  scanCode?: string;
  duplicate?: boolean;
  points?: number;
  attendee?: AttendeeSummary;
};

/**
 * Staff scanner endpoint. The client sends ONLY the scanned opaque string and
 * the event being worked; identity, registration and attendance status are all
 * resolved on the server from the signed pass.
 */
export async function scanPassAction(eventId: string, token: string): Promise<ScanResult> {
  return runAction({ permission: "events.manage_attendance", bucket: "checkin:scan", max: 600 }, async (ctx) => {
    const ids = z.object({ e: recordId, t: z.string().min(10).max(200) }).safeParse({ e: eventId, t: token });
    if (!ids.success) return { ok: false, code: "INVALID", scanCode: "TOKEN_NOT_FOUND" };

    const r = await checkInByToken(ids.data.t, { eventId: ids.data.e, actorId: ctx.userId, method: "QR_SCAN" });
    revalidatePath(`/admin/events/${ids.data.e}`);
    if (r.ok) return { ok: true, points: r.points, attendee: r.attendee, duplicate: false };
    return { ok: false, code: "INVALID", scanCode: r.code, duplicate: r.duplicate, attendee: r.attendee };
  });
}

export type RegistrantHit = AttendeeSummary & { userId: string };

/** Manual fallback: find confirmed registrants by name or student id. */
export async function searchRegistrantsAction(eventId: string, query: string): Promise<{ ok: boolean; hits: RegistrantHit[] }> {
  const res = await runAction({ permission: "events.manage_attendance", bucket: "checkin:search", max: 120 }, async () => ({ ok: true }));
  if (!res.ok) return { ok: false, hits: [] };
  const ids = z.object({ e: recordId, q: z.string().trim().min(2).max(60) }).safeParse({ e: eventId, q: query });
  if (!ids.success) return { ok: true, hits: [] };

  const rows = await db.eventRegistration.findMany({
    where: {
      eventId: ids.data.e,
      status: "CONFIRMED",
      user: { OR: [{ name: { contains: ids.data.q, mode: "insensitive" } }, { studentId: { contains: ids.data.q, mode: "insensitive" } }] },
    },
    take: 8,
    orderBy: { user: { name: "asc" } },
    select: { status: true, user: { select: { id: true, name: true, studentId: true, attendance: { where: { eventId: ids.data.e }, select: { status: true, pointsAwarded: true } } } } },
  });
  return {
    ok: true,
    hits: rows.map((r) => ({
      userId: r.user.id, name: r.user.name, studentId: r.user.studentId, registrationStatus: r.status,
      attendanceStatus: r.user.attendance[0]?.status ?? null, points: r.user.attendance[0]?.pointsAwarded ?? 0,
    })),
  };
}

/** Member self check-in after scanning the venue's rotating code. */
export async function selfCheckInAction(eventId: string, code: string): Promise<ActionResult & { scanCode?: string; points?: number }> {
  const guard = await guardMutation("checkin:self", 10, 60_000);
  if (!guard.ok) return { ok: false, code: guard.code };
  const ids = z.object({ e: recordId, c: z.string().min(10).max(100) }).safeParse({ e: eventId, c: code });
  if (!ids.success) return { ok: false, code: "INVALID", scanCode: "TOKEN_NOT_FOUND" };
  const r = await checkInWithRotatingCode({ eventId: ids.data.e, code: ids.data.c, userId: guard.ctx.userId });
  if (r.ok) {
    revalidatePath("/dashboard/events");
    return { ok: true, points: r.points };
  }
  return { ok: false, code: "INVALID", scanCode: r.code };
}
