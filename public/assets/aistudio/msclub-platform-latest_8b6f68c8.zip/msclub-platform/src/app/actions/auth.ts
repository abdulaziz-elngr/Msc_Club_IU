"use server";

import { hash } from "bcryptjs";
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";
import { signIn, signOut } from "@/auth";
import { db } from "@/lib/db";
import { emailUrl, sendEmail } from "@/lib/email";
import { getEnv } from "@/lib/env";
import { isBlockedStatus, landingFor, safeNext } from "@/lib/auth/policy";
import { checkbox, errorState, formValues, parseForm, successState, type FormState } from "@/lib/forms";
import { logAudit } from "@/lib/audit";
import { notify } from "@/lib/notifications";
import { clientKey, rateLimit, resetRateLimit } from "@/lib/rate-limit";
import { randomToken, sha256 } from "@/lib/tokens";
import { DUMMY_BCRYPT_HASH, isLoginThrottled, recordLoginAttempt } from "@/lib/auth/throttle";

/**
 * Authentication server actions.
 *
 * Every flow here follows the same shape:
 *   1. rate-limit by client identity
 *   2. validate input with Zod (never trust the client)
 *   3. perform the database mutation
 *   4. write an audit entry for anything security-relevant
 *   5. return a `FormState` consumed by `useActionState`
 *
 * Redirects are performed *last* and outside any `catch`, because Next.js
 * encodes them as a special thrown error that must not be swallowed.
 */

const PASSWORD_RULES = z
  .string()
  .min(8, "Password must be at least 8 characters.")
  .max(200, "Password is too long.")
  .refine((v) => /[A-Za-z]/.test(v), "Password must contain a letter.")
  .refine((v) => /\d/.test(v), "Password must contain a number.");

const emailSchema = z
  .string()
  .trim()
  .min(1, "Email is required.")
  .max(320, "Email is too long.")
  .email("Enter a valid email address.")
  .transform((v) => v.toLowerCase());

const registerSchema = z.object({
  name: z.string().trim().min(2, "Enter your full name.").max(80, "Name is too long."),
  email: emailSchema,
  password: PASSWORD_RULES,
  confirmPassword: z.string(),
  studentId: z
    .string()
    .trim()
    .max(32, "Student ID is too long.")
    .optional()
    .or(z.literal("")),
  faculty: z.string().trim().max(120).optional().or(z.literal("")),
  department: z.string().trim().max(120).optional().or(z.literal("")),
  academicYear: z.string().trim().max(60).optional().or(z.literal("")),
  phone: z
    .string()
    .trim()
    .max(40, "Phone number is too long.")
    .optional()
    .or(z.literal("")),
  preferredTrackId: z.string().trim().optional().or(z.literal("")),
  motivation: z.string().trim().max(1000, "Please keep this under 1000 characters.").optional().or(z.literal("")),
  agree: checkbox,
});

const loginSchema = z.object({
  email: emailSchema,
  password: z.string().min(1, "Password is required.").max(200),
  next: z.string().trim().max(512).optional().or(z.literal("")),
});

const forgotSchema = z.object({ email: emailSchema });

const resetSchema = z
  .object({
    token: z.string().trim().min(10, "Invalid reset link."),
    email: emailSchema.optional().or(z.literal("")),
    password: PASSWORD_RULES,
    confirmPassword: z.string(),
  })
  .refine((v) => v.password === v.confirmPassword, {
    path: ["confirmPassword"],
    message: "Passwords do not match.",
  });

const verifySchema = z.object({
  token: z.string().trim().min(10, "Invalid verification link."),
  email: emailSchema.optional().or(z.literal("")),
});

const VERIFICATION_TTL_HOURS = 24;
const RESET_TTL_MINUTES = 30;

async function clientIp(): Promise<string> {
  const h = await headers();
  return h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "unknown";
}

function isDevWithConsoleMail(): boolean {
  return process.env.NODE_ENV !== "production" && !getEnv().RESEND_API_KEY;
}

// ==============================================================================
// REGISTER
// ==============================================================================

export async function registerAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const ip = await clientIp();
  const limit = rateLimit(clientKey("auth:register", ip), 5, 10 * 60_000);
  if (!limit.ok) {
    return errorState("Too many attempts. Please wait a few minutes and try again.");
  }

  const parsed = parseForm(registerSchema, formData);
  if (!parsed.success) return parsed.state;

  const data = parsed.data;
  if (!data.agree) {
    return {
      ok: false,
      message: "Please confirm your information is accurate.",
      errors: { agree: ["Please confirm your information is accurate."] },
      values: formValues(formData),
    };
  }
  if (data.password !== data.confirmPassword) {
    return {
      ok: false,
      message: "Passwords do not match.",
      errors: { confirmPassword: ["Passwords do not match."] },
      values: formValues(formData),
    };
  }

  const email = data.email;
  const existing = await db.user.findUnique({ where: { email }, select: { id: true } });
  if (existing) {
    return {
      ok: false,
      message: "An account with this email already exists. Try signing in instead.",
      errors: { email: ["An account with this email already exists."] },
      values: formValues(formData),
    };
  }

  // Optional profile fields that reference seeded rows must exist.
  let preferredTrackId: string | null = null;
  if (data.preferredTrackId) {
    const track = await db.learningTrack.findUnique({
      where: { id: data.preferredTrackId },
      select: { id: true },
    });
    preferredTrackId = track?.id ?? null;
  }

  const passwordHash = await hash(data.password, 12);
  const verificationToken = randomToken(32);

  let account: { id: string; email: string; name: string };
  try {
    account = await db.user.create({
      data: {
        name: data.name,
        email,
        passwordHash,
        status: "UNVERIFIED",
        studentId: data.studentId ? data.studentId : null,
        faculty: data.faculty ? data.faculty : null,
        department: data.department ? data.department : null,
        academicYear: data.academicYear ? data.academicYear : null,
        phone: data.phone ? data.phone : null,
        motivation: data.motivation ? data.motivation : null,
        preferredTrackId,
        roles: {
          create: [{ role: { connect: { key: "APPLICANT" } } }],
        },
      },
      select: { id: true, email: true, name: true },
    });
  } catch (error) {
    // Unique constraint: the email check above raced with another signup, or
    // the student ID is already claimed by a different account.
    const code = (error as { code?: string } | null)?.code;
    if (code === "P2002") {
      const target = (error as { meta?: { target?: string[] } }).meta?.target?.[0];
      if (target === "studentId") {
        return {
          ok: false,
          message: "That student ID is already registered to another account.",
          errors: { studentId: ["This student ID is already registered."] },
          values: formValues(formData),
        };
      }
      return {
        ok: false,
        message: "An account with this email already exists. Try signing in instead.",
        errors: { email: ["An account with this email already exists."] },
        values: formValues(formData),
      };
    }
    throw error;
  }

  await db.verificationToken.create({
    data: {
      identifier: email,
      token: sha256(verificationToken),
      expires: new Date(Date.now() + VERIFICATION_TTL_HOURS * 3600_000),
    },
  });

  const verifyHref = `/verify-email?token=${encodeURIComponent(verificationToken)}&email=${encodeURIComponent(email)}`;

  const result = await sendEmail({
    to: email,
    subject: "Verify your email — Microsoft Student Clubs",
    heading: "Confirm your email address",
    body: `Hi ${data.name},\n\nWelcome to Microsoft Student Clubs at Innovation University. Confirm your email address to activate your account.\n\nThis link expires in ${VERIFICATION_TTL_HOURS} hours.`,
    action: { label: "Verify email", href: emailUrl(verifyHref) },
  });

  await notify({
    userId: account.id,
    type: "SYSTEM",
    title: "Welcome to Microsoft Student Clubs",
    titleAr: "مرحبًا بك في نادي مايكروسوفت للطلاب",
    body: "Confirm your email address to activate your account.",
    bodyAr: "أكّد بريدك الإلكتروني لتفعيل حسابك.",
    href: verifyHref,
    email: false,
  });

  await logAudit({
    actorId: account.id,
    action: "auth.register",
    entityType: "User",
    entityId: account.id,
    after: { email, status: "UNVERIFIED" },
    reason: ip,
  });

  resetRateLimit(clientKey("auth:register", ip));

  // In local development there is no real inbox: surface the link so the flow
  // can be completed without a mail provider. Never true in production.
  const devVerifyUrl = isDevWithConsoleMail() ? emailUrl(verifyHref) : undefined;

  return {
    ok: true,
    message: result.delivered
      ? `We sent a verification link to ${email}.`
      : `Account created. Check your inbox for the verification link.`,
    ...(devVerifyUrl ? { values: { devVerifyUrl } } : {}),
  };
}

// ==============================================================================
// LOGIN
// ==============================================================================

export async function loginAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const ip = await clientIp();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const limit = rateLimit(clientKey("auth:login", ip, email), 8, 10 * 60_000);

  const parsed = parseForm(loginSchema, formData);
  if (!parsed.success) {
    if (!limit.ok) return errorState("Too many attempts. Please wait a few minutes and try again.");
    return parsed.state;
  }
  if (!limit.ok) {
    return errorState("Too many attempts. Please wait a few minutes and try again.");
  }

  const { password, next } = parsed.data;
  const ipAddr = ip;

  if (await isLoginThrottled(parsed.data.email, ipAddr)) {
    return errorState("Too many attempts. Please wait a few minutes and try again.");
  }

  const recordAttempt = (success: boolean) => recordLoginAttempt(parsed.data.email, ipAddr, success);

  const account = await db.user.findUnique({
    where: { email: parsed.data.email },
    select: {
      id: true,
      email: true,
      name: true,
      status: true,
      emailVerified: true,
      passwordHash: true,
    },
  });

  // One bcrypt comparison regardless of whether the account exists, so timing
  // does not reveal which emails are registered.
  const { compare } = await import("bcryptjs");
  const valid = await compare(password, account?.passwordHash ?? DUMMY_BCRYPT_HASH);
  if (!account?.passwordHash || !valid) {
    await recordAttempt(false);
    return errorState("Invalid email or password.");
  }

  if (isBlockedStatus(account.status)) {
    await recordAttempt(false);
    await logAudit({
      actorId: account.id,
      action: "auth.login.blocked",
      entityType: "User",
      entityId: account.id,
      reason: `status=${account.status} ip=${ip}`,
    });
    return errorState("This account has been suspended. Contact an administrator.");
  }

  await recordAttempt(true);
  resetRateLimit(clientKey("auth:login", ip, parsed.data.email));

  const target = landingFor({
    status: account.status,
    emailVerified: account.emailVerified,
    next: safeNext(next),
  });

  await logAudit({
    actorId: account.id,
    action: "auth.login",
    entityType: "User",
    entityId: account.id,
    reason: ip,
  });

  // `redirect: false` lets us await the session cookie being written and then
  // perform our own (policy-aware) redirect. A failing Auth.js sign-in returns
  // a URL carrying `error=` instead of throwing.
  const returned = await signIn("credentials", {
    email: parsed.data.email,
    password,
    redirectTo: target,
    redirect: false,
  });

  if (typeof returned === "string" && returned.includes("error=")) {
    return errorState("Invalid email or password.");
  }

  redirect(target);
}

// ==============================================================================
// LOGOUT
// ==============================================================================

export async function logoutAction(): Promise<void> {
  const h = await headers();
  const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  await signOut({ redirectTo: "/login", redirect: false }).catch(() => undefined);
  await logAudit({ action: "auth.logout", entityType: "Session", reason: ip });
  redirect("/");
}

// ==============================================================================
// EMAIL VERIFICATION
// ==============================================================================

export async function verifyEmailAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const ip = await clientIp();
  const limit = rateLimit(clientKey("auth:verify", ip), 10, 10 * 60_000);
  if (!limit.ok) return errorState("Too many attempts. Please wait a few minutes and try again.");

  const parsed = parseForm(verifySchema, formData);
  if (!parsed.success) return parsed.state;

  const { token } = parsed.data;
  const email = parsed.data.email;

  // The token identifies the account on its own; the email is a second factor
  // that must match when supplied.
  const candidates = await db.verificationToken.findMany({
    where: { token: sha256(token) },
    orderBy: { createdAt: "desc" },
    take: 5,
  });

  const match = candidates.find((c) => !email || c.identifier === email);
  if (!match || match.expires < new Date()) {
    return errorState("This verification link is invalid or has expired.");
  }

  const account = await db.user.findUnique({
    where: { email: match.identifier },
    select: { id: true, status: true, emailVerified: true },
  });
  if (!account) return errorState("This verification link is invalid or has expired.");

  await db.$transaction([
    db.verificationToken.deleteMany({ where: { identifier: match.identifier } }),
    db.user.update({
      where: { id: account.id },
      data: {
        emailVerified: new Date(),
        // First verified account becomes an applicant; later re-verifications
        // must never demote an active member.
        ...(account.status === "UNVERIFIED" ? { status: "APPLICANT" as const } : {}),
      },
    }),
  ]);

  await logAudit({
    actorId: account.id,
    action: "auth.verify_email",
    entityType: "User",
    entityId: account.id,
    reason: ip,
  });

  await notify({
    userId: account.id,
    type: "SYSTEM",
    title: "Email verified",
    titleAr: "تم التحقق من بريدك",
    body: "Your account is active. You can now submit a membership application.",
    bodyAr: "حسابك نشط. يمكنك الآن تقديم طلب الانضمام.",
    href: "/join",
    email: false,
  });

  resetRateLimit(clientKey("auth:verify", ip));
  redirect("/login?verified=1");
}

export async function resendVerificationAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const ip = await clientIp();
  const limit = rateLimit(clientKey("auth:resend", ip), 4, 15 * 60_000);
  if (!limit.ok) return errorState("Too many attempts. Please wait a few minutes and try again.");

  const parsed = parseForm(z.object({ email: emailSchema }), formData);
  if (!parsed.success) return parsed.state;

  const account = await db.user.findUnique({
    where: { email: parsed.data.email },
    select: { id: true, emailVerified: true },
  });

  // Same response whether or not the account exists — prevents email probing.
  const generic = successState("If that account exists, a new verification link was sent.");

  if (!account || account.emailVerified) return generic;

  const token = randomToken(32);
  await db.verificationToken.deleteMany({ where: { identifier: parsed.data.email } });
  await db.verificationToken.create({
    data: {
      identifier: parsed.data.email,
      token: sha256(token),
      expires: new Date(Date.now() + VERIFICATION_TTL_HOURS * 3600_000),
    },
  });

  const verifyHref = `/verify-email?token=${encodeURIComponent(token)}&email=${encodeURIComponent(parsed.data.email)}`;
  const result = await sendEmail({
    to: parsed.data.email,
    subject: "Verify your email — Microsoft Student Clubs",
    heading: "Confirm your email address",
    body: `Use the link below to verify your email address.\n\nThis link expires in ${VERIFICATION_TTL_HOURS} hours.`,
    action: { label: "Verify email", href: emailUrl(verifyHref) },
  });

  return {
    ...generic,
    ...(isDevWithConsoleMail() && result.delivered
      ? { values: { devVerifyUrl: emailUrl(verifyHref) } }
      : {}),
  };
}

// ==============================================================================
// PASSWORD RESET
// ==============================================================================

export async function forgotPasswordAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const ip = await clientIp();
  const limit = rateLimit(clientKey("auth:forgot", ip), 4, 15 * 60_000);
  if (!limit.ok) return errorState("Too many attempts. Please wait a few minutes and try again.");

  const parsed = parseForm(forgotSchema, formData);
  if (!parsed.success) return parsed.state;

  const account = await db.user.findUnique({
    where: { email: parsed.data.email },
    select: { id: true, emailVerified: true },
  });

  const generic = successState("If that account exists, a password reset link was sent.");
  if (!account) return generic;

  const token = randomToken(32);
  // One live token per address: issuing a new link invalidates the old one.
  await db.passwordResetToken.deleteMany({ where: { email: parsed.data.email } });
  await db.passwordResetToken.create({
    data: {
      email: parsed.data.email,
      tokenHash: sha256(token),
      expires: new Date(Date.now() + RESET_TTL_MINUTES * 60_000),
    },
  });

  const resetHref = `/reset-password?token=${encodeURIComponent(token)}&email=${encodeURIComponent(parsed.data.email)}`;
  const result = await sendEmail({
    to: parsed.data.email,
    subject: "Reset your password — Microsoft Student Clubs",
    heading: "Reset your password",
    body: `We received a request to reset the password for this account.\n\nThis link expires in ${RESET_TTL_MINUTES} minutes. If you did not request it, you can safely ignore this email.`,
    action: { label: "Choose a new password", href: emailUrl(resetHref) },
  });

  return {
    ...generic,
    ...(isDevWithConsoleMail() && result.delivered
      ? { values: { devVerifyUrl: emailUrl(resetHref) } }
      : {}),
  };
}

export async function resetPasswordAction(_prev: FormState, formData: FormData): Promise<FormState> {
  const ip = await clientIp();
  const limit = rateLimit(clientKey("auth:reset", ip), 8, 15 * 60_000);
  if (!limit.ok) return errorState("Too many attempts. Please wait a few minutes and try again.");

  const parsed = parseForm(resetSchema, formData);
  if (!parsed.success) return parsed.state;

  const { token, email, password } = parsed.data;

  const candidates = await db.passwordResetToken.findMany({
    where: { tokenHash: sha256(token) },
    orderBy: { createdAt: "desc" },
    take: 5,
  });
  const match = candidates.find((c) => !email || c.email === email);

  if (!match || match.usedAt || match.expires < new Date()) {
    return errorState("This reset link is invalid or has expired. Request a new one.");
  }

  const account = await db.user.findUnique({
    where: { email: match.email },
    select: { id: true, status: true },
  });
  if (!account) return errorState("This reset link is invalid or has expired. Request a new one.");
  if (isBlockedStatus(account.status)) {
    return errorState("This account has been suspended. Contact an administrator.");
  }

  const passwordHash = await hash(password, 12);

  await db.$transaction([
    db.passwordResetToken.update({ where: { id: match.id }, data: { usedAt: new Date() } }),
    db.user.update({ where: { id: account.id }, data: { passwordHash, sessionVersion: { increment: 1 } } }),
    // A password change invalidates every other outstanding link.
    db.passwordResetToken.deleteMany({
      where: { email: match.email, id: { not: match.id } },
    }),
    db.loginAttempt.deleteMany({ where: { email: match.email, success: false } }),
  ]);

  await logAudit({
    actorId: account.id,
    action: "auth.password_reset",
    entityType: "User",
    entityId: account.id,
    reason: ip,
  });

  await notify({
    userId: account.id,
    type: "SYSTEM",
    title: "Your password was changed",
    titleAr: "تم تغيير كلمة المرور الخاصة بك",
    body: "If you did not do this, contact an administrator immediately.",
    bodyAr: "إذا لم تقم بذلك، تواصل مع المدير فورًا.",
    href: "/dashboard/profile",
    email: false,
  });

  resetRateLimit(clientKey("auth:reset", ip));
  redirect("/login?reset=1");
}
