"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { parseBuilderFields, eventSchema, slugify } from "@/lib/schemas/event";
import { parseForm, parseValue, runAction, type ActionResult } from "@/lib/actions/admin";
import { assertPermission } from "@/lib/auth/dal";
import { checkInManually, correctAttendance } from "@/lib/attendance";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { notify } from "@/lib/notifications";
import { cancelRegistration, fillFromWaitlist } from "@/lib/registration";
import { recordId, optionalText } from "@/lib/validation";
import type { Prisma } from "@/generated/client";

const PUBLISHED_STATUSES = ["PUBLISHED", "REGISTRATION_OPEN", "REGISTRATION_CLOSED", "IN_PROGRESS", "COMPLETED", "CANCELLED"];

function revalidateEvents(slug?: string) {
  revalidatePath("/admin/events");
  revalidatePath("/events");
  if (slug) revalidatePath(`/events/${slug}`);
}

/** Create (eventId = null) or update an event. */
export async function saveEventAction(eventId: string | null, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: eventId ? "events.update" : "events.create", bucket: "admin:event:save", max: 40 }, async (ctx) => {
    const id = eventId === null ? null : recordId.safeParse(eventId);
    if (id && !id.success) return { ok: false, code: "NOT_FOUND" };
    const parsed = parseForm(eventSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;

    const existing = id?.success ? await db.event.findUnique({ where: { id: id.data } }) : null;
    if (id && !existing) return { ok: false, code: "NOT_FOUND" };

    // Publishing, closing, completing or cancelling is a separate, stronger permission.
    const statusChanged = !existing || existing.status !== v.status;
    if (statusChanged && PUBLISHED_STATUSES.includes(v.status)) assertPermission(ctx, "events.publish");

    if (v.teamId && !(await db.team.findUnique({ where: { id: v.teamId }, select: { id: true } }))) {
      return { ok: false, code: "INVALID", fieldErrors: { teamId: "invalid" } };
    }

    const data: Prisma.EventUncheckedUpdateInput = {
      title: v.title, titleAr: v.titleAr ?? null, summary: v.summary ?? null,
      description: v.description ?? null, descriptionAr: v.descriptionAr ?? null,
      category: v.category, status: v.status,
      isOnline: v.isOnline, location: v.location ?? null, onlineUrl: v.onlineUrl ?? null,
      startsAt: v.startsAt, endsAt: v.endsAt,
      registrationOpensAt: v.registrationOpensAt ?? null, registrationClosesAt: v.registrationClosesAt ?? null,
      capacity: v.capacity ?? null, waitlistEnabled: v.waitlistEnabled,
      attendancePoints: v.attendancePoints, completionPoints: v.completionPoints, certificateEnabled: v.certificateEnabled,
      speakerName: v.speakerName ?? null, speakerTitle: v.speakerTitle ?? null, speakerBio: v.speakerBio ?? null,
      teamId: v.teamId ?? null, rotatingQrEnabled: v.rotatingQrEnabled, qrRotateSeconds: v.qrRotateSeconds,
      ...(v.status !== "DRAFT" && !existing?.publishedAt ? { publishedAt: new Date() } : {}),
    };

    if (!existing) {
      const slug = v.slug ?? slugify(v.title);
      let created;
      try {
        created = await db.event.create({ data: { ...(data as Prisma.EventUncheckedCreateInput), slug, organizerId: ctx.userId } });
      } catch (e) {
        if ((e as { code?: string }).code === "P2002") {
          if (v.slug) return { ok: false, code: "INVALID", fieldErrors: { slug: "duplicate" } };
          created = await db.event.create({ data: { ...(data as Prisma.EventUncheckedCreateInput), slug: `${slug}-${Math.random().toString(36).slice(2, 6)}`, organizerId: ctx.userId } });
        } else throw e;
      }
      await logAudit({ actorId: ctx.userId, action: "event.create", entityType: "Event", entityId: created.id, after: { title: created.title, status: created.status } });
      revalidateEvents(created.slug);
      return { ok: true, id: created.id, redirectTo: `/admin/events/${created.id}` };
    }

    const updated = await db.event.update({ where: { id: existing.id }, data });
    await logAudit({
      actorId: ctx.userId, action: "event.update", entityType: "Event", entityId: existing.id,
      before: { title: existing.title, status: existing.status, capacity: existing.capacity, startsAt: existing.startsAt },
      after: { title: updated.title, status: updated.status, capacity: updated.capacity, startsAt: updated.startsAt },
    });

    // Capacity raised → seats may have opened for people on the waitlist.
    if ((updated.capacity ?? Infinity) > (existing.capacity ?? Infinity) || (existing.capacity !== null && updated.capacity === null)) {
      await fillFromWaitlist(existing.id, ctx.userId);
    }
    // Cancelled → tell everyone who held a seat or a waitlist spot.
    if (existing.status !== "CANCELLED" && updated.status === "CANCELLED") {
      const regs = await db.eventRegistration.findMany({ where: { eventId: existing.id, status: { in: ["CONFIRMED", "WAITLISTED"] } }, select: { userId: true } });
      for (const r of regs) {
        await notify({
          userId: r.userId, type: "EVENT_CANCELLED", title: `Cancelled: ${updated.title}`,
          titleAr: `تم إلغاء الفعالية: ${updated.titleAr ?? updated.title}`, href: `/events/${updated.slug}`,
        });
      }
    }
    revalidateEvents(updated.slug);
    revalidatePath(`/admin/events/${existing.id}`);
    return { ok: true };
  });
}

export async function deleteEventAction(eventId: string): Promise<ActionResult> {
  return runAction({ permission: "events.delete", bucket: "admin:event:delete", max: 20 }, async (ctx) => {
    const id = recordId.safeParse(eventId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    const event = await db.event.findUnique({ where: { id: id.data }, select: { id: true, title: true, slug: true, _count: { select: { registrations: true, attendance: true } } } });
    if (!event) return { ok: false, code: "NOT_FOUND" };
    // History is never destroyed: events that have people attached are cancelled, not deleted.
    if (event._count.registrations > 0 || event._count.attendance > 0) return { ok: false, code: "CONFLICT" };
    await db.event.delete({ where: { id: event.id } });
    await logAudit({ actorId: ctx.userId, action: "event.delete", entityType: "Event", entityId: event.id, before: { title: event.title } });
    revalidateEvents(event.slug);
    return { ok: true, redirectTo: "/admin/events" };
  });
}

/** Replaces the custom registration form of an event. Existing answers stay keyed by field key. */
export async function saveFormFieldsAction(eventId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "events.update", bucket: "admin:event:fields", max: 30 }, async (ctx) => {
    const id = recordId.safeParse(eventId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    const built = parseBuilderFields(formData);
    if (!built.ok) return { ok: false, code: "INVALID", fieldErrors: { [built.field]: "invalid" } };

    const event = await db.event.findUnique({ where: { id: id.data }, select: { id: true, slug: true } });
    if (!event) return { ok: false, code: "NOT_FOUND" };

    await db.$transaction([
      db.eventFormField.deleteMany({ where: { eventId: event.id } }),
      db.eventFormField.createMany({
        data: built.fields.map((f, order) => ({ eventId: event.id, order, key: f.key, label: f.label, labelAr: f.labelAr ?? null, type: f.type, options: f.options, required: f.required })),
      }),
    ]);
    await logAudit({ actorId: ctx.userId, action: "event.form.update", entityType: "Event", entityId: event.id, after: { fields: built.fields.map((f) => f.key) } });
    revalidatePath(`/events/${event.slug}`);
    return { ok: true };
  });
}

export async function fillWaitlistAction(eventId: string): Promise<ActionResult> {
  return runAction({ permission: "events.manage_registrations", bucket: "admin:event:waitlist", max: 20 }, async (ctx) => {
    const id = recordId.safeParse(eventId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    await fillFromWaitlist(id.data, ctx.userId);
    revalidatePath(`/admin/events/${id.data}`);
    return { ok: true };
  });
}

export async function adminCancelRegistrationAction(eventId: string, userId: string): Promise<ActionResult> {
  return runAction({ permission: "events.manage_registrations", bucket: "admin:event:cancelreg", max: 60 }, async (ctx) => {
    const ids = z.object({ e: recordId, u: recordId }).safeParse({ e: eventId, u: userId });
    if (!ids.success) return { ok: false, code: "NOT_FOUND" };
    const r = await cancelRegistration({ eventId: ids.data.e, userId: ids.data.u });
    if (!r.ok) return { ok: false, code: r.code === "EVENT_STARTED" ? "CONFLICT" : "NOT_FOUND" };
    await logAudit({ actorId: ctx.userId, action: "event.registration.cancel", entityType: "Event", entityId: ids.data.e, after: { userId: ids.data.u } });
    revalidatePath(`/admin/events/${ids.data.e}`);
    return { ok: true };
  });
}

export async function manualCheckInAction(eventId: string, userId: string): Promise<ActionResult & { checkInCode?: string }> {
  return runAction({ permission: "events.manage_attendance", bucket: "admin:event:checkin", max: 300 }, async (ctx) => {
    const ids = z.object({ e: recordId, u: recordId }).safeParse({ e: eventId, u: userId });
    if (!ids.success) return { ok: false, code: "NOT_FOUND" };
    const r = await checkInManually({ eventId: ids.data.e, userId: ids.data.u, actorId: ctx.userId });
    revalidatePath(`/admin/events/${ids.data.e}`);
    if (r.ok) return { ok: true };
    return { ok: false, code: r.code === "ALREADY_CHECKED_IN" ? "CONFLICT" : r.code === "NOT_REGISTERED" ? "NOT_FOUND" : "INVALID", checkInCode: r.code };
  });
}

const correctionSchema = z.object({
  toStatus: z.enum(["PRESENT", "LATE", "ABSENT", "EXCUSED"]),
  reason: z.enum(["MIS_SCAN", "LATE_ARRIVAL", "TECHNICAL_ISSUE", "ADMIN_ADJUSTMENT", "OTHER"]),
  note: optionalText(500),
});

/** Attendance correction: the reason is mandatory and logged in AttendanceLog + AuditLog. */
export async function correctAttendanceAction(attendanceId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "events.correct_attendance", bucket: "admin:event:correct", max: 60 }, async (ctx) => {
    const id = recordId.safeParse(attendanceId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    const parsed = parseForm(correctionSchema, formData);
    if (!parsed.ok) return parsed.result;
    const r = await correctAttendance({ attendanceId: id.data, ...parsed.data, actorId: ctx.userId });
    if (!r.ok) return { ok: false, code: "CONFLICT" };
    revalidatePath("/admin/events");
    return { ok: true };
  });
}

const reminderSchema = z.object({ hoursBefore: z.coerce.number().int().min(1).max(24 * 14) });

export async function addReminderAction(eventId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "events.update", bucket: "admin:event:reminder", max: 30 }, async (ctx) => {
    const id = recordId.safeParse(eventId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    const parsed = parseForm(reminderSchema, formData);
    if (!parsed.ok) return parsed.result;
    const event = await db.event.findUnique({ where: { id: id.data }, select: { id: true, startsAt: true } });
    if (!event) return { ok: false, code: "NOT_FOUND" };
    const sendAt = new Date(event.startsAt.getTime() - parsed.data.hoursBefore * 3600_000);
    await db.eventReminder.create({ data: { eventId: event.id, sendAt } });
    await logAudit({ actorId: ctx.userId, action: "event.reminder.add", entityType: "Event", entityId: event.id, after: { sendAt } });
    revalidatePath(`/admin/events/${event.id}`);
    return { ok: true };
  });
}

export async function deleteReminderAction(reminderId: string): Promise<ActionResult> {
  return runAction({ permission: "events.update", bucket: "admin:event:reminder", max: 30 }, async () => {
    const id = recordId.safeParse(reminderId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    const r = await db.eventReminder.deleteMany({ where: { id: id.data, sentAt: null } });
    if (r.count === 0) return { ok: false, code: "NOT_FOUND" };
    revalidatePath("/admin/events");
    return { ok: true };
  });
}

const rotatingSchema = z.object({ enabled: z.boolean(), seconds: z.number().int().min(30).max(900) });

export async function setRotatingQrAction(eventId: string, enabled: boolean, seconds: number): Promise<ActionResult> {
  return runAction({ permission: "events.manage_attendance", bucket: "admin:event:rotating", max: 30 }, async (ctx) => {
    const id = recordId.safeParse(eventId);
    const v = parseValue(rotatingSchema, { enabled, seconds });
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    if (!v.ok) return v.result;
    await db.event.update({ where: { id: id.data }, data: { rotatingQrEnabled: v.data.enabled, qrRotateSeconds: v.data.seconds } });
    await logAudit({ actorId: ctx.userId, action: "event.rotating_qr", entityType: "Event", entityId: id.data, after: v.data });
    revalidatePath(`/admin/events/${id.data}`);
    return { ok: true };
  });
}
