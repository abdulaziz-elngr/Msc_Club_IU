"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { guardMutation } from "@/lib/actions/guard";
import { cancelRegistration, registerForEvent } from "@/lib/registration";

/**
 * Member-facing event actions.
 *
 * Results carry machine-readable codes (never English prose) so the client can
 * render them in the viewer's language. Identity always comes from the server
 * session; the client only supplies the event id and the form answers.
 */
export type EventActionState =
  | undefined
  | {
      ok: boolean;
      code?: string;
      status?: "CONFIRMED" | "WAITLISTED";
      position?: number | null;
      fieldErrors?: Record<string, string>;
      values?: Record<string, string>;
    };

const eventId = z.string().min(8).max(40).regex(/^[A-Za-z0-9_-]+$/);

export async function registerForEventAction(
  rawEventId: string,
  _prev: EventActionState,
  formData: FormData,
): Promise<EventActionState> {
  const id = eventId.safeParse(rawEventId);
  if (!id.success) return { ok: false, code: "EVENT_NOT_FOUND" };

  const guard = await guardMutation("events:register", 10, 60_000);
  if (!guard.ok) return { ok: false, code: guard.code };

  const answers: Record<string, string> = {};
  for (const [key, value] of formData.entries()) {
    if (typeof value === "string" && !key.startsWith("$ACTION")) answers[key] = value;
  }

  const result = await registerForEvent({ eventId: id.data, userId: guard.ctx.userId, answers });
  if (!result.ok) {
    return {
      ok: false,
      code: result.code,
      ...(result.code === "INVALID_ANSWERS" ? { fieldErrors: result.fieldErrors, values: answers } : {}),
    };
  }

  revalidatePath("/dashboard/events");
  revalidatePath("/dashboard");
  return { ok: true, status: result.status, position: result.waitlistPosition };
}

export async function cancelRegistrationAction(rawEventId: string): Promise<EventActionState> {
  const id = eventId.safeParse(rawEventId);
  if (!id.success) return { ok: false, code: "EVENT_NOT_FOUND" };

  const guard = await guardMutation("events:cancel", 10, 60_000);
  if (!guard.ok) return { ok: false, code: guard.code };

  const result = await cancelRegistration({ eventId: id.data, userId: guard.ctx.userId });
  if (!result.ok) return { ok: false, code: result.code };

  revalidatePath("/dashboard/events");
  revalidatePath("/dashboard");
  return { ok: true };
}
