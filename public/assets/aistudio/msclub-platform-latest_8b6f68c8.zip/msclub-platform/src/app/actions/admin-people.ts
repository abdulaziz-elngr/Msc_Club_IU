"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { parseForm, runAction, type ActionResult } from "@/lib/actions/admin";
import { assertPermission } from "@/lib/auth/dal";
import { transitionApplication } from "@/lib/applications";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { setUserRole } from "@/lib/roles-admin";
import { optionalText, recordId, text } from "@/lib/validation";

const decisionSchema = z.object({ to: z.enum(["UNDER_REVIEW", "ACCEPTED", "REJECTED"]), note: optionalText(1000) });

/** Moves an application through the workflow. Reviewing and deciding are separate permissions. */
export async function decideApplicationAction(applicationId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ bucket: "admin:application", max: 60 }, async (ctx) => {
    const id = recordId.safeParse(applicationId);
    const parsed = parseForm(decisionSchema, formData);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    if (!parsed.ok) return parsed.result;
    assertPermission(ctx, parsed.data.to === "UNDER_REVIEW" ? "applications.review" : "applications.decide");

    const r = await transitionApplication({ applicationId: id.data, to: parsed.data.to, note: parsed.data.note, actorId: ctx.userId });
    revalidatePath("/admin/applications");
    revalidatePath("/admin/members");
    if (r.ok) return { ok: true };
    return r.code === "NOTE_REQUIRED" ? { ok: false, code: "INVALID", fieldErrors: { note: "required" } } : { ok: false, code: r.code === "NOT_FOUND" ? "NOT_FOUND" : "CONFLICT" };
  });
}

const STATUS_CHANGES = ["ACTIVE", "SUSPENDED", "ARCHIVED"] as const;
const statusSchema = z.object({ status: z.enum(STATUS_CHANGES), reason: text(500) });

/** Suspend / archive / reactivate. Signing the member out everywhere is immediate (sessionVersion bump). */
export async function changeMemberStatusAction(userId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "members.suspend", bucket: "admin:member:status", max: 30 }, async (ctx) => {
    const id = recordId.safeParse(userId);
    const parsed = parseForm(statusSchema, formData);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    if (!parsed.ok) return parsed.result;
    if (id.data === ctx.userId) return { ok: false, code: "SELF_STATUS" };

    const user = await db.user.findUnique({ where: { id: id.data }, select: { id: true, status: true } });
    if (!user) return { ok: false, code: "NOT_FOUND" };
    // Only people who were already members can be (re)activated here; applications go through the workflow.
    if (parsed.data.status === "ACTIVE" && !["SUSPENDED", "ARCHIVED"].includes(user.status)) return { ok: false, code: "CONFLICT" };

    await db.user.update({
      where: { id: user.id },
      data: { status: parsed.data.status, ...(parsed.data.status !== "ACTIVE" ? { sessionVersion: { increment: 1 } } : {}) },
    });
    await logAudit({ actorId: ctx.userId, action: `member.${parsed.data.status.toLowerCase()}`, entityType: "User", entityId: user.id, before: { status: user.status }, after: { status: parsed.data.status }, reason: parsed.data.reason });
    revalidatePath(`/admin/members/${user.id}`);
    revalidatePath("/admin/members");
    return { ok: true };
  });
}

const ROLE_KEYS = ["SUPER_ADMIN", "CLUB_PRESIDENT", "VICE_PRESIDENT", "TECHNICAL_LEAD", "HR_LEAD", "EVENTS_LEAD", "MARKETING_LEAD", "MEMBER", "APPLICANT"] as const;

export async function setMemberRoleAction(userId: string, role: string, grant: boolean): Promise<ActionResult> {
  return runAction({ permission: "admin.roles.manage", bucket: "admin:member:role", max: 40 }, async (ctx) => {
    const v = z.object({ id: recordId, role: z.enum(ROLE_KEYS) }).safeParse({ id: userId, role });
    if (!v.success) return { ok: false, code: "NOT_FOUND" };
    if (v.data.role === "SUPER_ADMIN" && v.data.id === ctx.userId) return { ok: false, code: "SELF_SUPER_ADMIN" };
    const r = await setUserRole({ actor: ctx, userId: v.data.id, role: v.data.role, grant });
    revalidatePath(`/admin/members/${v.data.id}`);
    return r.ok ? { ok: true } : { ok: false, code: r.code === "NOT_FOUND" ? "NOT_FOUND" : r.code };
  });
}

const profileSchema = z.object({
  name: text(120, 2),
  studentId: z.string().trim().regex(/^[A-Za-z0-9-]{4,20}$/).optional(),
  department: optionalText(120),
  phone: z.string().trim().regex(/^[0-9+()\-\s]{6,20}$/).optional(),
});

export async function updateMemberProfileAction(userId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "members.update", bucket: "admin:member:profile", max: 40 }, async (ctx) => {
    const id = recordId.safeParse(userId);
    const parsed = parseForm(profileSchema, formData);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    if (!parsed.ok) return parsed.result;
    const before = await db.user.findUnique({ where: { id: id.data }, select: { name: true, studentId: true, department: true, phone: true } });
    if (!before) return { ok: false, code: "NOT_FOUND" };
    try {
      await db.user.update({ where: { id: id.data }, data: { name: parsed.data.name, studentId: parsed.data.studentId ?? null, department: parsed.data.department ?? null, phone: parsed.data.phone ?? null } });
    } catch (e) {
      if ((e as { code?: string }).code === "P2002") return { ok: false, code: "INVALID", fieldErrors: { studentId: "duplicate" } };
      throw e;
    }
    await logAudit({ actorId: ctx.userId, action: "member.update", entityType: "User", entityId: id.data, before, after: parsed.data });
    revalidatePath(`/admin/members/${id.data}`);
    return { ok: true };
  });
}
