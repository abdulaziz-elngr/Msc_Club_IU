"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { parseForm, runAction, type ActionResult } from "@/lib/actions/admin";
import { assertPermission } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { slugify } from "@/lib/schemas/event";
import { addTeamMember, authorizeTeam, removeTeamMember, setLeadership } from "@/lib/teams-admin";
import { saveImage } from "@/lib/uploads";
import { int, optionalText, recordId, text } from "@/lib/validation";

const teamSchema = z.object({
  name: text(100, 2),
  nameAr: optionalText(100),
  slug: z.string().trim().toLowerCase().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(60).optional(),
  description: optionalText(2000),
  descriptionAr: optionalText(2000),
  trackId: recordId.optional(),
  visibility: z.enum(["PUBLIC", "PRIVATE", "HIDDEN"]),
  order: int(0, 1000).default(0),
});

function revalidateTeams(slug?: string) {
  revalidatePath("/admin/teams");
  revalidatePath("/teams");
  if (slug) revalidatePath(`/teams/${slug}`);
}

const uploadError = (code: string): ActionResult => ({ ok: false, code: "INVALID", fieldErrors: { logo: code === "TOO_LARGE" ? "tooBig" : "invalid" } });

export async function saveTeamAction(teamId: string | null, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: teamId ? "teams.update" : "teams.create", bucket: "admin:team:save", max: 30 }, async (ctx) => {
    const id = teamId === null ? null : recordId.safeParse(teamId);
    if (id && !id.success) return { ok: false, code: "NOT_FOUND" };
    const parsed = parseForm(teamSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;

    let logo: string | undefined;
    const file = formData.get("logo");
    if (file instanceof File && file.size > 0) {
      const up = await saveImage(file, "team-logo");
      if (!up.ok) return uploadError(up.code);
      logo = up.url;
    }
    if (v.trackId && !(await db.learningTrack.findUnique({ where: { id: v.trackId }, select: { id: true } }))) {
      return { ok: false, code: "INVALID", fieldErrors: { trackId: "invalid" } };
    }

    const common = {
      name: v.name, nameAr: v.nameAr ?? null, description: v.description ?? null, descriptionAr: v.descriptionAr ?? null,
      trackId: v.trackId ?? null, visibility: v.visibility, order: v.order, ...(logo ? { logo } : {}),
    };

    if (!id) {
      const slug = v.slug ?? slugify(v.name);
      let team;
      try {
        team = await db.team.create({ data: { ...common, slug } });
      } catch (e) {
        if ((e as { code?: string }).code !== "P2002") throw e;
        if (v.slug) return { ok: false, code: "INVALID", fieldErrors: { slug: "duplicate" } };
        team = await db.team.create({ data: { ...common, slug: `${slug}-${Math.random().toString(36).slice(2, 6)}` } });
      }
      await logAudit({ actorId: ctx.userId, action: "team.create", entityType: "Team", entityId: team.id, after: { name: team.name } });
      revalidateTeams(team.slug);
      return { ok: true, id: team.id, redirectTo: `/admin/teams/${team.id}` };
    }

    const before = await db.team.findUnique({ where: { id: id.data }, select: { name: true, visibility: true, slug: true } });
    if (!before) return { ok: false, code: "NOT_FOUND" };
    await db.team.update({ where: { id: id.data }, data: common });
    await logAudit({ actorId: ctx.userId, action: "team.update", entityType: "Team", entityId: id.data, before, after: { name: v.name, visibility: v.visibility } });
    revalidateTeams(before.slug);
    revalidatePath(`/admin/teams/${id.data}`);
    return { ok: true };
  });
}

export async function archiveTeamAction(teamId: string, archive: boolean): Promise<ActionResult> {
  return runAction({ permission: "teams.archive", bucket: "admin:team:archive", max: 20 }, async (ctx) => {
    const id = recordId.safeParse(teamId);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    const team = await db.team.update({ where: { id: id.data }, data: { status: archive ? "ARCHIVED" : "ACTIVE" }, select: { slug: true } });
    await logAudit({ actorId: ctx.userId, action: archive ? "team.archive" : "team.restore", entityType: "Team", entityId: id.data });
    revalidateTeams(team.slug);
    revalidatePath(`/admin/teams/${id.data}`);
    return { ok: true };
  });
}

const teamResultCode = (code: string): ActionResult => (code === "NOT_FOUND" ? { ok: false, code: "NOT_FOUND" } : { ok: false, code });

/** Members can be managed by global managers OR by the lead/co-lead of that exact team. */
export async function addTeamMemberAction(teamId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ bucket: "team:member:add", max: 30 }, async (ctx) => {
    const id = recordId.safeParse(teamId);
    const parsed = parseForm(z.object({ email: z.string().trim().email().max(200) }), formData);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    if (!parsed.ok) return parsed.result;
    authorizeTeam(ctx, id.data, "manage_members");
    const r = await addTeamMember({ teamId: id.data, email: parsed.data.email, actorId: ctx.userId });
    revalidatePath(`/admin/teams/${id.data}`);
    revalidatePath("/team", "layout");
    return r.ok ? { ok: true } : r.code === "NOT_ACTIVE" ? { ok: false, code: "INVALID", fieldErrors: { email: "invalid" } } : teamResultCode(r.code);
  });
}

export async function removeTeamMemberAction(teamId: string, userId: string): Promise<ActionResult> {
  return runAction({ bucket: "team:member:remove", max: 40 }, async (ctx) => {
    const ids = z.object({ t: recordId, u: recordId }).safeParse({ t: teamId, u: userId });
    if (!ids.success) return { ok: false, code: "NOT_FOUND" };
    authorizeTeam(ctx, ids.data.t, "manage_members");
    const r = await removeTeamMember({ teamId: ids.data.t, userId: ids.data.u, actorId: ctx.userId });
    revalidatePath(`/admin/teams/${ids.data.t}`);
    revalidatePath("/team", "layout");
    return r.ok ? { ok: true } : teamResultCode(r.code);
  });
}

const leadershipSchema = z.object({
  leadEmail: z.string().trim().email().max(200).optional(),
  coLeadEmail: z.string().trim().email().max(200).optional(),
});

export async function setLeadershipAction(teamId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "teams.update", bucket: "admin:team:lead", max: 20 }, async (ctx) => {
    const id = recordId.safeParse(teamId);
    const parsed = parseForm(leadershipSchema, formData);
    if (!id.success) return { ok: false, code: "NOT_FOUND" };
    if (!parsed.ok) return parsed.result;
    assertPermission(ctx, "teams.update");
    // An empty field means "remove": formToObject drops empties, so pass "" explicitly.
    const r = await setLeadership({ teamId: id.data, leadEmail: parsed.data.leadEmail ?? "", coLeadEmail: parsed.data.coLeadEmail ?? "", actorId: ctx.userId });
    revalidateTeams();
    revalidatePath(`/admin/teams/${id.data}`);
    if (r.ok) return { ok: true };
    return r.code === "NOT_ACTIVE" ? { ok: false, code: "INVALID", fieldErrors: { leadEmail: "invalid" } } : r.code === "SAME_PERSON" ? { ok: false, code: "INVALID", fieldErrors: { coLeadEmail: "duplicate" } } : teamResultCode(r.code);
  });
}
