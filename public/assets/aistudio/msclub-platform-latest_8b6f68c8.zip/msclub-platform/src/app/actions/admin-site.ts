"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { parseForm, runAction, type ActionResult } from "@/lib/actions/admin";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { APPLICATION_FIELD_KEYS, SETTING_KEYS, getSettings, putSetting } from "@/lib/settings";
import { checkbox, int, optionalText, recordId, text } from "@/lib/validation";

const settingsSchema = z.object({
  siteName: text(80),
  tagline: optionalText(160),
  contactEmail: z.string().trim().email().max(200),
  contactPhone: optionalText(40),
  address: optionalText(200),
  registrationOpen: checkbox,
  requiredFields: z.preprocess((v) => (v === undefined ? [] : Array.isArray(v) ? v : [v]), z.array(z.enum(APPLICATION_FIELD_KEYS))),
  welcomeXp: int(0, 10_000),
  leaderboardPublic: checkbox,
  leaderboardPeriod: z.enum(["weekly", "monthly", "all_time"]),
});

export async function saveSettingsAction(_prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "admin.settings.manage", bucket: "admin:settings", max: 20 }, async (ctx) => {
    const parsed = parseForm(settingsSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;
    const before = await getSettings();

    await db.$transaction([
      ...([
        [SETTING_KEYS.SITE_NAME, v.siteName, "string"], [SETTING_KEYS.TAGLINE, v.tagline ?? "", "string"],
        [SETTING_KEYS.CONTACT_EMAIL, v.contactEmail, "string"], [SETTING_KEYS.CONTACT_PHONE, v.contactPhone ?? "", "string"],
        [SETTING_KEYS.ADDRESS, v.address ?? "", "string"], [SETTING_KEYS.REGISTRATION_OPEN, v.registrationOpen, "boolean"],
        [SETTING_KEYS.REQUIRED_FIELDS, v.requiredFields, "json"], [SETTING_KEYS.XP_WELCOME, v.welcomeXp, "number"],
        [SETTING_KEYS.LEADERBOARD_PUBLIC, v.leaderboardPublic, "boolean"], [SETTING_KEYS.LEADERBOARD_PERIOD, v.leaderboardPeriod, "string"],
      ] as const).map(([key, value, type]) =>
        db.siteSettings.upsert({ where: { key }, create: { key, value: value as never, type, group: key.split(".")[0] }, update: { value: value as never, type } }),
      ),
    ]);
    await logAudit({
      actorId: ctx.userId, action: "settings.update", entityType: "SiteSettings",
      before: { registrationOpen: before[SETTING_KEYS.REGISTRATION_OPEN], leaderboardPublic: before[SETTING_KEYS.LEADERBOARD_PUBLIC], requiredFields: before[SETTING_KEYS.REQUIRED_FIELDS] },
      after: { registrationOpen: v.registrationOpen, leaderboardPublic: v.leaderboardPublic, requiredFields: v.requiredFields },
    });
    revalidatePath("/", "layout");
    return { ok: true };
  });
}

const SOCIAL = ["instagram", "linkedin", "youtube", "github", "x", "discord"] as const;
const socialUrl = z.string().trim().url().max(300).refine((u) => /^https:\/\//i.test(u));

export async function saveSocialLinksAction(_prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "content.manage", bucket: "admin:social", max: 20 }, async (ctx) => {
    const parsed = parseForm(z.object(Object.fromEntries(SOCIAL.map((k) => [k, socialUrl.optional()]))), formData);
    if (!parsed.ok) return parsed.result;
    // Only https links and only known networks are stored; blank removes a link.
    const links = Object.fromEntries(SOCIAL.map((k) => [k, (parsed.data as Record<string, string | undefined>)[k] ?? ""]));
    await putSetting(SETTING_KEYS.SOCIAL, links, "json");
    await logAudit({ actorId: ctx.userId, action: "content.social.update", entityType: "SiteSettings", after: links });
    revalidatePath("/", "layout");
    return { ok: true };
  });
}

const testimonialSchema = z.object({
  name: text(100), nameAr: optionalText(100), role: optionalText(120), roleAr: optionalText(120),
  quote: text(600, 10), quoteAr: optionalText(600), approved: checkbox, order: int(0, 1000).default(0),
});

export async function saveTestimonialAction(id: string | null, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "content.testimonials.manage", bucket: "admin:testimonial", max: 40 }, async (ctx) => {
    const rid = id === null ? null : recordId.safeParse(id);
    if (rid && !rid.success) return { ok: false, code: "NOT_FOUND" };
    const parsed = parseForm(testimonialSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;
    const data = { name: v.name, nameAr: v.nameAr ?? null, role: v.role ?? null, roleAr: v.roleAr ?? null, quote: v.quote, quoteAr: v.quoteAr ?? null, approved: v.approved, order: v.order };
    const row = rid ? await db.testimonial.update({ where: { id: rid.data }, data }) : await db.testimonial.create({ data });
    await logAudit({ actorId: ctx.userId, action: rid ? "testimonial.update" : "testimonial.create", entityType: "Testimonial", entityId: row.id, after: { approved: v.approved } });
    revalidatePath("/"); revalidatePath("/admin/content");
    return { ok: true };
  });
}

export async function deleteTestimonialAction(id: string): Promise<ActionResult> {
  return runAction({ permission: "content.testimonials.manage", bucket: "admin:testimonial", max: 40 }, async (ctx) => {
    const rid = recordId.safeParse(id);
    if (!rid.success) return { ok: false, code: "NOT_FOUND" };
    await db.testimonial.delete({ where: { id: rid.data } });
    await logAudit({ actorId: ctx.userId, action: "testimonial.delete", entityType: "Testimonial", entityId: rid.data });
    revalidatePath("/"); revalidatePath("/admin/content");
    return { ok: true };
  });
}

export async function setMessageReadAction(id: string, read: boolean): Promise<ActionResult> {
  return runAction({ permission: "content.manage", bucket: "admin:message", max: 120 }, async () => {
    const rid = recordId.safeParse(id);
    if (!rid.success) return { ok: false, code: "NOT_FOUND" };
    await db.contactMessage.update({ where: { id: rid.data }, data: { readAt: read ? new Date() : null } });
    revalidatePath("/admin/messages");
    return { ok: true };
  });
}
