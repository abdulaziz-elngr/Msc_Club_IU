"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { parseForm, runAction, type ActionResult } from "@/lib/actions/admin";
import { assertPermission } from "@/lib/auth/dal";
import { logAudit } from "@/lib/audit";
import { db } from "@/lib/db";
import { ICON_NAMES } from "@/lib/icons";
import { notify } from "@/lib/notifications";
import { adjustXp, awardXp, reverseXp } from "@/lib/xp";
import { checkbox, hexColor, int, optionalInt, optionalText, recordId, text } from "@/lib/validation";

const nonce = z.string().regex(/^[A-Za-z0-9-]{12,64}$/);
const email = z.string().trim().email().max(200);

async function activeUser(address: string) {
  return db.user.findFirst({ where: { email: { equals: address, mode: "insensitive" }, status: "ACTIVE" }, select: { id: true, totalXp: true } });
}
const fail = (code: string): ActionResult => ({ ok: false, code, fieldErrors: undefined });
const fieldFail = (field: string, code: string): ActionResult => ({ ok: false, code: "INVALID", fieldErrors: { [field]: code } });

// ---------------------------------------------------------------- points rules
const ruleSchema = z.object({
  key: z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_.-]{1,60}$/).optional(),
  label: text(120), labelAr: optionalText(120), activityType: text(60),
  points: int(-10_000, 10_000), maxAwardsPerUser: optionalInt(1, 100_000),
  requiresApproval: checkbox, enabled: checkbox,
  referenceType: z.enum(["EVENT", "ATTENDANCE", "COURSE", "LESSON", "TASK", "SUBMISSION", "BADGE", "LEVEL", "ADMIN_ADJUSTMENT", "COMMUNITY"]),
});

export async function savePointsRuleAction(ruleId: string | null, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "points.adjust", bucket: "admin:points:rule", max: 40 }, async (ctx) => {
    const id = ruleId === null ? null : recordId.safeParse(ruleId);
    if (id && !id.success) return fail("NOT_FOUND");
    const parsed = parseForm(ruleSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;
    // These two keys are reserved for system ledger entries.
    if (v.key && ["admin.adjustment", "admin.reversal"].includes(v.key)) return fieldFail("key", "duplicate");
    const data = { label: v.label, labelAr: v.labelAr ?? null, activityType: v.activityType, points: v.points, maxAwardsPerUser: v.maxAwardsPerUser ?? null, requiresApproval: v.requiresApproval, enabled: v.enabled, referenceType: v.referenceType };

    if (!id) {
      if (!v.key) return fieldFail("key", "required");
      try {
        const row = await db.pointsRule.create({ data: { ...data, key: v.key } });
        await logAudit({ actorId: ctx.userId, action: "points.rule.create", entityType: "PointsRule", entityId: row.id, after: { key: v.key, points: v.points } });
      } catch (e) {
        if ((e as { code?: string }).code === "P2002") return fieldFail("key", "duplicate");
        throw e;
      }
    } else {
      const before = await db.pointsRule.findUnique({ where: { id: id.data }, select: { points: true, enabled: true, maxAwardsPerUser: true } });
      if (!before) return fail("NOT_FOUND");
      await db.pointsRule.update({ where: { id: id.data }, data });
      await logAudit({ actorId: ctx.userId, action: "points.rule.update", entityType: "PointsRule", entityId: id.data, before, after: { points: v.points, enabled: v.enabled, maxAwardsPerUser: v.maxAwardsPerUser ?? null } });
    }
    revalidatePath("/admin/points");
    return { ok: true };
  });
}

// ---------------------------------------------------------------- manual award
const awardSchema = z.object({ email, ruleKey: z.string().min(2).max(70), nonce });

export async function awardPointsAction(_prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "points.award", bucket: "admin:points:award", max: 60 }, async (ctx) => {
    const parsed = parseForm(awardSchema, formData);
    if (!parsed.ok) return parsed.result;
    const [user, rule] = await Promise.all([activeUser(parsed.data.email), db.pointsRule.findFirst({ where: { key: parsed.data.ruleKey, enabled: true } })]);
    if (!user) return fieldFail("email", "invalid");
    if (!rule) return fieldFail("ruleKey", "invalid");
    if (rule.requiresApproval) assertPermission(ctx, "points.adjust");

    const r = await awardXp({
      userId: user.id, activityKey: rule.key, referenceType: rule.referenceType, description: rule.label, descriptionAr: rule.labelAr,
      awardedById: ctx.userId, idempotencyKey: `manual:${user.id}:${parsed.data.nonce}`,
    });
    // A replay of the same submission is a success (idempotent); a refused award is not.
    if (!r.awarded && !r.duplicate) return fail("CAPPED");
    if (r.awarded) await logAudit({ actorId: ctx.userId, action: "points.award", entityType: "User", entityId: user.id, after: { rule: rule.key, amount: r.amount } });
    revalidatePath("/admin/points");
    return { ok: true };
  });
}

// ---------------------------------------------------------------- adjustments
const adjustSchema = z.object({ email, amount: z.coerce.number().int().min(-10_000).max(10_000).refine((n) => n !== 0), reason: text(300), nonce });

export async function adjustPointsAction(_prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ bucket: "admin:points:adjust", max: 40 }, async (ctx) => {
    const parsed = parseForm(adjustSchema, formData);
    if (!parsed.ok) return parsed.result;
    // Deducting is the sensitive direction and needs the stronger permission.
    assertPermission(ctx, parsed.data.amount < 0 ? "points.adjust" : "points.award");
    const user = await activeUser(parsed.data.email);
    if (!user) return fieldFail("email", "invalid");

    const r = await adjustXp({ userId: user.id, amount: parsed.data.amount, reason: parsed.data.reason, actorId: ctx.userId, key: parsed.data.nonce });
    if (!r.awarded && !r.duplicate) return fail("GENERIC");
    if (r.awarded) await logAudit({ actorId: ctx.userId, action: parsed.data.amount < 0 ? "points.deduct" : "points.adjust", entityType: "User", entityId: user.id, after: { amount: parsed.data.amount }, reason: parsed.data.reason });
    revalidatePath("/admin/points");
    return { ok: true };
  });
}

export async function reversePointsAction(transactionId: string, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "points.reverse", bucket: "admin:points:reverse", max: 40 }, async (ctx) => {
    const id = recordId.safeParse(transactionId);
    const parsed = parseForm(z.object({ reason: text(300) }), formData);
    if (!id.success) return fail("NOT_FOUND");
    if (!parsed.ok) return parsed.result;
    const r = await reverseXp({ transactionId: id.data, reason: parsed.data.reason, actorId: ctx.userId });
    if (!r.awarded && !r.duplicate) return fail("CONFLICT");
    if (r.awarded) {
      const original = await db.xPTransaction.findUnique({ where: { id: id.data }, select: { userId: true } });
      await logAudit({ actorId: ctx.userId, action: "points.reverse", entityType: "XPTransaction", entityId: id.data, after: { userId: original?.userId, amount: r.amount }, reason: parsed.data.reason });
    }
    revalidatePath("/admin/points");
    return { ok: true };
  });
}

// ---------------------------------------------------------------- levels
const levelSchema = z.object({
  key: z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_-]{1,40}$/).optional(),
  name: text(60), nameAr: optionalText(60), minXp: int(0, 10_000_000),
  description: optionalText(300), descriptionAr: optionalText(300),
  icon: z.enum(ICON_NAMES), color: hexColor, rewards: optionalText(1000), enabled: checkbox,
});

/** Re-derives every member's level from XP in one statement, and renumbers level order by threshold. */
async function recalculateLevels() {
  await db.$executeRaw`
    UPDATE "levels" l SET "order" = r.rn FROM (
      SELECT "id", ROW_NUMBER() OVER (ORDER BY "minXp" ASC, "createdAt" ASC) AS rn FROM "levels"
    ) r WHERE l."id" = r."id"`;
  await db.$executeRaw`
    UPDATE "users" u SET "levelId" = (
      SELECT l."id" FROM "levels" l WHERE l."enabled" AND l."minXp" <= u."totalXp" ORDER BY l."minXp" DESC LIMIT 1)`;
}

export async function saveLevelAction(levelId: string | null, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "levels.manage", bucket: "admin:level", max: 30 }, async (ctx) => {
    const id = levelId === null ? null : recordId.safeParse(levelId);
    if (id && !id.success) return fail("NOT_FOUND");
    const parsed = parseForm(levelSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;

    // Two enabled levels with the same threshold would make the level of a member ambiguous.
    if (v.enabled && (await db.level.count({ where: { enabled: true, minXp: v.minXp, ...(id ? { NOT: { id: id.data } } : {}) } })) > 0) return fieldFail("minXp", "duplicate");

    const rewards = (v.rewards ?? "").split("\n").map((r) => r.trim()).filter(Boolean).slice(0, 10);
    const data = { name: v.name, nameAr: v.nameAr ?? null, minXp: v.minXp, description: v.description ?? null, descriptionAr: v.descriptionAr ?? null, icon: v.icon, color: v.color, rewards, enabled: v.enabled };
    if (!id) {
      if (!v.key) return fieldFail("key", "required");
      try {
        const row = await db.level.create({ data: { ...data, key: v.key } });
        await logAudit({ actorId: ctx.userId, action: "level.create", entityType: "Level", entityId: row.id, after: { key: v.key, minXp: v.minXp } });
      } catch (e) {
        if ((e as { code?: string }).code === "P2002") return fieldFail("key", "duplicate");
        throw e;
      }
    } else {
      const before = await db.level.findUnique({ where: { id: id.data }, select: { minXp: true, enabled: true } });
      if (!before) return fail("NOT_FOUND");
      await db.level.update({ where: { id: id.data }, data });
      await logAudit({ actorId: ctx.userId, action: "level.update", entityType: "Level", entityId: id.data, before, after: { minXp: v.minXp, enabled: v.enabled } });
    }
    await recalculateLevels();
    revalidatePath("/admin/levels");
    return { ok: true };
  });
}

export async function recalculateLevelsAction(): Promise<ActionResult> {
  return runAction({ permission: "levels.manage", bucket: "admin:level:recalc", max: 6 }, async (ctx) => {
    await recalculateLevels();
    await logAudit({ actorId: ctx.userId, action: "level.recalculate", entityType: "Level" });
    revalidatePath("/admin/levels");
    return { ok: true };
  });
}

export async function deleteLevelAction(levelId: string): Promise<ActionResult> {
  return runAction({ permission: "levels.manage", bucket: "admin:level:delete", max: 20 }, async (ctx) => {
    const id = recordId.safeParse(levelId);
    if (!id.success) return fail("NOT_FOUND");
    if ((await db.user.count({ where: { levelId: id.data } })) > 0) return fail("IN_USE");
    await db.level.delete({ where: { id: id.data } });
    await recalculateLevels();
    await logAudit({ actorId: ctx.userId, action: "level.delete", entityType: "Level", entityId: id.data });
    revalidatePath("/admin/levels");
    return { ok: true };
  });
}

// ---------------------------------------------------------------- badges
const CRITERIA = ["total_xp", "level", "events_attended", "courses_completed", "lessons_completed", "tasks_approved", "certificates", "badges_count"] as const;
const badgeSchema = z.object({
  key: z.string().trim().toLowerCase().regex(/^[a-z][a-z0-9_-]{1,40}$/).optional(),
  name: text(60), nameAr: optionalText(60), description: optionalText(300), descriptionAr: optionalText(300),
  icon: z.enum(ICON_NAMES), color: hexColor, tier: z.enum(["bronze", "silver", "gold", "platinum"]),
  criteriaType: z.enum([...CRITERIA, "manual"]), threshold: optionalInt(1, 10_000_000),
  autoAward: checkbox, enabled: checkbox,
});

export async function saveBadgeAction(badgeId: string | null, _prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "badges.manage", bucket: "admin:badge", max: 30 }, async (ctx) => {
    const id = badgeId === null ? null : recordId.safeParse(badgeId);
    if (id && !id.success) return fail("NOT_FOUND");
    const parsed = parseForm(badgeSchema, formData);
    if (!parsed.ok) return parsed.result;
    const v = parsed.data;
    const manual = v.criteriaType === "manual";
    if (!manual && v.threshold === undefined) return fieldFail("threshold", "required");

    const data = {
      name: v.name, nameAr: v.nameAr ?? null, description: v.description ?? null, descriptionAr: v.descriptionAr ?? null,
      icon: v.icon, color: v.color, tier: v.tier, enabled: v.enabled,
      criteria: manual ? {} : { type: v.criteriaType, threshold: v.threshold }, autoAward: !manual && v.autoAward,
    };
    if (!id) {
      if (!v.key) return fieldFail("key", "required");
      try {
        const row = await db.badge.create({ data: { ...data, key: v.key } });
        await logAudit({ actorId: ctx.userId, action: "badge.create", entityType: "Badge", entityId: row.id, after: { key: v.key } });
      } catch (e) {
        if ((e as { code?: string }).code === "P2002") return fieldFail("key", "duplicate");
        throw e;
      }
    } else {
      await db.badge.update({ where: { id: id.data }, data });
      await logAudit({ actorId: ctx.userId, action: "badge.update", entityType: "Badge", entityId: id.data, after: { enabled: v.enabled, criteria: data.criteria } });
    }
    revalidatePath("/admin/badges");
    return { ok: true };
  });
}

const holderSchema = z.object({ email, badgeId: recordId });

export async function grantBadgeAction(_prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "badges.manage", bucket: "admin:badge:grant", max: 60 }, async (ctx) => {
    const parsed = parseForm(holderSchema, formData);
    if (!parsed.ok) return parsed.result;
    const [user, badge] = await Promise.all([activeUser(parsed.data.email), db.badge.findUnique({ where: { id: parsed.data.badgeId } })]);
    if (!user) return fieldFail("email", "invalid");
    if (!badge) return fieldFail("badgeId", "invalid");
    const made = await db.userBadge.createMany({ data: [{ userId: user.id, badgeId: badge.id, awardedById: ctx.userId }], skipDuplicates: true });
    if (made.count === 0) return fail("ALREADY_HELD");
    await notify({ userId: user.id, type: "BADGE_EARNED", title: `Badge earned: ${badge.name}`, titleAr: `حصلت على شارة: ${badge.nameAr ?? badge.name}`, href: "/dashboard/achievements", email: false });
    await logAudit({ actorId: ctx.userId, action: "badge.grant", entityType: "User", entityId: user.id, after: { badge: badge.key } });
    revalidatePath("/admin/badges");
    return { ok: true };
  });
}

export async function revokeBadgeAction(_prev: ActionResult | undefined, formData: FormData): Promise<ActionResult> {
  return runAction({ permission: "badges.manage", bucket: "admin:badge:revoke", max: 60 }, async (ctx) => {
    const parsed = parseForm(holderSchema, formData);
    if (!parsed.ok) return parsed.result;
    const user = await activeUser(parsed.data.email);
    if (!user) return fieldFail("email", "invalid");
    const gone = await db.userBadge.deleteMany({ where: { userId: user.id, badgeId: parsed.data.badgeId } });
    if (gone.count === 0) return fail("NOT_HELD");
    await logAudit({ actorId: ctx.userId, action: "badge.revoke", entityType: "User", entityId: user.id, after: { badgeId: parsed.data.badgeId } });
    revalidatePath("/admin/badges");
    return { ok: true };
  });
}
