import { PrismaAdapter } from "@auth/prisma-adapter";
import NextAuth from "next-auth";
import Credentials from "next-auth/providers/credentials";
import { z } from "zod";
import { db } from "@/lib/db";
import { headers } from "next/headers";
import { DUMMY_BCRYPT_HASH, isLoginThrottled, recordLoginAttempt } from "@/lib/auth/throttle";
import { isBlockedStatus } from "@/lib/auth/policy";
import { getEnv } from "@/lib/env";

/**
 * Auth.js (v5) configuration.
 *
 * Design notes
 *  • JWT session strategy — the signed cookie only ever carries the user id.
 *    Authorization (roles / permissions / team access) is ALWAYS resolved from
 *    the database in `src/lib/rbac/*`, never trusted from the token.
 *  • The Prisma adapter persists users / accounts / sessions so OAuth providers
 *    can be added later without a schema change.
 *  • Credentials are validated by the login server action first (rate limiting,
 *    account-status policy, precise error messages), then handed to Auth.js
 *    which owns session creation and cookie handling.
 */

const credentialsSchema = z.object({
  email: z.string().trim().min(1).max(320),
  password: z.string().min(1).max(200),
});

export const { handlers, auth, signIn, signOut } = NextAuth({
  adapter: PrismaAdapter(db),
  secret: getEnv().AUTH_SECRET,
  trustHost: getEnv().AUTH_TRUST_HOST !== "false",
  session: {
    strategy: "jwt",
    maxAge: getEnv().SESSION_MAX_AGE_DAYS * 24 * 60 * 60,
    updateAge: 24 * 60 * 60,
  },
  pages: {
    signIn: "/login",
    error: "/login",
    verifyRequest: "/verify-email",
    newUser: "/dashboard",
  },
  providers: [
    Credentials({
      id: "credentials",
      name: "Email and password",
      credentials: {
        email: { label: "University email", type: "email" },
        password: { label: "Password", type: "password" },
      },
      async authorize(raw) {
        const parsed = credentialsSchema.safeParse(raw);
        if (!parsed.success) return null;

        // This callback is also reachable by POSTing straight to
        // /api/auth/callback/credentials, so it must enforce the same policy as
        // the login server action: throttling, constant-time lookup, status.
        const email = parsed.data.email.toLowerCase();
        const { password } = parsed.data;
        const h = await headers();
        const ip = h.get("x-forwarded-for")?.split(",")[0]?.trim() || h.get("x-real-ip") || "unknown";

        if (await isLoginThrottled(email, ip)) return null;

        const user = await db.user.findUnique({
          where: { email },
          select: {
            id: true,
            email: true,
            name: true,
            image: true,
            passwordHash: true,
            status: true,
            sessionVersion: true,
          },
        });

        const { compare } = await import("bcryptjs");
        // Always run one bcrypt comparison so response time does not reveal
        // whether the account exists.
        const valid = await compare(password, user?.passwordHash ?? DUMMY_BCRYPT_HASH);
        if (!user?.passwordHash || !valid || isBlockedStatus(user.status)) {
          await recordLoginAttempt(email, ip, false);
          return null;
        }

        return {
          id: user.id,
          email: user.email,
          name: user.name,
          image: user.image,
          sessionVersion: user.sessionVersion,
        };
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user?.id) {
        token.sub = user.id;
        token.sv = (user as { sessionVersion?: number }).sessionVersion ?? 0;
      }
      return token;
    },
    async session({ session, token }) {
      if (token.sub) session.user.id = token.sub;
      session.sv = typeof token.sv === "number" ? token.sv : 0;
      return session;
    },
  },
  events: {
    async signIn({ user }) {
      // Placeholder for post-sign-in hooks (last-seen tracking, etc.).
      void user;
    },
  },
  debug: process.env.NODE_ENV === "development" && process.env.AUTH_DEBUG === "true",
});
