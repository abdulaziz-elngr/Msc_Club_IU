import * as React from "react"

const MOBILE_BREAKPOINT = 768

/**
 * Subscribes to the viewport breakpoint instead of calling `setState` from an
 * effect body (which triggers a cascading render). `useSyncExternalStore`
 * keeps the value correct on resize, on hydration, and on the server.
 */
function subscribe(callback: () => void) {
  const mql = window.matchMedia(`(max-width: ${MOBILE_BREAKPOINT - 1}px)`)
  mql.addEventListener("change", callback)
  return () => mql.removeEventListener("change", callback)
}

function getSnapshot() {
  return window.innerWidth < MOBILE_BREAKPOINT
}

/** Server rendering has no viewport: assume desktop to avoid layout shift. */
function getServerSnapshot() {
  return false
}

export function useIsMobile(): boolean {
  return React.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot)
}
