import "server-only";

import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@/generated/client";
import { getEnv } from "@/lib/env";

/**
 * Singleton Prisma client.
 *
 * Prisma 7 requires an explicit driver adapter. We use `@prisma/adapter-pg`
 * (node-postgres), which works with both a local Postgres and Neon's
 * pooled/HTTP endpoints — no code change required when switching to Neon.
 */

const globalForPrisma = globalThis as unknown as { __prisma?: PrismaClient };

function createClient(): PrismaClient {
  const env = getEnv();
  const adapter = new PrismaPg({
    connectionString: env.DATABASE_URL,
  });
  return new PrismaClient({ adapter });
}

export const db = globalForPrisma.__prisma ?? createClient();

if (process.env.NODE_ENV !== "production") {
  globalForPrisma.__prisma = db;
}

export type Database = typeof db;
