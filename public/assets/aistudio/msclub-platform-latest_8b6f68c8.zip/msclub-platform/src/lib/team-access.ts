import "server-only";

import { notFound } from "next/navigation";
import { ForbiddenError, requireAuth, requireTeamAccess } from "@/lib/auth/dal";
import { getTeamBySlug } from "@/lib/queries/team";

/**
 * Shared guard for every /team/[slug]/* page: authenticates, resolves the team and
 * verifies access to THAT team on the server. Missing team and forbidden team give
 * the same 404, so team slugs cannot be probed.
 */
export async function loadTeamForUser(slug: string, action: "view" | "manage_tasks" | "manage_learning" | "manage_members" = "view") {
  await requireAuth(`/team/${slug}/dashboard`);
  const team = await getTeamBySlug(slug);
  if (!team) notFound();
  try {
    const { ctx, membership } = await requireTeamAccess(team.id, action);
    return { team, ctx, membership };
  } catch (e) {
    if (e instanceof ForbiddenError) notFound();
    throw e;
  }
}
