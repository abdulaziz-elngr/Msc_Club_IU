import "server-only";

import { createHmac, timingSafeEqual } from "node:crypto";
import { getEnv } from "@/lib/env";

/**
 * Event pass tokens.
 *
 * A pass is `<registrationId>.<signature>` where
 *   signature = base64url(HMAC-SHA256(secret, "pass:v<qrVersion>:<registrationId>"))
 *
 *  • 256-bit signature → unguessable; the id half is an opaque cuid, no personal data.
 *  • Nothing secret is stored in the database, so a database leak yields no valid
 *    passes. Bumping `EventRegistration.qrVersion` revokes a single pass; rotating
 *    QR_SECRET revokes all of them.
 *  • Verification is constant-time.
 */

function secret(): string {
  const env = getEnv();
  return env.QR_SECRET || env.AUTH_SECRET;
}

function sign(registrationId: string, version: number, key = secret()): string {
  return createHmac("sha256", key).update(`pass:v${version}:${registrationId}`).digest("base64url");
}

export function issuePassToken(registrationId: string, version: number): string {
  return `${registrationId}.${sign(registrationId, version)}`;
}

/** Splits a scanned value into its id half without trusting it. */
export function parsePassToken(raw: string): { registrationId: string; signature: string } | null {
  const value = raw.trim();
  if (value.length < 40 || value.length > 200) return null;
  const dot = value.indexOf(".");
  if (dot <= 0 || dot !== value.lastIndexOf(".")) return null;
  const registrationId = value.slice(0, dot);
  const signature = value.slice(dot + 1);
  if (!/^[A-Za-z0-9_-]{8,64}$/.test(registrationId)) return null;
  if (!/^[A-Za-z0-9_-]{43}$/.test(signature)) return null;
  return { registrationId, signature };
}

/** True when `signature` is the valid signature for this registration + version. */
export function verifyPassSignature(registrationId: string, version: number, signature: string): boolean {
  const expected = Buffer.from(sign(registrationId, version));
  const actual = Buffer.from(signature);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
