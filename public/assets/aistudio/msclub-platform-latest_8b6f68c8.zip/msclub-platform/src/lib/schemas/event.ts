import { z } from "zod";
import { checkbox, int, isoDate, optionalInt, optionalIsoDate, optionalText, recordId, text } from "@/lib/validation";

export const EVENT_CATEGORIES = ["WORKSHOP", "TECHNICAL_SESSION", "BOOTCAMP", "COMPETITION", "HACKATHON", "COMMUNITY", "WEBINAR", "OTHER"] as const;
export const EVENT_STATUSES = ["DRAFT", "PUBLISHED", "REGISTRATION_OPEN", "REGISTRATION_CLOSED", "IN_PROGRESS", "COMPLETED", "CANCELLED"] as const;
export const FIELD_TYPES = ["text", "textarea", "select", "checkbox", "number", "url"] as const;

const httpsUrl = z.string().trim().url().max(500).refine((u) => /^https?:\/\//i.test(u));

/** Whitelisted event fields. Anything not listed here can never reach the database. */
export const eventSchema = z
  .object({
    title: text(160),
    titleAr: optionalText(160),
    slug: z.string().trim().toLowerCase().regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/).max(80).optional(),
    summary: optionalText(300),
    description: optionalText(8000),
    descriptionAr: optionalText(8000),
    category: z.enum(EVENT_CATEGORIES),
    status: z.enum(EVENT_STATUSES),
    isOnline: checkbox,
    location: optionalText(200),
    onlineUrl: httpsUrl.optional(),
    startsAt: isoDate,
    endsAt: isoDate,
    registrationOpensAt: optionalIsoDate,
    registrationClosesAt: optionalIsoDate,
    capacity: optionalInt(1, 100_000),
    waitlistEnabled: checkbox,
    attendancePoints: int(0, 10_000),
    completionPoints: int(0, 10_000),
    certificateEnabled: checkbox,
    speakerName: optionalText(120),
    speakerTitle: optionalText(160),
    speakerBio: optionalText(2000),
    teamId: recordId.optional(),
    rotatingQrEnabled: checkbox,
    qrRotateSeconds: int(30, 900).default(120),
  })
  .superRefine((v, ctx) => {
    if (v.endsAt <= v.startsAt) ctx.addIssue({ code: "custom", path: ["endsAt"], message: "invalid" });
    if (v.registrationOpensAt && v.registrationClosesAt && v.registrationClosesAt <= v.registrationOpensAt)
      ctx.addIssue({ code: "custom", path: ["registrationClosesAt"], message: "invalid" });
    if (v.registrationClosesAt && v.registrationClosesAt > v.endsAt)
      ctx.addIssue({ code: "custom", path: ["registrationClosesAt"], message: "invalid" });
  });

export const formFieldSchema = z.object({
  key: z.string().trim().regex(/^[a-z][a-z0-9_]{0,30}$/),
  label: text(120),
  labelAr: optionalText(120),
  type: z.enum(FIELD_TYPES),
  options: z.array(z.string().trim().min(1).max(60)).max(20),
  required: z.boolean(),
});

export type FormFieldInput = z.infer<typeof formFieldSchema>;

/** Parallel arrays from the dynamic form builder → validated field list. */
export function parseBuilderFields(formData: FormData): { ok: true; fields: FormFieldInput[] } | { ok: false; field: string } {
  const keys = formData.getAll("f_key").map(String);
  const labels = formData.getAll("f_label").map(String);
  const labelsAr = formData.getAll("f_labelAr").map(String);
  const types = formData.getAll("f_type").map(String);
  const options = formData.getAll("f_options").map(String);
  const required = formData.getAll("f_required").map(String);
  if (keys.length > 30) return { ok: false, field: "fields" };

  const fields: FormFieldInput[] = [];
  const seen = new Set<string>();
  for (let i = 0; i < keys.length; i += 1) {
    const parsed = formFieldSchema.safeParse({
      key: keys[i], label: labels[i], labelAr: labelsAr[i] || undefined, type: types[i],
      options: (options[i] ?? "").split("\n").map((o) => o.trim()).filter(Boolean),
      required: required[i] === "yes",
    });
    if (!parsed.success || seen.has(parsed.data.key)) return { ok: false, field: "fields" };
    if (parsed.data.type === "select" && parsed.data.options.length < 2) return { ok: false, field: "fields" };
    seen.add(parsed.data.key);
    fields.push(parsed.data);
  }
  return { ok: true, fields };
}

export function slugify(input: string): string {
  const base = input.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  return base.length >= 2 ? base : `event-${Math.random().toString(36).slice(2, 8)}`;
}
