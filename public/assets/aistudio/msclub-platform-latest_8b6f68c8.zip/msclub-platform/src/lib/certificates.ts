import "server-only";

import { randomBytes } from "node:crypto";
import { db } from "@/lib/db";
import { getEnv } from "@/lib/env";
import { logAudit } from "@/lib/audit";
import { notify } from "@/lib/notifications";
import type { CertificateType, Prisma } from "@/generated/client";

/** Crockford-style alphabet without look-alikes (no 0/O/1/I/L/U). */
const ALPHABET = "23456789ABCDEFGHJKMNPQRSTVWXYZ";

/** `MSC-XXXX-XXXX-XXXX` — 12 random characters (~58 bits), unguessable and easy to read aloud. */
export function newCertificateCode(): string {
  const bytes = randomBytes(12);
  const chars = Array.from(bytes, (b) => ALPHABET[b % ALPHABET.length]);
  return `MSC-${chars.slice(0, 4).join("")}-${chars.slice(4, 8).join("")}-${chars.slice(8, 12).join("")}`;
}

export const CODE_PATTERN = /^MSC-[2-9A-HJKMNP-TV-Z]{4}-[2-9A-HJKMNP-TV-Z]{4}-[2-9A-HJKMNP-TV-Z]{4}$/;

export function verificationUrl(code: string): string {
  return `${getEnv().NEXT_PUBLIC_APP_URL.replace(/\/$/, "")}/verify/${code}`;
}

/** "Sara Ahmed Hassan" → "Sara H." — enough to recognise the holder, not enough to identify them to strangers. */
export function maskName(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length <= 1) return parts[0] ?? "—";
  const last = [...(parts[parts.length - 1] as string)][0] ?? "";
  return `${parts[0]} ${last}.`;
}

export type IssueInput = {
  type: CertificateType;
  title: string;
  titleAr?: string | null;
  userId: string;
  referenceType: string;
  referenceId: string;
  issuedById?: string | null;
  metadata?: Prisma.InputJsonValue;
};

/**
 * Issues a certificate. Idempotent per (member, reference): asking twice returns
 * the same certificate, even under concurrency (advisory lock on the pair).
 */
export async function issueCertificate(input: IssueInput) {
  const lockKey = `cert:${input.userId}:${input.referenceType}:${input.referenceId}`;
  const { certificate, created } = await db.$transaction(async (tx) => {
    await tx.$executeRaw`SELECT pg_advisory_xact_lock(hashtext(${lockKey}))`;
    const existing = await tx.certificate.findFirst({
      where: { userId: input.userId, referenceType: input.referenceType, referenceId: input.referenceId, revokedAt: null },
    });
    if (existing) return { certificate: existing, created: false };

    const user = await tx.user.findUniqueOrThrow({ where: { id: input.userId }, select: { name: true } });
    const template = await tx.certificateTemplate.findFirst({ where: { type: input.type, enabled: true }, orderBy: { createdAt: "asc" }, select: { id: true } });
    const code = newCertificateCode();
    const row = await tx.certificate.create({
      data: {
        code, qrPayload: verificationUrl(code), type: input.type, title: input.title, titleAr: input.titleAr ?? null,
        recipientName: user.name, userId: input.userId, referenceType: input.referenceType, referenceId: input.referenceId,
        issuedById: input.issuedById ?? null, templateId: template?.id ?? null, metadata: input.metadata ?? {},
      },
    });
    return { certificate: row, created: true };
  });

  if (created) {
    await notify({
      userId: input.userId, type: "SYSTEM", title: `Certificate issued: ${input.title}`,
      titleAr: `تم إصدار شهادة: ${input.titleAr ?? input.title}`, href: "/dashboard/certificates", email: true,
    });
    await logAudit({ actorId: input.issuedById ?? null, action: "certificate.issue", entityType: "Certificate", entityId: certificate.id, after: { code: certificate.code, userId: input.userId } });
  }
  return certificate;
}

/** Public verification result. Contains NO e-mail, student id, phone or internal ids. */
export type PublicVerification =
  | { status: "not_found" }
  | { status: "valid" | "revoked"; code: string; type: CertificateType; title: string; titleAr: string | null; holder: string; issuedAt: Date };

export async function verifyCertificate(rawCode: string): Promise<PublicVerification> {
  const code = rawCode.trim().toUpperCase();
  if (!CODE_PATTERN.test(code)) return { status: "not_found" };
  const c = await db.certificate.findUnique({
    where: { code },
    select: { code: true, type: true, title: true, titleAr: true, recipientName: true, issueDate: true, revokedAt: true },
  });
  if (!c) return { status: "not_found" };
  return { status: c.revokedAt ? "revoked" : "valid", code: c.code, type: c.type, title: c.title, titleAr: c.titleAr, holder: maskName(c.recipientName), issuedAt: c.issueDate };
}

export async function revokeCertificate(params: { certificateId: string; reason: string; actorId: string }) {
  if (!params.reason.trim()) return { ok: false as const, code: "REASON_REQUIRED" as const };
  const r = await db.certificate.updateMany({ where: { id: params.certificateId, revokedAt: null }, data: { revokedAt: new Date(), revokedReason: params.reason.trim() } });
  if (r.count === 0) return { ok: false as const, code: "NOT_FOUND" as const };
  await logAudit({ actorId: params.actorId, action: "certificate.revoke", entityType: "Certificate", entityId: params.certificateId, reason: params.reason });
  return { ok: true as const };
}
