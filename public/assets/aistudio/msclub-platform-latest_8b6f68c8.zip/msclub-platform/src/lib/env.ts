import "server-only";

import { z } from "zod";

/**
 * Central, validated access to server-side environment variables.
 * Reading env vars through this module guarantees a loud failure at boot
 * instead of an obscure runtime crash, and keeps secrets out of the client.
 */

const schema = z.object({
  NODE_ENV: z.enum(["development", "test", "production"]).default("development"),
  DATABASE_URL: z.string().min(1),
  DIRECT_URL: z.string().optional().or(z.literal("")),

  AUTH_SECRET: z.string().min(16, "AUTH_SECRET must be at least 16 characters"),
  AUTH_TRUST_HOST: z.string().optional(),
  SESSION_MAX_AGE_DAYS: z.coerce.number().int().positive().default(7),

  NEXT_PUBLIC_APP_URL: z.string().url().default("http://localhost:3000"),
  NEXT_PUBLIC_APP_NAME: z.string().default("Microsoft Student Clubs"),

  RESEND_API_KEY: z.string().optional().or(z.literal("")),
  EMAIL_FROM: z.string().default("Microsoft Student Clubs <onboarding@resend.dev>"),

  CLOUDINARY_CLOUD_NAME: z.string().optional().or(z.literal("")),
  CLOUDINARY_API_KEY: z.string().optional().or(z.literal("")),
  CLOUDINARY_API_SECRET: z.string().optional().or(z.literal("")),
  CLOUDINARY_UPLOAD_PRESET: z.string().optional().or(z.literal("")),

  /** HMAC key for event passes. Falls back to AUTH_SECRET; set it to rotate passes independently. */
  QR_SECRET: z.string().min(16).optional().or(z.literal("")),
  /** Shared secret protecting cron-style route handlers (event reminders). */
  CRON_SECRET: z.string().min(16).optional().or(z.literal("")),

  RATE_LIMIT_WINDOW_MS: z.coerce.number().int().positive().default(60_000),
  RATE_LIMIT_MAX_AUTH: z.coerce.number().int().positive().default(10),
  RATE_LIMIT_MAX_MUTATION: z.coerce.number().int().positive().default(60),
});

export type Env = z.infer<typeof schema>;

let cached: Env | undefined;

/** Lazily parse the environment so `next build` can still collect pages. */
export function getEnv(): Env {
  if (cached) return cached;

  const parsed = schema.safeParse(process.env);
  if (!parsed.success) {
    const issues = parsed.error.issues
      .map((i) => `  • ${i.path.join(".")}: ${i.message}`)
      .join("\n");
    throw new Error(`Invalid environment variables:\n${issues}\n\nSee .env.example`);
  }

  cached = parsed.data;
  return cached;
}

/** Public (browser-safe) application configuration. */
export function getPublicEnv() {
  return {
    appUrl: process.env.NEXT_PUBLIC_APP_URL ?? "http://localhost:3000",
    appName: process.env.NEXT_PUBLIC_APP_NAME ?? "Microsoft Student Clubs",
  };
}
