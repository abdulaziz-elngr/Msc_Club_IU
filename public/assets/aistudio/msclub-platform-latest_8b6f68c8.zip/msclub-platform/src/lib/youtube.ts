/**
 * YouTube handling.
 *
 * Only an 11-character video ID is ever persisted. The server parses and
 * validates whatever URL an administrator pastes, so arbitrary iframe HTML
 * never reaches the database or the DOM.
 */

const VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;

const PATTERNS = [
  /(?:youtube\.com|youtube-nocookie\.com)\/watch\?(?:.*&)?v=([A-Za-z0-9_-]{11})/i,
  /(?:youtube\.com|youtube-nocookie\.com)\/shorts\/([A-Za-z0-9_-]{11})/i,
  /(?:youtube\.com|youtube-nocookie\.com)\/embed\/([A-Za-z0-9_-]{11})/i,
  /(?:youtube\.com|youtube-nocookie\.com)\/live\/([A-Za-z0-9_-]{11})/i,
  /youtu\.be\/([A-Za-z0-9_-]{11})/i,
];

/** Extracts and validates a YouTube video id from any supported URL. */
export function extractYouTubeId(input: string): string | null {
  const value = input.trim();
  if (!value) return null;

  // Already a bare id.
  if (VIDEO_ID.test(value)) return value;

  let url: URL;
  try {
    url = new URL(value.startsWith("http") ? value : `https://${value}`);
  } catch {
    return null;
  }

  const host = url.hostname.toLowerCase().replace(/^www\./, "");
  if (host !== "youtube.com" && host !== "m.youtube.com" && host !== "youtube-nocookie.com" && host !== "youtu.be") {
    return null;
  }

  for (const pattern of PATTERNS) {
    const match = pattern.exec(url.toString());
    if (match?.[1] && VIDEO_ID.test(match[1])) return match[1];
  }

  // youtube.com/v/<id> legacy form
  const parts = url.pathname.split("/").filter(Boolean);
  const vIndex = parts.indexOf("v");
  if (vIndex >= 0 && parts[vIndex + 1] && VIDEO_ID.test(parts[vIndex + 1])) {
    return parts[vIndex + 1];
  }

  return null;
}

export function isValidYouTubeId(id: string): boolean {
  return VIDEO_ID.test(id);
}

/** Responsive, privacy-enhanced embed URL (no cookie consent banner). */
export function youtubeEmbedUrl(id: string, opts: { start?: number; autoplay?: boolean } = {}): string {
  const params = new URLSearchParams({
    rel: "0",
    modestbranding: "1",
    playsinline: "1",
    enablejsapi: "0",
  });
  if (opts.start) params.set("start", String(Math.max(0, Math.floor(opts.start))));
  if (opts.autoplay) params.set("autoplay", "1");
  return `https://www.youtube-nocookie.com/embed/${id}?${params.toString()}`;
}

export function youtubeWatchUrl(id: string): string {
  return `https://www.youtube.com/watch?v=${id}`;
}

export function youtubeThumbnailUrl(id: string): string {
  return `https://i.ytimg.com/vi/${id}/hqdefault.jpg`;
}
