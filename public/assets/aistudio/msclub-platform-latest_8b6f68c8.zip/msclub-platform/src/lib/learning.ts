import "server-only";

import { db } from "@/lib/db";
import { issueCertificate } from "@/lib/certificates";
import { notify } from "@/lib/notifications";
import { awardXp } from "@/lib/xp";

/**
 * Learning engine. Everything that grants progress, XP or a certificate is decided HERE,
 * on the server, from database state:
 *  • enrolling checks the course is published and its prerequisite courses are completed;
 *  • a lesson can be opened only by an enrolled, active member (and, for sequential
 *    courses, only after the previous lesson is complete);
 *  • "watch time" is credited by heartbeats, but never more than the REAL time elapsed
 *    since the previous heartbeat, so a client cannot claim minutes it did not spend;
 *  • completing a lesson requires that credited time to reach the required minimum;
 *  • XP and certificates use idempotency keys, so repeats never double-award.
 */

export const MIN_WATCH_RATIO = 0.7;
export const HEARTBEAT_MIN_MS = 5_000;
export const HEARTBEAT_MAX_CREDIT_S = 40;
/** Lessons with no declared duration (reading material) need at least this much time-on-page. */
export const MIN_DWELL_SECONDS = 10;

export function requiredWatchSeconds(durationSeconds: number, ratio = MIN_WATCH_RATIO): number {
  if (durationSeconds <= 0) return MIN_DWELL_SECONDS;
  return Math.min(durationSeconds, Math.ceil(durationSeconds * ratio));
}

/** Seconds to credit for a heartbeat that arrived `elapsedMs` after the previous one. */
export function heartbeatCredit(elapsedMs: number): number {
  if (!Number.isFinite(elapsedMs) || elapsedMs < HEARTBEAT_MIN_MS) return 0;
  return Math.min(Math.floor(elapsedMs / 1000), HEARTBEAT_MAX_CREDIT_S);
}

export function courseProgress(completed: number, total: number, rule: string, threshold: number) {
  const pct = total === 0 ? 0 : Math.min(100, Math.round((completed / total) * 100));
  const done = total > 0 && (rule === "PERCENT" ? pct >= Math.min(100, Math.max(1, threshold)) : completed >= total);
  return { pct, done };
}

type Fail<C extends string> = { ok: false; code: C };

// ---------------------------------------------------------------- enrolment
export async function missingPrerequisites(userId: string, courseId: string) {
  const links = await db.coursePrerequisite.findMany({ where: { courseId }, select: { requires: { select: { id: true, title: true, slug: true } } } });
  if (links.length === 0) return [];
  const done = await db.courseEnrollment.findMany({
    where: { userId, completedAt: { not: null }, courseId: { in: links.map((l) => l.requires.id) } },
    select: { courseId: true },
  });
  const doneIds = new Set(done.map((d) => d.courseId));
  return links.map((l) => l.requires).filter((c) => !doneIds.has(c.id));
}

export type EnrollResult = { ok: true; enrollmentId: string; already: boolean } | Fail<"NOT_FOUND" | "NOT_ELIGIBLE" | "PREREQUISITES">;

export async function enrollInCourse(params: { userId: string; courseId: string }): Promise<EnrollResult> {
  const [user, course] = await Promise.all([
    db.user.findUnique({ where: { id: params.userId }, select: { status: true } }),
    db.course.findFirst({ where: { id: params.courseId, published: true, archivedAt: null }, select: { id: true, title: true, titleAr: true } }),
  ]);
  if (!course) return { ok: false, code: "NOT_FOUND" };
  if (!user || user.status !== "ACTIVE") return { ok: false, code: "NOT_ELIGIBLE" };

  const existing = await db.courseEnrollment.findUnique({ where: { userId_courseId: { userId: params.userId, courseId: course.id } }, select: { id: true } });
  if (existing) return { ok: true, enrollmentId: existing.id, already: true };
  if ((await missingPrerequisites(params.userId, course.id)).length > 0) return { ok: false, code: "PREREQUISITES" };

  // Unique (userId, courseId) makes concurrent enrolments collapse into one row.
  const enrollment = await db.courseEnrollment.upsert({
    where: { userId_courseId: { userId: params.userId, courseId: course.id } },
    create: { userId: params.userId, courseId: course.id }, update: {}, select: { id: true },
  });
  await awardXp({
    userId: params.userId, activityKey: "course.enroll", referenceType: "COURSE", referenceId: course.id,
    description: `Enrolled in ${course.title}`, descriptionAr: `الالتحاق بدورة ${course.titleAr ?? course.title}`,
    idempotencyKey: `xp:course-enroll:${params.userId}:${course.id}`,
  });
  return { ok: true, enrollmentId: enrollment.id, already: false };
}

// ---------------------------------------------------------------- lesson access
/** All lessons of a course in learning order (module order, then lesson order). */
export async function orderedLessons(courseId: string) {
  const lessons = await db.lesson.findMany({
    where: { courseId },
    select: { id: true, title: true, titleAr: true, durationSeconds: true, isPreview: true, order: true, module: { select: { id: true, order: true, title: true, titleAr: true } } },
  });
  return lessons.sort((a, b) => a.module.order - b.module.order || a.order - b.order);
}

export type LessonAccess =
  | { ok: true; lessonId: string; courseId: string; enrollmentId: string; required: number; secondsWatched: number; completed: boolean }
  | Fail<"NOT_FOUND" | "NOT_ELIGIBLE" | "NOT_ENROLLED" | "LOCKED">;

export async function getLessonAccess(params: { userId: string; lessonId: string }): Promise<LessonAccess> {
  const lesson = await db.lesson.findFirst({
    where: { id: params.lessonId, course: { published: true, archivedAt: null } },
    select: { id: true, courseId: true, durationSeconds: true, course: { select: { sequential: true } } },
  });
  if (!lesson) return { ok: false, code: "NOT_FOUND" };
  const [user, enrollment] = await Promise.all([
    db.user.findUnique({ where: { id: params.userId }, select: { status: true } }),
    db.courseEnrollment.findUnique({ where: { userId_courseId: { userId: params.userId, courseId: lesson.courseId } }, select: { id: true } }),
  ]);
  if (!user || user.status !== "ACTIVE") return { ok: false, code: "NOT_ELIGIBLE" };
  if (!enrollment) return { ok: false, code: "NOT_ENROLLED" };

  if (lesson.course.sequential) {
    const list = await orderedLessons(lesson.courseId);
    const idx = list.findIndex((l) => l.id === lesson.id);
    if (idx > 0) {
      const prev = await db.lessonProgress.findUnique({ where: { userId_lessonId: { userId: params.userId, lessonId: list[idx - 1].id } }, select: { completedAt: true } });
      if (!prev?.completedAt) return { ok: false, code: "LOCKED" };
    }
  }
  const progress = await db.lessonProgress.findUnique({ where: { userId_lessonId: { userId: params.userId, lessonId: lesson.id } }, select: { secondsWatched: true, completedAt: true } });
  return {
    ok: true, lessonId: lesson.id, courseId: lesson.courseId, enrollmentId: enrollment.id,
    required: requiredWatchSeconds(lesson.durationSeconds), secondsWatched: progress?.secondsWatched ?? 0, completed: Boolean(progress?.completedAt),
  };
}

// ---------------------------------------------------------------- heartbeat
export type HeartbeatResult = { ok: true; secondsWatched: number; required: number; canComplete: boolean; completed: boolean } | Fail<"NOT_FOUND" | "NOT_ELIGIBLE" | "NOT_ENROLLED" | "LOCKED">;

export async function recordHeartbeat(params: { userId: string; lessonId: string; now?: Date }): Promise<HeartbeatResult> {
  const now = params.now ?? new Date();
  const access = await getLessonAccess(params);
  if (!access.ok) return access;
  if (access.completed) return { ok: true, secondsWatched: access.secondsWatched, required: access.required, canComplete: true, completed: true };

  // Credit is computed inside a row-locked transaction so parallel heartbeats cannot double-count.
  const seconds = await db.$transaction(async (tx) => {
    await tx.lessonProgress.upsert({
      where: { userId_lessonId: { userId: params.userId, lessonId: access.lessonId } },
      create: { userId: params.userId, lessonId: access.lessonId, courseId: access.courseId, lastHeartbeatAt: now }, update: {},
    });
    await tx.$queryRaw`SELECT "id" FROM "lesson_progress" WHERE "userId" = ${params.userId} AND "lessonId" = ${access.lessonId} FOR UPDATE`;
    const row = await tx.lessonProgress.findUniqueOrThrow({ where: { userId_lessonId: { userId: params.userId, lessonId: access.lessonId } }, select: { secondsWatched: true, lastHeartbeatAt: true } });
    const credit = row.lastHeartbeatAt ? heartbeatCredit(now.getTime() - row.lastHeartbeatAt.getTime()) : 0;
    // A rejected (too-early) heartbeat must NOT move the clock, or rapid calls would starve real credit.
    const moveClock = !row.lastHeartbeatAt || credit > 0;
    const updated = await tx.lessonProgress.update({
      where: { userId_lessonId: { userId: params.userId, lessonId: access.lessonId } },
      data: { secondsWatched: { increment: credit }, ...(moveClock ? { lastHeartbeatAt: now } : {}) },
      select: { secondsWatched: true },
    });
    return updated.secondsWatched;
  });
  return { ok: true, secondsWatched: seconds, required: access.required, canComplete: seconds >= access.required, completed: false };
}

// ---------------------------------------------------------------- completion
export type CompleteResult =
  | { ok: true; already: boolean; courseCompleted: boolean; progressPct: number; lessonXp: number; courseXp: number }
  | Fail<"NOT_FOUND" | "NOT_ELIGIBLE" | "NOT_ENROLLED" | "LOCKED" | "NOT_ENOUGH_TIME">
  & { remainingSeconds?: number };

export async function completeLesson(params: { userId: string; lessonId: string; now?: Date }): Promise<CompleteResult> {
  const now = params.now ?? new Date();
  const access = await getLessonAccess(params);
  if (!access.ok) return access;

  const txResult = await db.$transaction(async (tx) => {
    // Serialise completions for this enrolment so counters are computed consistently.
    await tx.$queryRaw`SELECT "id" FROM "course_enrollments" WHERE "id" = ${access.enrollmentId} FOR UPDATE`;
    const progress = await tx.lessonProgress.upsert({
      where: { userId_lessonId: { userId: params.userId, lessonId: access.lessonId } },
      create: { userId: params.userId, lessonId: access.lessonId, courseId: access.courseId }, update: {},
      select: { id: true, completedAt: true, secondsWatched: true },
    });
    if (progress.completedAt) return { kind: "already" as const };
    if (progress.secondsWatched < access.required) return { kind: "time" as const, remaining: access.required - progress.secondsWatched };

    await tx.lessonProgress.update({ where: { id: progress.id }, data: { completedAt: now, attempts: { increment: 1 } } });

    const [course, total, completed] = await Promise.all([
      tx.course.findUniqueOrThrow({ where: { id: access.courseId }, select: { completionRule: true, completionThreshold: true } }),
      tx.lesson.count({ where: { courseId: access.courseId } }),
      tx.lessonProgress.count({ where: { userId: params.userId, courseId: access.courseId, completedAt: { not: null } } }),
    ]);
    const { pct, done } = courseProgress(completed, total, course.completionRule, course.completionThreshold);
    const enrollment = await tx.courseEnrollment.findUniqueOrThrow({ where: { id: access.enrollmentId }, select: { completedAt: true } });
    const newlyCompleted = done && !enrollment.completedAt;
    await tx.courseEnrollment.update({
      where: { id: access.enrollmentId },
      data: { progressPct: pct, completedLessons: completed, lastLessonId: access.lessonId, ...(newlyCompleted ? { completedAt: now } : {}) },
    });
    return { kind: "done" as const, pct, newlyCompleted };
  });

  if (txResult.kind === "time") return { ok: false, code: "NOT_ENOUGH_TIME", remainingSeconds: txResult.remaining };
  if (txResult.kind === "already") {
    const e = await db.courseEnrollment.findUniqueOrThrow({ where: { id: access.enrollmentId }, select: { progressPct: true, completedAt: true } });
    return { ok: true, already: true, courseCompleted: Boolean(e.completedAt), progressPct: e.progressPct, lessonXp: 0, courseXp: 0 };
  }

  // XP / certificate / notification happen after the commit and are idempotent, so a crash
  // between steps is healed by the next completion attempt or by `healCourseRewards`.
  const lesson = await db.lesson.findUniqueOrThrow({ where: { id: access.lessonId }, select: { title: true, titleAr: true, xpReward: true } });
  const lessonAward = await awardXp({
    userId: params.userId, activityKey: "lesson.complete", referenceType: "LESSON", referenceId: access.lessonId,
    ...(lesson.xpReward > 0 ? { amount: lesson.xpReward } : {}),
    description: `Completed lesson: ${lesson.title}`, descriptionAr: `إتمام درس: ${lesson.titleAr ?? lesson.title}`,
    idempotencyKey: `xp:lesson:${params.userId}:${access.lessonId}`,
  });
  await db.lessonProgress.updateMany({ where: { userId: params.userId, lessonId: access.lessonId, xpAwarded: 0 }, data: { xpAwarded: lessonAward.amount } });

  let courseXp = 0;
  if (txResult.newlyCompleted) courseXp = await grantCourseRewards(params.userId, access.courseId, access.enrollmentId);
  return { ok: true, already: false, courseCompleted: txResult.newlyCompleted, progressPct: txResult.pct, lessonXp: lessonAward.amount, courseXp };
}

/** Course XP + certificate + notification. Safe to call repeatedly (keys / advisory lock). */
export async function grantCourseRewards(userId: string, courseId: string, enrollmentId: string): Promise<number> {
  const course = await db.course.findUniqueOrThrow({ where: { id: courseId }, select: { title: true, titleAr: true, xpReward: true, certificateEnabled: true } });
  const award = await awardXp({
    userId, activityKey: "course.complete", referenceType: "COURSE", referenceId: courseId,
    ...(course.xpReward > 0 ? { amount: course.xpReward } : {}),
    description: `Completed course: ${course.title}`, descriptionAr: `إتمام دورة: ${course.titleAr ?? course.title}`,
    idempotencyKey: `xp:course-complete:${enrollmentId}`,
  });
  if (course.certificateEnabled) {
    const cert = await issueCertificate({ type: "COURSE", title: course.title, titleAr: course.titleAr, userId, referenceType: "COURSE", referenceId: courseId });
    await db.courseEnrollment.updateMany({ where: { id: enrollmentId, certificateId: null }, data: { certificateId: cert.id } });
  }
  if (award.awarded) {
    await notify({ userId, type: "COURSE_COMPLETED", title: `Course completed: ${course.title}`, titleAr: `أتممت الدورة: ${course.titleAr ?? course.title}`, href: "/dashboard/learning" });
  }
  return award.amount;
}

/** The lesson to continue from: last opened, else the first incomplete one. */
export async function getResumeLessonId(userId: string, courseId: string): Promise<string | null> {
  const [enrollment, lessons, done] = await Promise.all([
    db.courseEnrollment.findUnique({ where: { userId_courseId: { userId, courseId } }, select: { lastLessonId: true } }),
    orderedLessons(courseId),
    db.lessonProgress.findMany({ where: { userId, courseId, completedAt: { not: null } }, select: { lessonId: true } }),
  ]);
  const completed = new Set(done.map((d) => d.lessonId));
  const next = lessons.find((l) => !completed.has(l.id));
  if (next) return next.id;
  return enrollment?.lastLessonId ?? lessons[0]?.id ?? null;
}
