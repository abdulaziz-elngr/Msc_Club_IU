import { format, formatDistanceToNowStrict, intervalToDuration } from "date-fns";
import { arEG, enUS } from "date-fns/locale";
import { localeTag, type Locale } from "@/lib/i18n";

function dateFnsLocale(locale: Locale) {
  return locale === "ar" ? arEG : enUS;
}

export function formatDate(value: Date | string | number, locale: Locale = "en", pattern = "dd MMM yyyy") {
  return format(toDate(value), pattern, { locale: dateFnsLocale(locale) });
}

export function formatDateTime(value: Date | string | number, locale: Locale = "en") {
  return format(toDate(value), "dd MMM yyyy · HH:mm", { locale: dateFnsLocale(locale) });
}

export function formatTime(value: Date | string | number, locale: Locale = "en") {
  return format(toDate(value), "HH:mm", { locale: dateFnsLocale(locale) });
}

export function formatMonthYear(value: Date | string | number, locale: Locale = "en") {
  return format(toDate(value), "MMMM yyyy", { locale: dateFnsLocale(locale) });
}

export function formatRelative(value: Date | string | number, locale: Locale = "en") {
  return formatDistanceToNowStrict(toDate(value), { addSuffix: true, locale: dateFnsLocale(locale) });
}

export function formatNumber(value: number, locale: Locale = "en", options?: Intl.NumberFormatOptions) {
  return new Intl.NumberFormat(localeTag(locale), options).format(value);
}

export function formatCompact(value: number, locale: Locale = "en") {
  return new Intl.NumberFormat(localeTag(locale), { notation: "compact", maximumFractionDigits: 1 }).format(value);
}

export function formatPercent(value: number, locale: Locale = "en", digits = 0) {
  return new Intl.NumberFormat(localeTag(locale), {
    style: "percent",
    maximumFractionDigits: digits,
  }).format(value / 100);
}

/** `1:45:00` / `12:30` style duration from seconds. */
export function formatDuration(seconds: number): string {
  const total = Math.max(0, Math.floor(seconds));
  const hours = Math.floor(total / 3600);
  const minutes = Math.floor((total % 3600) / 60);
  const secs = total % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return hours > 0 ? `${hours}:${pad(minutes)}:${pad(secs)}` : `${minutes}:${pad(secs)}`;
}

/** Human "2 h 35 m" / "٢ س ٣٥ د" style duration. */
export function formatDurationHuman(seconds: number, locale: Locale = "en"): string {
  const duration = intervalToDuration({ start: 0, end: Math.max(0, seconds) * 1000 });
  const arabic = locale === "ar";
  const parts: string[] = [];
  if (duration.hours) parts.push(arabic ? `${duration.hours} س` : `${duration.hours} h`);
  if (duration.minutes) parts.push(arabic ? `${duration.minutes} د` : `${duration.minutes} m`);
  if (parts.length === 0) parts.push(arabic ? "أقل من د" : "<1 m");
  return parts.join(" ");
}

export function toDate(value: Date | string | number): Date {
  return value instanceof Date ? value : new Date(value);
}

export function formatDateRange(
  start: Date | string | number,
  end: Date | string | number,
  locale: Locale = "en",
) {
  const s = toDate(start);
  const e = toDate(end);
  const sameDay = s.toDateString() === e.toDateString();
  if (sameDay) {
    return `${formatDate(s, locale)} · ${formatTime(s, locale)} – ${formatTime(e, locale)}`;
  }
  return `${formatDateTime(s, locale)} – ${formatDateTime(e, locale)}`;
}
