import "server-only";

import { headers } from "next/headers";
import type { Prisma } from "@/generated/client";
import { db } from "@/lib/db";

/**
 * Append-only audit trail for sensitive operations.
 *
 * Failures here must never break the business operation, but they are logged
 * loudly so a missing trail is visible during development.
 */
export type AuditEntry = {
  actorId?: string | null;
  action: string;
  entityType: string;
  entityId?: string | null;
  before?: unknown;
  after?: unknown;
  reason?: string | null;
};

export async function logAudit(entry: AuditEntry, extra: { ip?: string; userAgent?: string } = {}) {
  try {
    let ip: string | null | undefined = extra.ip;
    let userAgent: string | null | undefined = extra.userAgent;

    if (!ip || !userAgent) {
      const h = await headers();
      ip ??= h.get("x-forwarded-for")?.split(",")[0]?.trim() ?? h.get("x-real-ip") ?? null;
      userAgent ??= h.get("user-agent");
    }

    await db.auditLog.create({
      data: {
        actorId: entry.actorId ?? null,
        action: entry.action,
        entityType: entry.entityType,
        entityId: entry.entityId ?? null,
        before: entry.before === undefined ? undefined : (entry.before as Prisma.InputJsonValue),
        after: entry.after === undefined ? undefined : (entry.after as Prisma.InputJsonValue),
        reason: entry.reason ?? null,
        ip: ip ?? null,
        userAgent: userAgent ?? null,
      },
    });
  } catch (error) {
    console.error("[audit] failed to write audit log", error);
  }
}
