import "server-only";

import type { Prisma } from "@/generated/client";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { notify } from "@/lib/notifications";
import { validateAnswers, type AnswerErrorCode } from "@/lib/event-forms";

/**
 * Event registration service.
 *
 * Concurrency model: every mutation locks the EVENT row (`SELECT … FOR UPDATE`)
 * for the duration of its transaction. Registrations, cancellations and
 * waitlist promotions for one event therefore run strictly one after another,
 * which makes overbooking and double promotion impossible without retry loops.
 * `@@unique([eventId, userId])` additionally guarantees one row per member.
 *
 * Passes (QR) are not stored: they are derived from (registration id,
 * `qrVersion`) in `lib/qr.ts`. Re-registering after a cancellation bumps
 * `qrVersion`, so an old screenshot of a cancelled pass can never be reused.
 */

export type RegisterResult =
  | { ok: true; status: "CONFIRMED" | "WAITLISTED"; registrationId: string; waitlistPosition: number | null }
  | { ok: false; code: "EVENT_NOT_FOUND" | "REGISTRATION_CLOSED" | "NOT_ELIGIBLE" | "ALREADY_REGISTERED" | "FULL" }
  | { ok: false; code: "INVALID_ANSWERS"; fieldErrors: Record<string, AnswerErrorCode> };

export type CancelResult =
  | { ok: true; promotedUserId: string | null }
  | { ok: false; code: "NOT_REGISTERED" | "ALREADY_CANCELLED" | "EVENT_STARTED" };

const REGISTERABLE_STATUS = ["REGISTRATION_OPEN"] as const;

async function lockEvent(tx: Prisma.TransactionClient, eventId: string) {
  await tx.$queryRaw`SELECT "id" FROM "events" WHERE "id" = ${eventId} FOR UPDATE`;
}

/** 1-based waitlist rank, derived from creation order so it never needs renumbering. */
export async function waitlistRank(eventId: string, userId: string): Promise<number | null> {
  const mine = await db.eventRegistration.findUnique({
    where: { eventId_userId: { eventId, userId } },
    select: { status: true, waitlistPos: true },
  });
  if (!mine || mine.status !== "WAITLISTED" || mine.waitlistPos === null) return null;
  const ahead = await db.eventRegistration.count({
    where: { eventId, status: "WAITLISTED", waitlistPos: { lt: mine.waitlistPos } },
  });
  return ahead + 1;
}

export async function registerForEvent(params: {
  eventId: string;
  userId: string;
  answers: Record<string, unknown>;
  now?: Date;
}): Promise<RegisterResult> {
  const now = params.now ?? new Date();

  const outcome = await db.$transaction(async (tx) => {
    await lockEvent(tx, params.eventId);

    const event = await tx.event.findUnique({
      where: { id: params.eventId },
      select: {
        id: true,
        slug: true,
        title: true,
        titleAr: true,
        status: true,
        startsAt: true,
        endsAt: true,
        capacity: true,
        waitlistEnabled: true,
        registrationOpensAt: true,
        registrationClosesAt: true,
        formFields: { select: { key: true, type: true, options: true, required: true } },
      },
    });
    if (!event || event.status === "DRAFT") return { ok: false as const, code: "EVENT_NOT_FOUND" as const };

    const open =
      (REGISTERABLE_STATUS as readonly string[]).includes(event.status) &&
      event.endsAt > now &&
      (!event.registrationOpensAt || event.registrationOpensAt <= now) &&
      (!event.registrationClosesAt || event.registrationClosesAt > now);
    if (!open) return { ok: false as const, code: "REGISTRATION_CLOSED" as const };

    const user = await tx.user.findUnique({ where: { id: params.userId }, select: { status: true } });
    if (!user || user.status !== "ACTIVE") return { ok: false as const, code: "NOT_ELIGIBLE" as const };

    const validation = validateAnswers(event.formFields, params.answers);
    if (!validation.ok) {
      return { ok: false as const, code: "INVALID_ANSWERS" as const, fieldErrors: validation.errors };
    }

    const existing = await tx.eventRegistration.findUnique({
      where: { eventId_userId: { eventId: event.id, userId: params.userId } },
      select: { id: true, status: true, qrVersion: true },
    });
    if (existing && existing.status !== "CANCELLED" && existing.status !== "REJECTED") {
      return { ok: false as const, code: "ALREADY_REGISTERED" as const };
    }

    const confirmed = await tx.eventRegistration.count({ where: { eventId: event.id, status: "CONFIRMED" } });
    const full = event.capacity !== null && confirmed >= event.capacity;
    if (full && !event.waitlistEnabled) return { ok: false as const, code: "FULL" as const };

    let waitlistPos: number | null = null;
    if (full) {
      const last = await tx.eventRegistration.aggregate({
        where: { eventId: event.id, status: "WAITLISTED" },
        _max: { waitlistPos: true },
      });
      waitlistPos = (last._max.waitlistPos ?? 0) + 1;
    }
    const status = full ? ("WAITLISTED" as const) : ("CONFIRMED" as const);

    const data = {
      status,
      answers: validation.answers as Prisma.InputJsonValue,
      waitlistPos,
      confirmedAt: full ? null : now,
      cancelledAt: null,
      checkedInAt: null,
    };

    const registration = existing
      ? await tx.eventRegistration.update({
          where: { id: existing.id },
          // New pass generation: any earlier pass for this member is dead.
          data: { ...data, qrVersion: { increment: 1 } },
          select: { id: true },
        })
      : await tx.eventRegistration.create({
          data: { eventId: event.id, userId: params.userId, ...data },
          select: { id: true },
        });

    return { ok: true as const, status, registrationId: registration.id, waitlistPos, event };
  });

  if (!outcome.ok) return outcome;

  const { event } = outcome;
  await notify({
    userId: params.userId,
    type: "EVENT_REGISTERED",
    title:
      outcome.status === "CONFIRMED" ? `You're registered: ${event.title}` : `Waitlisted: ${event.title}`,
    titleAr:
      outcome.status === "CONFIRMED"
        ? `تم تسجيلك: ${event.titleAr ?? event.title}`
        : `قائمة الانتظار: ${event.titleAr ?? event.title}`,
    body:
      outcome.status === "CONFIRMED"
        ? "Your QR pass is ready in your dashboard."
        : "We'll confirm your spot automatically if a place opens up.",
    bodyAr:
      outcome.status === "CONFIRMED"
        ? "تذكرة الدخول (QR) جاهزة في لوحتك."
        : "سنؤكد حجزك تلقائيًا إذا توفر مكان.",
    href: "/dashboard/events",
    data: { eventId: event.id, registrationId: outcome.registrationId },
  });

  return {
    ok: true,
    status: outcome.status,
    registrationId: outcome.registrationId,
    waitlistPosition: outcome.waitlistPos === null ? null : (await waitlistRank(event.id, params.userId)) ?? 1,
  };
}

/** Promotes waitlisted members (oldest first) while seats are free. Runs inside the event lock. */
async function promoteWhileSeatsFree(tx: Prisma.TransactionClient, eventId: string, now: Date) {
  const event = await tx.event.findUnique({ where: { id: eventId }, select: { capacity: true } });
  if (!event) return [] as string[];

  const promoted: string[] = [];
  for (;;) {
    const confirmed = await tx.eventRegistration.count({ where: { eventId, status: "CONFIRMED" } });
    if (event.capacity !== null && confirmed >= event.capacity) break;

    const next = await tx.eventRegistration.findFirst({
      where: { eventId, status: "WAITLISTED" },
      orderBy: [{ waitlistPos: "asc" }, { createdAt: "asc" }],
      select: { id: true, userId: true },
    });
    if (!next) break;

    await tx.eventRegistration.update({
      where: { id: next.id },
      data: { status: "CONFIRMED", waitlistPos: null, confirmedAt: now },
    });
    promoted.push(next.userId);
  }
  return promoted;
}

async function notifyPromoted(eventId: string, userIds: string[]) {
  if (userIds.length === 0) return;
  const event = await db.event.findUnique({ where: { id: eventId }, select: { title: true, titleAr: true } });
  if (!event) return;
  for (const userId of userIds) {
    await notify({
      userId,
      type: "EVENT_REGISTERED",
      title: `A seat opened up: ${event.title}`,
      titleAr: `توفر مكان لك: ${event.titleAr ?? event.title}`,
      body: "You moved off the waitlist. Your QR pass is ready.",
      bodyAr: "تم تأكيد حجزك من قائمة الانتظار. تذكرتك جاهزة.",
      href: "/dashboard/events",
      data: { eventId },
    });
  }
}

export async function cancelRegistration(params: {
  eventId: string;
  userId: string;
  now?: Date;
}): Promise<CancelResult> {
  const now = params.now ?? new Date();

  const outcome = await db.$transaction(async (tx) => {
    await lockEvent(tx, params.eventId);

    const reg = await tx.eventRegistration.findUnique({
      where: { eventId_userId: { eventId: params.eventId, userId: params.userId } },
      select: { id: true, status: true, event: { select: { startsAt: true } } },
    });
    if (!reg) return { ok: false as const, code: "NOT_REGISTERED" as const };
    if (reg.status === "CANCELLED") return { ok: false as const, code: "ALREADY_CANCELLED" as const };
    if (reg.event.startsAt <= now) return { ok: false as const, code: "EVENT_STARTED" as const };

    await tx.eventRegistration.update({
      where: { id: reg.id },
      data: { status: "CANCELLED", cancelledAt: now, waitlistPos: null, qrVersion: { increment: 1 } },
    });

    const promoted = reg.status === "CONFIRMED" ? await promoteWhileSeatsFree(tx, params.eventId, now) : [];
    return { ok: true as const, promoted };
  });

  if (!outcome.ok) return outcome;
  await notifyPromoted(params.eventId, outcome.promoted);
  return { ok: true, promotedUserId: outcome.promoted[0] ?? null };
}

/**
 * Staff action: fill any free seats from the waitlist (e.g. after the capacity
 * was raised). Safe to call repeatedly.
 */
export async function fillFromWaitlist(eventId: string, actorId: string): Promise<number> {
  const promoted = await db.$transaction(async (tx) => {
    await lockEvent(tx, eventId);
    return promoteWhileSeatsFree(tx, eventId, new Date());
  });
  await notifyPromoted(eventId, promoted);
  if (promoted.length > 0) {
    await logAudit({
      actorId,
      action: "event.waitlist.promote",
      entityType: "Event",
      entityId: eventId,
      after: { promoted: promoted.length },
    });
  }
  return promoted.length;
}
