import "server-only";

import type { RoleKey } from "@/generated/client";
import type { AuthContext } from "@/lib/auth/dal";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";

/**
 * Role assignment with privilege-escalation guards:
 *  • only a SUPER_ADMIN may grant or revoke SUPER_ADMIN;
 *  • an actor may only grant a role whose permissions they already hold;
 *  • the last SUPER_ADMIN can never be removed (nobody would be able to administer).
 */
export type RoleChangeResult = { ok: true } | { ok: false; code: "FORBIDDEN" | "NOT_FOUND" | "LAST_SUPER_ADMIN" | "SELF_SUPER_ADMIN" };

export async function setUserRole(params: { actor: AuthContext; userId: string; role: RoleKey; grant: boolean }): Promise<RoleChangeResult> {
  const { actor, userId, role, grant } = params;
  if (role === "SUPER_ADMIN" && !actor.isSuperAdmin) return { ok: false, code: "FORBIDDEN" };

  const [target, roleRow] = await Promise.all([
    db.user.findUnique({ where: { id: userId }, select: { id: true } }),
    db.role.findUnique({ where: { key: role }, select: { id: true, permissions: { select: { permission: { select: { key: true } } } } } }),
  ]);
  if (!target || !roleRow) return { ok: false, code: "NOT_FOUND" };

  if (grant && !actor.isSuperAdmin) {
    const missing = roleRow.permissions.some((p) => !actor.permissions.has(p.permission.key as never));
    if (missing) return { ok: false, code: "FORBIDDEN" };
  }

  if (!grant && role === "SUPER_ADMIN") {
    // Serialize so two concurrent revocations cannot both pass the "not last" check.
    const blocked = await db.$transaction(async (tx) => {
      await tx.$queryRaw`SELECT "id" FROM "roles" WHERE "id" = ${roleRow.id} FOR UPDATE`;
      const holders = await tx.userRole.count({ where: { roleId: roleRow.id } });
      const isHolder = await tx.userRole.count({ where: { roleId: roleRow.id, userId } });
      if (isHolder && holders <= 1) return true;
      await tx.userRole.deleteMany({ where: { roleId: roleRow.id, userId } });
      return false;
    });
    if (blocked) return { ok: false, code: "LAST_SUPER_ADMIN" };
  } else if (grant) {
    await db.userRole.createMany({ data: [{ userId, roleId: roleRow.id, grantedById: actor.userId }], skipDuplicates: true });
  } else {
    await db.userRole.deleteMany({ where: { userId, roleId: roleRow.id } });
  }

  await logAudit({ actorId: actor.userId, action: grant ? "role.grant" : "role.revoke", entityType: "User", entityId: userId, after: { role } });
  return { ok: true };
}
