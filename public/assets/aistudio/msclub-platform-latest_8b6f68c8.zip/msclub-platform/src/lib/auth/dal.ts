import "server-only";

import { cache } from "react";
import { redirect } from "next/navigation";
import { auth } from "@/auth";
import { db } from "@/lib/db";
import type { PermissionKey } from "@/lib/rbac/permissions";
import type { RoleKey } from "@/lib/rbac/roles";
import { isRoleKey } from "@/lib/rbac/roles";
import { isBlockedStatus } from "@/lib/auth/policy";

/** Errors raised by the `assert*` variants (server actions / route handlers). */
export class UnauthorizedError extends Error {
  readonly code = "UNAUTHORIZED" as const;
  constructor(message = "You must be signed in.") {
    super(message);
    this.name = "UnauthorizedError";
  }
}

export class ForbiddenError extends Error {
  readonly code = "FORBIDDEN" as const;
  constructor(message = "You do not have permission to perform this action.") {
    super(message);
    this.name = "ForbiddenError";
  }
}

export type TeamMembershipScope = {
  teamId: string;
  teamSlug: string;
  teamName: string;
  role: "LEAD" | "CO_LEAD" | "MEMBER";
  permissions: string[];
};

export type AuthContext = {
  userId: string;
  id: string;
  name: string;
  email: string;
  image: string | null;
  status: string;
  locale: "EN" | "AR";
  isActive: boolean;
  isSuperAdmin: boolean;
  roles: RoleKey[];
  /** Global permission keys resolved from the database. */
  permissions: Set<PermissionKey>;
  /** Team-scoped permission grants, keyed by team id. */
  teamPermissions: Map<string, Set<string>>;
  teams: TeamMembershipScope[];
};

const USER_SELECT = {
  id: true,
  name: true,
  email: true,
  image: true,
  status: true,
  sessionVersion: true,
  locale: true,
  roles: { select: { role: { select: { key: true } } } },
  teamMemberships: {
    where: { status: "ACTIVE" as const },
    select: {
      role: true,
      permissions: true,
      team: { select: { id: true, slug: true, name: true, permissions: true } },
    },
  },
};

/**
 * Resolves the signed-in user together with their authoritative roles,
 * permissions and team scopes — always from the database, never from the
 * session cookie. Memoised per render pass with React `cache`.
 */
export const getAuthContext = cache(async (): Promise<AuthContext | null> => {
  const session = await auth();
  const userId = session?.user?.id;
  if (!userId) return null;

  const user = await db.user.findUnique({
    where: { id: userId },
    select: USER_SELECT,
  });
  if (!user) return null;

  // A JWT cannot be revoked server-side, so revocation is a generation counter:
  // password resets and suspensions bump `sessionVersion`, which orphans every
  // token issued before. Blocked accounts never get a context at all.
  if (isBlockedStatus(user.status)) return null;
  if ((session?.sv ?? 0) !== user.sessionVersion) return null;

  const roleKeys = user.roles.map((r) => r.role.key).filter(isRoleKey);

  let permissions = new Set<PermissionKey>();
  if (roleKeys.length > 0) {
    const granted = await db.rolePermission.findMany({
      where: { role: { key: { in: roleKeys } } },
      select: { permission: { select: { key: true } } },
    });
    permissions = new Set(granted.map((g) => g.permission.key) as PermissionKey[]);
  }

  const isSuperAdmin = roleKeys.includes("SUPER_ADMIN");

  const teamPermissions = new Map<string, Set<string>>();
  const teams: TeamMembershipScope[] = [];

  for (const m of user.teamMemberships) {
    const union = new Set<string>([...m.team.permissions, ...m.permissions]);
    teamPermissions.set(m.team.id, union);
    teams.push({
      teamId: m.team.id,
      teamSlug: m.team.slug,
      teamName: m.team.name,
      role: m.role,
      permissions: [...union],
    });
  }

  const isActive = user.status === "ACTIVE";

  return {
    userId: user.id,
    id: user.id,
    name: user.name,
    email: user.email,
    image: user.image,
    status: user.status,
    locale: user.locale,
    isActive,
    isSuperAdmin,
    roles: roleKeys,
    permissions,
    teamPermissions,
    teams,
  };
});

/** Convenience accessor — `null` when signed out. */
export const getCurrentUser = cache(async () => {
  const ctx = await getAuthContext();
  if (!ctx) return null;
  return {
    id: ctx.userId,
    name: ctx.name,
    email: ctx.email,
    image: ctx.image,
    status: ctx.status,
    locale: ctx.locale,
  };
});

/** Requires a signed-in user; redirects to the login page otherwise. */
export async function requireAuth(next?: string): Promise<AuthContext> {
  const ctx = await getAuthContext();
  if (!ctx) {
    const suffix = next ? `?next=${encodeURIComponent(next)}` : "";
    redirect(`/login${suffix}`);
  }
  return ctx;
}

/** Non-throwing variant for progressive UI rendering. */
export async function requireAuthOrThrow(): Promise<AuthContext> {
  const ctx = await getAuthContext();
  if (!ctx) throw new UnauthorizedError();
  return ctx;
}

/** Requires at least one of the given roles. */
export async function requireRole(...roles: RoleKey[]): Promise<AuthContext> {
  const ctx = await requireAuth();
  assertRole(ctx, ...roles);
  return ctx;
}

export function assertRole(ctx: AuthContext, ...roles: RoleKey[]): void {
  if (ctx.isSuperAdmin) return;
  if (roles.some((r) => ctx.roles.includes(r))) return;
  throw new ForbiddenError("Your role does not allow this action.");
}

/**
 * Requires a global or (when `teamId` is supplied) team-scoped permission.
 * Team-scoped grants never widen access to a team the user does not belong to.
 */
export async function requirePermission(
  key: PermissionKey,
  options: { teamId?: string; next?: string } = {},
): Promise<AuthContext> {
  const ctx = await requireAuth(options.next);
  assertPermission(ctx, key, options.teamId);
  return ctx;
}

export function assertPermission(ctx: AuthContext, key: PermissionKey, teamId?: string): void {
  if (ctx.isSuperAdmin) return;
  if (ctx.permissions.has(key)) return;
  if (teamId && ctx.teamPermissions.get(teamId)?.has(key)) return;
  throw new ForbiddenError(`Missing permission: ${key}`);
}

/** Non-redirecting permission check for conditional rendering. */
export function can(ctx: AuthContext | null, key: PermissionKey, teamId?: string): boolean {
  if (!ctx) return false;
  if (ctx.isSuperAdmin) return true;
  if (ctx.permissions.has(key)) return true;
  if (teamId && ctx.teamPermissions.get(teamId)?.has(key)) return true;
  return false;
}

export type TeamAction = "view" | "manage" | "manage_members" | "manage_tasks" | "manage_learning";

const TEAM_LEAD_ACTIONS: TeamAction[] = ["view", "manage", "manage_members", "manage_tasks", "manage_learning"];

/**
 * Verifies the caller may act on a specific team.
 *
 * Super admins and club-wide managers pass immediately. Everyone else must be
 * an ACTIVE member of that exact team, with a role sufficient for the action —
 * which is what stops a Web Development lead from touching the AI team.
 */
export async function requireTeamAccess(
  teamId: string,
  action: TeamAction = "view",
): Promise<{ ctx: AuthContext; membership: TeamMembershipScope }> {
  const ctx = await requireAuth();
  const membership = assertTeamAccess(ctx, teamId, action);
  return { ctx, membership };
}

export function assertTeamAccess(
  ctx: AuthContext,
  teamId: string,
  action: TeamAction = "view",
): TeamMembershipScope {
  if (ctx.isSuperAdmin || ctx.permissions.has("teams.manage_all")) {
    const found = ctx.teams.find((t) => t.teamId === teamId);
    return (
      found ?? {
        teamId,
        teamSlug: "",
        teamName: "",
        role: "MEMBER",
        permissions: [],
      }
    );
  }

  const membership = ctx.teams.find((t) => t.teamId === teamId);
  if (!membership) {
    throw new ForbiddenError("You are not a member of this team.");
  }

  if (action === "view") return membership;

  if (membership.role === "LEAD" && TEAM_LEAD_ACTIONS.includes(action)) return membership;

  if (membership.role === "CO_LEAD" && action !== "manage_members") return membership;

  const scoped = ctx.teamPermissions.get(teamId);
  const allowedByGrant =
    scoped?.has(`teams.${action}`) ||
    (action === "manage_tasks" && scoped?.has("teams.manage_tasks")) ||
    (action === "manage_learning" && scoped?.has("teams.manage_learning"));

  if (allowedByGrant) return membership;

  throw new ForbiddenError("Your role in this team does not allow this action.");
}

/** Requires an approved, active member account. */
export async function requireActiveMember(): Promise<AuthContext> {
  const ctx = await requireAuth();
  if (!ctx.isActive) redirect(`/join/status`);
  return ctx;
}
