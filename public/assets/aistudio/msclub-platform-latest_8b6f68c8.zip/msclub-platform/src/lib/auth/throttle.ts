import "server-only";

import { db } from "@/lib/db";

/**
 * Persistent login throttling.
 *
 * The in-memory limiter in `rate-limit.ts` is per server instance and resets on
 * deploy; this one counts failed attempts stored in `login_attempts`, so it also
 * protects the raw Auth.js credentials endpoint and survives restarts.
 */

export const LOGIN_WINDOW_MS = 15 * 60_000;
export const MAX_FAILURES_PER_EMAIL = 10;
export const MAX_FAILURES_PER_IP = 40;

export async function isLoginThrottled(email: string, ip: string): Promise<boolean> {
  const since = new Date(Date.now() - LOGIN_WINDOW_MS);
  const [byEmail, byIp] = await Promise.all([
    db.loginAttempt.count({ where: { email, success: false, createdAt: { gte: since } } }),
    ip === "unknown"
      ? Promise.resolve(0)
      : db.loginAttempt.count({ where: { ip, success: false, createdAt: { gte: since } } }),
  ]);
  return byEmail >= MAX_FAILURES_PER_EMAIL || byIp >= MAX_FAILURES_PER_IP;
}

export async function recordLoginAttempt(email: string, ip: string, success: boolean): Promise<void> {
  await db.loginAttempt.create({ data: { email, ip, success } }).catch(() => undefined);
}

/** A valid bcrypt hash of a random string, compared against when the account is unknown. */
export const DUMMY_BCRYPT_HASH = "$2b$12$C6UzMDM.H6dfI/f/IKcEeO5fYdQ3cD2s3nUyQ0F7YqF3w2xQ0m1Gy";
