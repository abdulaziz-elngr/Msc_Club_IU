import type { UserStatus } from "@/generated/client";

/**
 * Pure authentication policy helpers.
 *
 * Kept outside the `"use server"` action module so they can be unit-tested
 * directly and shared by login, register, reset and the auth proxy.
 */

/** Account states that may never establish a session. */
export const BLOCKED_STATUSES: readonly UserStatus[] = ["SUSPENDED", "ARCHIVED"];

export function isBlockedStatus(status: string): boolean {
  return (BLOCKED_STATUSES as readonly string[]).includes(status);
}

/**
 * Only same-origin relative paths are accepted as post-login targets.
 * Blocks `https://evil.example`, `//evil.example` and `/\evil.example`
 * open-redirect attempts, and refuses to bounce back into the auth pages.
 */
export function safeNext(next: string | null | undefined): string | null {
  if (!next) return null;
  if (!next.startsWith("/")) return null;
  if (next.startsWith("//") || next.startsWith("/\\")) return null;
  if (next.includes("\\")) return null;
  const lower = next.toLowerCase();
  if (lower.startsWith("/login") || lower.startsWith("/register") || lower.startsWith("/logout")) {
    return null;
  }
  return next;
}

export type LandingInput = {
  status: string;
  emailVerified: Date | null;
  /** Explicit `?next=` target, already passed through `safeNext`. */
  next?: string | null;
};

/**
 * Where a successfully authenticated user should land.
 *
 * Order matters: an explicit target wins (it was already sanitised), then the
 * account's lifecycle state, then email verification, then the dashboard.
 */
export function landingFor(input: LandingInput): string {
  if (isBlockedStatus(input.status)) return "/login?error=suspended";
  if (input.next) return input.next;
  if (input.status === "REJECTED") return "/join/status";
  if (!input.emailVerified) return "/verify-email";
  if (input.status === "UNVERIFIED") return "/verify-email";
  return "/dashboard";
}

/** Where an anonymous visitor should be sent after hitting a protected route. */
export function loginPathWithNext(pathname: string, search = ""): string {
  const next = `${pathname}${search}`;
  const suffix = next && next !== "/" ? `?next=${encodeURIComponent(next)}` : "";
  return `/login${suffix}`;
}
