import "server-only";

import type { ApplicationStatus } from "@/generated/client";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { notify } from "@/lib/notifications";

/**
 * Membership application workflow:
 *   SUBMITTED → UNDER_REVIEW → ACCEPTED (→ user becomes an ACTIVE member) | REJECTED
 * Every transition is atomic, guarded against concurrent decisions, recorded in
 * `ApplicationEvent` (history) and `AuditLog`, and announced to the applicant.
 */
export const TRANSITIONS: Record<ApplicationStatus, ApplicationStatus[]> = {
  DRAFT: [],
  SUBMITTED: ["UNDER_REVIEW", "ACCEPTED", "REJECTED", "WITHDRAWN"],
  UNDER_REVIEW: ["ACCEPTED", "REJECTED"],
  REJECTED: ["UNDER_REVIEW"],
  ACCEPTED: [],
  WITHDRAWN: [],
};

export const DECISIONS: ApplicationStatus[] = ["ACCEPTED", "REJECTED"];

export type TransitionResult =
  | { ok: true; from: ApplicationStatus; userId: string }
  | { ok: false; code: "NOT_FOUND" | "INVALID_TRANSITION" | "NOTE_REQUIRED" };

/** Account states an application decision is allowed to change (never un-suspends anyone). */
const USER_STATES_OPEN_TO_DECISION = ["APPLICANT", "UNDER_REVIEW", "REJECTED", "ACTIVE"] as const;

export async function transitionApplication(params: {
  applicationId: string;
  to: ApplicationStatus;
  note?: string | null;
  actorId: string;
}): Promise<TransitionResult> {
  const note = params.note?.trim() || null;
  if (params.to === "REJECTED" && !note) return { ok: false, code: "NOTE_REQUIRED" };

  const outcome = await db.$transaction(async (tx) => {
    const app = await tx.memberApplication.findUnique({
      where: { id: params.applicationId },
      select: { id: true, status: true, userId: true, user: { select: { status: true } } },
    });
    if (!app) return { ok: false as const, code: "NOT_FOUND" as const };
    if (!TRANSITIONS[app.status].includes(params.to)) return { ok: false as const, code: "INVALID_TRANSITION" as const };

    // Optimistic guard: only one concurrent decision can move the row out of `from`.
    const moved = await tx.memberApplication.updateMany({
      where: { id: app.id, status: app.status },
      data: {
        status: params.to,
        reviewedAt: new Date(),
        reviewedById: params.actorId,
        ...(note ? { decisionNote: note } : {}),
      },
    });
    if (moved.count === 0) return { ok: false as const, code: "INVALID_TRANSITION" as const };

    await tx.applicationEvent.create({
      data: { applicationId: app.id, fromStatus: app.status, toStatus: params.to, note, actorId: params.actorId },
    });

    if ((USER_STATES_OPEN_TO_DECISION as readonly string[]).includes(app.user.status)) {
      const userStatus = params.to === "ACCEPTED" ? "ACTIVE" : params.to === "REJECTED" ? "REJECTED" : params.to === "UNDER_REVIEW" ? "UNDER_REVIEW" : null;
      if (userStatus) await tx.user.update({ where: { id: app.userId }, data: { status: userStatus } });
    }

    if (params.to === "ACCEPTED") {
      const [member, applicant] = await Promise.all([
        tx.role.findUnique({ where: { key: "MEMBER" }, select: { id: true } }),
        tx.role.findUnique({ where: { key: "APPLICANT" }, select: { id: true } }),
      ]);
      if (member) {
        await tx.userRole.createMany({ data: [{ userId: app.userId, roleId: member.id, grantedById: params.actorId }], skipDuplicates: true });
      }
      if (applicant) await tx.userRole.deleteMany({ where: { userId: app.userId, roleId: applicant.id } });
    }

    return { ok: true as const, from: app.status, userId: app.userId };
  });

  if (!outcome.ok) return outcome;

  await logAudit({
    actorId: params.actorId,
    action: `application.${params.to.toLowerCase()}`,
    entityType: "MemberApplication",
    entityId: params.applicationId,
    before: { status: outcome.from },
    after: { status: params.to },
    reason: note,
  });

  const copy: Partial<Record<ApplicationStatus, { title: string; titleAr: string; body: string; bodyAr: string }>> = {
    UNDER_REVIEW: {
      title: "Your application is under review", titleAr: "طلبك قيد المراجعة",
      body: "A team member is reviewing your application. We'll update you soon.", bodyAr: "يراجع أحد أعضاء الفريق طلبك. سنوافيك بالمستجدات قريبًا.",
    },
    ACCEPTED: {
      title: "Welcome to the club!", titleAr: "أهلًا بك في النادي!",
      body: note ?? "Your application was accepted. You're now an active member.", bodyAr: note ?? "تم قبول طلبك، وأصبحت عضوًا نشطًا.",
    },
    REJECTED: {
      title: "Update on your application", titleAr: "تحديث بخصوص طلبك",
      body: note ?? "Unfortunately your application was not accepted this time.", bodyAr: note ?? "للأسف لم يتم قبول طلبك هذه المرة.",
    },
  };
  const c = copy[params.to];
  if (c) {
    await notify({ userId: outcome.userId, type: "APPLICATION_STATUS", ...c, href: params.to === "ACCEPTED" ? "/dashboard" : "/join/status", email: true });
  }
  return outcome;
}
