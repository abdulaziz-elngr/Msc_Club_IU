/**
 * Minimal RFC-4180 CSV writer with spreadsheet-formula-injection protection.
 *
 * Cells that begin with `= + - @` (or a tab / CR) are prefixed with an
 * apostrophe so Excel / Sheets treat attacker-controlled text (e.g. a name or
 * a custom registration answer) as plain text instead of a formula.
 */

const FORMULA_START = /^[=+\-@\t\r]/;

export function csvCell(value: unknown): string {
  let text = value === null || value === undefined ? "" : value instanceof Date ? value.toISOString() : String(value);
  if (FORMULA_START.test(text) && !/^-?\d+(\.\d+)?$/.test(text)) text = `'${text}`;
  return /[",\r\n]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

export function toCsv(header: string[], rows: unknown[][]): string {
  const lines = [header, ...rows].map((row) => row.map(csvCell).join(","));
  // BOM so Excel opens Arabic text as UTF-8.
  return `\uFEFF${lines.join("\r\n")}`;
}
