/**
 * Permission catalogue.
 *
 * Every sensitive operation in the application maps to exactly one key from
 * this file. Keys are persisted in the `permissions` table and granted to
 * roles through `role_permissions`, so a Super Admin can re-wire the whole
 * permission model from the dashboard without a deploy.
 */

export const PERMISSIONS = {
  // --- administration ---------------------------------------------------------
  ADMIN_DASHBOARD: "admin.dashboard",
  ADMIN_SETTINGS: "admin.settings.manage",
  ADMIN_ROLES_READ: "admin.roles.read",
  ADMIN_ROLES_MANAGE: "admin.roles.manage",
  ADMIN_PERMISSIONS_MANAGE: "admin.permissions.manage",
  ADMIN_AUDIT_READ: "admin.audit.read",
  ADMIN_ANALYTICS: "admin.analytics.view",
  ADMIN_ANALYTICS_EXPORT: "admin.analytics.export",

  // --- membership -------------------------------------------------------------
  MEMBERS_READ: "members.read",
  MEMBERS_UPDATE: "members.update",
  MEMBERS_SUSPEND: "members.suspend",
  MEMBERS_DELETE: "members.delete",
  MEMBERS_EXPORT: "members.export",

  APPLICATIONS_READ: "applications.read",
  APPLICATIONS_REVIEW: "applications.review",
  APPLICATIONS_DECIDE: "applications.decide",

  // --- teams ------------------------------------------------------------------
  TEAMS_READ: "teams.read",
  TEAMS_CREATE: "teams.create",
  TEAMS_UPDATE: "teams.update",
  TEAMS_ARCHIVE: "teams.archive",
  TEAMS_MANAGE_MEMBERS: "teams.manage_members",
  TEAMS_MANAGE_TASKS: "teams.manage_tasks",
  TEAMS_MANAGE_LEARNING: "teams.manage_learning",
  TEAMS_MANAGE_ALL: "teams.manage_all",

  // --- events -----------------------------------------------------------------
  EVENTS_READ: "events.read",
  EVENTS_CREATE: "events.create",
  EVENTS_UPDATE: "events.update",
  EVENTS_DELETE: "events.delete",
  EVENTS_PUBLISH: "events.publish",
  EVENTS_MANAGE_REGISTRATIONS: "events.manage_registrations",
  EVENTS_EXPORT_REGISTRATIONS: "events.export_registrations",
  EVENTS_MANAGE_ATTENDANCE: "events.manage_attendance",
  EVENTS_CORRECT_ATTENDANCE: "events.correct_attendance",

  // --- learning ---------------------------------------------------------------
  LEARNING_READ: "learning.read",
  LEARNING_CREATE: "learning.create",
  LEARNING_UPDATE: "learning.update",
  LEARNING_DELETE: "learning.delete",
  LEARNING_PUBLISH: "learning.publish",
  LEARNING_MANAGE_ENROLLMENTS: "learning.manage_enrollments",

  // --- tasks ------------------------------------------------------------------
  TASKS_READ: "tasks.read",
  TASKS_CREATE: "tasks.create",
  TASKS_ASSIGN: "tasks.assign",
  TASKS_REVIEW: "tasks.review",
  TASKS_MANAGE: "tasks.manage",

  // --- gamification -----------------------------------------------------------
  POINTS_READ: "points.read",
  POINTS_AWARD: "points.award",
  POINTS_ADJUST: "points.adjust",
  POINTS_REVERSE: "points.reverse",
  LEVELS_MANAGE: "levels.manage",
  BADGES_MANAGE: "badges.manage",
  LEADERBOARD_CONFIGURE: "leaderboard.configure",

  // --- certificates -----------------------------------------------------------
  CERTIFICATES_READ: "certificates.read",
  CERTIFICATES_ISSUE: "certificates.issue",
  CERTIFICATES_REVOKE: "certificates.revoke",
  CERTIFICATES_TEMPLATES: "certificates.templates.manage",

  // --- notifications & content ------------------------------------------------
  NOTIFICATIONS_SEND: "notifications.send",
  NOTIFICATIONS_MANAGE: "notifications.manage",
  CONTENT_MANAGE: "content.manage",
  TESTIMONIALS_MANAGE: "content.testimonials.manage",
} as const;

export type PermissionKey = (typeof PERMISSIONS)[keyof typeof PERMISSIONS];

/** Human-readable grouping used by the admin permission matrix UI. */
export const PERMISSION_GROUPS: Record<string, { key: string; label: string; labelAr: string }[]> = {
  admin: [
    { key: PERMISSIONS.ADMIN_DASHBOARD, label: "View admin dashboard", labelAr: "عرض لوحة الإدارة" },
    { key: PERMISSIONS.ADMIN_SETTINGS, label: "Manage platform settings", labelAr: "إدارة إعدادات المنصة" },
    { key: PERMISSIONS.ADMIN_ROLES_READ, label: "View roles", labelAr: "عرض الأدوار" },
    { key: PERMISSIONS.ADMIN_ROLES_MANAGE, label: "Manage roles", labelAr: "إدارة الأدوار" },
    { key: PERMISSIONS.ADMIN_PERMISSIONS_MANAGE, label: "Manage permissions", labelAr: "إدارة الصلاحيات" },
    { key: PERMISSIONS.ADMIN_AUDIT_READ, label: "Read audit logs", labelAr: "قراءة سجلات التدقيق" },
    { key: PERMISSIONS.ADMIN_ANALYTICS, label: "View analytics", labelAr: "عرض التحليلات" },
    { key: PERMISSIONS.ADMIN_ANALYTICS_EXPORT, label: "Export analytics", labelAr: "تصدير التحليلات" },
  ],
  members: [
    { key: PERMISSIONS.MEMBERS_READ, label: "View members", labelAr: "عرض الأعضاء" },
    { key: PERMISSIONS.MEMBERS_UPDATE, label: "Edit members", labelAr: "تعديل الأعضاء" },
    { key: PERMISSIONS.MEMBERS_SUSPEND, label: "Suspend members", labelAr: "تعليق الأعضاء" },
    { key: PERMISSIONS.MEMBERS_DELETE, label: "Remove members", labelAr: "إزالة الأعضاء" },
    { key: PERMISSIONS.MEMBERS_EXPORT, label: "Export member list", labelAr: "تصدير قائمة الأعضاء" },
    { key: PERMISSIONS.APPLICATIONS_READ, label: "View applications", labelAr: "عرض الطلبات" },
    { key: PERMISSIONS.APPLICATIONS_REVIEW, label: "Review applications", labelAr: "مراجعة الطلبات" },
    { key: PERMISSIONS.APPLICATIONS_DECIDE, label: "Approve / reject applications", labelAr: "القبول أو رفض الطلبات" },
  ],
  teams: [
    { key: PERMISSIONS.TEAMS_READ, label: "View teams", labelAr: "عرض الفرق" },
    { key: PERMISSIONS.TEAMS_CREATE, label: "Create teams", labelAr: "إنشاء الفرق" },
    { key: PERMISSIONS.TEAMS_UPDATE, label: "Edit teams", labelAr: "تعديل الفرق" },
    { key: PERMISSIONS.TEAMS_ARCHIVE, label: "Archive teams", labelAr: "أرشفة الفرق" },
    { key: PERMISSIONS.TEAMS_MANAGE_MEMBERS, label: "Manage team members", labelAr: "إدارة أعضاء الفريق" },
    { key: PERMISSIONS.TEAMS_MANAGE_TASKS, label: "Manage team tasks", labelAr: "إدارة مهام الفريق" },
    { key: PERMISSIONS.TEAMS_MANAGE_LEARNING, label: "Manage team learning", labelAr: "إدارة تعلم الفريق" },
    { key: PERMISSIONS.TEAMS_MANAGE_ALL, label: "Manage every team", labelAr: "إدارة جميع الفرق" },
  ],
  events: [
    { key: PERMISSIONS.EVENTS_READ, label: "View events", labelAr: "عرض الفعاليات" },
    { key: PERMISSIONS.EVENTS_CREATE, label: "Create events", labelAr: "إنشاء الفعاليات" },
    { key: PERMISSIONS.EVENTS_UPDATE, label: "Edit events", labelAr: "تعديل الفعاليات" },
    { key: PERMISSIONS.EVENTS_DELETE, label: "Delete events", labelAr: "حذف الفعاليات" },
    { key: PERMISSIONS.EVENTS_PUBLISH, label: "Publish events", labelAr: "نشر الفعاليات" },
    { key: PERMISSIONS.EVENTS_MANAGE_REGISTRATIONS, label: "Manage registrations", labelAr: "إدارة التسجيلات" },
    { key: PERMISSIONS.EVENTS_EXPORT_REGISTRATIONS, label: "Export registrations (CSV)", labelAr: "تصدير التسجيلات" },
    { key: PERMISSIONS.EVENTS_MANAGE_ATTENDANCE, label: "Scan / record attendance", labelAr: "مسح وتسجيل الحضور" },
    { key: PERMISSIONS.EVENTS_CORRECT_ATTENDANCE, label: "Correct attendance records", labelAr: "تصحيح سجلات الحضور" },
  ],
  learning: [
    { key: PERMISSIONS.LEARNING_READ, label: "View learning hub", labelAr: "عرض مركز التعلم" },
    { key: PERMISSIONS.LEARNING_CREATE, label: "Create courses", labelAr: "إنشاء الدورات" },
    { key: PERMISSIONS.LEARNING_UPDATE, label: "Edit courses", labelAr: "تعديل الدورات" },
    { key: PERMISSIONS.LEARNING_DELETE, label: "Delete courses", labelAr: "حذف الدورات" },
    { key: PERMISSIONS.LEARNING_PUBLISH, label: "Publish / unpublish courses", labelAr: "نشر أو إخفاء الدورات" },
    { key: PERMISSIONS.LEARNING_MANAGE_ENROLLMENTS, label: "Manage enrollments", labelAr: "إدارة التسجيلات في الدورات" },
  ],
  tasks: [
    { key: PERMISSIONS.TASKS_READ, label: "View tasks", labelAr: "عرض المهام" },
    { key: PERMISSIONS.TASKS_CREATE, label: "Create tasks", labelAr: "إنشاء المهام" },
    { key: PERMISSIONS.TASKS_ASSIGN, label: "Assign tasks", labelAr: "إسناد المهام" },
    { key: PERMISSIONS.TASKS_REVIEW, label: "Review submissions", labelAr: "مراجعة التسليمات" },
    { key: PERMISSIONS.TASKS_MANAGE, label: "Manage all tasks", labelAr: "إدارة جميع المهام" },
  ],
  gamification: [
    { key: PERMISSIONS.POINTS_READ, label: "View points ledger", labelAr: "عرض سجل النقاط" },
    { key: PERMISSIONS.POINTS_AWARD, label: "Award points", labelAr: "منح النقاط" },
    { key: PERMISSIONS.POINTS_ADJUST, label: "Adjust points (±)", labelAr: "تعديل النقاط" },
    { key: PERMISSIONS.POINTS_REVERSE, label: "Reverse point transactions", labelAr: "عكس معاملات النقاط" },
    { key: PERMISSIONS.LEVELS_MANAGE, label: "Manage levels", labelAr: "إدارة المستويات" },
    { key: PERMISSIONS.BADGES_MANAGE, label: "Manage badges", labelAr: "إدارة الشارات" },
    { key: PERMISSIONS.LEADERBOARD_CONFIGURE, label: "Configure leaderboards", labelAr: "إعداد لوحات المتصدرين" },
  ],
  certificates: [
    { key: PERMISSIONS.CERTIFICATES_READ, label: "View certificates", labelAr: "عرض الشهادات" },
    { key: PERMISSIONS.CERTIFICATES_ISSUE, label: "Issue certificates", labelAr: "إصدار الشهادات" },
    { key: PERMISSIONS.CERTIFICATES_REVOKE, label: "Revoke certificates", labelAr: "إلغاء الشهادات" },
    { key: PERMISSIONS.CERTIFICATES_TEMPLATES, label: "Manage templates", labelAr: "إدارة القوالب" },
  ],
  content: [
    { key: PERMISSIONS.NOTIFICATIONS_SEND, label: "Send notifications", labelAr: "إرسال الإشعارات" },
    { key: PERMISSIONS.NOTIFICATIONS_MANAGE, label: "Manage notifications", labelAr: "إدارة الإشعارات" },
    { key: PERMISSIONS.CONTENT_MANAGE, label: "Manage site content", labelAr: "إدارة محتوى الموقع" },
    { key: PERMISSIONS.TESTIMONIALS_MANAGE, label: "Manage testimonials", labelAr: "إدارة آراء الأعضاء" },
  ],
};

export const ALL_PERMISSION_KEYS: PermissionKey[] = Object.values(PERMISSIONS);
