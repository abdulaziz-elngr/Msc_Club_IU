/** Icon names admins can pick for levels and badges (rendered through `components/shared/named-icon.tsx`). */
export const ICON_NAMES = [
  "star", "award", "trophy", "medal", "zap", "flame", "rocket", "code", "compass", "hammer", "wrench",
  "seedling", "book-open", "graduation-cap", "target", "shield", "crown", "gem", "heart",
] as const;
export type IconName = (typeof ICON_NAMES)[number];
