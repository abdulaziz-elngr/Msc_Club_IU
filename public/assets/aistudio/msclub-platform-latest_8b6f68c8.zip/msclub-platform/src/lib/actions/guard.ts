import "server-only";

import { getAuthContext, type AuthContext } from "@/lib/auth/dal";
import { clientKey, rateLimit } from "@/lib/rate-limit";

/**
 * Entry guard for member-facing mutations (server actions).
 * Authenticates from the database (never the client), then rate-limits per
 * user + bucket. Returns a code the caller maps to a localized message.
 */
export type GuardResult =
  | { ok: true; ctx: AuthContext }
  | { ok: false; code: "UNAUTHENTICATED" | "RATE_LIMITED" };

export async function guardMutation(bucket: string, max?: number, windowMs?: number): Promise<GuardResult> {
  const ctx = await getAuthContext();
  if (!ctx) return { ok: false, code: "UNAUTHENTICATED" };
  const limit = rateLimit(clientKey(bucket, ctx.userId), max, windowMs);
  if (!limit.ok) return { ok: false, code: "RATE_LIMITED" };
  return { ok: true, ctx };
}
