import "server-only";

import { z, type ZodType } from "zod";
import { ForbiddenError, UnauthorizedError, assertPermission, getAuthContext, type AuthContext } from "@/lib/auth/dal";
import type { PermissionKey } from "@/lib/rbac/permissions";
import { clientKey, rateLimit } from "@/lib/rate-limit";
import { formToObject } from "@/lib/validation";

/**
 * Uniform result for every mutation server action. Messages are NEVER English
 * prose: the client translates `code` / `fieldErrors` with the active locale.
 */
export type ActionResult = {
  ok: boolean;
  code?: "FORBIDDEN" | "UNAUTHENTICATED" | "RATE_LIMITED" | "INVALID" | "NOT_FOUND" | "CONFLICT" | "GENERIC" | (string & {});
  fieldErrors?: Record<string, string>;
  /** Id of a created record, for client-side navigation. */
  id?: string;
  redirectTo?: string;
};

export function fieldErrorsFrom(error: z.ZodError): Record<string, string> {
  const out: Record<string, string> = {};
  for (const issue of error.issues) {
    const key = String(issue.path[0] ?? "_");
    if (out[key]) continue;
    const origin = (issue as { origin?: string }).origin;
    let code = "invalid";
    if (issue.code === "invalid_type") code = "required";
    else if (issue.code === "too_small") code = origin === "string" || origin === "array" ? ((issue as { minimum?: number }).minimum === 1 ? "required" : "tooShort") : "tooSmall";
    else if (issue.code === "too_big") code = origin === "string" || origin === "array" ? "tooLong" : "tooBig";
    out[key] = code;
  }
  return out;
}

export type Parsed<T> = { ok: true; data: T } | { ok: false; result: ActionResult };

/** Validates FormData against an explicit schema. */
export function parseForm<S extends ZodType>(schema: S, formData: FormData): Parsed<z.output<S>> {
  const parsed = schema.safeParse(formToObject(formData));
  if (!parsed.success) return { ok: false, result: { ok: false, code: "INVALID", fieldErrors: fieldErrorsFrom(parsed.error) } };
  return { ok: true, data: parsed.data };
}

/** Same, for already-structured input (e.g. a bound id + a JSON payload). */
export function parseValue<S extends ZodType>(schema: S, value: unknown): Parsed<z.output<S>> {
  const parsed = schema.safeParse(value);
  if (!parsed.success) return { ok: false, result: { ok: false, code: "INVALID", fieldErrors: fieldErrorsFrom(parsed.error) } };
  return { ok: true, data: parsed.data };
}

type RunOptions = {
  /** Required global permission; checked against the DATABASE, not the session cookie. */
  permission?: PermissionKey;
  /** Rate-limit bucket; combined with the user id. */
  bucket: string;
  max?: number;
  windowMs?: number;
};

/**
 * Wraps a mutation: authenticates, authorizes, rate-limits and converts thrown
 * authorization errors into result codes. Unexpected errors are logged and
 * surfaced as GENERIC (never leaking internals to the client).
 */
export async function runAction(opts: RunOptions, fn: (ctx: AuthContext) => Promise<ActionResult>): Promise<ActionResult> {
  try {
    const ctx = await getAuthContext();
    if (!ctx) return { ok: false, code: "UNAUTHENTICATED" };
    if (opts.permission) assertPermission(ctx, opts.permission);
    if (!rateLimit(clientKey(opts.bucket, ctx.userId), opts.max ?? 60, opts.windowMs ?? 60_000).ok) {
      return { ok: false, code: "RATE_LIMITED" };
    }
    return await fn(ctx);
  } catch (error) {
    if (error instanceof ForbiddenError) return { ok: false, code: "FORBIDDEN" };
    if (error instanceof UnauthorizedError) return { ok: false, code: "UNAUTHENTICATED" };
    if ((error as { code?: string } | null)?.code === "P2002") return { ok: false, code: "CONFLICT" };
    if ((error as { code?: string } | null)?.code === "P2025") return { ok: false, code: "NOT_FOUND" };
    // Next.js redirect()/notFound() signals must keep propagating.
    if (typeof error === "object" && error !== null && "digest" in error) throw error;
    console.error(`[action:${opts.bucket}]`, error);
    return { ok: false, code: "GENERIC" };
  }
}
