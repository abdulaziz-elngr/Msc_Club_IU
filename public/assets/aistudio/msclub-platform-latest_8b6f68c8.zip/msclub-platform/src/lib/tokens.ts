import "server-only";

import { createHash, randomBytes, randomUUID } from "node:crypto";

/** URL-safe, unguessable token (256 bits by default). */
export function randomToken(bytes = 32): string {
  return randomBytes(bytes).toString("base64url");
}

/** Short human-friendly public identifier, e.g. certificate codes. */
export function shortCode(length = 10): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no ambiguous glyphs
  const buf = randomBytes(length);
  let out = "";
  for (let i = 0; i < length; i += 1) out += alphabet[buf[i] % alphabet.length];
  return out;
}

export function sha256(value: string): string {
  return createHash("sha256").update(value).digest("hex");
}

/** Deterministic idempotency key for ledger writes. */
export function idempotencyKey(...parts: (string | number | null | undefined)[]): string {
  return parts.map((p) => (p === null || p === undefined ? "" : String(p))).join(":");
}

export function uuid(): string {
  return randomUUID();
}
