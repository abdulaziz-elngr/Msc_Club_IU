import "server-only";

import { cache } from "react";
import { db } from "@/lib/db";

/**
 * Typed accessor for the `site_settings` key/value table.
 *
 * Values are JSON, so this module is the single place that defines their
 * shape and their defaults — pages never read raw rows.
 */

export const SETTING_KEYS = {
  SITE_NAME: "site.name",
  TAGLINE: "site.tagline",
  CONTACT_EMAIL: "site.contactEmail",
  CONTACT_PHONE: "site.contactPhone",
  ADDRESS: "site.address",
  SOCIAL: "site.social",
  REGISTRATION_OPEN: "registration.open",
  LEADERBOARD_PERIOD: "leaderboard.period",
  XP_WELCOME: "xp.welcome",
  REQUIRED_FIELDS: "registration.requiredFields",
  LEADERBOARD_PUBLIC: "leaderboard.public",
} as const;

export type SettingKey = (typeof SETTING_KEYS)[keyof typeof SETTING_KEYS];

const DEFAULTS: Record<string, unknown> = {
  [SETTING_KEYS.SITE_NAME]: "Microsoft Student Clubs",
  [SETTING_KEYS.TAGLINE]: "Innovation University",
  [SETTING_KEYS.CONTACT_EMAIL]: "clubs@innovation.edu",
  [SETTING_KEYS.CONTACT_PHONE]: "",
  [SETTING_KEYS.ADDRESS]: "Innovation University, Campus 1",
  [SETTING_KEYS.SOCIAL]: {
    instagram: "",
    linkedin: "",
    youtube: "",
    github: "",
    x: "",
    discord: "",
  },
  [SETTING_KEYS.REGISTRATION_OPEN]: true,
  [SETTING_KEYS.LEADERBOARD_PERIOD]: "monthly",
  [SETTING_KEYS.XP_WELCOME]: 25,
  [SETTING_KEYS.REQUIRED_FIELDS]: ["studentId", "motivation"],
  [SETTING_KEYS.LEADERBOARD_PUBLIC]: true,
};

function coerce(row: { value: unknown; type: string } | undefined, fallback: unknown) {
  if (!row) return fallback;
  const value = row.value;
  switch (row.type) {
    case "number":
      return typeof value === "number" && Number.isFinite(value) ? value : Number.isFinite(Number(value)) && value !== "" && value !== null ? Number(value) : fallback;
    case "boolean":
      return typeof value === "boolean" ? value : value === "true" || value === 1;
    case "json":
      return value ?? fallback;
    default:
      return typeof value === "string" ? value : String(value ?? fallback);
  }
}

/** Reads every setting in one query and caches the result per render pass. */
export const getSettings = cache(async (): Promise<Record<string, unknown>> => {
  try {
    const rows = await db.siteSettings.findMany({
      select: { key: true, value: true, type: true },
    });
    const map: Record<string, unknown> = { ...DEFAULTS };
    for (const row of rows) map[row.key] = coerce(row, DEFAULTS[row.key]);
    return map;
  } catch {
    // Settings must never take the site down.
    return { ...DEFAULTS };
  }
});

export async function getString(key: SettingKey, fallback = ""): Promise<string> {
  const settings = await getSettings();
  const value = settings[key];
  return typeof value === "string" && value.length > 0 ? value : fallback;
}

export async function getBoolean(key: SettingKey, fallback = false): Promise<boolean> {
  const settings = await getSettings();
  const value = settings[key];
  return typeof value === "boolean" ? value : fallback;
}

export async function getNumber(key: SettingKey, fallback = 0): Promise<number> {
  const settings = await getSettings();
  const value = settings[key];
  return typeof value === "number" && Number.isFinite(value) ? value : fallback;
}

export async function getSocialLinks(): Promise<Record<string, string>> {
  const settings = await getSettings();
  const value = settings[SETTING_KEYS.SOCIAL];
  if (typeof value !== "object" || value === null) return {};
  const out: Record<string, string> = {};
  for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
    if (typeof v === "string" && v.trim()) out[k] = v.trim();
  }
  return out;
}

/** Admin console: writes a single setting back with its declared type. */
export async function putSetting(
  key: SettingKey,
  value: unknown,
  type: "string" | "number" | "boolean" | "json",
  label?: string,
) {
  return db.siteSettings.upsert({
    where: { key },
    create: { key, value: value as never, type, label: label ?? null },
    update: { value: value as never, type, ...(label ? { label } : {}) },
  });
}

/** Fields an applicant must fill in on /join (admin-configurable). Always a safe subset of the known keys. */
export const APPLICATION_FIELD_KEYS = ["studentId", "phone", "department", "academicYear", "motivation"] as const;
export type ApplicationFieldKey = (typeof APPLICATION_FIELD_KEYS)[number];

export async function getRequiredApplicationFields(): Promise<ApplicationFieldKey[]> {
  const settings = await getSettings();
  const value = settings[SETTING_KEYS.REQUIRED_FIELDS];
  if (!Array.isArray(value)) return ["studentId", "motivation"];
  return value.filter((v): v is ApplicationFieldKey => (APPLICATION_FIELD_KEYS as readonly string[]).includes(v as string));
}
