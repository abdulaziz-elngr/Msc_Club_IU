import "server-only";

import { randomBytes } from "node:crypto";
import { mkdir, writeFile } from "node:fs/promises";
import path from "node:path";
import { getEnv } from "@/lib/env";

/**
 * Image uploads.
 *  • The file TYPE is decided by magic bytes, never by the client's MIME type or filename.
 *  • SVG is refused (script-capable); only PNG / JPEG / WebP are accepted.
 *  • Stored names are random; the original filename is discarded.
 *  • Cloudinary when configured, otherwise `public/uploads` (development fallback —
 *    serverless hosts have a read-only filesystem, so configure Cloudinary in production).
 */
export const MAX_IMAGE_BYTES = 2 * 1024 * 1024;
export type ImageKind = "team-logo" | "avatar" | "testimonial" | "cover";
export type DetectedImage = { ext: "png" | "jpg" | "webp"; mime: string };

export function detectImageType(bytes: Uint8Array): DetectedImage | null {
  const b = bytes;
  if (b.length >= 8 && b[0] === 0x89 && b[1] === 0x50 && b[2] === 0x4e && b[3] === 0x47 && b[4] === 0x0d && b[5] === 0x0a && b[6] === 0x1a && b[7] === 0x0a) {
    return { ext: "png", mime: "image/png" };
  }
  if (b.length >= 3 && b[0] === 0xff && b[1] === 0xd8 && b[2] === 0xff) return { ext: "jpg", mime: "image/jpeg" };
  if (b.length >= 12 && b[0] === 0x52 && b[1] === 0x49 && b[2] === 0x46 && b[3] === 0x46 && b[8] === 0x57 && b[9] === 0x45 && b[10] === 0x42 && b[11] === 0x50) {
    return { ext: "webp", mime: "image/webp" };
  }
  return null;
}

export type UploadResult =
  | { ok: true; url: string }
  | { ok: false; code: "NO_FILE" | "TOO_LARGE" | "BAD_TYPE" | "STORAGE_FAILED" };

export async function saveImage(file: unknown, kind: ImageKind): Promise<UploadResult> {
  if (!(file instanceof File) || file.size === 0) return { ok: false, code: "NO_FILE" };
  if (file.size > MAX_IMAGE_BYTES) return { ok: false, code: "TOO_LARGE" };

  const bytes = new Uint8Array(await file.arrayBuffer());
  if (bytes.length > MAX_IMAGE_BYTES) return { ok: false, code: "TOO_LARGE" };
  const type = detectImageType(bytes);
  if (!type) return { ok: false, code: "BAD_TYPE" };

  const name = randomBytes(16).toString("hex");
  const env = getEnv();

  try {
    if (env.CLOUDINARY_CLOUD_NAME && env.CLOUDINARY_API_KEY && env.CLOUDINARY_API_SECRET) {
      const { v2: cloudinary } = await import("cloudinary");
      cloudinary.config({ cloud_name: env.CLOUDINARY_CLOUD_NAME, api_key: env.CLOUDINARY_API_KEY, api_secret: env.CLOUDINARY_API_SECRET, secure: true });
      const url = await new Promise<string>((resolve, reject) => {
        cloudinary.uploader
          .upload_stream({ folder: `msclub/${kind}`, public_id: name, resource_type: "image", allowed_formats: ["png", "jpg", "webp"] }, (err, res) => (err || !res ? reject(err) : resolve(res.secure_url)))
          .end(Buffer.from(bytes));
      });
      return { ok: true, url };
    }

    const dir = path.join(process.cwd(), "public", "uploads", kind);
    await mkdir(dir, { recursive: true });
    await writeFile(path.join(dir, `${name}.${type.ext}`), bytes);
    return { ok: true, url: `/uploads/${kind}/${name}.${type.ext}` };
  } catch (error) {
    console.error("[uploads] storage failed", error);
    return { ok: false, code: "STORAGE_FAILED" };
  }
}
