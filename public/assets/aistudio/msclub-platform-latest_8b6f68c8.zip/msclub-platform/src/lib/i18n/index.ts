import { ar } from "@/lib/i18n/ar";
import { en, type Dictionary } from "@/lib/i18n/en";

export type { Dictionary };

export const LOCALES = ["en", "ar"] as const;
export type Locale = (typeof LOCALES)[number];

export const DICTIONARIES: Record<Locale, Dictionary> = { en, ar };

/** Dotted key paths of the dictionary, e.g. `"nav.home"` or `"tasks.status.APPROVED"`. */
type TranslationKeyOf<T> = T extends string
  ? never
  : {
      [K in keyof T & string]: T[K] extends string ? K : `${K}.${TranslationKeyOf<T[K]>}`;
    }[keyof T & string];

export type TranslationKey = TranslationKeyOf<Dictionary>;

export type TranslationParams = Record<string, string | number>;

export function isLocale(value: unknown): value is Locale {
  return typeof value === "string" && (LOCALES as readonly string[]).includes(value);
}

export function getDictionary(locale: Locale | undefined | null): Dictionary {
  return DICTIONARIES[isLocale(locale) ? locale : "en"];
}

/** Resolves `key` against a dictionary, falling back to English, then to the key. */
export function translate(
  dictionary: Dictionary,
  key: TranslationKey,
  params?: TranslationParams,
): string {
  const segments = key.split(".");
  let cursor: unknown = dictionary;

  for (const segment of segments) {
    if (typeof cursor !== "object" || cursor === null) {
      cursor = undefined;
      break;
    }
    cursor = (cursor as Record<string, unknown>)[segment];
  }

  let value = typeof cursor === "string" ? cursor : undefined;

  if (value === undefined && dictionary !== en) {
    const fallback = translate(en, key);
    if (fallback !== key) value = fallback;
  }

  if (value === undefined) return key;
  if (!params) return value;

  return value.replace(/\{(\w+)\}/g, (match, name: string) =>
    Object.prototype.hasOwnProperty.call(params, name) ? String(params[name]) : match,
  );
}

/** Server-side translation helper. */
export function getTranslations(locale: Locale | undefined | null) {
  const dictionary = getDictionary(locale);
  return (key: TranslationKey, params?: TranslationParams) => translate(dictionary, key, params);
}

export function localeDirection(locale: Locale): "ltr" | "rtl" {
  return locale === "ar" ? "rtl" : "ltr";
}

export function localeLabel(locale: Locale): string {
  return locale === "ar" ? "العربية" : "English";
}

/** BCP-47 tag used for `Intl` formatting and the `lang` attribute. */
export function localeTag(locale: Locale): string {
  return locale === "ar" ? "ar-EG" : "en-US";
}
