import "server-only";

import { cookies } from "next/headers";
import { isLocale, type Locale } from "@/lib/i18n";

export const LOCALE_COOKIE = "msclub_locale";
export const LOCALE_COOKIE_MAX_AGE = 60 * 60 * 24 * 365;

/** Reads the preferred locale: cookie first, then the supplied user preference. */
export async function resolveLocale(userLocale?: Locale | null): Promise<Locale> {
  const store = await cookies();
  const fromCookie = store.get(LOCALE_COOKIE)?.value;
  if (isLocale(fromCookie)) return fromCookie;
  if (isLocale(userLocale)) return userLocale;
  return "en";
}

export function localeCookieOptions() {
  return {
    name: LOCALE_COOKIE,
    path: "/",
    maxAge: LOCALE_COOKIE_MAX_AGE,
    sameSite: "lax" as const,
    secure: process.env.NODE_ENV === "production",
  };
}
