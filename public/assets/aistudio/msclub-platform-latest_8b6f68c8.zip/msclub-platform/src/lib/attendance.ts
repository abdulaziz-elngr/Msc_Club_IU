import "server-only";

import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";
import { awardXp, reverseXp } from "@/lib/xp";
import { randomToken, sha256 } from "@/lib/tokens";
import { parsePassToken, verifyPassSignature } from "@/lib/qr";
import { toCsv } from "@/lib/csv";
import { notify } from "@/lib/notifications";

/**
 * Attendance service.
 *
 * Security model
 *  • The QR payload is an opaque random token stored on the registration.
 *    It encodes NO personal data — leaking a photo of someone's QR only
 *    reveals an unguessable string, and only that attendee can be marked.
 *  • Every write is validated server-side against the event window and the
 *    registration state; the client is never trusted.
 *  • Every write appends an `AttendanceLog` row (append-only) plus the
 *    platform-wide `AuditLog` for corrections.
 *  • `@@unique([eventId, userId])` makes duplicate check-ins impossible at
 *    the database level, independent of application logic.
 */

/** What the staff scanner shows after a scan. Never includes email or phone. */
export type AttendeeSummary = {
  name: string;
  studentId: string | null;
  registrationStatus: string | null;
  attendanceStatus: string | null;
  points: number;
};

export type CheckInResult =
  | { ok: true; attendanceId: string; duplicate: false; points: number; attendee?: AttendeeSummary }
  | { ok: false; code: CheckInErrorCode; message: string; duplicate?: boolean; attendee?: AttendeeSummary };

export type CheckInErrorCode =
  | "TOKEN_NOT_FOUND"
  | "EVENT_NOT_FOUND"
  | "EVENT_NOT_OPEN"
  | "EVENT_WINDOW"
  | "NOT_REGISTERED"
  | "REGISTRATION_NOT_CONFIRMED"
  | "ALREADY_CHECKED_IN"
  | "EVENT_CANCELLED"
  | "WRONG_EVENT";

/** How long before the start / after the end a scan is still accepted. */
const WINDOW_BEFORE_MS = 90 * 60_000;
const WINDOW_AFTER_MS = 180 * 60_000;

function fail(code: CheckInErrorCode, message: string, duplicate = false): CheckInResult {
  return { ok: false, code, message, duplicate };
}

const OPEN_EVENT_STATUSES = ["PUBLISHED", "REGISTRATION_OPEN", "REGISTRATION_CLOSED", "IN_PROGRESS"] as const;

type CheckInContext = {
  /** When set, the pass must belong to this event (the event being scanned). */
  eventId?: string;
  actorId?: string | null;
  method?: "QR_SCAN" | "MANUAL" | "CODE";
  ip?: string | null;
  note?: string | null;
};

type EventForCheckIn = {
  id: string;
  slug: string;
  title: string;
  titleAr: string | null;
  status: string;
  startsAt: Date;
  endsAt: Date;
  attendancePoints: number;
  rotatingQrEnabled: boolean;
  qrRotateSeconds: number;
};

/**
 * Grants the attendance XP. Idempotent (key derives from the attendance row), so
 * it is safe to call again to heal a check-in whose award failed the first time.
 */
async function grantAttendancePoints(event: EventForCheckIn, userId: string, attendanceId: string): Promise<number> {
  if (event.attendancePoints <= 0) return 0;

  const result = await awardXp({
    userId,
    activityKey: "event.attendance",
    referenceType: "ATTENDANCE",
    referenceId: attendanceId,
    amount: event.attendancePoints, // the event's own value, not the catalogue default
    description: `Attended ${event.title}`,
    descriptionAr: `حضور ${event.titleAr ?? event.title}`,
    idempotencyKey: `xp:attendance:${attendanceId}`,
    metadata: { eventId: event.id },
  });

  if (result.awarded || result.duplicate) {
    const amount = result.amount;
    await db.attendance.updateMany({
      where: { id: attendanceId, pointsAwarded: 0 },
      data: { pointsAwarded: amount, pointsAwardedAt: new Date() },
    });
    await db.eventRegistration.updateMany({
      where: { eventId: event.id, userId, pointsAwarded: 0 },
      data: { pointsAwarded: amount },
    });
    return amount;
  }
  return 0;
}

async function completeCheckIn(params: {
  event: EventForCheckIn;
  userId: string;
  registrationId: string | null;
  context: CheckInContext;
}): Promise<CheckInResult> {
  const { event, userId, registrationId, context } = params;

  // Attendance row, its first log entry and the registration stamp commit
  // together or not at all.
  const attendance = await db.$transaction(async (tx) => {
    const row = await tx.attendance.create({
      data: {
        eventId: event.id,
        userId,
        registrationId,
        status: "PRESENT",
        method: context.method ?? "QR_SCAN",
        recordedById: context.actorId ?? null,
        note: context.note ?? null,
      },
      select: { id: true },
    });
    await tx.attendanceLog.create({
      data: {
        attendanceId: row.id,
        action: "CREATED",
        fromStatus: null,
        toStatus: "PRESENT",
        reason: context.note ?? null,
        actorId: context.actorId ?? null,
        ip: context.ip ?? null,
      },
    });
    if (registrationId) {
      await tx.eventRegistration.update({ where: { id: registrationId }, data: { checkedInAt: new Date() } });
    }
    return row;
  });

  const points = await grantAttendancePoints(event, userId, attendance.id);

  await notify({
    userId,
    type: "ATTENDANCE_CONFIRMED",
    title: `Checked in: ${event.title}`,
    titleAr: `تم تسجيل حضورك: ${event.titleAr ?? event.title}`,
    ...(points > 0
      ? { body: `You earned ${points} XP for attending.`, bodyAr: `حصلت على ${points} XP للحضور.` }
      : {}),
    href: `/events/${event.slug}`,
    email: false,
  });

  return { ok: true, attendanceId: attendance.id, duplicate: false, points };
}

const EVENT_SELECT = {
  id: true,
  slug: true,
  title: true,
  titleAr: true,
  status: true,
  startsAt: true,
  endsAt: true,
  attendancePoints: true,
  rotatingQrEnabled: true,
  qrRotateSeconds: true,
} as const;

async function loadEventForCheckIn(eventId: string) {
  return db.event.findUnique({
    where: { id: eventId },
    select: EVENT_SELECT,
  });
}

function assertEventOpen(event: EventForCheckIn, now = new Date()): CheckInResult | null {
  if (event.status === "CANCELLED") return fail("EVENT_CANCELLED", "This event was cancelled.");
  if (!(OPEN_EVENT_STATUSES as readonly string[]).includes(event.status)) {
    return fail("EVENT_NOT_OPEN", "Check-in is not available for this event.");
  }
  if (now.getTime() < event.startsAt.getTime() - WINDOW_BEFORE_MS) {
    return fail("EVENT_WINDOW", "Check-in has not opened yet.");
  }
  if (now.getTime() > event.endsAt.getTime() + WINDOW_AFTER_MS) {
    return fail("EVENT_WINDOW", "Check-in for this event has closed.");
  }
  return null;
}

async function attendeeSummary(eventId: string, userId: string): Promise<AttendeeSummary> {
  const [user, registration, attendance] = await Promise.all([
    db.user.findUnique({ where: { id: userId }, select: { name: true, studentId: true } }),
    db.eventRegistration.findUnique({ where: { eventId_userId: { eventId, userId } }, select: { status: true } }),
    db.attendance.findUnique({ where: { eventId_userId: { eventId, userId } }, select: { status: true, pointsAwarded: true } }),
  ]);
  return {
    name: user?.name ?? "—",
    studentId: user?.studentId ?? null,
    registrationStatus: registration?.status ?? null,
    attendanceStatus: attendance?.status ?? null,
    points: attendance?.pointsAwarded ?? 0,
  };
}

async function withAttendee(result: CheckInResult, eventId: string, userId: string): Promise<CheckInResult> {
  return { ...result, attendee: await attendeeSummary(eventId, userId) };
}

/**
 * Validates an opaque QR token and records a check-in.
 * The token is the ONLY thing carried by the QR code.
 */
export async function checkInByToken(token: string, context: CheckInContext = {}): Promise<CheckInResult> {
  const parsed = parsePassToken(token);
  if (!parsed) return fail("TOKEN_NOT_FOUND", "Invalid pass.");

  const registration = await db.eventRegistration.findUnique({
    where: { id: parsed.registrationId },
    select: {
      id: true,
      userId: true,
      status: true,
      qrVersion: true,
      eventId: true,
      event: { select: EVENT_SELECT },
    },
  });

  // Same message for "no such registration" and "bad signature": no oracle.
  if (!registration || !verifyPassSignature(registration.id, registration.qrVersion, parsed.signature)) {
    return fail("TOKEN_NOT_FOUND", "Invalid pass.");
  }

  // A staff member may only check people into the event they are working.
  if (context.eventId && context.eventId !== registration.eventId) {
    return fail("WRONG_EVENT", "This pass is for a different event.");
  }

  const windowError = assertEventOpen(registration.event);
  if (windowError) return withAttendee(windowError, registration.eventId, registration.userId);

  if (registration.status !== "CONFIRMED") {
    return withAttendee(
      fail(
        "REGISTRATION_NOT_CONFIRMED",
        registration.status === "WAITLISTED"
          ? "This attendee is on the waitlist, not confirmed for this event."
          : "This registration is not confirmed.",
      ),
      registration.eventId,
      registration.userId,
    );
  }

  const result = await recordCheckIn({
    event: registration.event,
    userId: registration.userId,
    registrationId: registration.id,
    context,
  });
  return withAttendee(result, registration.eventId, registration.userId);
}

/**
 * Records a check-in, enforcing the database-level duplicate guard.
 * Returns `duplicate: true` instead of throwing when already present.
 */
async function recordCheckIn(params: {
  event: EventForCheckIn;
  userId: string;
  registrationId: string | null;
  context: CheckInContext;
}): Promise<CheckInResult> {
  const { event, userId, registrationId, context } = params;

  const existing = await db.attendance.findUnique({
    where: { eventId_userId: { eventId: event.id, userId } },
    select: { id: true, status: true, pointsAwarded: true },
  });
  if (existing) {
    // Self-heal: a previous attempt may have recorded presence but failed to
    // grant XP. The award is idempotent, so retrying here is always safe.
    if ((existing.status === "PRESENT" || existing.status === "LATE") && existing.pointsAwarded === 0) {
      await grantAttendancePoints(event, userId, existing.id).catch((e) =>
        console.error("[attendance] award retry failed", e),
      );
    }
    return fail("ALREADY_CHECKED_IN", "This attendee is already checked in.", true);
  }

  try {
    return await completeCheckIn({ event, userId, registrationId, context });
  } catch (error) {
    // Unique violation on (eventId, userId): a concurrent scan won the race.
    if ((error as { code?: string } | null)?.code === "P2002") {
      return fail("ALREADY_CHECKED_IN", "This attendee is already checked in.", true);
    }
    throw error;
  }
}

/**
 * Staff-driven check-in: by member (search) or by the member's event pass.
 * Used as the manual fallback when a camera/scanner is unavailable.
 */
export async function checkInManually(
  params: { eventId: string; userId: string } & CheckInContext,
): Promise<CheckInResult> {
  const event = await loadEventForCheckIn(params.eventId);
  if (!event) return fail("EVENT_NOT_FOUND", "Event not found.");

  const windowError = assertEventOpen(event);
  if (windowError) return windowError;

  const registration = await db.eventRegistration.findFirst({
    where: { eventId: params.eventId, userId: params.userId },
    select: { id: true, status: true },
  });
  if (!registration) return fail("NOT_REGISTERED", "This member is not registered for this event.");
  if (registration.status !== "CONFIRMED") {
    return fail("REGISTRATION_NOT_CONFIRMED", "This registration is not confirmed.");
  }

  const result = await recordCheckIn({
    event,
    userId: params.userId,
    registrationId: registration.id,
    context: { ...params, method: "MANUAL" },
  });
  return withAttendee(result, event.id, params.userId);
}

/**
 * Corrects an existing record. Never deletes: the old status moves into the
 * append-only log and a reversal of any awarded XP is appended separately.
 */
export async function correctAttendance(params: {
  attendanceId: string;
  toStatus: "PRESENT" | "LATE" | "ABSENT" | "EXCUSED";
  reason: "MIS_SCAN" | "LATE_ARRIVAL" | "TECHNICAL_ISSUE" | "ADMIN_ADJUSTMENT" | "OTHER";
  note?: string | null;
  actorId: string;
  ip?: string | null;
}): Promise<{ ok: boolean; message: string }> {
  const attendance = await db.attendance.findUnique({
    where: { id: params.attendanceId },
    select: { id: true, eventId: true, userId: true, status: true, pointsAwarded: true },
  });
  if (!attendance) return { ok: false, message: "Attendance record not found." };
  if (attendance.status === params.toStatus) return { ok: true, message: "No change." };

  await db.$transaction(async (tx) => {
    await tx.attendance.update({
      where: { id: attendance.id },
      data: {
        status: params.toStatus,
        reason: params.reason,
        note: params.note ?? null,
        recordedById: params.actorId,
        correctedAt: new Date(),
        ...(params.toStatus === "ABSENT" || params.toStatus === "EXCUSED"
          ? { pointsAwarded: 0, pointsAwardedAt: null }
          : {}),
      },
    });

    await tx.attendanceLog.create({
      data: {
        attendanceId: attendance.id,
        action: "CORRECTED",
        fromStatus: attendance.status,
        toStatus: params.toStatus,
        reason: `${params.reason}${params.note ? `: ${params.note}` : ""}`,
        actorId: params.actorId,
        ip: params.ip ?? null,
      },
    });
  });

  // Points follow presence: revoke when presence no longer holds, re-grant when restored.
  const absent = params.toStatus === "ABSENT" || params.toStatus === "EXCUSED";
  if (absent && attendance.pointsAwarded > 0) {
    const original = await db.xPTransaction.findFirst({
      where: { referenceType: "ATTENDANCE", referenceId: attendance.id, amount: { gt: 0 } },
      select: { id: true },
    });
    if (original) {
      await reverseXp({
        transactionId: original.id,
        reason: `Attendance corrected to ${params.toStatus}: ${params.reason}`,
        actorId: params.actorId,
      });
    }
  } else if (!absent && attendance.pointsAwarded === 0) {
    const event = await db.event.findUnique({ where: { id: attendance.eventId }, select: EVENT_SELECT });
    if (event && event.attendancePoints > 0) {
      const result = await awardXp({
        userId: attendance.userId,
        activityKey: "event.attendance",
        referenceType: "ATTENDANCE",
        referenceId: attendance.id,
        amount: event.attendancePoints,
        description: `Attended ${event.title}`,
        descriptionAr: `حضور ${event.titleAr ?? event.title}`,
        awardedById: params.actorId,
        // A fresh key per correction: the original award key is spent once reversed.
        idempotencyKey: `xp:attendance-regrant:${attendance.id}:${Date.now()}`,
        metadata: { eventId: event.id, regrant: true },
      });
      if (result.awarded) {
        await db.attendance.update({
          where: { id: attendance.id },
          data: { pointsAwarded: result.amount, pointsAwardedAt: new Date() },
        });
      }
    }
  }

  await logAudit(
    {
      actorId: params.actorId,
      action: "attendance.correct",
      entityType: "Attendance",
      entityId: attendance.id,
      before: { status: attendance.status, points: attendance.pointsAwarded },
      after: { status: params.toStatus, reason: params.reason, note: params.note ?? null },
      reason: params.note ? `${params.reason}: ${params.note}` : params.reason,
    },
    params.ip ? { ip: params.ip } : {},
  );

  return { ok: true, message: "Attendance updated." };
}

/**
 * Rotating QR mode: issues a short-lived, event-scoped code that staff scan
 * to open the check-in sheet. The attendee's personal pass stays constant —
 * rotation limits how long a photographed screen stays useful.
 */
export async function issueRotatingToken(eventId: string): Promise<{ token: string; expiresAt: Date } | null> {
  const event = await db.event.findUnique({
    where: { id: eventId },
    select: { id: true, rotatingQrEnabled: true, qrRotateSeconds: true },
  });
  if (!event?.rotatingQrEnabled) return null;

  const seconds = Math.min(Math.max(event.qrRotateSeconds, 30), 900);
  const token = randomToken(24);
  const expiresAt = new Date(Date.now() + seconds * 1000);

  await db.attendanceToken.create({
    data: { eventId, tokenHash: sha256(token), expiresAt },
  });

  // Prune expired codes so the table stays small.
  await db.attendanceToken.deleteMany({
    where: { eventId, expiresAt: { lt: new Date(Date.now() - 60_000) } },
  });

  return { token, expiresAt };
}

export async function validateRotatingToken(eventId: string, token: string): Promise<boolean> {
  const row = await db.attendanceToken.findUnique({
    where: { tokenHash: sha256(token.trim()) },
    select: { eventId: true, active: true, expiresAt: true },
  });
  return Boolean(row && row.eventId === eventId && row.active && row.expiresAt > new Date());
}

/**
 * Self check-in: a confirmed attendee scanned the rotating code shown at the
 * venue. The code only proves presence at the door; identity and registration
 * come from the signed-in session, never from the request.
 */
export async function checkInWithRotatingCode(params: {
  eventId: string;
  code: string;
  userId: string;
  ip?: string | null;
}): Promise<CheckInResult> {
  if (!(await validateRotatingToken(params.eventId, params.code))) {
    return fail("TOKEN_NOT_FOUND", "This code has expired. Scan the screen again.");
  }
  const event = await loadEventForCheckIn(params.eventId);
  if (!event) return fail("EVENT_NOT_FOUND", "Event not found.");
  const windowError = assertEventOpen(event);
  if (windowError) return windowError;

  const registration = await db.eventRegistration.findUnique({
    where: { eventId_userId: { eventId: event.id, userId: params.userId } },
    select: { id: true, status: true },
  });
  if (!registration) return fail("NOT_REGISTERED", "You are not registered for this event.");
  if (registration.status !== "CONFIRMED") {
    return fail("REGISTRATION_NOT_CONFIRMED", "Your registration is not confirmed.");
  }

  return recordCheckIn({
    event,
    userId: params.userId,
    registrationId: registration.id,
    context: { eventId: event.id, method: "CODE", actorId: null, ip: params.ip ?? null },
  });
}

/** CSV export used by the events console (formula-injection safe). */
export async function exportAttendanceCsv(eventId: string): Promise<string> {
  const rows = await db.attendance.findMany({
    where: { eventId },
    orderBy: { createdAt: "asc" },
    include: { user: { select: { name: true, email: true, studentId: true } } },
  });

  return toCsv(
    ["Name", "Email", "Student ID", "Status", "Method", "Points", "Checked in at"],
    rows.map((row) => [
      row.user.name,
      row.user.email,
      row.user.studentId ?? "",
      row.status,
      row.method,
      row.pointsAwarded,
      row.createdAt,
    ]),
  );
}
