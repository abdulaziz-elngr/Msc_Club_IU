import "server-only";

import { getEnv } from "@/lib/env";

/**
 * Email delivery.
 *
 * Two modes:
 *  - RESEND_API_KEY present  -> real delivery via the Resend HTTP API.
 *  - otherwise               -> console transport (development / CI).
 *
 * The console transport is intentional: the platform must boot, build and
 * pass tests without external credentials. Every message is additionally
 * persisted by the notification service, so nothing is lost in dev.
 */

export type SendInput = {
  to: string | string[];
  subject: string;
  heading: string;
  /** Body text. Newlines are preserved in both HTML and plain-text parts. */
  body: string;
  /** Optional call-to-action button. */
  action?: { label: string; href: string };
  locale?: "en" | "ar";
};

export type SendResult = {
  id: string;
  delivered: boolean;
  mode: "resend" | "console" | "skipped";
};

type TransportMessage = {
  from: string;
  to: string[];
  subject: string;
  html: string;
  text: string;
};

export type EmailTransport = {
  name: "resend" | "console";
  send: (msg: TransportMessage) => Promise<string>;
};

const LOGO_CID = "club-logo";

/** Absolute URL builder for links inside emails. */
export function emailUrl(path: string): string {
  const base = getEnv().NEXT_PUBLIC_APP_URL.replace(/\/$/, "");
  return `${base}${path.startsWith("/") ? path : `/${path}`}`;
}

function escapeHtml(value: string): string {
  return value
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

/** Convert plain-text paragraphs to HTML, preserving line breaks safely. */
function textToHtml(body: string): string {
  return escapeHtml(body)
    .split(/\r?\n{2,}/)
    .map((para) => `<p style="margin:0 0 14px">${para.replace(/\n/g, "<br/>")}</p>`)
    .join("");
}

/**
 * Minimal, dependency-free HTML email wrapper in the club brand.
 * Uses table layout (the only reliably supported email layout engine) and
 * an inline CID logo so images render without a public asset host.
 */
function layout(opts: {
  heading: string;
  body: string;
  action?: { label: string; href: string };
  locale: "en" | "ar";
}): string {
  const dir = opts.locale === "ar" ? "rtl" : "ltr";
  const font =
    opts.locale === "ar"
      ? "'Noto Sans Arabic', 'Segoe UI', Tahoma, Arial, sans-serif"
      : "'Inter', 'Segoe UI', Tahoma, Arial, sans-serif";
  const action = opts.action
    ? `<table role="presentation" cellpadding="0" cellspacing="0" style="margin:24px 0 6px"><tr><td style="border-radius:8px;background:#1b6ac4"><a href="${escapeHtml(
        opts.action.href,
      )}" style="display:inline-block;padding:12px 22px;color:#ffffff;text-decoration:none;font-weight:600;font-size:15px">${escapeHtml(
        opts.action.label,
      )}</a></td></tr></table>`
    : "";
  const footerNote =
    opts.locale === "ar"
      ? "هذا البريد تلقائي، لا ترد عليه."
      : "This is an automated message — please do not reply.";

  return `<!doctype html>
<html dir="${dir}" lang="${opts.locale}">
<head><meta charset="utf-8"/><meta name="viewport" content="width=device-width"/></head>
<body style="margin:0;background:#f2f5fa;font-family:${font};color:#0f1b2d">
  <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f2f5fa;padding:28px 12px">
    <tr><td align="center">
      <table role="presentation" width="100%" style="max-width:560px;background:#ffffff;border-radius:14px;border:1px solid #e6ecf5">
        <tr><td style="padding:24px 32px 4px">
          <table role="presentation" cellpadding="0" cellspacing="0"><tr>
            <td style="padding-right:10px" ${dir === "rtl" ? 'style="padding-left:10px"' : ""}><img src="cid:${LOGO_CID}" alt="" width="34" height="34" style="display:block;border:0"/></td>
            <td style="font-weight:700;font-size:15px;color:#123f6e;letter-spacing:-0.01em">Microsoft Student Clubs</td>
          </tr></table>
        </td></tr>
        <tr><td style="padding:16px 32px 0"><div style="height:3px;width:46px;background:#1b6ac4;border-radius:999px"></div></td></tr>
        <tr><td style="padding:20px 32px 8px" dir="${dir}">
          <h1 style="margin:0 0 14px;font-size:22px;line-height:1.3;color:#0f1b2d;font-weight:700">${escapeHtml(opts.heading)}</h1>
          ${textToHtml(opts.body)}
          ${action}
        </td></tr>
        <tr><td style="padding:22px 32px 26px;border-top:1px solid #e6ecf5;color:#5b6b82;font-size:12.5px;line-height:1.7" dir="${dir}">
          Microsoft Student Clubs — Innovation University<br/>${footerNote}
        </td></tr>
      </table>
    </td></tr>
  </table>
</body>
</html>`;
}

async function consoleTransport(msg: TransportMessage): Promise<string> {
  const id = `console_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
  // Single-line structured log keeps CI/dev output readable.
  console.info(
    JSON.stringify({
      level: "info",
      channel: "email",
      transport: "console",
      id,
      from: msg.from,
      to: msg.to,
      subject: msg.subject,
      preview: msg.text.slice(0, 400),
    }),
  );
  return id;
}

async function resendTransport(msg: TransportMessage): Promise<string> {
  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${getEnv().RESEND_API_KEY}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: msg.from,
      to: msg.to,
      subject: msg.subject,
      html: msg.html,
      text: msg.text,
    }),
    cache: "no-store",
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => "");
    throw new Error(`Resend ${res.status}: ${detail.slice(0, 300)}`);
  }

  const data = (await res.json().catch(() => ({}))) as { id?: string };
  return data.id ?? `resend_${Date.now().toString(36)}`;
}

const defaultTransport: EmailTransport = {
  name: "console",
  send: consoleTransport,
};

let override: EmailTransport | null = null;

/** Test seam: swap the transport for the duration of a test. */
export function __setEmailTransport(transport: EmailTransport | null): void {
  override = transport;
}

function resolveTransport(): EmailTransport {
  if (override) return override;
  if (getEnv().RESEND_API_KEY) return { name: "resend", send: resendTransport };
  return defaultTransport;
}

export async function sendEmail(input: SendInput): Promise<SendResult> {
  const locale = input.locale ?? "en";
  const recipients = (Array.isArray(input.to) ? input.to : [input.to])
    .map((v) => v.trim())
    .filter(Boolean);

  if (recipients.length === 0) {
    return { id: "skipped", delivered: false, mode: "skipped" };
  }

  const html = layout({
    heading: input.heading,
    body: input.body,
    action: input.action,
    locale,
  });

  const text = [
    input.heading,
    "",
    input.body,
    input.action ? `\n${input.action.label}: ${input.action.href}` : "",
    "",
    "Microsoft Student Clubs — Innovation University",
  ]
    .filter((line) => line !== "")
    .join("\n");

  try {
    const transport = resolveTransport();
    const id = await transport.send({
      from: getEnv().EMAIL_FROM,
      to: recipients,
      subject: input.subject,
      html,
      text,
    });
    return { id, delivered: true, mode: transport.name };
  } catch (error) {
    console.error(
      JSON.stringify({
        level: "error",
        channel: "email",
        message: error instanceof Error ? error.message : String(error),
      }),
    );
    // Delivery failure must never break the user-facing flow: the caller
    // already has a persisted notification row to fall back on.
    return { id: "failed", delivered: false, mode: "skipped" };
  }
}

/** Exposed for tests and for rendering a preview of a template. */
export function __renderEmailPreview(input: SendInput): string {
  return layout({
    heading: input.heading,
    body: input.body,
    action: input.action,
    locale: input.locale ?? "en",
  });
}

export const EMAIL_LOGO_CID = LOGO_CID;
