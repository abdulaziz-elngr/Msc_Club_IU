import { z } from "zod";

/**
 * Shared Zod building blocks for form-driven server actions.
 * Every action parses FormData through an explicit schema — raw input is never spread
 * into a database call (no mass assignment).
 */

/** HTML checkbox: present ("on") → true, absent → false. */
export const checkbox = z.preprocess((v) => v === "on" || v === "true" || v === true, z.boolean());

export const text = (max: number, min = 1) => z.string().trim().min(min).max(max);
export const optionalText = (max: number) => z.string().trim().max(max).optional();

export const int = (min: number, max: number) => z.coerce.number().int().min(min).max(max);
export const optionalInt = (min: number, max: number) => int(min, max).optional();

/** ISO string produced by the client `DateTimeField` (timezone-correct). */
export const isoDate = z.string().datetime({ offset: true }).transform((v) => new Date(v));
export const optionalIsoDate = isoDate.optional();

export const slug = z
  .string()
  .trim()
  .toLowerCase()
  .min(2)
  .max(80)
  .regex(/^[a-z0-9]+(?:-[a-z0-9]+)*$/);

/** cuid-like record id coming from a hidden input or route param. */
export const recordId = z.string().min(8).max(40).regex(/^[A-Za-z0-9_-]+$/);

export const hexColor = z.string().regex(/^#[0-9a-fA-F]{6}$/);

/** FormData → plain object. Empty strings are dropped, repeated keys become arrays. */
export function formToObject(formData: FormData): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const key of new Set(formData.keys())) {
    if (key.startsWith("$ACTION")) continue;
    const values = formData.getAll(key).filter((v): v is string => typeof v === "string");
    const cleaned = values.map((v) => v).filter((v) => v !== "");
    if (cleaned.length === 0) continue;
    out[key] = values.length > 1 ? cleaned : cleaned[0];
  }
  return out;
}
