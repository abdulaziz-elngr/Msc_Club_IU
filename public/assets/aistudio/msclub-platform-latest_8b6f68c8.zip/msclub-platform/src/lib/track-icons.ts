import {
  Award,
  BookOpen,
  Brain,
  Briefcase,
  CalendarCheck,
  Cloud,
  Code,
  Cpu,
  Database,
  GraduationCap,
  Layers,
  Lock,
  Palette,
  Rocket,
  Shield,
  Smartphone,
  Sparkles,
  Terminal,
  Wrench,
  type LucideIcon,
} from "lucide-react";

/**
 * Maps the `LearningTrack.icon` string (a plain column, so administrators can
 * add values without a code change) to a Lucide icon. Unknown values fall back
 * to a neutral book glyph rather than rendering nothing.
 */
export const TRACK_ICONS: Record<string, LucideIcon> = {
  "code-2": Code,
  code: Code,
  terminal: Terminal,
  brain: Brain,
  cpu: Cpu,
  database: Database,
  cloud: Cloud,
  shield: Shield,
  lock: Lock,
  smartphone: Smartphone,
  palette: Palette,
  pen: Palette,
  "book-open": BookOpen,
  "graduation-cap": GraduationCap,
  "badge-check": Award,
  wrench: Wrench,
  rocket: Rocket,
  layers: Layers,
  sparkles: Sparkles,
  briefcase: Briefcase,
  "calendar-check": CalendarCheck,
};

export function trackIcon(name: string | null | undefined): LucideIcon {
  if (!name) return BookOpen;
  return TRACK_ICONS[name] ?? BookOpen;
}
