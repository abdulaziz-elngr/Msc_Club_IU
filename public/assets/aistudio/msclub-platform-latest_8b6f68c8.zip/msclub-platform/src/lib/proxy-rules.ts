/**
 * Pure rules used by `src/proxy.ts`. Kept free of Next/Node imports so they can
 * be unit-tested and so the proxy bundle stays small.
 *
 * The proxy is an OPTIMISTIC gate only (cookie present?). Every protected page,
 * server action and route handler re-checks authentication and authorization
 * against the database — never rely on this file for security.
 */

const PROTECTED_PREFIXES = ["/dashboard", "/admin", "/team", "/join/status"];

/** `/events/<id>/manage` and `/events/<id>/check-in` are staff tools. */
const PROTECTED_PATTERNS = [/^\/events\/[^/]+\/(manage|check-in)(\/|$)/, /^\/learning\/.+/];

export function isProtectedPath(pathname: string): boolean {
  if (PROTECTED_PREFIXES.some((p) => pathname === p || pathname.startsWith(`${p}/`))) return true;
  return PROTECTED_PATTERNS.some((re) => re.test(pathname));
}

/** Auth.js session cookie, plain or `__Secure-` prefixed, possibly chunked (`.0`, `.1`). */
export function hasSessionCookie(names: string[]): boolean {
  return names.some((n) => /^(__Secure-)?authjs\.session-token(\.\d+)?$/.test(n));
}

export function buildCsp(nonce: string, isDev: boolean): string {
  const directives = [
    "default-src 'self'",
    // Strict, nonce-based scripts. `strict-dynamic` lets Next's own chunks load.
    `script-src 'self' 'nonce-${nonce}' 'strict-dynamic' 'wasm-unsafe-eval'${isDev ? " 'unsafe-eval'" : ""}`,
    // Inline style ATTRIBUTES (Radix, Framer Motion, Recharts) cannot carry a nonce.
    "style-src 'self' 'unsafe-inline'",
    "img-src 'self' data: blob: https://res.cloudinary.com https://i.ytimg.com https://img.youtube.com https://images.unsplash.com",
    "font-src 'self' data:",
    `connect-src 'self'${isDev ? " ws: wss:" : ""}`,
    // Lesson videos: privacy-enhanced YouTube only.
    "frame-src https://www.youtube-nocookie.com",
    "media-src 'self' blob:",
    "worker-src 'self' blob:",
    "object-src 'none'",
    "base-uri 'self'",
    "form-action 'self'",
    "frame-ancestors 'none'",
  ];
  if (!isDev) directives.push("upgrade-insecure-requests");
  return directives.join("; ");
}
