import "server-only";

import type { AuthContext, TeamAction } from "@/lib/auth/dal";
import { assertTeamAccess } from "@/lib/auth/dal";
import type { PermissionKey } from "@/lib/rbac/permissions";
import { db } from "@/lib/db";
import { logAudit } from "@/lib/audit";

const GLOBAL_PERMISSION: Record<TeamAction, PermissionKey> = {
  view: "teams.read",
  manage: "teams.update",
  manage_members: "teams.manage_members",
  manage_tasks: "teams.manage_tasks",
  manage_learning: "teams.manage_learning",
};

/**
 * Passes for club-wide managers holding the matching global permission, else
 * requires an ACTIVE membership of THIS team with a sufficient role (throws ForbiddenError).
 */
export function authorizeTeam(ctx: AuthContext, teamId: string, action: TeamAction): void {
  if (ctx.permissions.has(GLOBAL_PERMISSION[action])) return;
  assertTeamAccess(ctx, teamId, action);
}

export type TeamResult = { ok: true } | { ok: false; code: "NOT_FOUND" | "NOT_ACTIVE" | "SAME_PERSON" };

async function findActiveUserByEmail(email: string) {
  return db.user.findFirst({ where: { email: { equals: email.trim(), mode: "insensitive" }, status: "ACTIVE" }, select: { id: true } });
}

export async function addTeamMember(params: { teamId: string; email: string; actorId: string }): Promise<TeamResult> {
  const [team, user] = await Promise.all([
    db.team.findFirst({ where: { id: params.teamId, status: "ACTIVE" }, select: { id: true } }),
    findActiveUserByEmail(params.email),
  ]);
  if (!team) return { ok: false, code: "NOT_FOUND" };
  if (!user) return { ok: false, code: "NOT_ACTIVE" };

  await db.teamMembership.upsert({
    where: { userId_teamId: { userId: user.id, teamId: team.id } },
    create: { userId: user.id, teamId: team.id, role: "MEMBER", status: "ACTIVE" },
    // Re-adding a former member restores them as a plain member (never auto-promoted).
    update: { status: "ACTIVE", leftAt: null, role: "MEMBER", joinedAt: new Date() },
  });
  await logAudit({ actorId: params.actorId, action: "team.member.add", entityType: "Team", entityId: team.id, after: { userId: user.id } });
  return { ok: true };
}

export async function removeTeamMember(params: { teamId: string; userId: string; actorId: string }): Promise<TeamResult> {
  const result = await db.$transaction(async (tx) => {
    const m = await tx.teamMembership.updateMany({
      where: { teamId: params.teamId, userId: params.userId, status: "ACTIVE" },
      data: { status: "REMOVED", leftAt: new Date(), role: "MEMBER" },
    });
    if (m.count === 0) return false;
    await tx.team.updateMany({ where: { id: params.teamId, leadId: params.userId }, data: { leadId: null } });
    await tx.team.updateMany({ where: { id: params.teamId, coLeadId: params.userId }, data: { coLeadId: null } });
    return true;
  });
  if (!result) return { ok: false, code: "NOT_FOUND" };
  await logAudit({ actorId: params.actorId, action: "team.member.remove", entityType: "Team", entityId: params.teamId, after: { userId: params.userId } });
  return { ok: true };
}

/** Sets (or clears, with empty string) the team lead / co-lead; keeps memberships and roles consistent. */
export async function setLeadership(params: { teamId: string; leadEmail?: string; coLeadEmail?: string; actorId: string }): Promise<TeamResult> {
  const team = await db.team.findUnique({ where: { id: params.teamId }, select: { id: true, leadId: true, coLeadId: true } });
  if (!team) return { ok: false, code: "NOT_FOUND" };

  const resolve = async (email: string | undefined, current: string | null) => {
    if (email === undefined) return { id: current, changed: false };
    if (email.trim() === "") return { id: null, changed: current !== null };
    const u = await findActiveUserByEmail(email);
    return { id: u?.id ?? "__missing__", changed: true };
  };
  const lead = await resolve(params.leadEmail, team.leadId);
  const coLead = await resolve(params.coLeadEmail, team.coLeadId);
  if (lead.id === "__missing__" || coLead.id === "__missing__") return { ok: false, code: "NOT_ACTIVE" };
  if (lead.id && lead.id === coLead.id) return { ok: false, code: "SAME_PERSON" };

  await db.$transaction(async (tx) => {
    // Demote whoever is stepping down (but keep them in the team).
    for (const [prev, next, role] of [[team.leadId, lead.id, "LEAD"], [team.coLeadId, coLead.id, "CO_LEAD"]] as const) {
      if (prev && prev !== next) await tx.teamMembership.updateMany({ where: { teamId: team.id, userId: prev, role }, data: { role: "MEMBER" } });
    }
    await tx.team.update({ where: { id: team.id }, data: { leadId: lead.id, coLeadId: coLead.id } });
    for (const [id, role] of [[lead.id, "LEAD"], [coLead.id, "CO_LEAD"]] as const) {
      if (!id) continue;
      await tx.teamMembership.upsert({
        where: { userId_teamId: { userId: id, teamId: team.id } },
        create: { userId: id, teamId: team.id, role, status: "ACTIVE" },
        update: { role, status: "ACTIVE", leftAt: null },
      });
    }
  });
  await logAudit({ actorId: params.actorId, action: "team.leadership", entityType: "Team", entityId: team.id, before: { leadId: team.leadId, coLeadId: team.coLeadId }, after: { leadId: lead.id, coLeadId: coLead.id } });
  return { ok: true };
}
