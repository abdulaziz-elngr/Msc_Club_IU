import "server-only";

import { db } from "@/lib/db";

/** Dashboard KPIs — every figure is a live aggregate. */
export async function getAdminKpis() {
  const now = new Date();
  const [members, pending, upcoming, registrations, courses, xp, attended, completedRegs] = await Promise.all([
    db.user.count({ where: { status: "ACTIVE" } }),
    db.memberApplication.count({ where: { status: { in: ["SUBMITTED", "UNDER_REVIEW"] } } }),
    db.event.count({ where: { publishedAt: { not: null }, status: { notIn: ["DRAFT", "CANCELLED", "COMPLETED"] }, endsAt: { gte: now } } }),
    db.eventRegistration.count({ where: { status: "CONFIRMED" } }),
    db.course.count({ where: { published: true, archivedAt: null } }),
    db.xPTransaction.aggregate({ where: { amount: { gt: 0 } }, _sum: { amount: true } }),
    db.attendance.count({ where: { status: { in: ["PRESENT", "LATE"] }, event: { status: "COMPLETED" } } }),
    db.eventRegistration.count({ where: { status: "CONFIRMED", event: { status: "COMPLETED" } } }),
  ]);
  return {
    members, pending, upcoming, registrations, courses,
    xp: xp._sum.amount ?? 0,
    attendanceRate: completedRegs > 0 ? attended / completedRegs : null,
  };
}

/** New members per calendar month for the last `months` months (zero-filled). */
export async function getMemberGrowth(months = 6) {
  const start = new Date();
  start.setUTCDate(1);
  start.setUTCHours(0, 0, 0, 0);
  start.setUTCMonth(start.getUTCMonth() - (months - 1));

  const rows = await db.$queryRaw<{ month: Date; count: bigint }[]>`
    SELECT date_trunc('month', "joinedAt") AS month, COUNT(*) AS count
    FROM "users" WHERE "status" = 'ACTIVE' AND "joinedAt" >= ${start}
    GROUP BY 1 ORDER BY 1`;
  const byKey = new Map(rows.map((r) => [new Date(r.month).toISOString().slice(0, 7), Number(r.count)]));

  return Array.from({ length: months }, (_, i) => {
    const d = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + i, 1));
    return { date: d, count: byKey.get(d.toISOString().slice(0, 7)) ?? 0 };
  });
}

/** Registered vs attended for the most recent finished events. */
export async function getEventAttendance(limit = 8) {
  const events = await db.event.findMany({
    where: { publishedAt: { not: null }, endsAt: { lt: new Date() }, status: { not: "CANCELLED" } },
    orderBy: { startsAt: "desc" },
    take: limit,
    select: {
      id: true, title: true, titleAr: true,
      _count: {
        select: {
          registrations: { where: { status: "CONFIRMED" } },
          attendance: { where: { status: { in: ["PRESENT", "LATE"] } } },
        },
      },
    },
  });
  return events.reverse().map((e) => ({
    id: e.id, title: e.title, titleAr: e.titleAr, registered: e._count.registrations, attended: e._count.attendance,
  }));
}

export async function getMembersByLevel() {
  const [levels, groups, none] = await Promise.all([
    db.level.findMany({ where: { enabled: true }, orderBy: { minXp: "asc" }, select: { id: true, name: true, nameAr: true } }),
    db.user.groupBy({ by: ["levelId"], where: { status: "ACTIVE", levelId: { not: null } }, _count: { _all: true } }),
    db.user.count({ where: { status: "ACTIVE", levelId: null } }),
  ]);
  const counts = new Map(groups.map((g) => [g.levelId, g._count._all]));
  const rows = levels.map((l) => ({ name: l.name, nameAr: l.nameAr, count: counts.get(l.id) ?? 0 }));
  void none;
  return rows;
}

export async function getRecentAudit(limit = 8) {
  return db.auditLog.findMany({
    orderBy: { createdAt: "desc" },
    take: limit,
    select: { id: true, action: true, entityType: true, createdAt: true, actor: { select: { name: true } } },
  });
}
