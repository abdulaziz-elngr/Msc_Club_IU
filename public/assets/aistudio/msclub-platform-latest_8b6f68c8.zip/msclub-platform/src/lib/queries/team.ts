import "server-only";

import { db } from "@/lib/db";

export async function getTeamBySlug(slug: string) {
  return db.team.findUnique({ where: { slug }, select: { id: true, slug: true, name: true, nameAr: true, status: true } });
}

/** Overview figures for one team — every number is a live query scoped to the team. */
export async function getTeamOverview(teamId: string) {
  const memberIds = (await db.teamMembership.findMany({ where: { teamId, status: "ACTIVE" }, select: { userId: true } })).map((m) => m.userId);
  const [xp, openTasks, upcoming] = await Promise.all([
    db.user.aggregate({ where: { id: { in: memberIds } }, _sum: { totalXp: true } }),
    db.taskAssignment.count({ where: { assignment: { teamId }, status: { in: ["NOT_STARTED", "IN_PROGRESS", "SUBMITTED", "UNDER_REVIEW"] } } }),
    db.event.findMany({
      where: { teamId, publishedAt: { not: null }, status: { notIn: ["DRAFT", "CANCELLED", "COMPLETED"] }, endsAt: { gte: new Date() } },
      orderBy: { startsAt: "asc" }, take: 5,
      select: { id: true, slug: true, title: true, titleAr: true, startsAt: true },
    }),
  ]);
  return { members: memberIds.length, xp: xp._sum.totalXp ?? 0, openTasks, upcoming };
}

export async function getTeamMembers(teamId: string) {
  return db.teamMembership.findMany({
    where: { teamId, status: "ACTIVE" },
    orderBy: [{ role: "asc" }, { joinedAt: "asc" }],
    select: { role: true, joinedAt: true, user: { select: { id: true, name: true, email: true, studentId: true, totalXp: true, level: { select: { name: true, nameAr: true } } } } },
  });
}

/** Team analytics: monthly XP of current members, event attendance, approved tasks, top members. */
export async function getTeamAnalytics(teamId: string, months = 6) {
  const start = new Date();
  start.setUTCDate(1); start.setUTCHours(0, 0, 0, 0); start.setUTCMonth(start.getUTCMonth() - (months - 1));

  const members = await db.teamMembership.findMany({ where: { teamId, status: "ACTIVE" }, select: { userId: true } });
  const ids = members.map((m) => m.userId);

  const [xpRows, registered, attended, approved, top] = await Promise.all([
    ids.length
      ? db.$queryRaw<{ month: Date; total: bigint }[]>`
          SELECT date_trunc('month', "createdAt") AS month, SUM("amount") AS total
          FROM "xp_transactions" WHERE "userId" = ANY(${ids}) AND "createdAt" >= ${start}
          GROUP BY 1 ORDER BY 1`
      : Promise.resolve([] as { month: Date; total: bigint }[]),
    db.eventRegistration.count({ where: { status: "CONFIRMED", event: { teamId, status: "COMPLETED" } } }),
    db.attendance.count({ where: { status: { in: ["PRESENT", "LATE"] }, event: { teamId, status: "COMPLETED" } } }),
    db.taskAssignment.count({ where: { assignment: { teamId }, status: { in: ["APPROVED", "COMPLETED"] } } }),
    db.user.findMany({ where: { id: { in: ids } }, orderBy: { totalXp: "desc" }, take: 5, select: { id: true, name: true, totalXp: true } }),
  ]);

  const byKey = new Map(xpRows.map((r) => [new Date(r.month).toISOString().slice(0, 7), Number(r.total)]));
  const series = Array.from({ length: months }, (_, i) => {
    const d = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() + i, 1));
    return { date: d, xp: byKey.get(d.toISOString().slice(0, 7)) ?? 0 };
  });
  return { series, attendanceRate: registered > 0 ? attended / registered : null, approved, top };
}
