import "server-only";

import type { Prisma } from "@/generated/client";
import { PAGE_SIZE } from "@/components/admin/table";
import { db } from "@/lib/db";

export async function listApplications(params: { status?: string; q?: string; page: number }) {
  const open = ["SUBMITTED", "UNDER_REVIEW"] as const;
  const where: Prisma.MemberApplicationWhereInput = {
    status: params.status ? (params.status as never) : { in: [...open] },
    ...(params.q ? { user: { OR: [{ name: { contains: params.q, mode: "insensitive" } }, { email: { contains: params.q, mode: "insensitive" } }] } } : {}),
  };
  const [total, rows] = await Promise.all([
    db.memberApplication.count({ where }),
    db.memberApplication.findMany({
      where, orderBy: { submittedAt: "asc" }, skip: (params.page - 1) * PAGE_SIZE, take: PAGE_SIZE,
      select: { id: true, status: true, submittedAt: true, user: { select: { name: true, email: true } }, track: { select: { name: true, nameAr: true } } },
    }),
  ]);
  return { rows, total, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}

export async function getApplication(id: string) {
  const app = await db.memberApplication.findUnique({
    where: { id },
    select: {
      id: true, status: true, answers: true, submittedAt: true, decisionNote: true,
      user: { select: { id: true, name: true, email: true, studentId: true, department: true, status: true } },
      track: { select: { name: true, nameAr: true } },
      history: { orderBy: { createdAt: "asc" }, select: { id: true, fromStatus: true, toStatus: true, note: true, actorId: true, createdAt: true } },
    },
  });
  if (!app) return null;
  const actorIds = [...new Set(app.history.map((h) => h.actorId).filter((x): x is string => Boolean(x)))];
  const actors = actorIds.length ? await db.user.findMany({ where: { id: { in: actorIds } }, select: { id: true, name: true } }) : [];
  return { ...app, actors: Object.fromEntries(actors.map((a) => [a.id, a.name])) as Record<string, string> };
}

export async function listMembers(params: { q?: string; status?: string; page: number }) {
  const where: Prisma.UserWhereInput = {
    status: params.status ? (params.status as never) : { in: ["ACTIVE", "SUSPENDED", "ARCHIVED"] },
    ...(params.q
      ? { OR: [{ name: { contains: params.q, mode: "insensitive" } }, { email: { contains: params.q, mode: "insensitive" } }, { studentId: { contains: params.q, mode: "insensitive" } }] }
      : {}),
  };
  const [total, rows] = await Promise.all([
    db.user.count({ where }),
    db.user.findMany({
      where, orderBy: { name: "asc" }, skip: (params.page - 1) * PAGE_SIZE, take: PAGE_SIZE,
      select: { id: true, name: true, email: true, studentId: true, status: true, totalXp: true, joinedAt: true, level: { select: { name: true, nameAr: true } } },
    }),
  ]);
  return { rows, total, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}

export async function getMember(id: string) {
  const user = await db.user.findUnique({
    where: { id },
    select: {
      id: true, name: true, email: true, studentId: true, department: true, phone: true, status: true, totalXp: true, joinedAt: true,
      level: { select: { name: true, nameAr: true } },
      roles: { select: { role: { select: { key: true, name: true, nameAr: true } } } },
      teamMemberships: { where: { status: "ACTIVE" }, select: { role: true, team: { select: { slug: true, name: true, nameAr: true } } } },
      _count: { select: { badges: true } },
    },
  });
  if (!user) return null;
  const [xp, allRoles] = await Promise.all([
    db.xPTransaction.findMany({ where: { userId: id }, orderBy: { createdAt: "desc" }, take: 10, select: { id: true, amount: true, description: true, createdAt: true } }),
    db.role.findMany({ orderBy: { weight: "desc" }, select: { key: true, name: true, nameAr: true } }),
  ]);
  return { user, xp, allRoles };
}

export async function listRolesWithPermissions() {
  const roles = await db.role.findMany({
    orderBy: { weight: "desc" },
    select: {
      id: true, key: true, name: true, nameAr: true, description: true, descriptionAr: true, isSystem: true,
      _count: { select: { users: true } },
      permissions: { select: { permission: { select: { key: true, group: true, label: true, labelAr: true } } } },
    },
  });
  return roles;
}
