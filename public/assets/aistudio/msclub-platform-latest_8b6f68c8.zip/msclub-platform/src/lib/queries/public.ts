import "server-only";

import { cache } from "react";
import { db } from "@/lib/db";

/**
 * Public-site read models.
 *
 * Every number shown on the marketing pages comes from a real aggregate
 * here — there are no hard-coded statistics anywhere in the UI.
 */

export const getPublicStats = cache(async () => {
  const [members, teams, events, xp] = await Promise.all([
    db.user.count({ where: { status: "ACTIVE" } }),
    db.team.count({ where: { status: "ACTIVE", visibility: { not: "HIDDEN" } } }),
    db.event.count({ where: { status: { not: "DRAFT" }, publishedAt: { not: null } } }),
    db.xPTransaction.aggregate({ _sum: { amount: true } }),
  ]);

  return {
    members,
    teams,
    events,
    xpAwarded: Math.max(0, xp._sum.amount ?? 0),
  };
});

export const getPublicTracks = cache(async () =>
  db.learningTrack.findMany({
    where: { enabled: true, archivedAt: null, kind: { in: ["DEPARTMENT", "BOTH"] } },
    orderBy: { order: "asc" },
    select: {
      id: true,
      slug: true,
      name: true,
      nameAr: true,
      description: true,
      descriptionAr: true,
      icon: true,
      color: true,
      _count: { select: { members: true, courses: { where: { published: true } } } },
    },
  }),
);

export const getUpcomingEvents = cache(async (limit = 3) =>
  db.event.findMany({
    where: { publishedAt: { not: null }, status: { notIn: ["DRAFT", "CANCELLED"] }, startsAt: { gte: new Date() } },
    orderBy: { startsAt: "asc" },
    take: limit,
    select: {
      id: true,
      slug: true,
      title: true,
      titleAr: true,
      summary: true,
      category: true,
      status: true,
      startsAt: true,
      endsAt: true,
      location: true,
      isOnline: true,
      capacity: true,
      attendancePoints: true,
      _count: { select: { registrations: { where: { status: "CONFIRMED" } } } },
    },
  }),
);

export const getPastEvents = cache(async (limit = 4) =>
  db.event.findMany({
    where: { publishedAt: { not: null }, status: { in: ["COMPLETED", "IN_PROGRESS"] } },
    orderBy: { startsAt: "desc" },
    take: limit,
    select: {
      id: true,
      slug: true,
      title: true,
      titleAr: true,
      startsAt: true,
      category: true,
      _count: { select: { attendance: { where: { status: { in: ["PRESENT", "LATE"] } } } } },
    },
  }),
);

export const getFeaturedCourses = cache(async (limit = 3) =>
  db.course.findMany({
    where: { published: true, archivedAt: null },
    orderBy: [{ featured: "desc" }, { order: "asc" }],
    take: limit,
    select: {
      id: true,
      slug: true,
      title: true,
      titleAr: true,
      summary: true,
      difficulty: true,
      durationMinutes: true,
      instructor: true,
      featured: true,
      xpReward: true,
      certificateEnabled: true,
      track: { select: { name: true, nameAr: true, color: true, icon: true } },
      _count: { select: { lessons: true, enrollments: true } },
    },
  }),
);

/**
 * Monthly leaderboard of active members who opted in to being ranked.
 * Privacy preferences are honoured: hidden profiles never appear.
 */
export const getLeaderboard = cache(async (limit = 20, period: "all" | "monthly" | "weekly" = "all") => {
  const since =
    period === "weekly"
      ? new Date(Date.now() - 7 * 86_400_000)
      : period === "monthly"
        ? new Date(Date.now() - 30 * 86_400_000)
        : null;

  const rows = await db.user.findMany({
    where: {
      status: "ACTIVE",
      leaderboardVisible: true,
      profileVisibility: { in: ["PUBLIC"] },
      ...(since ? { xpTransactions: { some: { createdAt: { gte: since } } } } : {}),
    },
    orderBy: { totalXp: "desc" },
    take: limit,
    select: {
      id: true,
      name: true,
      image: true,
      totalXp: true,
      joinedAt: true,
      level: { select: { key: true, name: true, nameAr: true, color: true, icon: true } },
      ...(since
        ? { xpTransactions: { where: { createdAt: { gte: since } }, select: { amount: true } } }
        : {}),
    },
  });

  return rows
    .map((row, index) => {
      const periodXp = since
        ? row.xpTransactions.reduce((sum, tx) => sum + tx.amount, 0)
        : row.totalXp;
      return {
        rank: index + 1,
        id: row.id,
        name: row.name,
        image: row.image,
        totalXp: row.totalXp,
        periodXp,
        joinedAt: row.joinedAt,
        level: row.level,
      };
    })
    .filter((row) => row.periodXp > 0);
});

export const getTestimonials = cache(async (limit = 6) =>
  db.testimonial.findMany({
    where: { approved: true },
    orderBy: { order: "asc" },
    take: limit,
    select: {
      id: true,
      name: true,
      nameAr: true,
      role: true,
      roleAr: true,
      quote: true,
      quoteAr: true,
      image: true,
    },
  }),
);

export const getPublicTeams = cache(async () =>
  db.team.findMany({
    where: { status: "ACTIVE", visibility: "PUBLIC" },
    orderBy: { order: "asc" },
    select: {
      id: true,
      slug: true,
      name: true,
      nameAr: true,
      description: true,
      descriptionAr: true,
      logo: true,
      _count: { select: { memberships: { where: { status: "ACTIVE" } } } },
      lead: { select: { name: true } },
      track: { select: { name: true, nameAr: true, color: true } },
    },
  }),
);
