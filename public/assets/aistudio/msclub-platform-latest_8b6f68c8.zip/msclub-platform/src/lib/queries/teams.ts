import "server-only";

import { db } from "@/lib/db";

/**
 * One public team. The roster includes only ACTIVE members who made their
 * profile PUBLIC, and exposes name / title / avatar — never e-mail or student id.
 */
export async function getPublicTeam(slug: string) {
  const team = await db.team.findFirst({
    where: { slug, status: "ACTIVE", visibility: "PUBLIC" },
    select: {
      id: true,
      slug: true,
      name: true,
      nameAr: true,
      description: true,
      descriptionAr: true,
      logo: true,
      lead: { select: { name: true, image: true, profileVisibility: true } },
      track: { select: { name: true, nameAr: true } },
      _count: { select: { memberships: { where: { status: "ACTIVE" } } } },
      memberships: {
        where: { status: "ACTIVE", user: { profileVisibility: "PUBLIC", status: "ACTIVE" } },
        orderBy: [{ role: "asc" }, { joinedAt: "asc" }],
        take: 60,
        select: { id: true, role: true, title: true, user: { select: { id: true, name: true, image: true } } },
      },
    },
  });
  if (!team) return null;

  const upcomingEvents = await db.event.findMany({
    where: { teamId: team.id, publishedAt: { not: null }, status: { notIn: ["DRAFT", "CANCELLED"] }, endsAt: { gte: new Date() } },
    orderBy: { startsAt: "asc" },
    take: 3,
    select: {
      id: true, slug: true, title: true, titleAr: true, summary: true, category: true, status: true, startsAt: true,
      endsAt: true, location: true, isOnline: true, capacity: true, attendancePoints: true,
      _count: { select: { registrations: { where: { status: "CONFIRMED" } } } },
    },
  });

  return { ...team, upcomingEvents };
}
