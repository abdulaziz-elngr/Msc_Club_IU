import "server-only";

import { db } from "@/lib/db";
import { nextLevel } from "@/lib/xp";

/** Everything the member overview shows — each figure comes from a real query. */
export async function getMemberOverview(userId: string) {
  const now = new Date();

  const [user, attended, coursesDone, badges, upcoming, teams] = await Promise.all([
    db.user.findUniqueOrThrow({
      where: { id: userId },
      select: { totalXp: true, leaderboardVisible: true, level: { select: { key: true, name: true, nameAr: true, minXp: true } } },
    }),
    db.attendance.count({ where: { userId, status: { in: ["PRESENT", "LATE"] } } }),
    db.courseEnrollment.count({ where: { userId, completedAt: { not: null } } }),
    db.userBadge.count({ where: { userId } }),
    db.eventRegistration.findMany({
      where: { userId, status: { in: ["CONFIRMED", "WAITLISTED"] }, event: { endsAt: { gte: now } } },
      orderBy: { event: { startsAt: "asc" } },
      take: 3,
      select: {
        id: true,
        status: true,
        event: { select: { slug: true, title: true, titleAr: true, startsAt: true, location: true, isOnline: true } },
      },
    }),
    db.teamMembership.findMany({
      where: { userId, status: "ACTIVE" },
      select: { role: true, team: { select: { slug: true, name: true, nameAr: true } } },
    }),
  ]);

  // Rank among members who appear on the leaderboard (privacy setting respected).
  const myRank = user.leaderboardVisible
    ? (await db.user.count({ where: { status: "ACTIVE", leaderboardVisible: true, totalXp: { gt: user.totalXp } } })) + 1
    : null;

  return { user, attended, coursesDone, badges, upcoming, teams, rank: myRank, next: await nextLevel(user.totalXp) };
}

/** Registrations for /dashboard/events. */
export async function getMyRegistrations(userId: string) {
  return db.eventRegistration.findMany({
    where: { userId, status: { in: ["CONFIRMED", "WAITLISTED"] } },
    orderBy: { event: { startsAt: "desc" } },
    select: {
      id: true,
      status: true,
      qrVersion: true,
      checkedInAt: true,
      event: {
        select: { id: true, slug: true, title: true, titleAr: true, startsAt: true, endsAt: true, location: true, isOnline: true, status: true },
      },
    },
  });
}
