import "server-only";

import type { EventCategory, Prisma } from "@/generated/client";
import { db } from "@/lib/db";

/** Events visible to the public: published and not a draft. */
const PUBLIC_WHERE: Prisma.EventWhereInput = { publishedAt: { not: null }, status: { not: "DRAFT" } };

export const EVENT_PAGE_SIZE = 9;

export type EventWhen = "upcoming" | "past" | "all";

export async function listPublicEvents(params: { when: EventWhen; category?: EventCategory; page: number }) {
  const now = new Date();
  const where: Prisma.EventWhereInput = {
    ...PUBLIC_WHERE,
    ...(params.when === "upcoming" ? { endsAt: { gte: now }, status: { notIn: ["DRAFT", "CANCELLED"] } } : {}),
    ...(params.when === "past" ? { endsAt: { lt: now } } : {}),
    ...(params.category ? { category: params.category } : {}),
  };

  const [total, events] = await Promise.all([
    db.event.count({ where }),
    db.event.findMany({
      where,
      orderBy: { startsAt: params.when === "past" ? "desc" : "asc" },
      skip: (params.page - 1) * EVENT_PAGE_SIZE,
      take: EVENT_PAGE_SIZE,
      select: {
        id: true,
        slug: true,
        title: true,
        titleAr: true,
        summary: true,
        category: true,
        status: true,
        startsAt: true,
        endsAt: true,
        location: true,
        isOnline: true,
        capacity: true,
        attendancePoints: true,
        _count: { select: { registrations: { where: { status: "CONFIRMED" } } } },
      },
    }),
  ]);

  return { events, total, pages: Math.max(1, Math.ceil(total / EVENT_PAGE_SIZE)) };
}

/** Full public detail for one event, including the (public) registration form definition. */
export async function getPublicEvent(slug: string) {
  const event = await db.event.findFirst({
    where: { slug, ...PUBLIC_WHERE },
    select: {
      id: true,
      slug: true,
      title: true,
      titleAr: true,
      summary: true,
      description: true,
      descriptionAr: true,
      coverImage: true,
      category: true,
      status: true,
      location: true,
      isOnline: true,
      startsAt: true,
      endsAt: true,
      registrationOpensAt: true,
      registrationClosesAt: true,
      capacity: true,
      waitlistEnabled: true,
      attendancePoints: true,
      completionPoints: true,
      certificateEnabled: true,
      speakerName: true,
      speakerTitle: true,
      speakerBio: true,
      organizer: { select: { name: true } },
      team: { select: { slug: true, name: true, nameAr: true } },
      formFields: {
        orderBy: { order: "asc" },
        select: { key: true, label: true, labelAr: true, type: true, options: true, required: true },
      },
      _count: {
        select: {
          registrations: { where: { status: "CONFIRMED" } },
        },
      },
    },
  });
  if (!event) return null;

  const waitlisted = await db.eventRegistration.count({ where: { eventId: event.id, status: "WAITLISTED" } });
  return { ...event, waitlisted };
}

export type RegistrationWindow = "open" | "closed" | "not_yet" | "ended" | "cancelled";

/** Pure: whether a member could register right now (mirrors the server-side rule). */
export function registrationWindow(
  event: { status: string; endsAt: Date; registrationOpensAt: Date | null; registrationClosesAt: Date | null },
  now = new Date(),
): RegistrationWindow {
  if (event.status === "CANCELLED") return "cancelled";
  if (event.endsAt <= now || event.status === "COMPLETED") return "ended";
  if (event.status !== "REGISTRATION_OPEN") return "closed";
  if (event.registrationOpensAt && event.registrationOpensAt > now) return "not_yet";
  if (event.registrationClosesAt && event.registrationClosesAt <= now) return "closed";
  return "open";
}
