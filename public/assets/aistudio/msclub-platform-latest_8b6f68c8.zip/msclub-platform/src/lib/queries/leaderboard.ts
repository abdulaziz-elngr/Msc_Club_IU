import "server-only";

import { db } from "@/lib/db";

export type LeaderboardScope = "global" | "team" | "event" | "track";
export type LeaderboardPeriod = "all" | "monthly" | "weekly";

export type LeaderboardEntry = {
  rank: number;
  userId: string;
  name: string;
  image: string | null;
  value: number;
  level: { name: string; nameAr: string | null } | null;
  profilePublic: boolean;
};

export function periodStart(period: LeaderboardPeriod, now = new Date()): Date | null {
  if (period === "all") return null;
  const d = new Date(now);
  if (period === "monthly") return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), 1));
  const day = (d.getUTCDay() + 6) % 7; // Monday-based week
  return new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate() - day));
}

/** Standard competition ranking: equal scores share a rank (1, 2, 2, 4). */
export function assignRanks<T extends { value: number }>(rows: T[]): (T & { rank: number })[] {
  let last = Number.NaN;
  let rank = 0;
  return rows.map((row, i) => {
    if (row.value !== last) { rank = i + 1; last = row.value; }
    return { ...row, rank };
  });
}

/**
 * Leaderboards. A member appears only if ACTIVE and `leaderboardVisible` — the
 * per-user privacy switch always wins over any scope or setting.
 */
export async function getLeaderboard(params: { scope: LeaderboardScope; period: LeaderboardPeriod; refId?: string; limit?: number }): Promise<LeaderboardEntry[]> {
  const limit = Math.min(params.limit ?? 50, 100);
  const visible = { status: "ACTIVE" as const, leaderboardVisible: true };
  let scores: { userId: string; value: number }[] = [];

  if (params.scope === "event") {
    if (!params.refId) return [];
    const rows = await db.attendance.groupBy({
      by: ["userId"], where: { eventId: params.refId, status: { in: ["PRESENT", "LATE"] }, pointsAwarded: { gt: 0 }, user: visible },
      _sum: { pointsAwarded: true }, orderBy: { _sum: { pointsAwarded: "desc" } }, take: limit,
    });
    scores = rows.map((r) => ({ userId: r.userId, value: r._sum.pointsAwarded ?? 0 }));
  } else {
    let memberFilter: { id: { in: string[] } } | Record<string, never> = {};
    if (params.scope === "team" || params.scope === "track") {
      if (!params.refId) return [];
      const memberships = await db.teamMembership.findMany({
        where: { status: "ACTIVE", team: params.scope === "team" ? { id: params.refId } : { trackId: params.refId, status: "ACTIVE" } },
        select: { userId: true },
      });
      memberFilter = { id: { in: [...new Set(memberships.map((m) => m.userId))] } };
    }
    const since = periodStart(params.period);
    if (since === null) {
      const rows = await db.user.findMany({ where: { ...visible, ...memberFilter, totalXp: { gt: 0 } }, orderBy: [{ totalXp: "desc" }, { name: "asc" }], take: limit, select: { id: true, totalXp: true } });
      scores = rows.map((r) => ({ userId: r.id, value: r.totalXp }));
    } else {
      const rows = await db.xPTransaction.groupBy({
        by: ["userId"], where: { createdAt: { gte: since }, user: { ...visible, ...memberFilter } },
        _sum: { amount: true }, having: { amount: { _sum: { gt: 0 } } }, orderBy: { _sum: { amount: "desc" } }, take: limit,
      });
      scores = rows.map((r) => ({ userId: r.userId, value: r._sum.amount ?? 0 }));
    }
  }
  if (scores.length === 0) return [];

  const users = await db.user.findMany({
    where: { id: { in: scores.map((s) => s.userId) } },
    select: { id: true, name: true, image: true, profileVisibility: true, level: { select: { name: true, nameAr: true } } },
  });
  const byId = new Map(users.map((u) => [u.id, u]));
  const rows = scores.flatMap((s) => {
    const u = byId.get(s.userId);
    return u ? [{ userId: u.id, name: u.name, image: u.image, value: s.value, level: u.level, profilePublic: u.profileVisibility === "PUBLIC" }] : [];
  });
  return assignRanks(rows);
}

export async function countOptedOut() {
  return db.user.count({ where: { status: "ACTIVE", leaderboardVisible: false } });
}
