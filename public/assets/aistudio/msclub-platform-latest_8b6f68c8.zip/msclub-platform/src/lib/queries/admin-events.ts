import "server-only";

import type { Prisma } from "@/generated/client";
import { db } from "@/lib/db";
import { PAGE_SIZE } from "@/components/admin/table";

export async function listAdminEvents(params: { q?: string; status?: string; page: number }) {
  const where: Prisma.EventWhereInput = {
    ...(params.q ? { OR: [{ title: { contains: params.q, mode: "insensitive" } }, { titleAr: { contains: params.q, mode: "insensitive" } }] } : {}),
    ...(params.status ? { status: params.status as Prisma.EnumEventStatusFilter["equals"] } : {}),
  };
  const [total, rows] = await Promise.all([
    db.event.count({ where }),
    db.event.findMany({
      where, orderBy: { startsAt: "desc" }, skip: (params.page - 1) * PAGE_SIZE, take: PAGE_SIZE,
      select: {
        id: true, title: true, titleAr: true, status: true, startsAt: true, capacity: true,
        _count: { select: { registrations: { where: { status: "CONFIRMED" } } } },
      },
    }),
  ]);
  return { rows, total, pages: Math.max(1, Math.ceil(total / PAGE_SIZE)) };
}

const LIST_CAP = 200;

/** Everything the event console needs in one place (lists are capped; exports are complete). */
export async function getAdminEvent(id: string) {
  const event = await db.event.findUnique({
    where: { id },
    include: {
      formFields: { orderBy: { order: "asc" } },
      reminders: { orderBy: { sendAt: "asc" } },
      team: { select: { id: true, name: true } },
    },
  });
  if (!event) return null;

  const [registrations, attendance, counts, teams] = await Promise.all([
    db.eventRegistration.findMany({
      where: { eventId: id }, orderBy: [{ status: "asc" }, { createdAt: "asc" }], take: LIST_CAP,
      select: { id: true, status: true, waitlistPos: true, createdAt: true, checkedInAt: true, user: { select: { id: true, name: true, studentId: true } } },
    }),
    db.attendance.findMany({
      where: { eventId: id }, orderBy: { createdAt: "desc" }, take: LIST_CAP,
      select: { id: true, status: true, method: true, pointsAwarded: true, createdAt: true, user: { select: { name: true, studentId: true } } },
    }),
    db.eventRegistration.groupBy({ by: ["status"], where: { eventId: id }, _count: { _all: true } }),
    db.team.findMany({ where: { status: "ACTIVE" }, orderBy: { name: "asc" }, select: { id: true, name: true } }),
  ]);
  const byStatus = Object.fromEntries(counts.map((c) => [c.status, c._count._all])) as Record<string, number>;
  const present = await db.attendance.count({ where: { eventId: id, status: { in: ["PRESENT", "LATE"] } } });

  return { event, registrations, attendance, teams, stats: { confirmed: byStatus.CONFIRMED ?? 0, waitlisted: byStatus.WAITLISTED ?? 0, present }, cap: LIST_CAP };
}

/** `/events/<x>/…` staff routes accept either the record id or the public slug. */
export async function findEventByIdOrSlug(key: string) {
  return db.event.findFirst({ where: { OR: [{ id: key }, { slug: key }] }, select: { id: true, slug: true, title: true, titleAr: true, startsAt: true, endsAt: true, status: true } });
}
