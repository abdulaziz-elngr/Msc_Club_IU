import "server-only";

import { cache } from "react";
import { db } from "@/lib/db";

/** Community achievements: every number is a live aggregate, never a constant. */
export const getCommunityStats = cache(async () => {
  const [members, events, attendees, courses, certificates] = await Promise.all([
    db.user.count({ where: { status: "ACTIVE" } }),
    db.event.count({ where: { publishedAt: { not: null }, status: "COMPLETED" } }),
    db.attendance.count({ where: { status: { in: ["PRESENT", "LATE"] } } }),
    db.course.count({ where: { published: true, archivedAt: null } }),
    db.certificate.count({ where: { revokedAt: null } }),
  ]);
  return { members, events, attendees, courses, certificates };
});
