/**
 * Server-side validation of a registration's custom-field answers.
 *
 * The client form is only a convenience: the answers JSON stored on a
 * registration is rebuilt here from the event's own `EventFormField` rows, so
 * unknown keys are dropped, types are enforced and sizes are capped
 * (no mass assignment, no unbounded JSON).
 */

export type FormFieldDef = {
  key: string;
  type: string;
  options: string[];
  required: boolean;
};

export type AnswerErrorCode = "required" | "invalid" | "tooLong" | "notAnOption";

export type AnswerValidation =
  | { ok: true; answers: Record<string, string | number | boolean> }
  | { ok: false; errors: Record<string, AnswerErrorCode> };

const MAX_TEXT = 300;
const MAX_TEXTAREA = 2000;
const MAX_URL = 500;

export function validateAnswers(fields: FormFieldDef[], raw: Record<string, unknown>): AnswerValidation {
  const answers: Record<string, string | number | boolean> = {};
  const errors: Record<string, AnswerErrorCode> = {};

  for (const field of fields) {
    const value = raw[field.key];
    const text = typeof value === "string" ? value.trim() : value === undefined || value === null ? "" : String(value).trim();

    if (field.type === "checkbox") {
      const checked = value === true || text === "on" || text === "true" || text === "1";
      if (field.required && !checked) errors[field.key] = "required";
      else answers[field.key] = checked;
      continue;
    }

    if (text === "") {
      if (field.required) errors[field.key] = "required";
      continue;
    }

    switch (field.type) {
      case "number": {
        const n = Number(text);
        if (!Number.isFinite(n) || Math.abs(n) > 1e12) errors[field.key] = "invalid";
        else answers[field.key] = n;
        break;
      }
      case "select":
        if (!field.options.includes(text)) errors[field.key] = "notAnOption";
        else answers[field.key] = text;
        break;
      case "url": {
        let ok = false;
        try {
          const u = new URL(text);
          ok = u.protocol === "https:" || u.protocol === "http:";
        } catch {
          ok = false;
        }
        if (text.length > MAX_URL) errors[field.key] = "tooLong";
        else if (!ok) errors[field.key] = "invalid";
        else answers[field.key] = text;
        break;
      }
      case "textarea":
        if (text.length > MAX_TEXTAREA) errors[field.key] = "tooLong";
        else answers[field.key] = text;
        break;
      default:
        if (text.length > MAX_TEXT) errors[field.key] = "tooLong";
        else answers[field.key] = text;
    }
  }

  return Object.keys(errors).length > 0 ? { ok: false, errors } : { ok: true, answers };
}
