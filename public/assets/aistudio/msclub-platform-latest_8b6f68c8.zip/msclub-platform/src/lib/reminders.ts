import "server-only";

import type { db as Db } from "@/lib/db";
import { notify } from "@/lib/notifications";

/**
 * Sends due event reminders. Each reminder row is CLAIMED with a conditional
 * update (`sentAt IS NULL`) before sending, so two overlapping cron runs can
 * never notify the same audience twice.
 */
export async function processDueReminders(db: typeof Db, now = new Date()) {
  const due = await db.eventReminder.findMany({
    where: { sentAt: null, sendAt: { lte: now } },
    orderBy: { sendAt: "asc" },
    take: 50,
    select: { id: true, event: { select: { id: true, slug: true, title: true, titleAr: true, startsAt: true, status: true } } },
  });

  let reminders = 0;
  let notified = 0;
  for (const reminder of due) {
    const claimed = await db.eventReminder.updateMany({ where: { id: reminder.id, sentAt: null }, data: { sentAt: now } });
    if (claimed.count === 0) continue;
    reminders += 1;

    const { event } = reminder;
    // Past or cancelled events get no reminder (the row is still marked sent).
    if (event.status === "CANCELLED" || event.startsAt <= now) continue;

    const regs = await db.eventRegistration.findMany({ where: { eventId: event.id, status: "CONFIRMED" }, select: { userId: true } });
    for (const r of regs) {
      await notify({
        userId: r.userId, type: "EVENT_REMINDER",
        title: `Reminder: ${event.title}`, titleAr: `تذكير: ${event.titleAr ?? event.title}`,
        body: "Your QR pass is ready in your dashboard.", bodyAr: "تذكرتك (QR) جاهزة في لوحتك.",
        href: "/dashboard/events",
      });
      notified += 1;
    }
  }
  return { reminders, notified };
}
