import "server-only";

import { readFileSync } from "node:fs";
import path from "node:path";
import PDFDocument from "pdfkit";
import QRCode from "qrcode";
import { db } from "@/lib/db";
import { verificationUrl } from "@/lib/certificates";

/**
 * Certificate PDF (A4 landscape, brand colours). Fonts are embedded static OFL fonts:
 * Inter for Latin and Noto Sans Arabic for Arabic — pdfkit shapes Arabic through fontkit.
 * The QR encodes ONLY the public verification URL.
 */
const FONT_DIR = path.join(process.cwd(), "src", "fonts", "pdf");
const load = (name: string) => readFileSync(path.join(FONT_DIR, name));

const NAVY = "#123F6E";
const ROYAL = "#1B6AC4";
const MID = "#599FE4";
const GREY = "#5B6B7F";
const ARABIC = /[\u0600-\u06FF]/;

/**
 * In a right-to-left line, whitespace at the edges of a non-Arabic run (digits, Latin) belongs on
 * the opposite side of where a left-to-right draw would put it, so swap it.
 */
function visual(run: string, rtl: boolean): string {
  if (!rtl || ARABIC.test(run)) return run;
  const lead = /^\s*/.exec(run)?.[0] ?? "";
  const trail = /\s*$/.exec(run)?.[0] ?? "";
  return `${trail}${run.trim()}${lead}`;
}

const COPY = {
  en: {
    certify: "This is to certify that",
    verbs: { COURSE: "has successfully completed", EVENT: "has successfully attended", DEFAULT: "has been recognised for" } as Record<string, string>,
    issued: "Issued on",
    id: "Certificate ID",
    verify: "Verify at",
    heading: "Certificate of Achievement",
    footer: "Microsoft Student Clubs — Innovation University",
  },
  ar: {
    certify: "تشهد نوادي مايكروسوفت الطلابية بأن",
    verbs: { COURSE: "قد أتمّ بنجاح دورة", EVENT: "قد حضر بنجاح فعالية", DEFAULT: "قد حصل على التقدير عن" } as Record<string, string>,
    issued: "تاريخ الإصدار",
    id: "رقم الشهادة",
    verify: "للتحقق",
    heading: "شهادة تقدير",
    footer: "نوادي مايكروسوفت الطلابية — جامعة الابتكار",
  },
};

export async function renderCertificatePdf(certificateId: string, locale: "en" | "ar"): Promise<Buffer> {
  const cert = await db.certificate.findUniqueOrThrow({ where: { id: certificateId }, include: { template: true } });
  const copy = COPY[locale];
  const tpl = cert.template;
  const accent = tpl && /^#[0-9a-fA-F]{6}$/.test(tpl.accent) ? tpl.accent : ROYAL;
  const heading = (locale === "ar" ? tpl?.headingAr : tpl?.heading) ?? copy.heading;
  const body = (locale === "ar" ? tpl?.bodyAr : tpl?.body) ?? copy.certify;
  const footer = (locale === "ar" ? tpl?.footerAr : tpl?.footer) ?? copy.footer;
  const title = locale === "ar" && cert.titleAr ? cert.titleAr : cert.title;

  const url = verificationUrl(cert.code);
  const qr = await QRCode.toBuffer(url, { errorCorrectionLevel: "M", margin: 1, width: 240, color: { dark: NAVY, light: "#FFFFFF" } });

  const doc = new PDFDocument({ size: "A4", layout: "landscape", margin: 0, info: { Title: `${heading} — ${cert.code}`, Author: "Microsoft Student Clubs — Innovation University" } });
  doc.registerFont("Latin", load("inter-latin-400-normal.woff"));
  doc.registerFont("LatinBold", load("inter-latin-700-normal.woff"));
  doc.registerFont("Arabic", load("noto-sans-arabic-arabic-400-normal.woff"));
  doc.registerFont("ArabicBold", load("noto-sans-arabic-arabic-700-normal.woff"));

  const chunks: Buffer[] = [];
  doc.on("data", (c: Buffer) => chunks.push(c));
  const done = new Promise<Buffer>((resolve) => doc.on("end", () => resolve(Buffer.concat(chunks))));

  const W = doc.page.width;
  const H = doc.page.height;

  /**
   * Draws one centred line, choosing the font PER RUN. The Arabic font file is a script
   * subset (no space, no digits), so spaces / digits / Latin go to Inter. Runs are laid out
   * right-to-left when the line contains Arabic (a single-level bidi pass, which is all a
   * certificate line needs). Long lines shrink to fit instead of wrapping.
   */
  const line = (text: string, y: number, size: number, color: string, bold = false, maxWidth = W - 160) => {
    const rtl = ARABIC.test(text);
    const runs = text.match(/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+|[^\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+/g) ?? [];
    const fontFor = (run: string) => (ARABIC.test(run) ? (bold ? "ArabicBold" : "Arabic") : bold ? "LatinBold" : "Latin");
    const measure = (px: number) => runs.reduce((sum, r) => sum + doc.font(fontFor(r)).fontSize(px).widthOfString(r), 0);

    let px = size;
    while (px > 12 && measure(px) > maxWidth) px -= 1;
    const ordered = (rtl ? [...runs].reverse() : runs).map((r) => visual(r, rtl));
    let x = (W - measure(px)) / 2;
    doc.fillColor(color);
    for (const run of ordered) {
      doc.font(fontFor(run)).fontSize(px);
      doc.text(run, x, y, { lineBreak: false });
      x += doc.widthOfString(run);
    }
  };
  const font = (text: string, bold = false) => (ARABIC.test(text) ? (bold ? "ArabicBold" : "Arabic") : bold ? "LatinBold" : "Latin");

  // Frame
  doc.rect(0, 0, W, H).fill("#FFFFFF");
  doc.lineWidth(10).strokeColor(accent).rect(20, 20, W - 40, H - 40).stroke();
  doc.lineWidth(1.5).strokeColor(MID).rect(36, 36, W - 72, H - 72).stroke();

  // Logo mark (drawn from the brand SVG primitives)
  const s = 0.42; const ox = W / 2 - 64 * s; const oy = 58;
  doc.roundedRect(ox, oy, 128 * s, 128 * s, 12 * s).fill(accent);
  doc.roundedRect(ox + 18 * s, oy + 18 * s, 92 * s, 92 * s, 6 * s).fill("#FFFFFF");
  doc.roundedRect(ox + 18 * s, oy + 18 * s, 30 * s, 30 * s, 4 * s).fill(NAVY);
  doc.lineWidth(11 * s).lineCap("round").lineJoin("round").strokeColor(accent);
  doc.circle(ox + 66 * s, oy + 52 * s, 15 * s).stroke();
  doc.moveTo(ox + 66 * s, oy + 67 * s).lineTo(ox + 66 * s, oy + 83 * s).bezierCurveTo(ox + 66 * s, oy + 90 * s, ox + 60 * s, oy + 96 * s, ox + 53 * s, oy + 96 * s).lineTo(ox + 45 * s, oy + 96 * s).stroke();

  line(heading, 122, 30, NAVY, true);
  line(body, 168, 14, GREY);
  line(cert.recipientName, 196, 36, accent, true);
  line(copy.verbs[cert.type] ?? copy.verbs.DEFAULT, 264, 14, GREY);
  line(title, 296, 24, NAVY, true);

  const date = new Intl.DateTimeFormat(locale === "ar" ? "ar-EG-u-nu-latn" : "en-GB", { dateStyle: "long" }).format(cert.issueDate);
  line(locale === "ar" ? `${copy.issued} ${date}` : `${copy.issued}: ${date}`, 380, 12, GREY);

  /** Left-aligned label (labels are short; mixed-script safe). */
  const drawLeft = (text: string, x: number, y: number, size: number, color: string) => {
    const runs = text.match(/[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+|[^\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]+/g) ?? [];
    const rtl = ARABIC.test(text);
    let cx = x;
    doc.fillColor(color);
    for (const run of (rtl ? [...runs].reverse() : runs).map((r) => visual(r, rtl))) {
      doc.font(font(run)).fontSize(size).text(run, cx, y, { lineBreak: false });
      cx += doc.widthOfString(run);
    }
  };

  // Verification block
  doc.image(qr, 80, H - 150, { width: 84 });
  const lx = 176;
  drawLeft(copy.id, lx, H - 142, 10, GREY);
  doc.font("LatinBold").fontSize(13).fillColor(NAVY).text(cert.code, lx, H - 124, { width: 360, align: "left" });
  drawLeft(copy.verify, lx, H - 102, 10, GREY);
  doc.font("Latin").fontSize(10).fillColor(ROYAL).text(url, lx, H - 86, { width: 460, align: "left" });
  line(footer, H - 66, 10, GREY);

  doc.end();
  return done;
}
