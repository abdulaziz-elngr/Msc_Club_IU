import "server-only";

import type { NotificationType, Prisma } from "@/generated/client";
import { db } from "@/lib/db";
import { emailUrl, sendEmail } from "@/lib/email";

/**
 * Notification service.
 *
 * Every notification is persisted first (source of truth for the in-app bell),
 * and email is a best-effort second channel gated by the recipient's own
 * preferences. Failures are logged, never thrown — a mail outage must not
 * fail the business operation that triggered the notification.
 */

export type NotifyInput = {
  userId: string;
  type?: NotificationType;
  /** English title/body. */
  title: string;
  body?: string;
  /** Arabic variants — used when the recipient's locale is AR. */
  titleAr?: string;
  bodyAr?: string;
  /** In-app destination, e.g. `/events/my-event`. */
  href?: string;
  data?: Prisma.InputJsonValue;
  /**
   * When true the email is sent immediately using the recipient's locale.
   * Defaults to reading `user.notifyEmail`.
   */
  email?: boolean;
};

type NotifyResult = { id: string; emailed: boolean };

const EMAIL_TYPES: Set<NotificationType> = new Set<NotificationType>([
  "APPLICATION_STATUS",
  "EVENT_REGISTERED",
  "EVENT_REMINDER",
  "EVENT_CANCELLED",
  "EVENT_UPDATED",
  "BADGE_EARNED",
  "COURSE_COMPLETED",
  "SYSTEM",
  "ANNOUNCEMENT",
]);

export async function notify(input: NotifyInput): Promise<NotifyResult | null> {
  try {
    const user = await db.user.findUnique({
      where: { id: input.userId },
      select: {
        id: true,
        email: true,
        name: true,
        locale: true,
        notifyEmail: true,
        notifyInApp: true,
      },
    });
    if (!user) return null;

    const type = input.type ?? "SYSTEM";
    const wantsEmail = input.email ?? (user.notifyEmail && EMAIL_TYPES.has(type));

    const row = await db.notification.create({
      data: {
        userId: user.id,
        type,
        title: input.title,
        titleAr: input.titleAr ?? null,
        body: input.body ?? null,
        bodyAr: input.bodyAr ?? null,
        href: input.href ?? null,
        data: input.data === undefined ? undefined : input.data,
      },
      select: { id: true },
    });

    // In-app rows are always persisted: they are the user's history and the
    // source of truth for the bell. Email is the optional second channel.
    if (wantsEmail) {
      const locale = user.locale === "AR" ? "ar" : "en";
      const title = locale === "ar" ? (input.titleAr ?? input.title) : input.title;
      const body = locale === "ar" ? (input.bodyAr ?? input.body ?? "") : (input.body ?? "");

      const result = await sendEmail({
        to: user.email,
        subject: title,
        heading: title,
        body,
        locale,
        ...(input.href ? { action: { label: locale === "ar" ? "فتح" : "Open", href: emailUrl(input.href) } } : {}),
      });

      if (result.delivered) {
        await db.notification
          .update({ where: { id: row.id }, data: { emailedAt: new Date() } })
          .catch(() => undefined);
      }
    }

    return { id: row.id, emailed: wantsEmail };
  } catch (error) {
    console.error("[notifications] failed to persist notification", error);
    return null;
  }
}

/** Bulk variant used by system jobs (e.g. event reminders). */
export async function notifyMany(
  userIds: string[],
  input: Omit<NotifyInput, "userId">,
): Promise<number> {
  const unique = [...new Set(userIds)];
  let sent = 0;
  // Sequential on purpose: keeps rate limits predictable and errors isolated.
  for (const userId of unique) {
    const result = await notify({ ...input, userId });
    if (result) sent += 1;
  }
  return sent;
}

export type NotificationListItem = {
  id: string;
  type: NotificationType;
  title: string;
  body: string | null;
  href: string | null;
  readAt: Date | null;
  createdAt: Date;
};

export async function listNotifications(
  userId: string,
  options: { limit?: number; unreadOnly?: boolean } = {},
): Promise<NotificationListItem[]> {
  const rows = await db.notification.findMany({
    where: { userId, ...(options.unreadOnly ? { readAt: null } : {}) },
    orderBy: { createdAt: "desc" },
    take: Math.min(options.limit ?? 20, 100),
    select: {
      id: true,
      type: true,
      title: true,
      titleAr: true,
      body: true,
      bodyAr: true,
      href: true,
      readAt: true,
      createdAt: true,
    },
  });

  return rows.map((r) => ({
    id: r.id,
    type: r.type,
    title: r.title,
    body: r.body,
    href: r.href,
    readAt: r.readAt,
    createdAt: r.createdAt,
  }));
}

export async function unreadCount(userId: string): Promise<number> {
  return db.notification.count({ where: { userId, readAt: null } });
}

export async function markRead(userId: string, notificationId: string): Promise<boolean> {
  const result = await db.notification.updateMany({
    where: { id: notificationId, userId, readAt: null },
    data: { readAt: new Date() },
  });
  return result.count > 0;
}

export async function markAllRead(userId: string): Promise<number> {
  const result = await db.notification.updateMany({
    where: { userId, readAt: null },
    data: { readAt: new Date() },
  });
  return result.count;
}

export async function dismissNotification(userId: string, notificationId: string): Promise<void> {
  await db.notification.deleteMany({ where: { id: notificationId, userId } });
}
