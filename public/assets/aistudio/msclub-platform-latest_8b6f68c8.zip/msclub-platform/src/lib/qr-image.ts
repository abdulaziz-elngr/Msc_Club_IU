import "server-only";

import QRCode from "qrcode";
import { issuePassToken } from "@/lib/qr";

/** PNG data URL for a registration's pass. Encodes ONLY the signed opaque token. */
export async function passQrDataUrl(registrationId: string, qrVersion: number): Promise<string> {
  return QRCode.toDataURL(issuePassToken(registrationId, qrVersion), {
    errorCorrectionLevel: "M",
    margin: 2,
    width: 320,
    color: { dark: "#0B2545", light: "#FFFFFF" },
  });
}
