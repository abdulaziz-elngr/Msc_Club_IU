import "server-only";

import { getEnv } from "@/lib/env";

/**
 * Fixed-window rate limiter.
 *
 * Two tiers are kept in memory (per server instance) for cheap, synchronous
 * enforcement, and authentication failures are additionally persisted to
 * `login_attempts` so a restart cannot be used to reset an attacker's budget.
 */

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

function prune(now: number) {
  if (buckets.size < 10_000) return;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt <= now) buckets.delete(key);
  }
}

export type RateLimitResult = {
  ok: boolean;
  remaining: number;
  resetAt: number;
};

export function rateLimit(key: string, max?: number, windowMs?: number): RateLimitResult {
  const env = getEnv();
  const limit = max ?? env.RATE_LIMIT_MAX_MUTATION;
  const window = windowMs ?? env.RATE_LIMIT_WINDOW_MS;
  const now = Date.now();

  prune(now);

  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    const fresh: Bucket = { count: 1, resetAt: now + window };
    buckets.set(key, fresh);
    return { ok: true, remaining: limit - 1, resetAt: fresh.resetAt };
  }

  bucket.count += 1;
  return {
    ok: bucket.count <= limit,
    remaining: Math.max(0, limit - bucket.count),
    resetAt: bucket.resetAt,
  };
}

export function resetRateLimit(key: string) {
  buckets.delete(key);
}

/** Read a stable client identifier for rate-limit keys. */
export function clientKey(prefix: string, ...parts: (string | null | undefined)[]) {
  return [prefix, ...parts.map((p) => (p ?? "unknown").toLowerCase())].join(":");
}
