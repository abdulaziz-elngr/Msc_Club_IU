import "server-only";

import { db } from "@/lib/db";

/**
 * Badge engine.
 *
 * A badge's `criteria` is a small declarative object evaluated against
 * aggregate statistics — never against a running counter — so badges remain
 * correct after XP reversals, attendance corrections or course un-enrolment.
 *
 * Supported criteria:
 *   { type: "total_xp",         threshold: n }
 *   { type: "level",            threshold: n }   // level order, 1-based
 *   { type: "events_attended",  threshold: n }
 *   { type: "courses_completed",threshold: n }
 *   { type: "lessons_completed",threshold: n }
 *   { type: "tasks_approved",   threshold: n }
 *   { type: "certificates",     threshold: n }
 *   { type: "badges_count",     threshold: n }   // meta: how many others
 */

export type BadgeCriteria =
  | { type: "total_xp"; threshold: number }
  | { type: "level"; threshold: number }
  | { type: "events_attended"; threshold: number }
  | { type: "courses_completed"; threshold: number }
  | { type: "lessons_completed"; threshold: number }
  | { type: "tasks_approved"; threshold: number }
  | { type: "certificates"; threshold: number }
  | { type: "badges_count"; threshold: number };

export type BadgeStats = {
  totalXp: number;
  levelOrder: number;
  eventsAttended: number;
  coursesCompleted: number;
  lessonsCompleted: number;
  tasksApproved: number;
  certificates: number;
  badgesCount: number;
};

export function parseCriteria(raw: unknown): BadgeCriteria | null {
  if (typeof raw !== "object" || raw === null) return null;
  const value = raw as { type?: unknown; threshold?: unknown };
  if (typeof value.type !== "string") return null;
  const threshold = typeof value.threshold === "number" ? value.threshold : Number(value.threshold);
  if (!Number.isFinite(threshold)) return null;
  return { type: value.type as BadgeCriteria["type"], threshold } as BadgeCriteria;
}

export function meetsCriteria(criteria: BadgeCriteria, stats: BadgeStats): boolean {
  switch (criteria.type) {
    case "total_xp":
      return stats.totalXp >= criteria.threshold;
    case "level":
      return stats.levelOrder >= criteria.threshold;
    case "events_attended":
      return stats.eventsAttended >= criteria.threshold;
    case "courses_completed":
      return stats.coursesCompleted >= criteria.threshold;
    case "lessons_completed":
      return stats.lessonsCompleted >= criteria.threshold;
    case "tasks_approved":
      return stats.tasksApproved >= criteria.threshold;
    case "certificates":
      return stats.certificates >= criteria.threshold;
    case "badges_count":
      return stats.badgesCount >= criteria.threshold;
    default:
      return false;
  }
}

/** Loads every statistic a badge might reference, in as few queries as possible. */
export async function loadBadgeStats(userId: string): Promise<BadgeStats> {
  const [user, eventsAttended, coursesCompleted, lessonsCompleted, tasksApproved, certificates, badgesCount] =
    await Promise.all([
      db.user.findUnique({
        where: { id: userId },
        select: { totalXp: true, level: { select: { order: true } } },
      }),
      db.attendance.count({ where: { userId, status: { in: ["PRESENT", "LATE"] } } }),
      db.courseEnrollment.count({ where: { userId, completedAt: { not: null } } }),
      db.lessonProgress.count({ where: { userId, completedAt: { not: null } } }),
      db.assignmentSubmission.count({ where: { userId, status: "APPROVED" } }),
      db.certificate.count({ where: { userId, revokedAt: null } }),
      db.userBadge.count({ where: { userId } }),
    ]);

  return {
    totalXp: user?.totalXp ?? 0,
    levelOrder: user?.level?.order ?? 0,
    eventsAttended,
    coursesCompleted,
    lessonsCompleted,
    tasksApproved,
    certificates,
    badgesCount,
  };
}

/**
 * Awards every auto-award badge the user now qualifies for.
 * Returns the badges that were newly earned (both language names).
 * Idempotent: the `@@unique([userId, badgeId])` constraint makes re-awards
 * harmless, and we skip work entirely when nothing is eligible.
 */
export type EarnedBadge = { name: string; nameAr: string | null };

export async function awardEligibleBadges(userId: string): Promise<EarnedBadge[]> {
  const [badges, earnedIds] = await Promise.all([
    db.badge.findMany({
      where: { enabled: true, autoAward: true },
      orderBy: { order: "asc" },
      select: { id: true, name: true, nameAr: true, criteria: true },
    }),
    db.userBadge.findMany({ where: { userId }, select: { badgeId: true } }),
  ]);

  if (badges.length === 0) return [];

  const already = new Set(earnedIds.map((b) => b.badgeId));
  const pending = badges.filter((b) => !already.has(b.id));
  if (pending.length === 0) return [];

  // `badges_count` depends on how many badges are already held, so refresh the
  // stat once after the first pass and re-check only the meta badges.
  let stats = await loadBadgeStats(userId);
  const earned: EarnedBadge[] = [];

  for (const badge of pending) {
    const criteria = parseCriteria(badge.criteria);
    if (!criteria) continue;
    if (!meetsCriteria(criteria, stats)) continue;

    try {
      await db.userBadge.create({ data: { userId, badgeId: badge.id } });
      earned.push({ name: badge.name, nameAr: badge.nameAr });
      stats = { ...stats, badgesCount: stats.badgesCount + 1 };
    } catch (error) {
      // Unique violation = awarded concurrently. Not an error.
      if ((error as { code?: string } | null)?.code !== "P2002") throw error;
    }
  }

  return earned;
}

/** Manual award used by the admin console (still idempotent). */
export async function awardBadgeManually(userId: string, badgeId: string, actorId: string): Promise<boolean> {
  try {
    await db.userBadge.create({
      data: { userId, badgeId, awardedById: actorId },
    });
    return true;
  } catch (error) {
    if ((error as { code?: string } | null)?.code === "P2002") return false;
    throw error;
  }
}

export async function revokeBadge(userId: string, badgeId: string): Promise<boolean> {
  const result = await db.userBadge.deleteMany({ where: { userId, badgeId } });
  return result.count > 0;
}
