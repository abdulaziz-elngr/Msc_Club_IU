import { z } from "zod";

/**
 * Shared shape returned by every server action invoked through `useActionState`.
 * `errors` is keyed by field name so client components can render inline
 * messages without any client-side validation logic.
 */
export type FormState = {
  ok?: boolean;
  message?: string;
  errors?: Record<string, string[]>;
  values?: Record<string, string>;
} | undefined;

export function fieldErrors(error: z.ZodError): Record<string, string[]> {
  const map: Record<string, string[]> = {};
  for (const issue of error.issues) {
    const key = issue.path.length > 0 ? issue.path.join(".") : "_";
    (map[key] ??= []).push(issue.message);
  }
  return map;
}

export function errorState(message: string, errors?: Record<string, string[]>): FormState {
  return { ok: false, message, ...(errors ? { errors } : {}) };
}

export function successState(message?: string): FormState {
  return { ok: true, message };
}

/** Every submitted value, so the form can repopulate itself after a failure. */
export function formValues(formData: FormData): Record<string, string> {
  const values: Record<string, string> = {};
  for (const [key, value] of formData.entries()) {
    if (typeof value === "string") values[key] = value;
  }
  return values;
}

/**
 * Validates a `FormData` against a Zod schema.
 * Returns either the typed payload or a `FormState` ready to return from the action.
 */
export function parseForm<S extends z.ZodType>(
  schema: S,
  formData: FormData,
):
  | { success: true; data: z.output<S> }
  | { success: false; state: FormState } {
  const candidate: Record<string, unknown> = {};
  for (const [key, value] of formData.entries()) {
    if (value instanceof File) {
      candidate[key] = value.size === 0 ? undefined : value;
    } else if (key in candidate) {
      const existing = candidate[key];
      candidate[key] = Array.isArray(existing) ? [...existing, value] : [existing, value];
    } else {
      candidate[key] = value;
    }
  }

  const parsed = schema.safeParse(candidate);
  if (!parsed.success) {
    return {
      success: false,
      state: {
        ok: false,
        message: "Please correct the highlighted fields.",
        errors: fieldErrors(parsed.error),
        values: formValues(formData),
      },
    };
  }
  return { success: true, data: parsed.data };
}

/** Convenience for optional checkboxes posted as hidden + checkbox pairs. */
export const checkbox = z
  .union([z.literal("on"), z.literal("true"), z.literal("1"), z.undefined()])
  .transform((v) => v === "on" || v === "true" || v === "1");
