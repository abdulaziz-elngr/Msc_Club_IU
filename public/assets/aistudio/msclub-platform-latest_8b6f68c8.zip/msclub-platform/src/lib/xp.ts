import "server-only";

import type { Prisma, XPReferenceType } from "@/generated/client";
import { db } from "@/lib/db";
import { idempotencyKey as makeIdempotencyKey } from "@/lib/tokens";
import { awardEligibleBadges } from "@/lib/badges";
import { notify } from "@/lib/notifications";

/**
 * Gamification core.
 *
 * Design rules (enforced here, not by callers):
 *  • The ledger is append-only. `User.totalXp` is a denormalised SUM that is
 *    recomputed inside the same transaction as the ledger write, while the user
 *    row is locked (`FOR UPDATE`) so concurrent awards serialise and can never
 *    persist a stale total.
 *  • Every write carries a unique `idempotencyKey`, so a double-click, a
 *    retried request or a replayed webhook can never double-award. The check is
 *    repeated inside the transaction and backed by the unique index.
 *  • Reversals are NEW negative rows linked through `reversesId`; history is
 *    never mutated or deleted.
 *  • Points come from the admin-configurable `PointsRule` catalogue. Only the
 *    two system activities below (manual adjustment / reversal) are rule-free,
 *    because their amount is supplied by an authorised administrator.
 */

export const SYSTEM_ACTIVITIES = {
  ADJUSTMENT: "admin.adjustment",
  REVERSAL: "admin.reversal",
} as const;

const RULE_FREE = new Set<string>(Object.values(SYSTEM_ACTIVITIES));

export type AwardInput = {
  userId: string;
  /** `PointsRule.key` — the catalogue entry that defines the activity. */
  activityKey: string;
  referenceType: XPReferenceType;
  referenceId?: string | null;
  description: string;
  descriptionAr?: string | null;
  /** Overrides the catalogue amount (manual adjustments only). */
  amount?: number;
  awardedById?: string | null;
  /** Stable key; omit to derive one from the activity + reference. */
  idempotencyKey?: string;
  metadata?: Prisma.InputJsonValue;
};

export type AwardResult = {
  awarded: boolean;
  /** True when the call was a replay of an already-recorded award. */
  duplicate: boolean;
  amount: number;
  transactionId: string | null;
  totalXp: number;
  levelKey: string | null;
  levelName: string | null;
  /** True when this award moved the user into a higher level. */
  leveledUp: boolean;
  newBadges: string[];
};

const NOTHING: AwardResult = {
  awarded: false,
  duplicate: false,
  amount: 0,
  transactionId: null,
  totalXp: 0,
  levelKey: null,
  levelName: null,
  leveledUp: false,
  newBadges: [],
};

function isUniqueViolation(error: unknown): boolean {
  return (error as { code?: string } | null)?.code === "P2002";
}

type LevelRow = { id: string; key: string; name: string; nameAr: string | null; minXp: number; order: number };

/** Pure: the highest enabled threshold ≤ xp. `levels` must be sorted by `minXp` ascending. */
export function pickLevel<T extends { minXp: number }>(levels: T[], totalXp: number): T | null {
  let match: T | null = null;
  for (const level of levels) if (totalXp >= level.minXp) match = level;
  return match;
}

export async function resolveLevel(totalXp: number) {
  const levels = await db.level.findMany({
    where: { enabled: true },
    orderBy: { minXp: "asc" },
    select: { id: true, key: true, name: true, nameAr: true, minXp: true, order: true },
  });
  return { level: pickLevel(levels, totalXp), catalogue: levels };
}

/** Next level above `totalXp`, or `null` when already at the top. */
export async function nextLevel(totalXp: number) {
  return db.level.findFirst({
    where: { enabled: true, minXp: { gt: totalXp } },
    orderBy: { minXp: "asc" },
    select: { key: true, name: true, nameAr: true, minXp: true },
  });
}

/** Serialises concurrent ledger writes for one user. Must run inside a transaction. */
async function lockUser(tx: Prisma.TransactionClient, userId: string) {
  await tx.$queryRaw`SELECT "id" FROM "users" WHERE "id" = ${userId} FOR UPDATE`;
}

/** Re-derives totalXp + level from the ledger and persists both. Returns the transition. */
async function syncUserTotals(tx: Prisma.TransactionClient, userId: string) {
  const [before, agg, levels] = await Promise.all([
    tx.user.findUnique({ where: { id: userId }, select: { levelId: true, level: { select: { order: true, minXp: true } } } }),
    tx.xPTransaction.aggregate({ where: { userId }, _sum: { amount: true } }),
    tx.level.findMany({
      where: { enabled: true },
      orderBy: { minXp: "asc" },
      select: { id: true, key: true, name: true, nameAr: true, minXp: true, order: true },
    }),
  ]);
  const totalXp = agg._sum.amount ?? 0;
  const level: LevelRow | null = pickLevel(levels, totalXp);
  await tx.user.update({ where: { id: userId }, data: { totalXp, levelId: level?.id ?? null } });
  const leveledUp = Boolean(level && level.minXp > (before?.level?.minXp ?? -1) && level.id !== before?.levelId);
  return { totalXp, level, leveledUp };
}

async function replayResult(key: string, fallbackUserId: string): Promise<AwardResult> {
  const row = await db.xPTransaction.findUnique({
    where: { idempotencyKey: key },
    select: { id: true, amount: true, userId: true },
  });
  const user = await db.user.findUnique({
    where: { id: row?.userId ?? fallbackUserId },
    select: { totalXp: true, level: { select: { key: true, name: true } } },
  });
  return {
    ...NOTHING,
    duplicate: true,
    amount: row?.amount ?? 0,
    transactionId: row?.id ?? null,
    totalXp: user?.totalXp ?? 0,
    levelKey: user?.level?.key ?? null,
    levelName: user?.level?.name ?? null,
  };
}

async function afterCommit(userId: string, leveledUp: boolean, level: LevelRow | null): Promise<string[]> {
  if (leveledUp && level) {
    await notify({
      userId,
      type: "LEVEL_UNLOCKED",
      title: `Level up: ${level.name}`,
      titleAr: `ارتقيت إلى مستوى جديد: ${level.nameAr ?? level.name}`,
      body: `You reached ${level.name}. Keep going!`,
      bodyAr: `وصلت إلى ${level.nameAr ?? level.name}. واصل التقدم!`,
      href: "/dashboard/achievements",
      data: { levelKey: level.key },
      email: false,
    });
  }
  const newBadges = await awardEligibleBadges(userId);
  for (const badge of newBadges) {
    await notify({
      userId,
      type: "BADGE_EARNED",
      title: `Badge earned: ${badge.name}`,
      titleAr: `حصلت على شارة: ${badge.nameAr ?? badge.name}`,
      href: "/dashboard/achievements",
      email: false,
    });
  }
  return newBadges.map((b) => b.name);
}

/** Awards XP for an activity. Safe to call multiple times with the same key. */
export async function awardXp(input: AwardInput): Promise<AwardResult> {
  const key =
    input.idempotencyKey ??
    makeIdempotencyKey("xp", input.userId, input.activityKey, input.referenceType, input.referenceId ?? "");

  // Fast path: a replayed award must not open a transaction.
  const existing = await db.xPTransaction.findUnique({ where: { idempotencyKey: key }, select: { id: true } });
  if (existing) return replayResult(key, input.userId);

  const ruleFree = RULE_FREE.has(input.activityKey);
  const rule = ruleFree
    ? null
    : await db.pointsRule.findUnique({
        where: { key: input.activityKey },
        select: { key: true, points: true, maxAwardsPerUser: true, enabled: true, labelAr: true },
      });

  // Unknown/disabled activity: record nothing rather than guessing a value.
  if (!ruleFree && (!rule || !rule.enabled)) return NOTHING;
  if (ruleFree && input.amount === undefined) return NOTHING;

  const amount = input.amount ?? rule?.points ?? 0;
  if (!Number.isInteger(amount) || amount === 0) return NOTHING;

  try {
    const outcome = await db.$transaction(async (tx) => {
      await lockUser(tx, input.userId);

      // Re-check under the lock: a concurrent request may have just won.
      if (await tx.xPTransaction.findUnique({ where: { idempotencyKey: key }, select: { id: true } })) {
        return { kind: "duplicate" as const };
      }

      if (rule?.maxAwardsPerUser != null) {
        const already = await tx.xPTransaction.count({
          where: { userId: input.userId, activityKey: input.activityKey, amount: { gt: 0 } },
        });
        if (already >= rule.maxAwardsPerUser) return { kind: "capped" as const };
      }

      const row = await tx.xPTransaction.create({
        data: {
          userId: input.userId,
          amount,
          activityKey: input.activityKey,
          referenceType: input.referenceType,
          referenceId: input.referenceId ?? null,
          description: input.description,
          descriptionAr: input.descriptionAr ?? rule?.labelAr ?? null,
          awardedById: input.awardedById ?? null,
          idempotencyKey: key,
          metadata: input.metadata,
        },
        select: { id: true },
      });
      const totals = await syncUserTotals(tx, input.userId);
      return { kind: "awarded" as const, row, ...totals };
    });

    if (outcome.kind === "duplicate") return replayResult(key, input.userId);
    if (outcome.kind === "capped") return NOTHING;

    const newBadges = await afterCommit(input.userId, outcome.leveledUp, outcome.level);
    return {
      awarded: true,
      duplicate: false,
      amount,
      transactionId: outcome.row.id,
      totalXp: outcome.totalXp,
      levelKey: outcome.level?.key ?? null,
      levelName: outcome.level?.name ?? null,
      leveledUp: outcome.leveledUp,
      newBadges,
    };
  } catch (error) {
    if (isUniqueViolation(error)) return replayResult(key, input.userId);
    throw error;
  }
}

export type ReverseInput = {
  transactionId: string;
  reason: string;
  actorId: string;
};

/**
 * Reverses a previous award by appending a compensating negative row linked via
 * `reversesId`. The original row is never touched, and a row can be reversed once.
 */
export async function reverseXp(input: ReverseInput): Promise<AwardResult> {
  if (!input.reason.trim()) return NOTHING;

  const original = await db.xPTransaction.findUnique({
    where: { id: input.transactionId },
    select: { id: true, userId: true, amount: true, description: true, idempotencyKey: true },
  });
  if (!original || original.amount <= 0) return NOTHING;

  const reversalKey = makeIdempotencyKey("xp-reversal", original.id);
  if (await db.xPTransaction.findUnique({ where: { idempotencyKey: reversalKey }, select: { id: true } })) {
    return replayResult(reversalKey, original.userId);
  }

  try {
    const outcome = await db.$transaction(async (tx) => {
      await lockUser(tx, original.userId);
      const row = await tx.xPTransaction.create({
        data: {
          userId: original.userId,
          amount: -original.amount,
          activityKey: SYSTEM_ACTIVITIES.REVERSAL,
          referenceType: "ADMIN_ADJUSTMENT",
          referenceId: original.id,
          description: `Reversal: ${original.description}`,
          descriptionAr: `استرداد: ${original.description}`,
          awardedById: input.actorId,
          reversesId: original.id,
          idempotencyKey: reversalKey,
          metadata: { reason: input.reason, reverses: original.idempotencyKey },
        },
        select: { id: true },
      });
      const totals = await syncUserTotals(tx, original.userId);
      return { row, ...totals };
    });

    return {
      ...NOTHING,
      awarded: true,
      amount: -original.amount,
      transactionId: outcome.row.id,
      totalXp: outcome.totalXp,
      levelKey: outcome.level?.key ?? null,
      levelName: outcome.level?.name ?? null,
    };
  } catch (error) {
    // Lost a race with an identical reversal (unique key / unique reversesId).
    if (isUniqueViolation(error)) return replayResult(reversalKey, original.userId);
    throw error;
  }
}

/**
 * Admin adjustment: positive or negative, always with a mandatory reason and its
 * own idempotency key so a retried form cannot apply twice. Callers MUST have
 * checked `points.adjust` (and `points.award` for positive amounts) first.
 */
export async function adjustXp(input: {
  userId: string;
  amount: number;
  reason: string;
  actorId: string;
  key: string;
}): Promise<AwardResult> {
  if (!input.reason.trim()) return NOTHING;
  if (!Number.isInteger(input.amount) || input.amount === 0) return NOTHING;

  return awardXp({
    userId: input.userId,
    activityKey: SYSTEM_ACTIVITIES.ADJUSTMENT,
    referenceType: "ADMIN_ADJUSTMENT",
    description: input.reason,
    descriptionAr: input.reason,
    amount: input.amount,
    awardedById: input.actorId,
    idempotencyKey: makeIdempotencyKey("xp-adjust", input.userId, input.key),
    metadata: { reason: input.reason, actorId: input.actorId },
  });
}

/** Reconciles `totalXp` / `levelId` from the ledger (repair tool). */
export async function reconcileUserXp(userId: string): Promise<number> {
  return db.$transaction(async (tx) => {
    await lockUser(tx, userId);
    const { totalXp } = await syncUserTotals(tx, userId);
    return totalXp;
  });
}
